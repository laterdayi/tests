## 操作步骤

<br>

- 登录至部署服务器

- 查看 `Nginx` 安装目录: `whereis nginx`

- 切换至 `Nginx` 目录: `cd nginx-path/html/product-name/dist/config`

- 查看权限 `ls -lp config.json`, 如已设置权限可忽略此步骤

- 修改权限 `chmod 777 config.json`, 如已设置权限可忽略此步骤

## 修改事项

<br>

> ### 图片

- `文件覆盖` 即可

- `注意事项`:

  - 需保持 `文件名` 一样

  - 后缀为 `png`

> ### 名称, 标题...

<br>

`使用修改后文件覆盖`

或

```
vim config.json

i

修改文件内容

ESC

:wq
```

- `注意事项`:

  - `中英文` 同步替换，修改对应 `value` 即可

  - projectName: 产品名称

  - websiteTitleSuffix: 网站标题后缀

  - copyrightName: 版权名称
