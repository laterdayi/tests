module.exports = require('@standard-semi/config/lib/commitlint');
