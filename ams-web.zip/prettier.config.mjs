import config from '@standard-semi/config/lib/prettier.mjs';

export default config;
