import type { AxiosRequestConfig, AxiosResponse } from 'axios';

type UseDownloadFileParmasType = AxiosRequestConfig & {
  suffix?: string;
};

export type ExportParamsType = {
  page: number | (() => number);
  size: number | (() => number);
  toexcel?: number;
};

// 下载文件
export const useDownloadFile = (
  url: string,
  { suffix = 'xlsx', responseType = 'blob', rawResponse = true }: UseDownloadFileParmasType = {}
) => {
  const {
    data,
    error,
    execute: handle,
    isLoading,
    response
  } = useAxiosGet<ResponseDataType<string>, AxiosResponse<ResponseDataType<string>>>(url, __, {
    rawResponse,
    responseType
  });
  function execute(queryParams: ExportParamsType | object, config?: AxiosRequestConfig): Promise<void>;
  function execute(): Promise<void>;
  async function execute(queryParams?: ExportParamsType | object, config?: AxiosRequestConfig): Promise<void> {
    try {
      const appStore = useAppStore();
      const params = queryParams ? { ...queryParams, toexcel: 1 } : __;
      await handle({ params: { ...params, language: appStore.local === LOCAL_DEFAULT ? 0 : 1 }, ...config });
      // 资源链接
      if (data.value?.data?.includes(suffix)) {
        window.open(`${import.meta.env.VITE_BASE_API}/${data.value}`);
      } else if (data.value instanceof Blob) {
        // Blob数据
        const url = window.URL.createObjectURL(data.value);
        const fileName = decodeURIComponent(
          /filename\*=UTF-8''([^;]+)/.exec(response.value?.headers?.['content-disposition'])?.[1] ?? `未知.${suffix}`
        );
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.log('下载文件异常：', error);
    }
  }
  return {
    execute,
    isLoading,
    error
  };
};
