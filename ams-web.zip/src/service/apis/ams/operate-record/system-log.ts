import { API_PREFIX_AMS } from '../../common/common';

export const SystemLogApis = {
  // 列表获取
  getListApi: API_PREFIX_AMS + '/AlarmLogs/GetList',
  // 日志级别
  alarmLevelListApi: API_PREFIX_AMS + '/AlarmLogs/AlarmLevelList'
};

export type QueryType = {
  name: string
  eqpId: string
  alarmId: string
  logLevel: string
  systemName: string
  timestamp: string[]
  language: number
};
export interface TableListType {
  eqpId: string
  alarmId: string
  logLevel: string
  systemName: string
  logDesc: string
  message: string
  ip: string
  remark: string
  logTime: string

}
