import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const OperateRecordApis = {
  // 列表获取
  getListApi: API_PREFIX_SYSTEM_MONITOR + '/TableChangeHistory/GetPageList',
};

export type QueryType = {
  old: string
  tableName: string
  operateType: string
  timestamp: string[]
  language: number
};
export interface TableListType {
  id: string
  keyId: string
  old: string
  creator: string
  createTime: string

}
