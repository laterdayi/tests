import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../common/common';

export const AlarmSystemSettingApis = {
  // 获取执行动作(已开启)
  getActionListApi: API_PREFIX_AMS + '/AlarmAction/GetAllOpenActions',
  // 获取执行动作(获取所有)
  getAllActionsApi: API_PREFIX_AMS + '/AlarmAction/GetAllActions',
  // 获取动作信息
  getActionInfoApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmActionGet',
  // 保存动作
  saveSettingApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmActionSetting',
  // 获取报警动作列表
  getInfoApi: API_PREFIX_AMS + '/AlarmAction/Get',
  // 获取右键模板设置
  getAlarmMailTemplateApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmMailTemplateGet',
  // 保存右键模板设置
  saveAlarmMailTemplateApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmMailTemplateSetting',
  // 获取报警看板设置
  getAlarmDashboardSettingApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmBoardGet',
  // 设置报警看板设置
  setAlarmDashboardSettingApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmBoardSetting',
  // 逐级上报设置查询
  // upReportGetApi: API_PREFIX_CONFIG + '/SystemSetting/UpReportGet',
  // 逐级上报设置
  // upReportSettingApi: API_PREFIX_CONFIG + '/SystemSetting/UpReportSetting',
  // 保存通用设置
  addGeneralSettingApi: API_PREFIX_CONFIG + '/SystemSetting/AddGeneralSetting',
  // 获取通用设置
  getGeneralSettingApi: API_PREFIX_CONFIG + '/SystemSetting/GetGeneralSetting',
  // 获取 SMS 设置
  getSMSSettingApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmSMSTemplateGet',
  // 保存 SMS 设置
  saveSMSSettingApi: API_PREFIX_CONFIG + '/SystemSetting/AlarmSMSTemplateSetting',
  // 获取企业微信模板设置
  getWorkWechatTemplateApi: API_PREFIX_CONFIG + '/SystemSetting/GetWorkWechatTemplate',
  // 保存企业微信模板设置
  workWechatTemplateSettingApi: API_PREFIX_CONFIG + '/SystemSetting/WorkWechatTemplateSetting',
  // 获取飞书模板设置
  getFeiShuTemplateApi: API_PREFIX_CONFIG + '/SystemSetting/GetFeiShuTemplate',
  // 保存飞书模板设置
  feiShuTemplateSettingApi: API_PREFIX_CONFIG + '/SystemSetting/FeiShuTemplateSetting',
  // 根据系统名称获取
  getWorkWechatGroupSettingApi: API_PREFIX_CONFIG + '/SystemSetting/GetWorkWechatGroupSetting',
  // 获取报修设置
  getCallCommonSettingApi: API_PREFIX_CONFIG + '/systemsetting/GetCallCommonSetting',
  // 保存报修设置
  setCallCommonSettingApi: API_PREFIX_CONFIG + '/systemsetting/SetCallCommonSetting',
  // 获取钉钉模版设置
  getDingTalkTemplateApi: API_PREFIX_CONFIG + '/systemsetting/GetDingTalkTemplate',
  // 保存钉钉模版设置
  dingTalkTemplateSettingApi: API_PREFIX_CONFIG + '/systemsetting/DingTalkTemplateSetting'
};

export type AlarmActionListType = {
  id: number;
  name: string;
};
export interface AlarmDashboardSettingType {
  interval: number;
  alarmNums: number;
}
export interface GeneralSettingsType {
  name?: string;
  type?: string;
  upReport?: Nullable<UpReportSettingType>;
  lockType?: Nullable<LockTypeSettingType>;
  groupUser?: Nullable<GroupUserSettingType>;
  workWXGroup?: Nullable<WorkWXGroupNotifySettingType>;
}
export interface GetGeneralSettingsType {
  name: string;
  type: string;
  upReport?: UpReportSettingType;
  lockType?: LockTypeSettingType;
  groupUser?: GroupUserSettingType;
  workWXGroup?: WorkWXGroupNotifySettingType;
}
export interface UpReportSettingType {
  upReportLimit: number;
  notifyType: number;
  notifyByAllLevel: number;
}
export interface LockTypeSettingType {
  lockType: number;
}
export interface GeneralSettingsTypeListType {
  key: string;
  type: string;
}
export interface GroupUserSettingType {
  isSyncGroupUser: number;
}
export interface WorkWXGroupNotifySettingType {
  webhookKey: string;
  systemName: string;
}

// 沛顿类型
export interface PtFormType {
  // callTotalUseTime: number
  mailSendTime: string;
  morningShiftTime: string;
  productTopRefreshTime: number;
  refreshTime: number;
  rollTime: number;
}
