import { API_PREFIX_CONFIG, API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const SystemLogApis = {
  // 页面表格列表
  getLoginLogListApi: API_PREFIX_CONFIG + '/Login/GetLoginHistory',
  // 系统日志
  getSystemLogApi: API_PREFIX_SYSTEM_MONITOR + '/Log/GetList',
  // 邮件发送记录
  getEmailSendLogListApi: API_PREFIX_SYSTEM_MONITOR + '/SendMailHistory/GetList',
  // 模块/日志级别
  getEnumListApi: API_PREFIX_CONFIG + '/common/GetEnumList'
};
export type ListType = {
  id: string;
  name: string;
  disabled?: boolean;
};
export type ActionType = 'loginLog' | 'emailSendingRecord' | 'systemLog';
// 系统日志
export type SystemLogQueryType = {
  level: string;
  timestamp: string[];
  message: string;
  module: string;
};
export type SystemLogListType = {
  id: string;
  level: string;
  logTime: string;
  message: string;
  module: string;
};
// 登录日志
export type LoginQueryType = {
  filter?: string;
};
export type LoginType = 1 | 2 | 3;
export type LoginListType = {
  id: string;
  logOutTime: string;
  loginIp: string;
  loginTime: string;
  loginType: LoginType;
  projectCode: string;
  remark: string;
  token: string;
  userId: string;
};
// 邮件发送记录
export type EmailQueryType = {
  filter?: string;
  timestamp: string[];
};
export type EmailListType = {
  id: string;
  businessType: string;
  businessTypeId: number;
  message: string;
  sendMailTime: string;
  smtpReceiverAddress: string;
  smtpSenderAddress: string;
  subject: string;
};
