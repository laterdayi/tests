import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const DashboardConfigurationApis = {
  // 获取列表
  getPageListApi: API_PREFIX_AMS + '/CallDashboard/GetPageList',
  // 新增
  addApi: API_PREFIX_AMS + '/CallDashboard/Add',
  // 编辑
  updateApi: API_PREFIX_AMS + '/CallDashboard/Update',
  // 删除
  deleteApi: API_PREFIX_AMS + '/CallDashboard/Delete',
  // 获取详情
  getDetailApi: API_PREFIX_AMS + '/CallDashboard/Get',
  // 获取设备列表
  getEquipmentListApi: API_PREFIX_CONFIG + '/LayoutStructure/GetTree?check=0&addEqp=1'
};
export type QueryType = {
  name: string
  area: string
  category: string
  eqpId: string
  language: number
};
export type EditType = {
  name: string
  areaName: string
  eqpIds: string[]
  description: string
  category: string
  backgroundColor: string
  flowTypes: string[]
};
export type TableListType = {
  id: string
  name: string
  createTime: string
  creator: string
  description: string
  editor: string
  isDeleted: number
  backgroundColor: string
  category: number
  flowTypes: string[]
  eqpNames: string[]
};
export interface EquipmentType {
  createTime: string
  creator: string
  description: string
  id: string
  isLeaf: string
  levelName: string
  name: string
  parentId: string
  parentName: string
  source: string
  children: EquipmentType[]
}
