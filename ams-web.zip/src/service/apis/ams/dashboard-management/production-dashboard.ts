import { API_PREFIX_AMS } from '../../common/common';

export const ProductionDashboardApis = {
  // 获取生产看板数据
  getProduceDashboardApi: API_PREFIX_AMS + '/CallDashboard/GetProduceDashboard',
  // 获取生产看板顶部数据
  getEqpStatusListApi: API_PREFIX_AMS + '/CallDashboard/GetEqpStatusList',
  // 获取生产看板顶部列表数据
  getEqpStatusDashboardApi: API_PREFIX_AMS + '/CallDashboard/GetEqpStatusDashboard',
  // 催单
  remindApi: API_PREFIX_AMS + '/CallDashboard/Remind'
};

export enum CallState {
  //  待接单
  toTakeOver = 1,
  // 维修中
  underRepair = 2,
  // 审核中
  underInspection = 3,
  // 结单
  finalizeTheOrder = 9
}

export type CallEqpInfosType = {
  [key: string]: string | number;
  downTime: string;
  eqpId: string;
  statues: string;
};
export type CallsType = {
  [key: string]: string | number;
  id: string;
  flowNo: string;
  eqpId: string;
  flowType: string;
  state: number;
  currentNoticeUserGroupName: string;
  currentHandler: string;
  systemTime: string;
  totalTime: string;
  speakCount: number;
  downtime: string;

  createTime: string;
  creator: string;
};
export type EqpStatusListDataType = {
  id: string;
  name: string;
  num: number;
  activeIsShow: boolean;
};
export type FaultStatisticsType = {
  value: number;
  name: string;
  num: number;
};
export type ProduceDashboardType = {
  areaName: string;
  backgroundColor: string;
  name: string;
  eqpStatistics: EqpStatisticsType[];
  faultStatistics: EqpStatisticsType[];
  calls: CallsType[];
};
export type EqpStatisticsType = {
  downtime: number;
  name: string;
  num: number;
};
export type StatusDashboardType = {
  callEqpStatusDtos: CallEqpStatusDtosType[];
  eqpStatusNumStatistics: EqpStatusNumStatisticsType[];
};
export type CallEqpStatusDtosType = {
  eqpType: string;
  callEqpInfos: CallEqpInfosType[];
};
export type EqpStatusNumStatisticsType = {
  status: string;
  num: number;
};
