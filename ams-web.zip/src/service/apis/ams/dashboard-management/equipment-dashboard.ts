import { API_PREFIX_AMS } from '../../common/common';

export const EquipmentDashboardApis = {
  // 获取设备看板数据
  getEqpDashboardApi: API_PREFIX_AMS + '/CallDashboard/GetEqpDashboard',

};

export type CallsType = {
  [key: string]: string | number
  id: string
  flowNo: string
  eqpId: string
  flowType: string
  state: number
  currentNoticeUserGroupName: string
  currentHandler: string
  systemTime: string
  totalTime: string
  speakCount: number
  downtime: string

  createTime: string
  creator: string
};
export type DashboardType = {
  areaName: string
  backgroundColor: string
  calls: CallsType[]
  name: string
  eqpCount: number
  inAuditCount: number
  inRepairCount: number
  normalCount: number
  toTakeOverCount: number
};

export type EchartListType = {
  name: string
  color: string
  value: number
};

export enum CallState {
  //  待接单
  toTakeOver = 1,
  // 维修中
  underRepair = 2,
  // 审核中
  underInspection = 3,
  // 结单
  finalizeTheOrder = 9
}
