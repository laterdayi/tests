import { API_PREFIX_AMS } from '../../common/common';

export const AlarmRealtimeDashboardApis = {
  // 获取数据列表
  getAlarmRealtimeListApi: API_PREFIX_AMS + '/AlarmBoard/GetLatestAlarmList'
};
export type AlarmDataType = {
  alarmNums: number;
  interval: number;
  name: string;
  backgroundColor: string;
  areaName: string;
  data: TableListType[];
}

export type TableListType = {
  [key: string]: string | number[] ;
  actions: number[];
  alarmDesc: string;
  alarmEndTime: string;
  alarmID: string;
  alarmStartTime: string;
  duration: string;
  eqpID: string;
  id: string;
}
export type AlarmDataObjType = {
  name: string;
  backgroundColor: string;
  areaName: string;
}
