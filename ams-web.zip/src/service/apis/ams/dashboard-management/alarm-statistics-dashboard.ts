import { API_PREFIX_AMS } from '../../common/common';

export const AlarmDashboardApis = {
  // 即时报警统计查询
  getAlarmStatisticsApi: API_PREFIX_AMS + '/AlarmBoard/ImmediateAlarmStatistics',
  // 历史报警信息统计
  getAlarmHistoricalApi: API_PREFIX_AMS + '/AlarmBoard/HistoricalAlarmStatistics'
};

export interface AlarmDashboardProps {
  // 当前设备报警
  alarmHistoryInfos: AlarmHistoryProps[];
  // 系统执行动作
  alarmActionInfos: AlarmActionInfosProps[];
  // 实时刷新间隔
  interval: number;
  name: string;
  backgroundColor: string;
  areaName: string;
}
export interface AlarmHistoryProps {
  [key: string]: string | number;
  alarmDesc: string;
  alarmEndTime: string;
  alarmId: string;
  alarmStartTime: string;
  eqpId: string;
  isClose: number;
}
export interface AlarmActionInfosProps {
  [key: string]: string | number;
  alarmAction: number;
  alarmId: string;
  eqpId: string;
  result: number;
  systemTime: string;
  alarmActionCategory: number
}

export interface EchartDataProps {
  alarmActionLists: {
    date: string;
    monthDay: string;
    alarmActions: {
      alarmActionId: string;
      count: number;
    }[];
  }[];
  alarmCodes: AlarmCodesType[];
  alarmEqps: AlarmEqpsType[];
  dailyAlarms: DailyAlarmsType[];
}
export type AlarmCodesType = {
  alarmDesc: string;
  alarmType: string;
  count: number;
};
export type AlarmEqpsType = {
  alarmDesc: string;
  alarmType: string;
  count: number;
};
export type DailyAlarmsType = {
  date: string;
  monthDay: string;
  totalAlarmCount: number;
};
