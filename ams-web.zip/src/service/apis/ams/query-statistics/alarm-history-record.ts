import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const AlarmHistoryRecordApis = {
  // 获取数据列表 | 导出数据
  getAlarmHistoryListApi: API_PREFIX_AMS + '/AlarmHistory/GetList',
  // 获取单个详情
  getAlarmHistoryDetailApi: API_PREFIX_AMS + '/AlarmHistory/Get',
  // 新增
  addAlarmHistoryApi: API_PREFIX_AMS + '/AlarmHistory/AddAlarmHistory',
  // 删除主表格行
  alarmHistoryDeleteApi: API_PREFIX_AMS + '/AlarmHistory/Delete',
  // 查询报警描述
  getAlarmDescApi: API_PREFIX_AMS + '/AlarmInfo/GetAlarmDesc',
  // 查询操作人
  getAllUserIdsApi: API_PREFIX_CONFIG + '/User/GetAllUserIds',
  // 导出
  exportAlarmHistoryApi: API_PREFIX_AMS + '/AlarmHistory/GetList',
  // 下载模板
  downloadAlarmHistoryRecordApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=AlarmHistoryList',
  // 导入
  importAlarmHistoryRecordApi: API_PREFIX_CONFIG + '/upload/submit?name=AlarmHistoryList',
  // 报警处理
  alarmDisposeApi: API_PREFIX_AMS + '/AlarmHistory/AddAdditional',
  // 报警处理历史列表
  getAlarmDisposeTableListApi: API_PREFIX_AMS + '/AlarmHistory/AlarmAdditionalDetail',
  // 删除报警处理历史记录
  deleteAlarmDisposeApi: API_PREFIX_AMS + '/AlarmHistory/DeleteAlarmAdditional',
  // 获取报警代码列表
  getAlarmCodeListApi: API_PREFIX_AMS + '/AlarmInfo/GetAlarmCodeList',
  // 获取接收人列表
  getAlarmTansfereesApi: API_PREFIX_AMS + '/AlarmHistory/GetAlarmTransferees',
  // 转单提交
  alarmTansferApi: API_PREFIX_AMS + '/AlarmHistory/AlarmTransfer'
};
export type FormType = {
  eqpId: string
  systemName: string
  alarmID: string
  alarmStartTime: number
  alarmEndTime: string
  alarmDesc: string
};
export type LotInfoDataType = {
  lotId: string
  loadPortId: string
  chamberId: string
  productId: string
  carrierId: string
  batchId: string
  reserved: string
  state: string
};
export type ActionInfoDataType = {
  // systemTime: string;
  systemTime: number
  alarmAction: number
  result: number
  relatedInfo: string
  remark: string
};
export type OperateRecordType = {
  alarmReason: string
  alarmDispose: string
  operator: string
  operateTime: number
};

export interface QueryType {
  treeIds: string
  eqpName: string[]
  alarmId: string
  alarmState: string
  description: string
  timestamp: string[]
  consumingStart: number
  consumingEnd: number
  lotId: string
  systemName: string
  language: number
  alarmCategory: number
  id: string
}

export interface TableListType {
  id: string
  alarmDesc: string
  alarmEndTime: string
  alarmID: string
  alarmLevel: string
  alarmStartTime: string
  alarmState: string
  createTime: string
  duration: string
  elapsedSeconds: number
  eqpID: string
  isEqpAlarm: number
  systemName: string
  treeId: string
  alarmConsuming: string
  txId: string
  isLaterCreate: number
  lotIdList: string[]
  alarmCategory: number
}

export interface DetailDataType {
  actionInfo: ExecuteActionType[]
  additionalInfo?: AlarmDisposeTableListType[]
  // 切换状态
  changeStateInfo?: ChangeStateInfoType[]
  lotInfo: BatchInfoType[]
  alarmDesc: string
  alarmEndTime: string
  alarmID: string
  alarmStartTime: string
  eqpID: string
  duration: string
  alarmConsuming: string
  operator?: string
  operateTime?: string
  treeId: string
  createTime: string
  isEqpAlarm: number

  systemName: string
  closedBy?: string
  txId?: string
  closeReason?: string
  alarmDispose?: string
  alarmReason?: string
  isManualClose?: OpenStateType
  remark: string
  alarmStatus: string
  alarmCategory: number
  unexecutedAction: number[]
}
export interface ChangeStateInfoType {
  alarmDispose: string
  operateTime: string
  operator: string
  reason: string
  remark: string
}
export interface AlarmDisposeTableListType {
  id: string
  alarmReason: string
  alarmDispose: string
  historyId: string
  operator: string
  isHasDeletePower: boolean
  operateTime: string
  projectCode: string
}
export interface AlarmDisposeType {
  alarmReason: string
  alarmDispose: string
}

export interface BatchInfoType {
  id: number
  historyId: number
  lotId: string

  recipeName: string
  lotPortId: string
  chamberId: string
  productId: string
  carrierId: string
  batchId: string
  reserved: string
  step: string
  state: string
  createTime: string
  alarmConsuming: string
}

export interface ExecuteActionType {
  id: number
  alarmAction: string
  // alarmActionId: string
  alarmID: string
  eqpID: string
  relatedPersons: string
  remark: string
  result: number
  systemTime: string
  alarmActionCategory: number
}
export enum ActionStatus {
  warning,
  success,
  error
}
export interface TurnOrderType {
  historyId: string
  transfereeList: string[]
}
export type AlarmStateType = {
  label: string,
  type: TagStateType
}
