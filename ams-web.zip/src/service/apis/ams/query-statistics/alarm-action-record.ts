import { API_PREFIX_AMS } from '../../common/common';

export const AlarmActionRecordApis = {
  // 获取用户列表 | 导出数据
  getListApi: API_PREFIX_AMS + '/AlarmActionHistory/GetList',
  // 编辑获取
  getInfoApi: API_PREFIX_AMS + '/AlarmActionHistory/Get'
};
export interface QueryActionInfoType {
  // 设备编号
  eqpName: string[];
  // 产线层级
  treeIds: string;
  // 报警ID
  txId: string;
  // 报警代码
  alarmId: string;
  // 执行动作
  alarmAction: string;
  // 执行结果
  result: string;
  alarmActionCategory: number;
  timestamp: string[];
  page?: number;
  size?: number;
  sortName?: string;
  sort?: string;
  consumingStart: number;
  consumingEnd: number;
  systemName: string[];
}

export interface ActionType {
  eqpID: string;
  alarmID: string;
  systemTime: string;
  alarmAction: string;
  result: string;
  remark: string;
  txId: string;
}

export type ActionListType = ActionType & QueryActionInfoType;

// 查看详情
export interface FormParamsProps {
  eqpID: string;
  alarmID: string;
  systemTime: string;
  alarmAction: string;
  result: string;
  alarmActionConsuming?: string;
  relatedPersons?: string;
  remark: string;
  txId: string;
  systemName: string;
  details?: DetailsType[];
  alarmActionCategory: number;

}
export interface DetailsType {
  account: number;
  actionHistoryId: string;
}
export enum ActionStatus {
  warning,
  success,
  error
}
export interface AlarmActionProps {
  id: number;
  name: string;
}

export interface ExecuteActionType {
  userID: string
  account: string;
  result: number;
  createTime: string;
  remark: string;
}
