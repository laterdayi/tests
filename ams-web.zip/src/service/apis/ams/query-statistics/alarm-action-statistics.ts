import { API_PREFIX_AMS } from '../../common/common';

export const AlarmActionStatisticssApis = {
  // 获取数据列表 | 导出数据
  getAlarmActionSummaryApi: API_PREFIX_AMS + '/AlarmActionHistory/GetAlarmActionSummary'

};
export type CustomType = {
  id: number;
  name: string;
};
export type AlarmActionType = {
  value: number;
  label: string;
};
export interface QueryType {
  type: number;
  treeIds: string[];
  eqpName: string[];
  alarmId: string;
  systemName: string;
  result: string;
  alarmAction: string;
  timestamp: string[];
}

export interface TableListType {
  alarmDesc: string;
  count: number;
  alarmDetailList: AlarmDetailListType[];
  expand?: boolean;
}

export interface AlarmDetailListType {
  alarmAction: number;
  actionCount: number;
}
