import { API_PREFIX_AMS } from '../../common/common';

export const EquipmentAlarmHistoryApis = {
  // 获取数据列表
  getAlarmSliceApi: API_PREFIX_AMS + '/AlarmSlice/GetAlarmSlice',
  // 获取详情
  getAlarmSliceDetailApi: API_PREFIX_AMS + '/AlarmSlice/GetAlarmSliceDetail'
};
export type QueryType = {
  timestamp: string[];
  treeIds: string[];
  eqpNames: string[];
  startTime?: string;
  endTime?: string;
};
export type AlarmSliceType = {
  id: string;
  levelCount: number;
  levelName: string;

  datas: AlarmSliceDatasType[];
};
export type AlarmSliceDatasType = {
  eqpId: string;
  eqpNameSort: number;
  datas: AlarmSliceDatasLevelType[];
  statisticsData: StatisticsDataType[];
};
export type AlarmSliceDatasLevelType = {
  alarmCount: string;
  color: string;
  interval: string;
  startTime: string;
  endTime: string;
};
export type SeriesDataType = {
  id: string;
  levelCount: number;
  levelName: string;
  echartIsShow: boolean;
  datas: SeriesDataDataSType[];
};
export type SeriesDataDataSType = {
  name: string;
  datas: EchartsType[];
  statisticsData: StatisticsDataType[];
};
export type StatisticsDataType = {
  color: string;
  percent: number;
  totalInterval: string;
};
export type EchartsType = {
  name: string;
  alarmCount: string;
  value: MixedArray;
  endTime: string;
  startTime: string;
  itemStyle: {
    color: string;
  };
};

export type ModalListType = {
  id: string;
  expandIsShow: boolean;
  eqpID: string;
  alarmID: string;
  alarmStartTime: string;
  alarmEndTime: string;
  formData: DetailFormType;
  actionInfo: ActionInfoType[];
  lotInfo: LotInfoType[];
  additionalInfo: OperateRecordType[];
};

export type DetailFormType = {
  systemName: string;
  treeId: string;
  txId: string;
  id: string;
  alarmConsuming: string;
  alarmDesc: string;
  alarmEndTime: string;
  alarmID: string;
  alarmStartTime: string;
  closeReason: string;
  closedBy: string;
  createTime: string;
  duration: string;
  eqpID: string;
  isEqpAlarm: number;
  isManualClose: number;
  actionInfo: ActionInfoType[];
  lotInfo: LotInfoType[];
  additionalInfo: OperateRecordType[];
};
export type LotInfoType = {
  batchId: string;
  carrierId: string;
  chamberId: string;
  createTime: string;
  historyId: number;
  id: number;
  lotId: string;
  lotPortId: string;
  productId: string;
  projectCode: string;
  recipeName: string;
  reserved: string;
  state: string;
  step: string;
};
export interface ActionInfoType {
  alarmAction: number;
  alarmActionConsuming: number;
  alarmActionId: string;
  alarmHistoryId: string;
  alarmID: string;
  eqpID: string;
  id: string;
  relatedPersons: string;
  remark: string;
  result: number;
  systemTime: string;
  txId: string;
  alarmActionCategory: number
}
export type HandleOpenModalType = {
  eqpName: EchartsType;
  state: number;
  language: number;
};
export type OperateRecordType = {
  alarmDispose: string;
  alarmReason: string;
  historyId: string;
  operateTime: string;
  operator: string;
  projectCode: string;
};
export type HandleOpenModalHistoryType = {
  eqpId: string;
  startTime: string;
  endTime: string;
  language: number;
};
