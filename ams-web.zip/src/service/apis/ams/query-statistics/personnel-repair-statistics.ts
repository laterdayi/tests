export type QueryType = {
  type: number
  flowType: string
  treeIds: string[]
  eqpName: string[]
  timestamp: string[]
  userGroupIds: string[]
};
