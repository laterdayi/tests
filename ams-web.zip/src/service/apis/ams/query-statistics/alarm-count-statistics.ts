import { API_PREFIX_AMS } from '../../common/common';

export const AlarmCountStatisticsApis = {
  // 获取数据列表 | 导出数据
  getAlarmListApi: API_PREFIX_AMS + '/AlarmHistory/GetSummary',
  // 获取报警级别列表
  getAlarmLevelListApi: API_PREFIX_AMS + '/alarmlevel/GetAllLevel'
};
