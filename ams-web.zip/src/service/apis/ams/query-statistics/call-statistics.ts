import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const CallStatisticsApis = {
  // 获取详情
  getCallStatisticsApi: API_PREFIX_AMS + '/CallReport/CallStatistics',
  // 呼叫异常类型
  getFlowTypeApi: API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.AMSFlowType}`,
  // 获取用户组
  getAllUserGroupsApi: API_PREFIX_CONFIG + '/UserGroup/GetAllUserGroups',
};

export type QueryType = {
  type: number
  timeFlag: number
  treeIds: string[]
  eqpName: string[]
  timestamp: string[]
  flowType: string
};
export type typeListType = {
  id: number
  name: string
};
export type CallStatisticsType = {
  callStatistics: TableListType[]
  totalAvgDownTime: number
  totalDownTime: number
  totalDownTimeRate: number
  totalNum: number
};

export type TableListType = {
  name: string
  num: number
  downtime: number
  downRate: number
  avgDownTime: number
};
