import { API_PREFIX_AMS } from '../../common/common';

export const EquipmentStateOverviewApis = {
  // 获取数据列表
  getEqpStateListApi: API_PREFIX_AMS + '/EqpStateList/GetEqpStateList',
  // 获取状态详情
  getAlarmStateDetailApi: API_PREFIX_AMS + '/EqpStateList/GetAlarmStateDetail'
};
export type TypeDemoType = {
  class: string;
  type: number;
  color: string;
  background: string;
  title?: string;
  duration?: string;
  state: number;
  cursor?: string;
  total?: number;
};
export type GetEqpStateListType = {
  alarmNumber: number;
  runningNumber: number;
  list: ListType[];
};
export type ListType = {
  id: string;
  levelCount: number;
  levelName: string;
  datas: DatasType[];
};
export type DatasType = {
  duration: string;
  eqpId: string;
  state: number;
};
