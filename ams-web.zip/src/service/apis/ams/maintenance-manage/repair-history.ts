import { API_PREFIX_PMS } from '../../common/common';
import type { WidgetType } from '@/components/project/form-designer/utils/designer-type';

export const RepairHistoryApis = {
  // 获取列表
  getRepairListApi: API_PREFIX_PMS + '/Repair/GetList',
  // 获取单个报修详情
  getRepairDetailApi: API_PREFIX_PMS + '/Repair/Get',
  // 删除
  deleteRepairApi: API_PREFIX_PMS + '/Repair/delete',

  // 接手/转手
  takeOverRepairApi: API_PREFIX_PMS + '/Repair/TakeOverRepair',
  // 获取QC表单信息
  getFormInfoApi: API_PREFIX_PMS + '/Repair/GetEFormInfo',
  // QC表单提交
  saveRepairHandlerFormApi: API_PREFIX_PMS + '/Repair/SaveRepairHandlerForm',
  // 设备接收
  saveEqpReceiveFormApi: API_PREFIX_PMS + '/Repair/SaveEqpReceiveForm',

  // 维修确认提交(非维修完成)
  submitFeedbackApi: API_PREFIX_PMS + '/Repair/SubmitFeedback',
  // 维修确认提交(data验证)
  checkSampleLimitApi: API_PREFIX_PMS + '/Repair/CheckSampleLimit',
  // 获取设备状态
  getEquipmentStateApi: API_PREFIX_PMS + '/EqpStateChange/GetEqpStatus',
  // 获取下一状态列表
  getNextStateListApi: API_PREFIX_PMS + '/Repair/GetRepairNextStateList',
  // 获取操作记录
  getRepairHistoryApi: API_PREFIX_PMS + '/RepairHistory/GetRepairHistory',
  // 获取操作记录详情
  getEFormHistoryApi: API_PREFIX_PMS + '/Repair/GetEFormHistory'
};
// 列表页------------------------------------------>
export enum RepairState {
  //  待接单
  toTakeOver = 1,
  // 待维修
  awaitingRepair = 2,
  // MarjorDown
  marjorDowarjorDow = 3,
  // 待QC确认
  toBeConfirmed = 4,
  // 设备接收
  eapReceive = 5,
  // PM
  PM = 6,
  // 修机
  repairMachine = 7,
  // 维修完成
  completeMlaintenance = 8
}

// 新增------------------------------------------>
export interface AddFormType {
  id?: string | number;
  layoutId: string;
  eqpId: string;
  alarmInfo: string;
  remark: string;
}
// 详情------------------------------------------>
export interface DetailFormType {
  id?: string | number;
  creator: string;
  createTime: string;
  layoutName: string;
  eqpName: string;
  productName: string;
  alarmInfo: string;
  alarmDesc: string;
  reason: string;
  improveMeasures: string;
  defaultSelection: number;
  parameterModification: string;
  sparePartChange: string;
}
// 接手
export interface TakeOverFormType {
  id: string;
  eqpId: string;
  secondaryTakeover: number;
  isBtnTakeOver: number;
  description: string;
}
// 维修确认
export interface MaintenanceType {
  state: number;
  reason: string;
  improveMeasures: string;
  parameterModification: string;
  sparePartChange: string;
}

// 操作记录列表
export interface OperateRecordListType {
  id: string;
  operateType: number;
  statusName: string;
  operator: string;
  operateTime: string;
  repairEFormId: string;
  description: string;
  result: number;
  formType?: string;

  goldSampleTableScroll?: number;
}

// 维修确认
export interface MaintenanceModalType {
  id: string;
  eqpId: string;
}
export interface FormItemListType {
  formPrefix: string;
  isSample: number;
}
export interface QcConfirmFormType {
  id: string;
  eFormId: string;
  prefix: string;
  repairHandleType: 4 | 7;
  table?: WidgetType;
}

export interface QueryType {
  eqpName: string;
  treeIds: string[];
  state: string;
  alarmDesc: string;
  alarmID: string;
  timestamp: string[];
  language: number;
}
export interface TableListType {
  id: string;

  workOrder: string;
  currentStatus: number;
  eqpID: string;
  alarmID: string;
  alarmType: string;
  alarmDesc: string;
  handleMeasures: string;
  repairSeconds: string;
  creator: string;
  createTime: string;
}

// ----------------------------> 新维修确认

// 获取表单id
export type MaintenanceFormType = {
  eFormId: string;
  isSample: number;
  prefix: string;
  repairHandleType: number;
  repairId: string;
};
// 抽屉传值类型
export type MaintenanceFormDataType = {
  formInfoData?: MaintenanceFormType;
  fromResult?: number;
  table?: WidgetType;
};
