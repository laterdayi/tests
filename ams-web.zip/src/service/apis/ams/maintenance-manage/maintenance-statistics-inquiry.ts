import { API_PREFIX_PMS } from '../../common/common';

export const MaintenanceStatisticsInquiryApis = {
  // 获列表
  getSummaryApi: API_PREFIX_PMS + '/Repair/GetSummary'
};
export type QueryType = {
  type: number
  layoutIds: number[]
  eqpName: string
  timestamp: string[]
  startTime?: string
  endTime?: string
};

export type TableListType = {
  summaryCount: number
  summaryType: string
};
