import { API_PREFIX_AMS, API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const AlarmMaintenanceConfigurationApis = {
  // 列表查询
  getListApi: API_PREFIX_PMS + '/RepairConfig/GetList',
  // 新增
  addApi: API_PREFIX_PMS + '/RepairConfig/Add',
  // 详情
  getDetailApi: API_PREFIX_PMS + '/RepairConfig/Get',
  // 编辑更新
  updateApi: API_PREFIX_PMS + '/RepairConfig/Update',
  // 删除
  deleteApi: API_PREFIX_PMS + '/RepairConfig/Delete',
  // 导入
  importApi: API_PREFIX_CONFIG + '/upload/submit?name=RepairConfigList',
  // 下载模板
  downloadApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=RepairConfigList',
  // 下载sop
  downloadSopApi: API_PREFIX_PMS + '/RepairConfig/SOPDownload',
  // 获取报警代码
  getEQPAlarmCodeListApi: API_PREFIX_AMS + '/ActionSetting/GetEQPAlarmCodeList'
};
export type QueryType = {
  eqpID: string
  alarmID: string
  alarmType: string
  handleMeasures: string
  isRepair: number
};
export type EditType = {
  id?: string
  eqpID: string
  alarmID: string
  alarmType: string
  handleMeasures: string
  isRepair: number
  sop: string
  sopName: string
  alarmDesc: string
  remark: string
  category: number
};
export type TableListType = {
  id?: string
  eqpID: string
  alarmID: string
  alarmType: string
  handleMeasures: string
  isRepair: number
  sop: string
  sopName: string
  alarmDesc: string
  remark: string
};
export type EQPAlarmCodeType = {
  alarmId: string
  description?: string
  id: string
}
