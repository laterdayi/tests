import { API_PREFIX_PMS } from '../../common/common';

export const CreateMaintenanceRequestApis = {
  // 获取设备详情
  repairConfigDetailApi: API_PREFIX_PMS + '/RepairConfig/RepairConfigDetail',
  // 新增
  addApi: API_PREFIX_PMS + '/Repair/Add',
  // 修改
  updateApi: API_PREFIX_PMS + '/Repair/Update',
  // 是否拥有保修单
  getRepairInfoApi: API_PREFIX_PMS + '/Repair/GetRepairInfo'
};
export type FormDataType = {
  toolingType: string
  eqpName: string
  alarmID: string
  alarmIDList: OptionsType[]
  alarmType: string
  createTime: string
  productName: string
  alarmDesc: string
  reason: string
  improveMeasures: string
  currentStatus?: number
  category: number
  handleMeasures: string
};
