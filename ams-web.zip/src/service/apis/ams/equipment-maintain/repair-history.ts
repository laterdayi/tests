import { API_PREFIX_AMS, API_PREFIX_CONFIG, API_PREFIX_REPORT_MANAGE } from '../../common/common';

import type { WidgetType } from '@/components/project/form-designer/utils/designer-type';

export const CallRepairHistoryApis = {
  // 获取列表
  getCallListApi: API_PREFIX_AMS + '/Call/GetList',
  // 获取单个详情
  getCallDetailApi: API_PREFIX_AMS + '/Call/GetCallDetail',
  // 获取操作记录
  getRepairHistoryApi: API_PREFIX_AMS + '/Call/GetRepairHistory',
  // 获取操作记录详情
  getCallEFormHistoryApi: API_PREFIX_AMS + '/Call/GetCallEFormHistory',
  // 获取lotId
  getEqpLotInfoApi: API_PREFIX_AMS + '/Call/GetEqpLotInfo',
  // 获取QC审核详情
  getRecoveryConditionListApi: API_PREFIX_AMS + '/Call/GetRecoveryConditionList',
  // 接单
  takeOverCallApi: API_PREFIX_AMS + '/Call/TakeOverCall',
  // 获取故障类型
  getFaultNameListApi: API_PREFIX_AMS + '/CallFaultConfig/GetFaultNameList',
  // 获取故障类型
  getFaultTypeApi: API_PREFIX_AMS + '/CallFaultType/GetFaultTypeList',
  // 转单
  transferCallApi: API_PREFIX_AMS + '/Call/TransferCall',
  // 获取接收人员
  getNotifyUsersByFlowTypeApi: API_PREFIX_CONFIG + '/UserGroup/GetUserGroupsByEqp',
  // 工程师维修
  repairCompleteApi: API_PREFIX_AMS + '/Call/RepairComplete',
  // sop+电子表单获取
  getMaintenanceInformationApi: API_PREFIX_AMS + '/Call/GetMaintenanceInformation',
  // 暂存sop+电子表单获取
  getRepairStageApi: API_PREFIX_AMS + '/Call/GetRepairStage',
  // 清除暂存
  clearStageEFormApi: API_PREFIX_AMS + '/Call/ClearStageEForm',
  // 历史维修报告
  getRepairReportListApi: API_PREFIX_AMS + '/Call/GetRepairReportList',
  // 复机条件
  getRecoveryConditiontListApi:
    API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.recoveryCondition}`,
  // 维修确认提交(data验证)
  checkSampleLimitApi: API_PREFIX_AMS + '/Repair/CheckSampleLimit',
  // 维修报告修正
  repairReportUpdateApi: API_PREFIX_AMS + '/Call/Update',
  // 维修报告修改记录
  tableChangeHistoryApi: API_PREFIX_REPORT_MANAGE + '/TableChangeHistory/GetPageList'
};
// 列表页------------------------------------------>

export type QueryType = {
  eqpIds: string[];
  treeIds: string[];
  state: string;
  timestamp: string[];
  language: number;
  flowNo: string;
  flowType: string;
  faultName: string;
  downTimeStart: number;
  downTimeEnd: number;
};
export type TableListType = {
  id: string;
  flowNo: string;
  eqpId: string;
  state: number;
  flowType: string;
  faultName: string;
  creator: string;
  createTime: string;
  waitingTime: string;
  currentHandler: string;
  systemTime: string;
  isTransfer: number;
  faultDescription: string;
};

export type FormType = {
  id?: string;
  faultDescription: string;
  faultName: string;
  faultReason: string;
  measure: string;
};

export enum CallState {
  //  待接单
  toTakeOver = 1,
  // 维修中
  underRepair = 2,
  // 审核中
  underInspection = 3,
  // 结单
  finalizeTheOrder = 9
}
// 详情------------------------------------------>
export type DetailFormType = {
  id?: string;
  creator: string;
  createTime: string;
  line: string;
  eqpId: string;
  flowType: string;
  faultName: string;
  eqpType?: number;
  faultDescription: string;
  lotId: string;
  faultReason: string;
  measure: string;
  callType: string;
  stageFlag: number;

  isBtnTakeOver?: number;
  isBtnHandOver?: number;
  isBtnRepairConfirm?: number;
  isBtnQCAudit?: number;
};
// 修改记录
export type ChangeHistoryType = {
  id?: string;
  faultDescription: string;
  faultReason: string;
  measure: string;
};
// 修改记录查询表单
export type HistoryFormType = {
  keyId?: string;
  tableName: string;
  operateType: string;
};
// 操作记录列表
export type OperateRecordListType = {
  id: string;
  operator: string;
  operateTime: string;
  description: string;
  callEFormId: string;
  operateType: number;
  iconIsShow?: boolean;

  result: number;
  formType?: string;
  goldSampleTableScroll?: number;
  qcTableData?: qcTableDataType[];
};
export type qcTableDataType = {
  condition: string;
  result: number;
  updateTime: string;
  createTime: string;
  remark: string;
};

// 接单
export type TakeOrderFormType = {
  id: string;
  userId: string;
  type: number;

  transferee: string;
  description: string;
};
export type EQPAlarmCodeType = {
  alarmId: string;
  description?: string;
  id: string;
};
export type FlowType = {
  id: string;
  isChild: boolean;
  name: string;
  children?: FlowType[];
};

// 工程师维修
export type EngineerRepairFormType = {
  lotId: string;
  faultName: string;
  faultDescription: string;
  faultReason: string;
  improveMeasure: string;
  recoveryConditions: string[];
};
export type EngineerRepairTableQueryType = {
  eqpTypeId: number;
  faultName: string;
};
export type EngineerRepairTableListType = {
  flowNo: string;
  faultDescription: string;
  faultReason: string;
  measure: number;
  repairCompleteTime: string;
};

// 抽屉传值类型
export type MaintenanceFormDataType = {
  formInfoData?: Nilable<MaintenanceInformationType>;
  fromResult?: number;
  table?: WidgetType;
};
// 获取表单id
export type MaintenanceInformationType = {
  faultDescription: string;
  eFormId: string;
  sop: string;
  sopName: string;
  callFaultConfigId: string;
  prefix: string;
};

export type RepairStageType = EngineerRepairFormType &
  MaintenanceInformationType & {
    table: WidgetType;
  };
