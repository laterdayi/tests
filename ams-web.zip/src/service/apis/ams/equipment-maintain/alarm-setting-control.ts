import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const AlarmSettingControlApis = {
  // 获取列表
  getListApi: API_PREFIX_AMS + '/EqpAlarmSetting/GetList',
  // 新增
  addApi: API_PREFIX_AMS + '/EqpAlarmSetting/Add',
  // 获取详情
  getDetailApi: API_PREFIX_AMS + '/EqpAlarmSetting/Get',
  // 获取编辑
  updateApi: API_PREFIX_AMS + '/EqpAlarmSetting/Update',
  // 删除
  deleteApi: API_PREFIX_AMS + '/EqpAlarmSetting/Delete',
  // 导入
  importApi: API_PREFIX_CONFIG + '/upload/submit?name=EqpTypeAlarmExcelList',
  // 下载模板
  downloadApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=EqpTypeAlarmExcelList',
};

export type QueryType = {
  eqpType: string
  alarmId: string
  alarmDescription: string
  alid: string
  lockLimit: number
  frequency: number
  isOP: string
  isValid: string
};
export type EditType = {
  eqpType: string
  alarmId: string
  alarmDescription: string
  alid: string
  lockLimit: number
  frequency: number
  isOP: string
  isValid: string
};

export type TableListType = {
  id: string
  eqpType: string
  alarmId: string
  alarmDescription: string
  alid: string
  lockLimit: number
  frequency: number
  isOP: string
  isValid: string
};
