import { API_PREFIX_AMS } from '../../common/common';

export const AuditSettingsApis = {
  // 显示隐藏
  hideDataApi: API_PREFIX_AMS + '/Call/HideData',

};
// 列表页------------------------------------------>

export type QueryType = {
  eqpIds: string[]
  treeIds: string[]
  state: string
  timestamp: string[]
  language: number
  isHide: number
  flowNo: string
  flowType: string
  faultName: string
  isCheck: number
  downTimeStart: number
  downTimeEnd: number
};
export type TableListType = {
  id: string
  flowNo: string
  eqpId: string
  state: number
  flowType: string
  faultName: string
  creator: string
  createTime: string
  downTime: string
  currentHandler: string
  systemTime: string
  isTransfer: number
  isHide: number
};
