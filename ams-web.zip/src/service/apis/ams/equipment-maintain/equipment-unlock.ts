import { API_PREFIX_AMS } from '../../common/common';

export const EquipmentUnlockApis = {
  // 获取列表
  getEquipmentLockListApi: API_PREFIX_AMS + '/CallEqpLock/GetList',
  // 设备解锁
  equipmentUnlockApi: API_PREFIX_AMS + '/CallEqpLock/ReleaseEqp'
};
