import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const FaultTypeMaintenanceApis = {
  // 列表查询
  getListApi: API_PREFIX_AMS + '/CallFaultType/GetList',
  // 新增
  addApi: API_PREFIX_AMS + '/CallFaultType/Add',
  // 详情
  getDetailApi: API_PREFIX_AMS + '/CallFaultType/get',
  // 编辑更新
  updateApi: API_PREFIX_AMS + '/CallFaultType/Update',
  // 删除
  deleteApi: API_PREFIX_AMS + '/CallFaultType/Delete',
  // 导入
  importApi: API_PREFIX_CONFIG + '/Upload/Submit?name=CallFaultTypeExcelList',
  // 下载
  downloadApi: API_PREFIX_CONFIG + '/Download/GetTemplateStream?name=CallFaultTypeExcelList'
};
export type QueryType = {
  eqpType: string
  faultName: string
};
export type EditType = {
  eqpType: string
  faultName: string
  remark: string
};
export type TableListType = {
  id?: string
  faultName: string
  createTime: string
  creator: string
  eFormId: string
  editor: string
  eqpType: string
  faultDescription: string
  remark: string
  isDeleted: string
  sopName: string
  eqpTypeName: string
  formName: string
};
export type EquipmentType = {
  level: number
  id: string
  name: string
  children?: EquipmentType[]
};
