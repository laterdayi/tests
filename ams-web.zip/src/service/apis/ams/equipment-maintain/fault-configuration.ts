import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const FaultConfigurationApis = {
  // 列表查询
  getListApi: API_PREFIX_AMS + '/CallFaultConfig/GetList',
  // 新增
  addApi: API_PREFIX_AMS + '/CallFaultConfig/Add',
  // 详情
  getDetailApi: API_PREFIX_AMS + '/CallFaultConfig/Get',
  // 编辑更新
  updateApi: API_PREFIX_AMS + '/CallFaultConfig/Update',
  // 删除
  deleteApi: API_PREFIX_AMS + '/CallFaultConfig/Delete',
  // 下载sop
  downloadSopApi: API_PREFIX_AMS + '/CallFaultConfig/SOPDownload',
  // 获取设备列表
  getEquipmentListApi: API_PREFIX_CONFIG + '/LayoutStructure/GetTree?check=0&addEqp=0',
  // 获取电子表单
  getCheckFormListApi: API_PREFIX_CONFIG + '/EFormFormCheck/GetFormList',
  // 获取故障类型
  getFaultTypeListApi: API_PREFIX_AMS + '/CallFaultType/GetFaultTypeList'
  // getFaultTypeListApi: API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.faultType}`
};
export type QueryType = {
  faultName: string
  eqpType: string
  faultDescription: string
};
export type EditType = {
  eqpType: string
  faultName: string
  faultDescription: string
  eFormId: string
  sopName: string
  sop: string
  remark: string
};
export type TableListType = {
  id?: string
  faultName: string
  createTime: string
  creator: string
  eFormId: string
  editor: string
  eqpType: string
  faultDescription: string
  remark: string
  isDeleted: string
  sop: string
  sopName: string
  eqpTypeName: string
  formName: string
};
export type EQPAlarmCodeType = {
  alarmId: string
  description?: string
  id: string
};
export interface EquipmentType {
  level: number
  id: string
  name: string
  children?: EquipmentType[]
}
