import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const CallEquipmentOverviewApis = {
  // 获取列表
  getCallStateApi: API_PREFIX_AMS + '/CallState/GetCallState',
  // 设备呼叫效验
  getCheckCallEqpApi: API_PREFIX_CONFIG + '/EquipmentBase/CheckCallEqp',
  // 发起呼叫
  getCallApi: API_PREFIX_AMS + '/Call/Call',
  // 呼叫异常类型
  getFlowTypeApi: API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.AMSFlowType}`,
  // 呼叫类型
  getAMSFlowTypeApi: API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.AMSCallType}`,
  // 员工工号验证
  checkUserApi: API_PREFIX_CONFIG + '/User/CheckUser'
};
export type TypeDemoType = {
  key: number | string
  class: string
  type: number
  color: string
  background: string
  statetime?: string
  title?: string
  state: number
  total?: number | CallStateTypeListType[]
  eqp?: string
};

export type TypeObjType = {
  name: string
  color: string
  background: string
};
export type CallStateType = {
  list: CallStateTypeListType[]
  inCallNumber: number
  inRepairNumber: number
  toAuditNumber: number
  normalNumber: number
};

export type CallStateTypeListType = {
  id: string
  levelCount: number
  levelName: string
  datas: CallStateTypeDatasType[]
  listIsShow?: boolean
};
export type CallStateTypeDatasType = {
  eqpId: string
  state: number
  statetime: string
};
export type FormDataType = {
  eqpName: string
  flowType: string
  userId: string
  callType: string
};
export type AbnormalityTypeList = {
  name: string
  disabled?: boolean
  clickIsShow: boolean
};
export type AMSFlowType = {
  id: string
  name: string
  clickIsShow: boolean
};

export type FormType = {
  treeIds: string[]
  eqpIds: string[]
};
export type FlowTypesListType = {
  id: string;
  name: string;
  disabled: boolean;
};
