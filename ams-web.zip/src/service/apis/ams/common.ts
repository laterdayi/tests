import { API_PREFIX_AMS } from '../common/common';

export const AMSCommonApis = {
  // 获取报警统计信息
  getAlarmStatisticsDataApi: API_PREFIX_AMS + '/AlarmBoard/GetTopAlarmStatistics'
};
