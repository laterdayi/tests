import { API_PREFIX_AMS } from '../../common/common';

export const StatusSwitchApis = {
  // 获取数据列表 | 导出数据
  getCloseListApi: API_PREFIX_AMS + '/AlarmClose/GetPageList',
  // 关闭报警
  closeAlarmApi: API_PREFIX_AMS + '/AlarmClose/CloseAlarms',
  // 保存切换状态
  getChangeEqpStateApi: API_PREFIX_AMS + '/AlarmClose/ChangeEqpState'
};

export interface QueryType {
  eqpName: string[]
  treeIds: string[]
  alarmId: string
  description: string
  language: number
  systemName: string
  alarmState: string
  timestamp?: string[]
}
export interface TableListType {
  id: string
  eqpID: string
  alarmID: string
  alarmStartTime: string
  alarmEndTime: string
  systemName: string
  duration: string
  createTime: string
  treeId: string
  isEqpAlarm: string
  alarmDesc: string
  elapsedSeconds: number
  alarmConsuming: number
  alarmState: string
  closeReason: string
  closedBy: string
  txId: string
  changeStateTime: string
}
export interface StatusSwitchType {
  alarmState: string
  reason: string
  remark: string
  historyIds: string[]
}
export interface DetailFormType {
  // 批次明细
  lotInfo?: InfoType[]
  // 执行动作明细
  actionInfo?: ActionType[]
  // 切换状态
  changeStateInfo?: ChangeStateInfoType[]
  // 操作记录
  additionalInfo?: AdditionalInfoType[]

  eqpID: string
  systemName: string
  alarmID: string
  txId: string
  alarmStartTime: string
  alarmEndTime: string
  isEqpAlarm: number
  alarmStatus: string
  duration: string
  alarmConsuming: string
  treeId: string
  createTime: string
  isManualClose: string
  closedBy: string
  closeReason: string
  alarmDesc: string

  remark?: string
}
export interface InfoType {
  id: number
  historyId: number
  lotId: string
  recipeName: string
  lotPortId: string
  chamberId: string
  productId: string
  carrierId: string
  batchId: string
  reserved: string
  step: string
  state: string
  createTime: string
  alarmConsuming: string
}
export interface ActionType {
  id: number
  alarmAction: string
  alarmActionId: string
  alarmID: string
  eqpID: string
  relatedPersons: string
  remark: string
  result: number
  systemTime: string
  alarmActionCategory: number
}
export interface ChangeStateInfoType {
  alarmDispose: string
  operateTime: string
  operator: string
  reason: string
  remark: string
}
export interface AdditionalInfoType {
  id: number
  alarmAction: number
  alarmActionId: string
  alarmID: string
  eqpID: string
  relatedPersons: string
  remark: string
  result: number
  systemTime: string
}

export enum ActionStatus {
  warning,
  success,
  error
}
