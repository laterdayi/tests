import { API_PREFIX_AMS } from '../../common/common';

export const AlarmTransferRecordApis = {
  // 获取数据列表 | 导出数据
  getCloseListApi: API_PREFIX_AMS + '/AlarmHistory/GetTransferPageList'
};
export interface QueryType {
  alarmId: string;
  language: number;
  alarmState: string;
  description: string
  timestamp?: string[];
}
export interface TableListType {
  id: string;
  txId: string;
  eqpID: string;
  alarmCode: string;
  alarmDesc: string;
  alarmStartTime: string;
  alarmEndTime: string
  transferor: string;
  transferTime: string;
  systemName: string;
  alarmState: string;
}
// 状态切换
export interface StatusSwitchType {
  alarmState: string;
  reason: string;
  remark: string;
  historyIds: string[];
}
// 操作
export interface OperateFormType {
  alarmDispose: string;
  alarmReason: string;
  historyId: string;
}
export interface OperateTableListType {
  id: string;
  alarmReason: string;
  alarmDispose: string;
  operator: string;
  operateTime: string;
  isHasDeletePower: string;
}
// 转单
export interface TurnOrderFormType {
  transfereeList: string[];
  historyId: string
}
