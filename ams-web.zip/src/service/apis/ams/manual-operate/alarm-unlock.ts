import { API_PREFIX_AMS } from '../../common/common';

export const AlarmUnlockApis = {
  // 获取数据列表 | 导出数据
  getAlarmListApi: API_PREFIX_AMS + '/AlarmLock/GetPageList',
  // 检查解锁全新啊
  checkUnLockApi: API_PREFIX_AMS + '/AlarmLock/CheckCanUnlock',
  // 解锁
  unLockApi: API_PREFIX_AMS + '/AlarmLock/UnLock'
};
