import { API_PREFIX_AMS } from '../../common/common';

export const CloseAlarmApis = {
  // 获取数据列表 | 导出数据
  getCloseListApi: API_PREFIX_AMS + '/AlarmClose/GetPageList',
  // 关闭报警
  closeAlarmApi: API_PREFIX_AMS + '/AlarmClose/CloseAlarms'
};
