import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const AlarmHandlingApis = {
  // 发送报警作业
  addAlarmApi: API_PREFIX_AMS + '/AlarmOperate/AddAlarm',
  // 获取报警代码
  getAllAlarmCodeListApi: API_PREFIX_AMS + '/ActionSetting/GetAllAlarmCodeList',
  // 获取详细信息
  getDetailApi: API_PREFIX_AMS + '/ActionSetting/Get',
  // 获取报警级别列表
  getAlarmLevelListApi: API_PREFIX_AMS + '/alarmlevel/GetAllLevel',
  // 按系统通知用户列表
  getNotifyUsersApi: API_PREFIX_CONFIG + '/UserGroup/GetNotifyUsers',
};
export type FormDataType = {
  isEqpAlarm: number
  category: number
  eqpName: string
  systemName: string
  alarmID: string
  notifyUsers: string[]
  alarmLevel: string
  alarmDesc: string
  startTime: string
  endTime: string
  categoryList?: string[]
};
export type DetailType = {
  description: string
  alarmLevel: string
  notifiedUserIds: string[]
};
export type UserListType = {
  id: string
  isChild: boolean
  name: string
  children?: UserListChildrenType[]
};
export type UserListChildrenType = {
  id: string
  isChild: boolean
  name: string
};
