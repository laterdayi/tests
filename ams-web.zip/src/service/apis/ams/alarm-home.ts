import { API_PREFIX_AMS } from '../common/common';

export const AlarmHomeApis = {
  // 获取报警分析
  getAlarmAnalysisApi: API_PREFIX_AMS + '/AlarmHistory/GetAlarmAnalysis'
};
