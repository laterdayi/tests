import { API_PREFIX_AMS, API_PREFIX_CONFIG, API_PREFIX_REPORT_MANAGE } from '../../common/common';

export const AlarmLevelRulesSettingApis = {
  // 列表
  getListApi: API_PREFIX_AMS + '/ActionSetting/GetPageList',
  //
  getIsEqpTypeApi: API_PREFIX_CONFIG + '/LayoutStructure/GetIsEqpType',
  // eqp类型
  queryDefaultConfigApi: API_PREFIX_AMS + '/ActionSetting/QueryDefaultConfig',
  // 保存默认配置
  saveDefaultConfigApi: API_PREFIX_AMS + '/ActionSetting/SaveDefaultConfig',
  // 导入下载(层级/设备)
  importMaterialCategoryApi: API_PREFIX_CONFIG + '/upload/submit?name=AlarmSetUpList',
  // 导入(系统)
  importSystemMaterialCategoryApi: API_PREFIX_CONFIG + '/upload/submit?name=AlarmSetUpBySystemNameList',
  // 新增
  handleAddApi: API_PREFIX_AMS + '/ActionSetting/Add',
  // 编辑
  handleUpdateApi: API_PREFIX_AMS + '/ActionSetting/Update',
  // 获取用户
  getNotifyUsersApi: API_PREFIX_CONFIG + '/UserGroup/GetNotifyUsers',
  // 下载(层级/设备)
  getTemplateApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=AlarmSetUpList',
  // 下载(系统)
  getSystemTemplateApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=AlarmSetUpBySystemNameList',
  // 表格删除
  handleDeleteApi: API_PREFIX_AMS + '/ActionSetting/Delete',
  // 修改记录
  getPageListApi: API_PREFIX_REPORT_MANAGE + '/TableChangeHistory/GetPageList',
  // holdCode列表
  getHodeCodeListApi: API_PREFIX_AMS + '/ActionSetting/GetHodeCodeList',
  // holdDepartment列表
  getHoldDepartmentListApi: API_PREFIX_AMS + '/ActionSetting/GetHoldDepartmentList',
  // 报警级别下拉验证
  getHoldInfoSelectTypeApi: API_PREFIX_AMS + '/ActionSetting/GetHoldInfoSelectType',
  // 按系统通知用户列表
  getSystemNameUsersApi: API_PREFIX_CONFIG + '/User/GetSystemNameUsers'
};

// 通知用户(层级设备)
export type UserListType = {
  id: string;
  isChild: boolean;
  name: string;
  children?: UserListChildrenType[];
};
export type UserListChildrenType = {
  id: string;
  isChild: boolean;
  name: string;
};
// 报警级别
export type AlarmLevelListProps = OptionsType & { isShowLotConfig: boolean };
// 左侧树
export interface LevelNodeProps {
  createTime: string;
  creator: string;
  description: string;
  id: string;
  isLeaf?: boolean;
  level: number;
  levelName: string;
  name: string;
  parentId: string;
  parentName: string;
  source: string;
  children?: LevelNodeProps[];
}
// 查询
export type QueryFormType = {
  isSave: string;
  alarmId: string;
  alarmLevel: string;
  user: string;
  alarmDesc: string;
  category: number;
  systemName?: string;
  eqpModel?: string;
};

// 保存表单
export interface SaveFormDataType {
  defaultLevel: string;
  effectiveTime: number;
  noAlarmEqpStates: string[];
  repeatCount: number;
  upInterval: number;
  removeDuplicateInterval: number;
}
// 右侧表格
export type TableDataType = AddTableType & {
  id: string;
  notifiedUserIds: string[];
  notifiedUserNames: string[];

  alarmIdVerify?: boolean;
  systemNameVerify?: boolean;
  upIntervalVerify?: boolean;
  lotTypeVerify?: boolean;
  lotPortListInfoVerify?: boolean;
  lotChamberListInfoVerify?: boolean;
};
// 新增弹窗表格
export type AddTableType = {
  isSave: number;
  isIgnoreEqpStatus: number;
  alarmId: string;
  alarmLevel: string;
  systemName: string;
  upInterval: number;
  holdCode: string;
  holdDepartment: string;
  holdEqpState: string;
  holdInfoSelectType: number;
  lotType: number;
  lotPortListInfo?: string[];
  lotChamberListInfo?: string[];
  notifiedUsers: string[];
  description: string;
  repeatCount: number;
  effectiveTime: number;
  removeDuplicateInterval: number;
};

// 修改记录
export type FormDataType = {
  keyId: string;
  tableName: string;
  operateType: string;
  language: number;
};

export type TableListType = {
  new: string;
  creator: string;
  createTime: string;
};
