import { API_PREFIX_AMS } from '../../common/common';

export const WeChatGroupBindingApis = {
  // 获取列表
  getListApi: API_PREFIX_AMS + '/AlarmWorkWechatBind/GetList',
  // 新增
  addApi: API_PREFIX_AMS + '/AlarmWorkWechatBind/Add',
  // 更新
  updateApi: API_PREFIX_AMS + '/AlarmWorkWechatBind/Update',
  // 删除
  deleteApi: API_PREFIX_AMS + '/AlarmWorkWechatBind/Delete',
  // 获取单个表单详情
  getDetailApi: API_PREFIX_AMS + '/AlarmWorkWechatBind/Get'
};

export interface QueryType {
  systemName: string
  webhookKey: string
}

export interface EditType {
  layoutId: string
  systemName: string
  webhookKey: string
}

export type TableListType = {
  id: string
  systemName: string
  layoutNameLists: string[]
  webhookKey: string
  creator: string
  createTime: string
  webhookList: string[]
};

export interface EquipmentType {
  createTime: string
  creator: string
  description: string
  id: string
  isLeaf: boolean
  levelName: string
  name: string
  parentId: string
  parentName: string
  source: string
  children?: EquipmentType[]
}
