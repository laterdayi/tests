import { API_PREFIX_AMS } from '../../common/common';

export const AlarmLevelManageApis = {
  // 获取用户列表 | 导出数据
  getUserListApi: API_PREFIX_AMS + '/AlarmLevel/GetPageList',
  // 新增
  createUserApi: API_PREFIX_AMS + '/AlarmLevel/Add',
  // 更新
  updateUserApi: API_PREFIX_AMS + '/AlarmLevel/Update',
  // 删除
  deleteUserApi: API_PREFIX_AMS + '/AlarmLevel/Delete',
  // 获取角色列表
  getInfoApi: API_PREFIX_AMS + '/AlarmLevel/Get',
  // 获取报警级别列表
  getAllLevelApi: API_PREFIX_AMS + '/AlarmLevel/GetAllLevel'
};
export interface AlarmLevelType {
  alarmLevel: string
  alarmAction: string[]
  description: string
}

export type AlarmLevelListType = AlarmLevelType & {
  id: string
  creator: string
  createTime: string
  actions: number[]
};
