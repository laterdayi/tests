import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';

export const AlarmCodeMaintainApis = {
  // 获取列表
  getCodeMaintainListApi: API_PREFIX_AMS + '/AlarmInfo/GetList',
  // 更新
  updateCodeMaintainApi: API_PREFIX_AMS + '/AlarmInfo/Update',
  // 删除
  deleteCodeMaintainApi: API_PREFIX_AMS + '/AlarmInfo/Delete',
  // 获取单个表单详情
  getCodeMaintainDetailApi: API_PREFIX_AMS + '/AlarmInfo/Get',
  // 新增
  createCodeMaintainApi: API_PREFIX_AMS + '/AlarmInfo/Add',
  // 导入
  importCodeMaintainApi: API_PREFIX_CONFIG + '/upload/submit?name=AlarmInfoExcelList',
  // 下载模板
  downloadCodeMaintainApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=AlarmInfoExcelList'
};
