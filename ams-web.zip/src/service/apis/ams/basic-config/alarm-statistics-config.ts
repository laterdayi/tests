import { API_PREFIX_AMS } from '../../common/common';

export const AlarmStatisticsConfigApis = {
  // 获取列表
  getListApi: API_PREFIX_AMS + '/SummaryConfig/GetList',
  // 添加配置
  addSummaryConfigApi: API_PREFIX_AMS + '/SummaryConfig/Add',
  // 获取信息
  getInfoApi: API_PREFIX_AMS + '/SummaryConfig/Get',
  // 更新
  updateSummaryConfigApi: API_PREFIX_AMS + '/SummaryConfig/Update',
  // 删除
  deleteSummaryConfigApi: API_PREFIX_AMS + '/SummaryConfig/Delete',
  // 获取报警代码列表
  getAlarmCodeListApi: API_PREFIX_AMS + '/ActionSetting/GetAlarmCodeList'
};
