import { API_PREFIX_AMS } from '../../common/common';

export const ArchiveRecordsApis = {
  // 获取数据列表
  getAlarmHistoryListApi: API_PREFIX_AMS + '/Archive/GetPageList',
  // 表明
  getTableListApi: API_PREFIX_AMS + '/Archive/GetTableList'
};
export type QueryType = {
  timestamp: string[];
  businessName: string;
  startTime?: string;
  endTime?: string;
};

export type TableListType = {
  timestamp: string[];
  treeIds: string[];
  eqpNames: string[];
};
