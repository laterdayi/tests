import { API_PREFIX_AMS } from '../../common/common';

export const ArchiveSettingsApis = {
  // 查询数据归档
  getArchiveSettingApi: API_PREFIX_AMS + '/Archive/GetArchiveSetting',
  // 新增数据归档
  addArchiveSettingApi: API_PREFIX_AMS + '/Archive/AddArchiveSetting'

};
export type QueryType = {
  isOpen: boolean;
  retainMonths: number;
};

export type RenderItemType = {
  archiveDays: number;
  archiveHours: number;
};
