import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const MaterialCategoryApis = {
  // 获取数据列表 | 导出数据
  getMaterialCategoryListApi: API_PREFIX_ASSEMBLY + '/MaterialType/GetList',
  // 获取单个详情
  getMaterialCategoryDetailApi: API_PREFIX_ASSEMBLY + '/MaterialType/Get',
  // 新增
  createMaterialCategoryApi: API_PREFIX_ASSEMBLY + '/MaterialType/Add',
  // 更新
  updateMaterialCategoryApi: API_PREFIX_ASSEMBLY + '/MaterialType/Update',
  // 删除
  deleteMaterialCategoryApi: API_PREFIX_ASSEMBLY + '/MaterialType/Delete',
  // 导入
  importMaterialCategoryApi: API_PREFIX_ASSEMBLY + '/upload/submit?name=MaterialTypeList',
  // 导出
  exportMaterialCategoryApi: API_PREFIX_ASSEMBLY + '/MaterialType/ExportMaterialType',
  // 下载
  downloadMaterialCategoryApi: API_PREFIX_ASSEMBLY + '/download/GetTemplateStream?name=MaterialTypeList'
};
