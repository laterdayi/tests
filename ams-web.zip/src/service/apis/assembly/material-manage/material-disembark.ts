import { API_PREFIX_ASSEMBLY, API_PREFIX_CONFIG } from '../../common/common';

export const MaterialDisembarkApis = {
  // 下机
  disembarkApi: API_PREFIX_ASSEMBLY + '/MaterialInfo/MaterialGetOffEqp',
  // 获取上下机信息
  getMachineInfoApi: API_PREFIX_ASSEMBLY + '/MaterialInfo/GetMaterialInfo',
  // 获取设备信息
  getEquipmentInfoApi: API_PREFIX_CONFIG + '/EquipmentBase/CheckEqpId'
};
