import { API_PREFIX_ASSEMBLY, API_PREFIX_CONFIG } from '../../common/common';

export const SparesModelManageApis = {
  // 列表
  getListApi: API_PREFIX_ASSEMBLY + '/ToolingModels/GetList',
  // 新增
  addApi: API_PREFIX_ASSEMBLY + '/ToolingModels/Add',
  // 编辑获取详情
  editDetailApi: API_PREFIX_ASSEMBLY + '/ToolingModels/Get',
  // 编辑提交
  getEditApi: API_PREFIX_ASSEMBLY + '/ToolingModels/Update',
  // 删除
  deleteApi: API_PREFIX_ASSEMBLY + '/ToolingModels/Delete',
  // 类别接口
  getByTypeModelListApi: API_PREFIX_ASSEMBLY + '/ToolingType/GetToolingTypeList',
  // 型号接口
  getToolingTypeIdListApi: API_PREFIX_ASSEMBLY + '/ToolingModels/GetByTypeModelList',
  // 导入
  importUserApi: API_PREFIX_CONFIG + '/upload/submit?name=ToolingModeList',
  // 下载
  downloadMaterialApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=ToolingModeList'
};
export type ListType = {
  id: string;
  name: string;
};
export type QueryType = {
  toolingModel: string;
};
export type TableListType = {
  id: number;
  toolingModel: string;
  toolingType: string;
  creator: string;
  createTime: string;
  editor: string;
  editTime: string;
};

export type EditType = {
  toolingModel: string;
  toolingType: string;
};
