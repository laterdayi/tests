import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const SparesCollectingDocApis = {
  // 页面表格列表
  getListApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/GetList',
  // 获取领用申请
  getFromApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/Get',
  // 修改领用申请
  updateApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/Update',
  // 新增领用申请
  addFormApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/Add',
  // 删除表格
  tableDeleteApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/Delete',
  // 获取发放Tooling列表
  getToolingInfoApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/GetToolingInfo',
  // 获取可用Tooling列表
  getQueryListApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetQueryList',
  // 驳回
  applyGrantRejectApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/ApplyGrantReject',
  // 发放
  applyGrantToolingApi: API_PREFIX_ASSEMBLY + '/ToolingApplyGrant/ApplyGrantTooling'
};

export type ListType = {
  id: string;
  name: string;
};
// 列表页查询表单类型
export type QueryFormType = {
  toolingType: string;
  toolingModel: string;
  flag: string;
  timestamp: string[];
};
export type TableListType = {
  id?: string;
  applyNo: string;
  toolingType: string;
  toolingModel: string;
  flag: string;
  applyId: string;
  applyTime: string;
  applyQty: string;
  applyRemark: string;
  grantId: string;
  grantTime: string;
  grantBarcode: string;
  grantRemark: string;
};
// 领用
export type CollectingApplicationFormType = {
  id?: string;
  applyQty: string;
  applyId: string;
  toolingType: string;
  toolingModel: string;
};
// 发放
export type GrantFormType = CollectingApplicationFormType & {
  toolingBarcde: string;
  grantId: string;
};
// 可用列表
export type AvailableQueryType = {
  toolingType: string;
  toolingModel: string;
};
// 发放表格
export type GrantQueryType = AvailableQueryType & {
  toolingBarcde: string | null;
};
export type GrantTableColumnsType = {
  id: string;
  toolingBarcode?: string;
  toolingType?: string;
  toolingModel?: string;
  stock?: string;
  hdStatus?: string | number;
  currentFlag?: string;
};
