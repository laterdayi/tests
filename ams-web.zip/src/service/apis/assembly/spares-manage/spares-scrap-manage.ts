import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const SparesScrapManageApis = {
  // 页面表格列表
  getListApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/GetList',
  // 删除表格
  tableDeleteApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/Delete',
  // 申请报废
  applyScrapToolingApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/ApplyScrapTooling',
  // 申请报废查询
  getToolingInfoApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/GetToolingInfo',
  // 确认报废
  confirmScrapToolingApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/ConfirmScrapTooling',
  // 确认报废查询
  toolongScrapInfoApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/ToolongScrapInfo',
  // 驳回
  rejectScrapToolingApi: API_PREFIX_ASSEMBLY + '/ToolingInfoScrap/RejectScrapTooling',
  // 人员验证
  checkUserApi: '/config/User/CheckUser'
};
export type ListType = {
  id: string;
  name: string;
};
// 列表页
export type QueryType = {
  toolingType: string;
  toolingModel: string;
  toolingBarcode: string;
  flag: string;
  timestamp: string[];
};
export type TableListType = {
  toolingBarcode: string;
  toolingType: string;
  toolingModel: string;
  flag: string;
  applicant: string;
  applyTime: string;
  reason: string;
  confirmer: string;
  confirmTime: string;
  remark: string;
};
// 报废弹窗
export type ScrapFormType = {
  toolingBarcde: string;
  applicant: string;
  confirmer: string;
  remark: string;
};
export type TableColumnsType = {
  id?: string | number;
  toolingBarcode: string;
  toolingType: string;
  toolingModel: string;
};
// 申请报废
export type ApplyForScrappingTableColumnsType = {
  stock: string;
  hdStatus: string;
  reason: string;
  userId: string;
  reasonIsShow?: boolean;
};
// 确认报废
export type ConfirmScrapTableColumnsType = {
  stock: string;
  hdStatus: string;
  applicant: string;
  applyTime: string;
};
