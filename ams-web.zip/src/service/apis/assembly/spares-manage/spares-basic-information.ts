import { API_PREFIX_ASSEMBLY, API_PREFIX_CONFIG } from '../../common/common';

export const SparesBasicInformationApis = {
  // 页面表格列表,导出
  getListApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetList',
  // 新增备件基础
  addFormApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Add',
  // 获取备件基础
  getFromApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Get',
  // 修改备件基础
  updateApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Update',
  // 删除表格
  tableDeleteApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Delete',
  // 状态
  getHDStatusApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetHDStatus',
  // 当前状态
  getEnumListApi: API_PREFIX_ASSEMBLY + '/Common/GetEnumList?enumName=ToolingStateEnum',
  // 导入
  importUserApi: API_PREFIX_CONFIG + '/upload/submit?name=ToolingBaseList',
  // 下载
  downloadApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=ToolingBaseList',
  // 获取用户列表 | 导出数据
  getUserListApi: API_PREFIX_ASSEMBLY + '/user/getlist',
  // 领用,发放,上机,下机详情
  getToolingInfoApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetToolingInfo',
  // 领用提交
  getLendToolingApi: API_PREFIX_ASSEMBLY + '/ToolingAction/LendTooling',
  // 发放提交
  grantToolingApi: API_PREFIX_ASSEMBLY + '/ToolingAction/GrantTooling',
  // 上机head
  getSiteIdListApi: API_PREFIX_CONFIG + '/EquipmentBase/GetSiteIdList',
  // 上机提交
  toolingLendOnEqpApi: API_PREFIX_ASSEMBLY + '/ToolingAction/ToolingLendOnEqp',
  // 下机提交
  toolingGetOffEqpApi: API_PREFIX_ASSEMBLY + '/ToolingAction/ToolingGetOffEqp',
  // 设备编号查询
  getAllToolingOnEqpApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetAllToolingOnEqp',
  // 维护提交
  maintainToolingApi: API_PREFIX_ASSEMBLY + '/ToolingAction/MaintainTooling',
  // 归还提交
  returnToolingApi: API_PREFIX_ASSEMBLY + '/ToolingAction/ReturnTooling',
  // 接收提交
  takebackToolingApi: API_PREFIX_ASSEMBLY + '/ToolingAction/TakebackTooling',
  // 外修归还提交
  repairReturnApi: API_PREFIX_ASSEMBLY + '/ToolingAction/RepairReturn'
};

export type ListType = {
  id: string;
  name: string;
  disabled?: boolean;
};

// 列表页,新增,编辑
export type SparesBasicInformationType = {
  area: string;
  stage: string;
  hdStatus: string;
  toolingModel: string;
  toolingBarcode: string;
  stock: string;
  trackId: string;
  poNo: string;
};
export type QueryType = SparesBasicInformationType & {
  currentFlag: string;
  timestamp: string[];
};

export type TableListType = SparesBasicInformationType & {
  id: string | number;
  lastPMDate: string;
  nextPMTime: string;
  reason: string;
  remark: string;
  pmCycle: string;
  alarmDay: string;
  toolingType: string;
  currentFlag: string;
};

export type FormType = SparesBasicInformationType & {
  id?: string | number;
  toolingType: string;
  lifeTime: string;
  usedTime: string;
  receiveDate: string | null;
  releaseDate: string;
  expireDate: string | null;
  pmCycle: string;
  WarningTime: string;
  remark: string;
  flag?: string;
};
// 领用,发放,归还,接收类型
export type CollectFormType = {
  id?: string | number;
  toolingBarcode: string;
  ToReturn: string;
  remark: string;
};
export type TableColumnsType = {
  id?: string | number;
  toolingBarcode: string;
  toolingModel: string;
  usedTime: string;
  stock?: string;
};
export type CollectTableColumnsType = TableColumnsType & {
  stock: string;
  actionType: string;
};
export type GrantTableColumnsType = TableColumnsType & {
  stock: string;
  lendDate: string;
  lendId: string;
};

export type ReceiveTableColumnsType = TableColumnsType & {
  stock: string;
  returnDate: string;
  returnId: string;
};
// 上机
export type BoardingFormType = {
  toolingBarcode: string;
  eqpId: string;
  headId: string;
  toolingType: string;
  toolingModel: string;
  usedTime: string;
  lifeTime: string;
  remark: string;
  newStock?: string;
};
// 维护
export type LeftMaintainerFormType = {
  cleanId?: string;
  cleanReason?: string;
  cleanMode?: string;
  maintainRemark?: string;
};
export type LeftUpkeepFormType = {
  repairId?: string;
  isOutRepair?: string;
  repairPart?: string;
  hdStatus?: string;
  isReset?: string;
  repairReason?: string;
  remark?: string;
  toolingImage?: string;
};
export type LeftFormType = {
  toolingBarcode: string;
  isRepair: number;
  isOutRepair?: string;
};
export type RightFormType = {
  id?: string;
  toolingType: string;
  toolingModel: string;
  currentFlag: string;
  time: string;
  usedTime: string;
  toolingBarcode?: string;
};
// 外修归还
export type ExternalRepairRestitutionFormType = {
  toolingBarcode: string;
  repairReturnDate: string;
};
