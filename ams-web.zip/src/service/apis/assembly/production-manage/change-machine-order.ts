import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const ChangeMachineOrderApis = {
  // 获取数据列表 | 导出数据
  getChangeMachineListApi: API_PREFIX_ASSEMBLY + '/ConversionForm/GetList',
  // 获取单个详情
  getChangeMachineDetailApi: API_PREFIX_ASSEMBLY + '/ConversionForm/get',
  // 新增
  createChangeMachineApi: API_PREFIX_ASSEMBLY + '/ConversionForm/add',
  // 更新
  updateChangeMachineApi: API_PREFIX_ASSEMBLY + '/ConversionForm/update',
  // 删除
  deleteChangeMachineApi: API_PREFIX_ASSEMBLY + '/ConversionForm/delete',
  // 导出
  exportChangeMachineApi: API_PREFIX_ASSEMBLY + '/ConversionForm/getlist',
  // 获取下一状态列表
  getNextStateListApi: API_PREFIX_ASSEMBLY + '/ConversionForm/GetConversionNextStateList',
  // 获取设备状态
  getEquipmentStateApi: API_PREFIX_ASSEMBLY + '/ConversionForm/GetEqpData',
  // 获取操作记录
  getOperateRecordListApi: API_PREFIX_ASSEMBLY + '/ConversionForm/GetOperateHistory',
  // 获取操作记录详情
  getOperateRecordDetailApi: API_PREFIX_ASSEMBLY + '/ConversionForm/GetEFormHis',
  // 审核
  executeReviewApi: API_PREFIX_ASSEMBLY + '/ConversionForm/VerifyConversion',
  // 接手
  executeTakeOverApi: API_PREFIX_ASSEMBLY + '/ConversionForm/TakeOverConversion',
  // 转手
  handOverApi: API_PREFIX_ASSEMBLY + '/ConversionForm/HandOverConversion',
  // 获取表单信息
  getFormInfoApi: API_PREFIX_ASSEMBLY + '/ConversionForm/GetEFormInfo',
  // 改机确认 & QC确认
  formConfirmApi: API_PREFIX_ASSEMBLY + '/ConversionForm/SaveConversionHandlerForm',
  // 设备接收确认
  equipmentReceiveConfirmApi: API_PREFIX_ASSEMBLY + '/ConversionForm/SaveEqpReceiveForm',
  // 废除改机
  abandonConversionApi: API_PREFIX_ASSEMBLY + '/ConversionForm/AbandonConversion'
};
