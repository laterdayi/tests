import { API_PREFIX_ASSEMBLY } from '../../common/common';
import type { ItemListType, ValidateFormItemResult } from '@/utils/project/electronic-form/electronic-form-type';

export const RepairManageApis = {
  // 获取列表
  getRepairListApi: API_PREFIX_ASSEMBLY + '/Repair/GetList',
  // 获取单个报修详情
  getRepairDetailApi: API_PREFIX_ASSEMBLY + '/Repair/Get',
  // 新增
  createRepairApi: API_PREFIX_ASSEMBLY + '/Repair/add',
  // 更新
  updateRepairApi: API_PREFIX_ASSEMBLY + '/Repair/update',
  // 删除
  deleteRepairApi: API_PREFIX_ASSEMBLY + '/Repair/delete',
  // 接手/转手
  takeOverRepairApi: API_PREFIX_ASSEMBLY + '/Repair/TakeOverRepair',

  // 获取QC表单信息
  getFormInfoApi: API_PREFIX_ASSEMBLY + '/Repair/GetEFormInfo',
  // QC表单提交
  saveRepairHandlerFormApi: API_PREFIX_ASSEMBLY + '/Repair/SaveRepairHandlerForm',

  // 设备接收
  saveEqpReceiveFormApi: API_PREFIX_ASSEMBLY + '/Repair/SaveEqpReceiveForm',

  // 维修确认提交(非维修完成)
  submitFeedbackApi: API_PREFIX_ASSEMBLY + '/Repair/SubmitFeedback',

  // 维修确认提交(data验证)
  checkSampleLimitApi: API_PREFIX_ASSEMBLY + '/ConversionForm/CheckSampleLimit',

  // 获取设备状态
  getEquipmentStateApi: API_PREFIX_ASSEMBLY + '/EqpStateChange/GetEqpStatus',
  // 获取下一状态列表
  getNextStateListApi: API_PREFIX_ASSEMBLY + '/Repair/GetRepairNextStateList',
  // 获取操作记录
  getOperateRecordListApi: API_PREFIX_ASSEMBLY + '/Repair/GetOperateHistory',
  // 获取操作记录详情
  getEFormHisApi: API_PREFIX_ASSEMBLY + '/Repair/GetEFormHis'
};
// 列表页------------------------------------------>
export enum RepairState {
  //  待接单
  toTakeOver = 1,
  // 待维修
  awaitingRepair = 2,
  // MarjorDown
  marjorDowarjorDow = 3,
  // 待QC确认
  toBeConfirmed = 4,
  // 设备接收
  eapReceive = 5,
  // PM
  PM = 6,
  // 修机
  repairMachine = 7,
  // 维修完成
  completeMlaintenance = 8
}
export interface QueryType {
  eqpNames: string[];
  treeIds: string[];
  state: string;
  remark: string;
  timestamp: string[];
}
export interface TableListType {
  id: string;
  repairFormNo: string;
  eqpName: string;
  eqpId: string;
  eqpState: string;
  lotId: string;
  remark: string;
  responseDeptId: string;
  currentHandler: string;
  state: number;
  stateStr: string;
  lastUpdateTime: string;
  totalRepairSecond: string;
  totalManageTime: string;
  handleMeasures: string;
  reason: string;
  improveMeasures: string;
  parameterModification: string;
  sparePartChange: string;
  creator: string;
  createTime: string;
  repairCreateTime: string;
  productName: string;
  alarmInfo: string;
}
// 设备状态
export interface EquipmentStateType {
  eqpStateName: string;
  lotId: string;
  productName: string;
  programNameFrom: string;
  programNameTo: string;
}
// 新增/编辑------------------------------------------>
export interface AddFormType {
  id?: string | number;
  layoutId: string;
  eqpId: string;
  eqpStateName: string;
  lotId: string;
  productName: string;
  nextEqpStateCode: string | number;
  alarmInfo: string;
  remark: string;
}

// 详情------------------------------------------>
export interface DetailFormType {
  creator: string;
  createTime: string;
  levelName: string;
  eqpName: string;
  productName: string;
  alarmInfo: string;
  remark: string;
  reason: string;
  parameterModification: string;
  handleMeasures: string;
  sparePartChange: string;

  eqpId?: string;
  defaultSelection?: number;
}
export enum DetailFormState {
  // 接手
  pendingOrder,
  // 转手
  awaitRepair,
  // QC确认
  inStock,
  // 维修确认
  awaitQcConfirm,
  // 设备接收
  equipmentReceive
}
// 操作记录列表
export interface OperateRecordListType {
  id: string;
  conEFormId?: string;
  operateType: string;
  statusName: string;
  operator: string;
  operateTime: string;
  repairEFormId: string;
  result: number;
  formType?: string;
  fromResult?: ValidateFormItemResult;
  typeTableData?: ItemListType[];
  nameTableData?: ItemListType[];
  goldSampleTableData?: ItemListType[];
  goldSampleTableColumns?: DataTableColumns<ItemListType>;
  goldSampleTableScroll?: number;
}
// 操作记录详情表单

// 接手
export interface TakeOverFormType {
  id: string;
  eqpId: string;
  secondaryTakeover: number;
  isBtnTakeOver: number;
  nextEqpStateCode: string;
  remark: string;
}
// QC确认
export interface QcConfirmFormType {
  id: string;
  eFormId: string;
  prefix: string;
  repairHandleType: 4 | 7;
  sampleNum: number;
  testNum: number;
  itemList: ItemListType[];
}
export interface QcConfirmModalType {
  id: string;
  eqpId: string;
}
export interface NextStateListType extends OptionsType {
  disabled: boolean;
}
export interface NextStateFormType {
  nextEqpStateCode: string;
}
export interface FormItemListSaveType {
  formPrefix: string;
  isSample: number;
  itemList: ItemListType[];
}
// 维修确认
export interface MaintenanceFormType {
  id: string;
  eFormId: string;
  prefix: string;
  repairHandleType: 4 | 7;
  sampleNum: number;
  testNum: number;
  itemList: ItemListType[];
}
export interface MaintenanceModalType {
  id: string;
  eqpId: string;
}
export interface MaintenanceType {
  state: number;
  reason: string;
  handleMeasures: string;
  parameterModification: string;
  sparePartChange: string;
  nextEqpStateCode: string;
}
export interface MaintenanceFormDataType {
  formInfoData: MaintenanceFormType;
  eFormItemList: ItemListType[];
  goldSampleDataColumns?: DataTableColumns<ItemListType>;
}
// 改机部分-------->

// 改机列表
export enum ChangeMachineState {
  all,
  // 待审核
  awaitReview,
  // 待接手
  awaitTakeOver,
  // 待处理
  awaitDispose,
  // 改机完成
  changeMachineComplete,
  // 待设备接收
  awaitEquipmentReceive
}

export interface TableListTypes {
  id: string;
  conversionFormNo: string;
  eqpName: string;
  lotId: string;
  remark: string;
  verifior: string;
  verifyTime: string;
  responser: string;
  eqpReceiver: null;
  eqpReceiveTime: string;
  conversionState: number;
  conversionStateStr: string;
  responseDeptName: string;
  creator: string;
  createTime: string;
  userDeptName: string;
  totalDealTime: string;
  editDetailIsShow: boolean;
}
export interface CurrentOperateDataType {
  id: string;
  editDetailIsShow: boolean;
}
export interface EditType {
  eqpName: string;
  lotId: string;
  levelName: string;
  creator: string;
  createTime: string;
  remark: string;
  responseDeptName: string;
  verifior: string;
  verifyTime: string;
  eqpStateName: string;
  nextEqpStateCode: string;
}
export interface ChangeMachineDetailRefType {
  handleOpenModal: (data: CurrentOperateDataType) => void;
  updateField: (data: Partial<Nilable<EditType>> | null | undefined) => void;
}
// 改机新增

export interface EditAddType {
  layoutId: string;
  eqpId: string;
  eqpStateName: string;
  lotId: string;
  lotIdIsShow: boolean;
  nextEqpStateCode: string | number;
  remark: number;
  list: ChangeMachineInfoListType[];
}
export interface ChangeMachineInfoListType {
  type: string;
  from: string;
  to: string;
  fromDisabled: boolean;
  toDisabled: boolean;
}
export interface CurrentEditDataType {
  creator: string;
  createTime: string;
  levelName: string;
  eqpName: string;
  lotId: string;
  responseDeptName: string;
  verifior: string;
  verifyTime: string;
  eqpStateName: string;

  layoutId: string;
  currentEqpState: string;
  isBtnVerify: number;
  isBtnTakeOver: number;
  isBtnHandOver: number;
  isBtnParmConfirm: number;
  isBtnQCConfirm: number;
  isBtnEqpReceive: number;
  secondaryTakeover: number;
  list: ChangeMachineInfoListType[];
  id: string;
  conversionFormNo: string;
  eqpId: string;
  remark: string;
  responser: string;
  eqpReceiver: string;
  eqpReceiveTime: string;
  conversionState: ChangeMachineState;
  conversionStateStr: string;
  userDeptName: string;
  totalDealTime: string;
}
// 改机详情
export interface MachineDetailType {
  creator: string;
  createTime: string;
  levelName: string;
  eqpName: string;
  lotId: string;
  responseDeptName: string;
  verifior: string;
  verifyTime: string;
  eqpStateName: string;
  list?: ChangeMachineInfoListType[];
}
// 审核
export interface VerifyType {
  id: string;
  eqpId: string;
  isBtnVerify?: number;
  secondaryTakeover?: number;
  nextEqpStateCode: string;
  remark: string;
}

export interface FormInfoDataType {
  conversionId: string;
  eFormId: string;
  prefix: string;
  conversionHandleType: number;
  conversionEFormHisId: string;
  itemList: [];
  sampleNum: number;
  testNum: number;
  isSample: number;
}

export interface OperateRecordDetailItemListType {
  attachmentPath: string;
  belongTo: number;
  itemName: string;
  itemValue: string;
  result: ValidateFormItemResult;
  sample: [];
  standard: string;
  unit: string;
}
export interface OperateRecordListTypes {
  id: string;
  operator: string;
  operateTime: string;
  operateType: string;
  remark: string;
  conEFormId: string;
  role: string;
  eqpStatus: string;
}
