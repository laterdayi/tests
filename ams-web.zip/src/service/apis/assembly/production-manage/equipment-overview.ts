import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const EquipmentOverviewApis = {
  // 获取设备列表
  getEquipmentListApi: API_PREFIX_ASSEMBLY + '/EqpStateChange/GetEqpList',
  // 获取父级状态列表
  getParentStateListApi: API_PREFIX_ASSEMBLY + '/Status/GetParentStatusList',
  // 获取操作设备数据
  getOperateEquipmentDataApi: API_PREFIX_ASSEMBLY + '/EqpStateChange/GetFunction',
  // 获取设备即将操作数据
  getWillOperateDataApi: API_PREFIX_ASSEMBLY + '/EqpStateChange/ChangeFunction',
  // 获取一级状态列表
  getLevelOneStateListApi: API_PREFIX_ASSEMBLY + '/Status/GetParChildList',
  // 新增切状态
  createSwitchStateApi: API_PREFIX_ASSEMBLY + '/EqpStateChange/AddChange'
};
