import { API_PREFIX_ASSEMBLY, API_PREFIX_REPORT_MANAGE } from '../../common/common';

export const TheoryUphMaintainApis = {
  // 获取数据列表 | 导出数据
  getUphMaintainListApi: API_PREFIX_ASSEMBLY + '/UphSetting/GetList',
  // 获取单个详情
  getUphMaintainDetailApi: API_PREFIX_ASSEMBLY + '/UphSetting/Get',
  // 新增
  createUphMaintainApi: API_PREFIX_ASSEMBLY + '/UphSetting/Add',
  // 更新
  updateUphMaintainApi: API_PREFIX_ASSEMBLY + '/UphSetting/Update',
  // 删除
  deleteUphMaintainApi: API_PREFIX_ASSEMBLY + '/UphSetting/Delete',
  // 导入
  importUphMaintainApi: API_PREFIX_ASSEMBLY + '/upload/submit?name=UPHSettingExcelList',
  // 导出
  exportUphMaintainApi: API_PREFIX_ASSEMBLY + '/UphSetting/GetList',
  // 下载模板
  downloadUphMaintainApi: API_PREFIX_ASSEMBLY + '/download/GetTemplateStream?name=UPHSettingExcelList',
  // 修改记录
  modifyRecordApi: API_PREFIX_REPORT_MANAGE + '/TableChangeHistory/GetPageList'
};
