import { API_PREFIX_ASSEMBLY, API_PREFIX_CONFIG } from '../../common/common';

export const StateStandardDefinitionApis = {
  // 获取状态定义列表
  getStateDefinitionListApi: API_PREFIX_ASSEMBLY + '/Status/GetPageList',
  // 新增状态定义
  createStateDefinitionApi: API_PREFIX_ASSEMBLY + '/Status/Add',
  // 获取父级状态列表
  getParentStateListApi: API_PREFIX_ASSEMBLY + '/Status/GetParentStatusCodeList',
  // 获取时间稼动率列表
  getTimeGrainClassifyListApi: API_PREFIX_ASSEMBLY + '/Status/GetTimeRateList',
  // 获取EAP事件列表
  getEapEventListApi: API_PREFIX_ASSEMBLY + '/Common/GetEnumList?enumName=EqpStatusEnum&showType=0',
  // 删除
  deleteStateApi: API_PREFIX_ASSEMBLY + '/Status/Delete',
  // 更新
  updateStateApi: API_PREFIX_ASSEMBLY + '/Status/Update',
  // 获取单个状态详情
  getStateDetailApi: API_PREFIX_ASSEMBLY + '/Status/Get',
  // 获取状态名称列表
  getStateNameListApi: API_PREFIX_ASSEMBLY + '/Status/GetChildStatusCode',
  // 获取 新增 | 编辑 状态信息
  getStateInfoListApi: API_PREFIX_ASSEMBLY + '/Status/GetStatusInfo',
  // 获取角色列表
  getRoleListApi: API_PREFIX_CONFIG + '/Role/GetAll',
  // 获取关联设置信息
  getAssociateInfoDataApi: API_PREFIX_ASSEMBLY + '/Status/GetRelation',
  // 获取关联设置状态列表
  getAssociateStateListApi: API_PREFIX_ASSEMBLY + '/Status/GetSubStatusList',
  // 新增关联
  createAssociateSettingApi: API_PREFIX_ASSEMBLY + '/Status/AddRelation',
  // 新增关联
  updateAssociateSettingApi: API_PREFIX_ASSEMBLY + '/Status/UpdateRelation'
};
