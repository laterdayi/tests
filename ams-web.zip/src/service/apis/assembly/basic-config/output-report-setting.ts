import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const OutputReportSettingApis = {
  // 获取产量列表
  getOutputListApi: API_PREFIX_ASSEMBLY + '/OutputSetting/GetList',
  // 获取单个产量上报详情
  getOutputDetailApi: API_PREFIX_ASSEMBLY + '/OutputSetting/Get',
  // 更新
  updateOutputApi: API_PREFIX_ASSEMBLY + '/OutputSetting/Update',
  // 删除
  deleteOutputApi: API_PREFIX_ASSEMBLY + '/OutputSetting/Delete',
  // 新增产量上报
  createOutputReportApi: API_PREFIX_ASSEMBLY + '/OutputSetting/Add',
  // 获取产量类型列表
  getOutputTypeListApi: API_PREFIX_ASSEMBLY + '/OutputSetting/GetReportTypeList'
};
