import { API_PREFIX_TESTING } from '../../common/common';

export const OpenBatchApis = {
  // 获取数据列表 | 导出数据
  getOpenListApi: API_PREFIX_TESTING + '/user/getlist',
  // 获取单个详情
  getOpenDetailApi: API_PREFIX_TESTING + '/user/get',
  // 新增
  createOpenApi: API_PREFIX_TESTING + '/user/add',
  // 更新
  updateOpenApi: API_PREFIX_TESTING + '/user/update',
  // 删除
  deleteOpenApi: API_PREFIX_TESTING + '/user/delete',
  // 导入
  importOpenApi: API_PREFIX_TESTING + '/upload/submit?name=***',
  // 导出
  exportOpenApi: API_PREFIX_TESTING + '/dept/getlist',
  // 下载
  downloadOpenApi: API_PREFIX_TESTING + '/dept/getlist'
};
