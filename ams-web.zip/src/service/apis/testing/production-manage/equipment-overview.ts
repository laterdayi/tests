import { API_PREFIX_TESTING } from '../../common/common';

export const EquipmentOverviewApis = {
  // 获取页面详情
  getAllEqpStatesApi: API_PREFIX_TESTING + '/EqpMonitor/GetAllEqpStates'
};

export type StatusCountListType = { id: string; activeIsShow: boolean };
export type EqpStatesType = {
  id?: string;
  levelCount?: string;
  levelName?: string;
  datas?: BaseInfoDetailType[];
};
export type BaseInfoDetailType = {
  handlerId?: string;
  testerId?: string;
  lotId?: string;
  customerCode?: string;
  productModel?: string;
  packageType?: string;
  workorder?: string;
  itemcode?: string;
  waferVersion?: string;
  customerBatch?: string;
  stepcode?: string;
  stepname?: string;
  state?: string;
  stateMessage?: string;
  jobname?: string;
  eqpStatusStartTime?: string;
};
