import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const TheoryUphQueryApis = {
  // 页面表格列表,导出
  getListApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetList',
  // 新增备件基础
  addFormApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Add',
  // 获取备件基础
  getFromApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Get',
  // 修改备件基础
  updateApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Update',
  // 删除表格
  tableDeleteApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Delete',
  // 状态
  getHDStatusApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetHDStatus',
  // 当前状态
  getEnumListApi: API_PREFIX_ASSEMBLY + '/Common/GetEnumList?enumName=ToolingStateEnum',
  // 导入
  importUserApi: API_PREFIX_ASSEMBLY + '/upload/submit?name=ToolingBaseList',
  // 下载
  downloadApi: API_PREFIX_ASSEMBLY + '/download/GetTemplateStream?name=ToolingBaseList',
  // 获取用户列表 | 导出数据
  getUserListApi: API_PREFIX_ASSEMBLY + '/user/getlist'
};

export type ListType = {
  id: string;
  name: string;
  disabled?: boolean;
};

// 列表页,新增,编辑
export type QueryType = {
  treeId: string;
  eapIds: string;
  recipe: string;
  uph: string;
  isVerify: string;
};

export type TableListType = {
  id: string | number;
  eqpID: string;
  recipe: string;
  configCategory: string;
  uph: string;
  correctUPH: string;
  promote: string;
  modifyReason: string;
  verifyStatusString: string;
  remark: string;
  creator: string;
  createTime: string;
  editor: string;
  editTime: string;
};

export type FormType = {
  id?: string | number;
  eqpID: string;
  recipe: string;
  uph: string;
  configCategory: number;
  remark: string;
};
