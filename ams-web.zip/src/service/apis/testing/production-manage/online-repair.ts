import { API_PREFIX_TESTING } from '../../common/common';

export const OnlineRepairApis = {
  // 获取数据列表 | 导出数据
  getOnlineListApi: API_PREFIX_TESTING + '/user/getlist',
  // 获取单个详情
  getOnlineDetailApi: API_PREFIX_TESTING + '/user/get',
  // 新增
  createOnlineApi: API_PREFIX_TESTING + '/user/add',
  // 更新
  updateOnlineApi: API_PREFIX_TESTING + '/user/update',
  // 删除
  deleteOnlineApi: API_PREFIX_TESTING + '/user/delete',
  // 导入
  importOnlineApi: API_PREFIX_TESTING + '/upload/submit?name=***',
  // 导出
  exportOnlineApi: API_PREFIX_TESTING + '/dept/getlist',
  // 下载
  downloadOnlineApi: API_PREFIX_TESTING + '/dept/getlist'
};
