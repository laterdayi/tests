import { API_PREFIX_ASSEMBLY, API_PREFIX_TESTING } from '../../common/common';

export const WorkRecordApis = {
  // 页面表格列表,导出
  getListApi: API_PREFIX_TESTING + '/ELotInformation/GetELotInfoList',
  // 新增备件基础
  addFormApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Add',
  // 获取备件基础
  getFromApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Get',
  // 修改备件基础
  updateApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Update',
  // 删除表格
  tableDeleteApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/Delete',
  // 状态
  getHDStatusApi: API_PREFIX_ASSEMBLY + '/ToolingInfo/GetHDStatus',
  // 当前状态
  getEnumListApi: API_PREFIX_ASSEMBLY + '/Common/GetEnumList?enumName=ToolingStateEnum',
  // 导入
  importUserApi: API_PREFIX_ASSEMBLY + '/upload/submit?name=ToolingBaseList',
  // 下载
  downloadApi: API_PREFIX_ASSEMBLY + '/download/GetTemplateStream?name=ToolingBaseList',
  // 获取用户列表 | 导出数据
  getUserListApi: API_PREFIX_ASSEMBLY + '/user/getlist'
};

export type ListType = {
  id: string;
  name: string;
  disabled?: boolean;
};

// 列表页,新增,编辑
export type QueryType = {
  eqp1Id: string;
  timestamp: string[];
  lotId: string;
  workOrder: string;
  trProgram: string;
  productName: string;
  custLotId: string;
  custName: string;
  eqp2Id: string;
  headid: string;
  startTime?: string;
  endTime?: string;
};
export type ELotModelType = {
  id?: string | number;
  eId: number;
  eqp1Id: string;
  eqp2Id: string;
  systemTime: string;
  status: number;
  trStep: string;
  trackStamp: string;
  workOrder: string;
  productName: string;
  custName: string;
  custLotId: string;
  lotId: string;
  trProgram: string;
  nextSystemTime: string;
  statusName: string;
  duration: number;
  trackOutStamp: string;
  stepTime: string;
  remarkBtn: string;
  // summaryList: PageSumType[];
  lotInfoMergeNum: number;
  lotInfoRowIndex: number;
  stepMergeNum: number;
  stepRowIndex: number;
  stepSum: PageSumType;
  trackSum: PageSumType;
};
export type PageSumType = {
  good: number;
  reject: number;
  total: number;
  yiled: number;
};
export type TableListType = {
  eLotModel: ELotModelType[];
  pageSum: PageSumType;
};

export type RenderItemType = {
  color: string;
  name: string;
  text?: number;
};
