import { API_PREFIX_TESTING } from '../../common/common';

export const CloseBatchApis = {
  // 获取数据列表 | 导出数据
  getCloseListApi: API_PREFIX_TESTING + '/user/getlist',
  // 获取单个详情
  getCloseDetailApi: API_PREFIX_TESTING + '/user/get',
  // 新增
  createCloseApi: API_PREFIX_TESTING + '/user/add',
  // 更新
  updateCloseApi: API_PREFIX_TESTING + '/user/update',
  // 删除
  deleteCloseApi: API_PREFIX_TESTING + '/user/delete',
  // 导入
  importCloseApi: API_PREFIX_TESTING + '/upload/submit?name=***',
  // 导出
  exportCloseApi: API_PREFIX_TESTING + '/dept/getlist',
  // 下载
  downloadCloseApi: API_PREFIX_TESTING + '/dept/getlist'
};
