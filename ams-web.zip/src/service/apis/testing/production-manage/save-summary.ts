import { API_PREFIX_TESTING } from '../../common/common';

export const SaveSummaryApis = {
  // 获取数据列表 | 导出数据
  getSaveListApi: API_PREFIX_TESTING + '/user/getlist',
  // 获取单个详情
  getSaveDetailApi: API_PREFIX_TESTING + '/user/get',
  // 新增
  createSaveApi: API_PREFIX_TESTING + '/user/add',
  // 更新
  updateSaveApi: API_PREFIX_TESTING + '/user/update',
  // 删除
  deleteSaveApi: API_PREFIX_TESTING + '/user/delete',
  // 导入
  importSaveApi: API_PREFIX_TESTING + '/upload/submit?name=***',
  // 导出
  exportSaveApi: API_PREFIX_TESTING + '/dept/getlist',
  // 下载
  downloadSaveApi: API_PREFIX_TESTING + '/dept/getlist'
};
