import { API_PREFIX_CONFIG, API_PREFIX_TESTING } from '../../common/common';

export const EequipmentRealtimeMonitorApis = {
  // 获取页面详情
  getLayoutDetailApi: API_PREFIX_CONFIG + '/Layouts/Get',
  // 获取区域名称与布局名称默认值
  getUserLayoutApi: API_PREFIX_TESTING + '/EqpMonitor/GetUserLayout',
  //  布局Id获取设备及状态
  getEqpInfoApi: API_PREFIX_TESTING + '/EqpMonitor/GetEqpInfo',
  //  获取机器详情base
  getEqpStateInfoApi: API_PREFIX_TESTING + '/EqpMonitor/GetEqpStateInfo',
  //  获取机器详情uph
  getUPHInfoApi: API_PREFIX_TESTING + '/EqpMonitor/GetUPHInfo'
};
export type QueryFormType = {
  areaName: string;
  layoutId: string;
};
export type EqpInfoListType = {
  action: string;
  color: string;
  handlerId: string;
  eqp2Id: string;
  headId: string;

  lotId: string;
  mesEqpStatus: string;
  status: string;
  testerId: string;

  width: number;
  height: number;
  top: number;
  left: number;
};

export type SchemasColor = {
  name: string;
  nameType: string;
  color: string;
};
export type StatusCountListType = {
  status: string;
  statusName: string;
  qty: number;
  qtyName: string;
  imgSrc: string;
  background: string;
  borderColor: string;
};

export type BaseInfoDetailType = {
  handlerId?: string;
  testerId?: string;
  lotId?: string;
  customerCode?: string;
  productModel?: string;
  packageType?: string;
  workorder?: string;
  itemcode?: string;
  waferVersion?: string;
  customerBatch?: string;
  stepcode?: string;
  stepname?: string;
  state?: string;
  stateMessage?: string;
  jobname?: string;
  eqpStatusStartTime?: string;
};
export type UphInfoDetailType = {
  targetUph?: string;
  avgUph?: string;
  trackInTime?: string;
  testedTime?: string;
  totalOutputQty?: string;
};
