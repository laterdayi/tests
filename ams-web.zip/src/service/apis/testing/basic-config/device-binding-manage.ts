import { API_PREFIX_CONFIG, API_PREFIX_TESTING } from '../../common/common';

export const DeviceBindingManageApis = {
  // 获取列表
  getPageListApi: API_PREFIX_TESTING + '/EqpBinding/GetPageList',
  // 详情
  detailApi: API_PREFIX_TESTING + '/EqpBinding/Get',
  // 添加
  addApi: API_PREFIX_TESTING + '/EqpBinding/Add',
  // 删除设备
  deleteApi: API_PREFIX_TESTING + '/EqpBinding/Delete',
  // 更新单
  updateApi: API_PREFIX_TESTING + '/EqpBinding/Update',
  // 获取测试机/分选机
  getAllEqpListApi: API_PREFIX_CONFIG + '/EquipmentBase/GetAllEqpList'
};
export type QueryType = {
  eqpName: string;
};
export type EditType = {
  handlerId: null;
  testerId?: null;
};
export type TableListType = {
  id?: string | number;
  handlerId: string;
  testerId: string;
  creator: string;
  createTime: string;
  editor: string;
  editTime: string;
};
