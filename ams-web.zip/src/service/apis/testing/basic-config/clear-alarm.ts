import { API_PREFIX_TESTING } from '../../common/common';

export const ClearAlarmApis = {
  // 获取列表
  getPageListApi: API_PREFIX_TESTING + '/AlarmHistory/GetPageList',
  // 清除报警
  cleanAlarmApi: API_PREFIX_TESTING + '/AlarmHistory/CleanAlarm',
  // 获取详情
  getDetailsApi: API_PREFIX_TESTING + '/AlarmHistory/Get'
};
export interface QueryType {
  customerCode: string;
  packageType: string;
  model: string;
  waferVersion: string;
  itemCode: string[];
  stepName: string;
  lotId: string;
  program: string;
  timestamp: string[];
}
export interface TableListType {
  createTime?: string;
  handlerId?: string;
  creator?: string;
  customerCode?: string;
  editTime?: string;
  editor?: string;
  status?: OpenStateType;
  id?: string;
  itemCode?: string;
  lotId?: string;
  model?: string;
  packageType?: string;
  program?: string;
  projectCode?: string;
  stepName?: string;
  waferVersion?: string;
  state?: number;
  systemTime?: string;
  stateMessage?: string;
  cleaner?: string;
  cleanTime?: string;
  cleanComment?: string;
}
export interface SelectDataType {
  customerCodeList: OptionsType[];
  packageTypeNameList: OptionsType[];
  modelList: OptionsType[];
  waferVersionList: OptionsType[];
  itemCodeList: OptionsType[];
  stepNameList: OptionsType[];
  ruleTypeList: OptionsType[];
  ruleStatusList: OptionsType[];
  passOnlyList: OptionsType[];
  ruleApplyScopeList: OptionsType[];
  bySiteList: OptionsType[];
  operLogicList: OptionsType[];
}
export interface ClearAlarmModelType {
  comment: string;
}
