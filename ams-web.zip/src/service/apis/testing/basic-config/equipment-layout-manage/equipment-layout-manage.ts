import { API_PREFIX_CONFIG } from '../../../common/common';

export const EquipmentLayoutManageApis = {
  // 获取设备布局管理列表
  getEquipmentLayoutListApi: API_PREFIX_CONFIG + '/Layouts/GetList',
  // 获取区域名称列表
  getAreaNameListApi: API_PREFIX_CONFIG + '/Layouts/GetEqpAreasList',
  // 删除
  deleteEquipmentLayoutApi: API_PREFIX_CONFIG + '/Layouts/Delete',
  // 更新
  updateEquipmentLayoutApi: API_PREFIX_CONFIG + '/Layouts/update',
  // 新增产量上报
  createEquipmentLayoutApi: API_PREFIX_CONFIG + '/Layouts/Add',
  // 获取单个设备布局详情
  getEquipmentLayoutDetailApi: API_PREFIX_CONFIG + '/Layouts/Get',
  // 拷贝布局
  copyEquipmentLayoutApi: API_PREFIX_CONFIG + '/Layouts/Copy',
  // 获取来源布局
  getSourceLayoutListApi: API_PREFIX_CONFIG + '/Layouts/GetLayoutNameList',
  // 获取机台
  getMachineListApi: API_PREFIX_CONFIG + '/LayoutEqps/GetList'
};
