import { API_PREFIX_CONFIG } from '../../../common/common';

export const EquipmentLayoutDetailApis = {
  // 获取设备列表
  getEquipmentListApi: API_PREFIX_CONFIG + '/LayoutEqps/GetList',
  // 获取容器详情
  getContainerDataApi: API_PREFIX_CONFIG + '/Layouts/Get',
  // 添加设备
  addEquipmentApi: API_PREFIX_CONFIG + '/LayoutEqps/Add',
  // 删除设备
  deleteEquipmentApi: API_PREFIX_CONFIG + '/LayoutEqps/Delete',
  // 更新多设备
  updateMultiEquipmentApi: API_PREFIX_CONFIG + '/LayoutEqps/Update',
  // 更新单设备
  updateEquipmentApi: API_PREFIX_CONFIG + '/LayoutEqps/UpdateFormat'
};
