import { API_PREFIX_CONFIG } from '../../common/common';

export const RuleConfigApis = {
  // 获取数据列表 | 导出数据
  getRuleListApi: API_PREFIX_CONFIG + '/RuleConfig/GetPageList',
  // 新增
  createRuleApi: API_PREFIX_CONFIG + '/RuleConfig/SaveRuleCondition',
  // 删除
  deleteRuleApi: API_PREFIX_CONFIG + '/RuleConfig/Delete',
  // 更细启用状态
  updateStartUseStateApi: API_PREFIX_CONFIG + '/RuleConfig/ChangeStatus',
  // 新增子规则
  createSubRuleApi: API_PREFIX_CONFIG + '/RuleConfig/SaveRuleContent',
  // 获取子规则列表
  getSubRuleListApi: API_PREFIX_CONFIG + '/RuleConfig/GetChildren',
  // 获取选择框数据
  getSelectDataApi: API_PREFIX_CONFIG + '/RuleConfig/GetSelectItem',
  // 更新子规则
  updateSubRuleApi: API_PREFIX_CONFIG + '/RuleConfig/Update',
  // 删除子规则
  deleteSubRuleApi: API_PREFIX_CONFIG + '/RuleConfig/RuleContentDelete',
  // 新增子子规则
  createSubSubRuleApi: API_PREFIX_CONFIG + '/RuleConfig/SaveSubRuleContent',
  // 更新子子规则
  updateSubSubRuleApi: API_PREFIX_CONFIG + '/RuleConfig/SubRuleUpdate',
  // 获取子子规则列表
  getSubSubRuleListApi: API_PREFIX_CONFIG + '/RuleConfig/GetSubChildren',
  // 删除子子规则列表
  deleteSubSubRuleApi: API_PREFIX_CONFIG + '/RuleConfig/SubRuleContentDelete',
  // 导入
  importRuleApi: API_PREFIX_CONFIG + '/upload/submit?name=ruleConfigList',
  // 下载模板
  downloadRuleApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=ruleConfigList'
};
