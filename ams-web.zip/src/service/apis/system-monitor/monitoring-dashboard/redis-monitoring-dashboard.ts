import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const RedisMonitoringDashboardApis = {
  // 获取Redis节点列表
  getRedisNodeListApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetRedisNodeList',
  // 获取Redis资源异常列表
  getRedisResourceExceptionsApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetRedisResourceExceptions',
  // 获取redis节点统计
  getRedisNodeStatisticsApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetRedisNodeStatistics',
  // 获取折线数据
  getRedisResourceUsagesApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetRedisResourceUsages'
};
export type RedisNodeListType = {
  [key: string]: string | number;
  node: string;
  startTime: string;
  status: number;
};
export type RedisResourceExceptionsType = {
  createTime: string;
  exceptionInfo: string;
  isSendEmail: number;
  node: string;
};
export type RedisNodeStatisticsType = {
  exceptionCount: number;
  normalCount: number;
  totalCount: number;
};

export type RedisResourceUsagesDataType = {
  [key: string]: string | ResourceUsagesListType[];
  node: string;
  cpuUsages: ResourceUsagesListType[];
  memoryUsages: ResourceUsagesListType[];
  memFragmentationUsages: ResourceUsagesListType[];
  clientConnectCountUsages: ResourceUsagesListType[];
};
export type ResourceUsagesListType = {
  count: number;
  time: string;
};
