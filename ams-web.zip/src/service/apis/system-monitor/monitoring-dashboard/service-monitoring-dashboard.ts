import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const MonitoringDashboardApis = {
  // 获取服务状态列表
  getListApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetList',
  // 获取服务资源使用情况
  getResourceUsagesApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetResourceUsages',
  // 获取服务统计
  getServiceStatisticsApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetServiceStatistics',
  // 获取异常动态
  getExceptionsApi: API_PREFIX_SYSTEM_MONITOR + '/MonitorDashboard/GetExceptions'
};
export type ServiceType = {
  [key: string]: string | number;
  port: number;
  serverIp: string;
  serverName: string;
  startTime: string;
  status: number;
};
export type ResourceUsagesType = {
  [key: string]: string | number | ResourceUsagesListType[];
  port: number;
  serverIp: string;
  serverName: string;
  blockUsages: ResourceUsagesListType[];
  cpuUsages: ResourceUsagesListType[];
  memoryUsages: ResourceUsagesListType[];
  threadCountUsages: ResourceUsagesListType[];
};
export type ResourceUsagesListType = {
  count: number;
  time: string;
};
export type ServiceStatisticsType = {
  exceptionCount: number;
  normalCount: number;
  totalCount: number;
};
export type ExceptionsType = {
  createTime: string;
  exceptionInfo: string;
  port: number;
  serverIp: string;
  serverName: string;
};
