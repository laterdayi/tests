import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const TaskPlanCommonApis = {
  // 获取任务状态列表
  getTaskStateApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/GetTaskStatusList',
  // 获取任务类型列表
  getTaskTypeListApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/GetTaskTypeList'
};
