import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const TaskExecuteRecordApis = {
  // 获取任务列表
  getTaskListApi: API_PREFIX_SYSTEM_MONITOR + '/jobdetail/GetPageList',
  // 获取任务日志列表
  getTaskLogListApi: API_PREFIX_SYSTEM_MONITOR + '/JobLog/GetLogs'
};
