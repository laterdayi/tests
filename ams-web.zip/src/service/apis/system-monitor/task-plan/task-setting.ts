import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const TaskSettingApis = {
  // 获取任务列表
  getTaskListApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/GetPageList',
  // 新增任务
  addTaskApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/Add',
  // 获取任务设定单个详情
  getTaskSettingDetailApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/Get',
  // 更新
  updateTaskSettingApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/Update',
  // 删除
  deleteTaskSettingApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/Delete',
  // 获取cron摘要
  getCronDescriptionApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/GetDescAndTimes',
  // 立即执行
  executeNowTaskApi: API_PREFIX_SYSTEM_MONITOR + '/JobMain/ExecuteNow'
};
