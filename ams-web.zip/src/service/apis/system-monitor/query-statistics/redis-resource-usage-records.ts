import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const RedisResourceUsageRecordsApis = {
  // 获取资源使用记录列表
  getListApi: API_PREFIX_SYSTEM_MONITOR + '/RedisResource/GetList',
  // 获取资源使用趋势列表
  getResourceUsageTrendApi: API_PREFIX_SYSTEM_MONITOR + '/RedisResource/GetResourceUsageTrend',
  // 获取redis节点下拉列表
  getRedisNodeListApi: API_PREFIX_SYSTEM_MONITOR + '/RedisResource/GetRedisNodeList'
};
export type QueryType = {
  node: string;
  timestamp: string[];
};

export type TableListType = {
  id: string;
  node: string;
  usedMemoryRss: number;
  memoryPercent: number;
  usedMemory: number;
  memoryTotal: number;
  memFragmentationRatio: number;
  cpuPercent: number;
  connectedClients: number;
  blockedClients: number;
  rejectedConnections: number;
  evictedKeys: number;
  keyMisses: number;
  createTime: string;
  isSendEmail: number
  exceptionInfo: string
};
export type QueryTrendType = {
  type: number;
  node: string;
  timestamp: string[];
};
export type ResourceUsageTrendType = {
  threshold: number;
  usages: usagesType[];
};
export type usagesType = {
  time: string;
  count: number;
};
