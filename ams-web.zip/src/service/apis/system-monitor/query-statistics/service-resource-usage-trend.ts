import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const ResourceUsageTrendApis = {
  // 获取资源使用趋势
  getResourceUsageTrendApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceUsage/GetResourceUsageTrend'
};
export type QueryType = {
  serverIp: string;
  port: string;
  type: number;
  timestamp: string[];
};

export type ResourceUsageTrendType = {
  threshold: number;
  usages: usagesType[];
  serviceName: string
};
export type usagesType = {
  time: string;
  count: number;
};
