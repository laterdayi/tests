import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const ResourceUsageRecordsApis = {
// 获取列表
getListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceUsage/GetList',
 // 获取服务IP
 getServiceIpListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceUsage/GetServiceIpList',
 // 获取端口
 getServicePortListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceUsage/GetServicePortList'
};
export type QueryType = {
  serverIp: string
  port: string
  serverName: string
  timestamp: string[];
};

export type TableListType = {
  id: string
  serverIp: string
  port: number
  serverName: string
  cpuPercent: number
  memoryUse: number
  memoryPercent: number
  memoryTotal: number
  threadCount: number
  block: number
  createTime: string
  exceptionInfo: string
  isSendEmail: number
};
