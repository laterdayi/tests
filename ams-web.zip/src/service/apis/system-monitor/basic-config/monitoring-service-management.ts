import { API_PREFIX_CONFIG, API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const MonitoringServiceManagementApis = {
  // 获取列表
  getListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/GetList',
  // 新增
  addApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Add',
  // 详情
  getDetailApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Get',
  // 编辑
  updateApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Update',
  // 删除
  deleteApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Delete',
  // 通知人列表
  getAllUserIdsApi: API_PREFIX_CONFIG + '/User/GetAllUserIds',
  // 服务名称列表
  getServiceNameListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/GetServiceNameList'
};
export type QueryType = {
  serverIp: string;
  port: string;
  serverName: string;

};
export type EditType = {
  serverIp: string;
  port: string;
  serverName: string;
  cpuThreshold: number;
  memoryThreshold: number;
  threadCountThreshold: number;
  blockThreshold: number;
  notifiedUserList: string;
  consecutiveTimes: number
};

export type TableListType = {
  id: string;
  serverIp: string;
  port: string;
  serverName: string;
  cpuThreshold: number;
  memoryThreshold: number;
  threadCountThreshold: number;
  blockThreshold: number;
  consecutiveTimes: number
  notifiedUserList: string[];
};
