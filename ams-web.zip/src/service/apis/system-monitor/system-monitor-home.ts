import { API_PREFIX_SYSTEM_MONITOR } from '../common/common';

export const SystemMonitorHomeApis = {
  // 获取数据
  getDataApi: API_PREFIX_SYSTEM_MONITOR + '/ApiHistory/GetTops'
};
