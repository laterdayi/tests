import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const ServerManageApis = {
  // 获服务器管理列表
  getServerManageListApi: API_PREFIX_SYSTEM_MONITOR + '/SeverIp/GetList',
  // 获服务器单个详情
  getServerManagDetailApi: API_PREFIX_SYSTEM_MONITOR + '/SeverIp/Get',
  // 新增服务器
  addServerApi: API_PREFIX_SYSTEM_MONITOR + '/SeverIp/Add',
  // 删除服务器
  deleteServerApi: API_PREFIX_SYSTEM_MONITOR + '/SeverIp/Delete',
  // 更新服务器
  updateServerApi: API_PREFIX_SYSTEM_MONITOR + '/SeverIp/Update'
};
