import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const ResourceAlarmSettingApis = {
  // 获取报警列表
  getAlarmListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/getList',
  // 获取报警单个详情
  getAlarmDetailApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/get',
  // 新增报警
  addAlarmApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Add',
  // 删除报警
  deleteAlarmApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Delete',
  // 更新报警
  updateAlarmApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceSet/Update'
};
