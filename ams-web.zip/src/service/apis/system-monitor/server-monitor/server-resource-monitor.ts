import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const ServerResourceMonitorApis = {
  // 获取服务器IP列表
  getServerIpListApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceUsage/GetServerIpList',
  // 获取资源监控数据
  getResourceMonitorApi: API_PREFIX_SYSTEM_MONITOR + '/ResourceUsage/GetResourceUsages'
};
