import { API_PREFIX_CONFIG, API_PREFIX_SYSTEM_MONITOR } from '../common/common';

export const AlarmSystemSettingApis = {
  // 获取redis资源监控设置
  getRedisResourceApi: API_PREFIX_SYSTEM_MONITOR + '/RedisResourceSet/Get',
  // 保存redis资源监控设置
  setRedisResourceApi: API_PREFIX_SYSTEM_MONITOR + '/RedisResourceSet/Setting',
  // 获取监控看板设置
  getMonitorBoardSettingApi: API_PREFIX_CONFIG + '/SystemSetting/GetMonitorBoardSetting',
  // 保存监控看板设置
  setMonitorBoardSettingApi: API_PREFIX_CONFIG + '/SystemSetting/SetMonitorBoardSetting',
};

export type RedisResourceType = {
  cpuThreshold: number;
  memoryThreshold: number;
  memFragmentationThreshold: number;
  clientConnectCountThreshold: number;
  notifiedUserList: string[];
  consecutiveTimes: number;
}
export type MonitorBoardSettingType = {
  refreshRate: number;
}
