import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const BusinessOperateRecordApis = {
  // 获取操作记录列表
  getBusinessOperateRecordListApi: API_PREFIX_SYSTEM_MONITOR + '/TableChangeHistory/GetPageList'
};
export interface QueryType {
  key?: string
  tableName?: string
  operateType?: string
  timestamp: string[]
}

export interface TableListType {
  id?: string
  businessName: string
  changeType: string
  createTime: string
  creator: string
  keyId: string
  new: string
  old: string
}
