import { API_PREFIX_CONFIG } from '../../common/common';

export const ButtonClickRecordApis = {
  // 页面表格列表
  getListApi: API_PREFIX_CONFIG + '/ButtonOperate/GetList',
  // 页面表格列表
  getEnumListApi: API_PREFIX_CONFIG + '/ButtonOperate/GetBussinessModules'
};
export type QueryType = {
  buttonName: string;
  bussinessModule: string;
  timestamp: string[];
};
export type TableListType = {
  id: number;
  buttonName: string;
  bussinessModule: string;
  pageName: string;
  clientIpAddress: string;
  serverIpAddress: string;
  operateUserID: string;
  operateTime: string;
};
