import { API_PREFIX_SYSTEM_MONITOR } from '../../common/common';

export const ApiRequestRecordApis = {
  // 获取接口请求记录列表
  getApiRequestRecordListApi: API_PREFIX_SYSTEM_MONITOR + '/ApiHistory/GetList',
  // 获取模块列表
  getModuleListApi: API_PREFIX_SYSTEM_MONITOR + '/ApiHistory/GetBussinessModules'
};
