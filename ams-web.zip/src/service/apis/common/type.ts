import type { LayoutType } from '@/constants/enum';

// 菜单列表
export interface MenuListType {
  routeName: null | string;
  routeAddress: null | string;
  hasChildren: boolean;
  visible: number;
  icon: null | string;
  id: string;
  isLeaf: boolean;
  order: number;
  path: string;
  pid: string;
  type: number;
  category: number;
  is_superadmin: number;
  componentPath: string;
  label: string;
  link: number;
  powers: string[];
  powersList?: string[];
  powersPosition?: string[];
  children?: MenuListType[];
  isClosePower?: OpenStateType;
}

// 路由
export interface RouteType {
  name: string;
  path: string;
  component: string;
  redirect?: string;
  meta: Partial<RouteMeta>;
  children?: RouteType[];
}

export interface RouteMeta {
  icon: string;
  link: number;
  title: string;
  noCache: boolean;
  hidden: boolean;
  remark?: string;
  layoutType?: LayoutType;
  powers: string[];
}

// 产线层级列表
export interface ProductionLineLevelType {
  createTime: string;
  creator: string;
  description: string;
  id: string;
  isLeaf: boolean;
  levelName: string;
  name: string;
  parentId: string;
  parentName: string;
  source: string;
  children: ProductionLineLevelType[];
}
