// API 模块前缀
export const API_PREFIX_CONFIG = '/config';
export const API_PREFIX_REPORT_MANAGE = '/reportManage';
export const API_PREFIX_SYSTEM_MONITOR = '/reportManage';
export const API_PREFIX_AMS = '/ams';
export const API_PREFIX_ASSEMBLY = '/assembly';
export const API_PREFIX_TESTING = '/testing';
export const API_PREFIX_PMS = '/pms';

export const CommonApis = {
  // 获取下拉服务器列表
  getServerIpListSelectApi: API_PREFIX_REPORT_MANAGE + '/SeverIp/GetServerIpList',
  // 获取收件人列表
  getEmailRecipientListApi: API_PREFIX_CONFIG + '/User/GetAllMailRecipient',
  // 获取所有完整路由
  getAllMenusListApi: API_PREFIX_CONFIG + '/Menu/Get?pid=0',
  // 获取产品列表
  getProductListApi: API_PREFIX_CONFIG + '/Common/GetEnEnumList?enumName=ProductModule',
  // 获取模块列表
  getModuleListApi: API_PREFIX_CONFIG + '/common/GetEnumList?enumName=BussinessModule&showType=0',
  // 发送按钮点击记录
  sendButtonClickRecordApi: API_PREFIX_CONFIG + '/ButtonOperate/Add',
  // 上传文件 Base64
  uploadFileBase64Api: API_PREFIX_CONFIG + '/File/UploadFileBase64',
  // 上传文件
  uploadFileApi: API_PREFIX_CONFIG + '/MinioFile/UploadFileByMinio',
  // 下载模版
  downloadTemplateApi: API_PREFIX_CONFIG + '/download/GetTemplateStream',
  // 设备编号列表
  getEquipmentNumberListApi: API_PREFIX_CONFIG + '/equipmentbase/GetEqpNameList',
  // 获取设备编号列表 - 带ID
  getEquipmentNumberIdListApi: API_PREFIX_CONFIG + '/EquipmentBase/GetEqpIdNameList',
  // 获取产线层级列表
  getProductionLineLevelApi: API_PREFIX_CONFIG + '/LayoutStructure/GetTree',
  // 获取产线层级列表 - 查询
  getProductionLineLevelQueryApi: API_PREFIX_CONFIG + '/LayoutStructure/GetLayoutTree',
  // 获取子设备编号
  getChildEquipmentListApi: API_PREFIX_CONFIG + '/LayoutStructure/GetChildEqps',
  // 获取多个子设备编号
  getMultiChildEquipmentListApi: API_PREFIX_CONFIG + '/LayoutStructure/GetChildEqpsMulti',
  //  根据多个产线层级获取设备编号
  getEqpsByLayoutIdsApi: API_PREFIX_CONFIG + '/LayoutStructure/GetEqpsByLayoutIds',
  // 获取系统名称列表
  getSystemNameListApi: API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.systemName}`,
  // 数据字典内容获取
  getSelectItemListApi: API_PREFIX_CONFIG + '/Attributes/GetSelectItemList'
};
