import { API_PREFIX_PMS } from '../common/common';

export const PmsHomeApis = {
  // 获取列表
  getToBePMEqpsAndToolingsApi: API_PREFIX_PMS + '/PMHomePage/GetToBePMEqpsAndToolings'
};
// 公共demo
export type TypeDemoType = {
  class: string;
  title: string;
  total: number;
  key: string;
  background: string;
};
// 列表页
export type QueryType = {
  toolingBarcode: string;
  timestamp: string[];
};
// 列表
export type TableListType = {
  toBePMEqps: ToBePMEqpsType[];
  toBePMToolings: ToBePMToolingsType[];
};

export type ToBePMEqpsType = {
  eqpName: string;
  line: string;
  planExecuteTime: string;
  planExecutorList: string[];
  planHours: string;
  scheduleName: string;
};

export type ToBePMToolingsType = {
  hdStatus: string;
  lifeTime: string;
  owner: string;
  seriesNo: string;
  stock: string;
  toolingBarcode: string;
  toolingModel: string;
  toolingType: string;
  usedTime: string;
};
