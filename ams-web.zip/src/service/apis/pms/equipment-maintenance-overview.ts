import { API_PREFIX_PMS } from '../common/common';

export const EquipmentMaintenanceOverviewApis = {
  // 获取列表
  getRepairStateApi: API_PREFIX_PMS + '/RepairState/GetRepairState',
  // 获取单个报修详情
  getEqpRepairApi: API_PREFIX_PMS + '/RepairState/GetEqpRepair'
};

type RepairStateListType = {
  id: string;
  levelCount: number;
  levelName: string;
  datas: RepairStateDatasType[];
};

export type TypeDemoType = {
  key: number | string;
  class: string;
  type: number;
  color: string;
  background: string;
  title?: string;
  state: number;
  total?: number | RepairStateListType[];
  eqp?: string;
};
export type RepairStateDatasType = {
  eqpId: string;
  state: number;
};
export type RepairStateType = {
  list: RepairStateListType[];
  awaitingRepairNumber: number;
  eqpReceiveNumber: number;
  normalNumber: number;
  toBeConfirmedNumber: number;
  toTakeOverNumber: number;
};
export type TypeObjType = {
  name: string;
  color: string;
  background: string;
};
export type DetailsType = {
  description: string;
  state: number;
};
