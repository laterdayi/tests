import { API_PREFIX_PMS } from '../common/common';
import type { ItemListType } from '@/utils/project/electronic-form/electronic-form-type';

export const EquipmentMaintainOverviewApis = {
  // 获取列表
  getEquipmentListApi: API_PREFIX_PMS + '/PMState/GetPMState',
  // 获取详情
  getEquipmentDetailDataApi: API_PREFIX_PMS + '/PMState/GetEqpPM',
  // 获取电子表单信息--->pm
  getEFormInfoApi: API_PREFIX_PMS + '/PM/GetEFormInfo',
  // 电子表单提交
  savePMHandlerFormApi: API_PREFIX_PMS + '/PM/SavePMHandlerForm',
  // 维修确认提交(data验证)
  checkSampleLimitApi: API_PREFIX_PMS + '/PM/CheckSampleLimit',
  // 获取电子表单信息--->Buyoff
  getAuditScheduleApi: API_PREFIX_PMS + '/PM/GetAuditSchedule',
  // 通过
  auditPassApi: API_PREFIX_PMS + '/PM/AuditPass'
};
// 列表
export type RepairStateType = {
  normalNum: number;
  overdueNum: number;
  toBePMNum: number;
  list: RepairStateListType[];
};

export type RepairStateListType = {
  id: string;
  levelCount: number;
  levelName: string;
  datas: RepairStateDatasType[];
};

export type RepairStateDatasType = {
  eqpId: string;
  eqpState: string;
  pmState: number;
};
export type TypeObjType = {
  name: string;
  color: string;
  background: string;
};
export type TypeDemoType = {
  key: number | string;
  class: string;
  type: number;
  color: string;
  background: string;
  title?: string;
  state: number;
  total?: number | RepairStateListType[];
  eqp?: string;
};
// 详情
export interface DetailsType {
  eqpId: string;
  eqpState: string;
  stateChangeTime: string;
  prevMaintain: string;
  nextMaintain: string;
  maintainPlan: string;
  description: string;
  executorList: string[];
  remark: string;
}

export interface EquipmentType {
  eqpId: string;
  state: number;
}
export interface OperateEquipmentDataType {
  eqpState: string;
  stateChangeTime: string;
  scheduleList: OptionsType[];
}
// 电子表单-pm
export interface PmDetailsListType {
  name: string;
  index: number;
  eFormId: string;
  pmId: string;
  prefix: string;
  sampleNum: number;
  testNum: number;

  typeTableData: ItemListType[];
  nameTableData: ItemListType[];
  goldSampleTableData: ItemListType[];
  goldSampleDataColumns: DataTableColumns<ItemListType>;
  itemList: ItemListType[];
  goldSampleTableScroll: number;
  tabIsShow: boolean;
}
// 电子表单-buyoff
export interface BuyoffDetailsListType {
  id: string;
  scheduleName: string;
  formData: BuyoffFormDataType;
  tableData: TableDataType[];
  expandedList: string[];
}
export interface OperateHistoryType {
  line: string;
  actualExecuteTime: string;
  actualExecutorList: string[];
  eqpName: string;
  id?: string;
  planExecuteTime: string;
  planExecutorList: string[];
  planHours: number;
  scheduleName: string;
  histories?: TableDataType[];
}
export interface BuyoffFormDataType {
  line: string;
  actualExecuteTime: string;
  actualExecutorList: string[];
  eqpName: string;
  id: string;
  planExecuteTime: string;
  planExecutorList: string[];
  planHours: number;
  scheduleName: string;
}

export interface TableDataType {
  id: string;
  operateTime: string;
  operateType: number;
  operator: string;
  pmeFormId: string;
  remark: string;

  formType?: string;
  fromResult?: number;
  typeTableData?: ItemListType[];
  nameTableData?: ItemListType[];
  goldSampleTableData?: ItemListType[];
  goldSampleTableColumns?: DataTableColumns<ItemListType>;
  goldSampleTableScroll?: number;
}
