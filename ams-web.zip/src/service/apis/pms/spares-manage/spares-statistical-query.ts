import { API_PREFIX_PMS } from '../../common/common';

export const SparesStatisticalQueryApis = {
  // 领还
  getCollectAndReturnApi: API_PREFIX_PMS + '/ToolingLendAndReturnRecord/GetList',
  // 保养
  getPreserveApi: API_PREFIX_PMS + '/ToolingMaintain/GetList?maintainType=1',
  // 维护
  getRepairApi: API_PREFIX_PMS + '/ToolingMaintain/GetList?maintainType=2,3',
  // 库存
  getStockApi: API_PREFIX_PMS + '/ToolingStockSummary/GetStockCountList',
  // 库存专用类别
  getToolingTypeIdListApi: API_PREFIX_PMS + '/ToolingType/GetToolingTypeIdList'
};

export type ListType = {
  id: string;
  name: string;
};

// 列表页
export type QueryType = {
  area: string;
  stage: string;
  toolingBarcode: string;
  toolingMode: string;
  toolingType: string;
  timestamp: string[];
};
export type TableListType = {
  toolingBarcode: string;
  toolingType: string;
  toolingModel: string;
  flag: string;
  applicant: string;
  applyTime: string;
  reason: string;
  confirmer: string;
  confirmTime: string;
  remark: string;
  actionType: string | number;
  resetFlag: string | number;
};
// 报废弹窗
export type ScrapFormType = {
  toolingBarcde: string;
  applicant: string;
  confirmer: string;
  remark: string;
};
export type TableColumnsType = {
  toolingBarcode: string;
  toolingType: string;
  toolingModel: string;
};
// 申请报废
export type ApplyForScrappingTableColumnsType = {
  stock: string;
  hdStatus: string;
  reason: string;
  userId: string;
};
// 确认报废
export type ConfirmScrapTableColumnsType = {
  stock: string;
  hdStatus: string;
  applicant: string;
  applyTime: string;
};
