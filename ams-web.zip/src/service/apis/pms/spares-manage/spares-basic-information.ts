import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const SparesBasicInformationApis = {
  // 页面表格列表,导出
  getListApi: API_PREFIX_PMS + '/ToolingInfo/GetList',
  // 新增备件基础
  addFormApi: API_PREFIX_PMS + '/ToolingInfo/Add',
  // 获取备件基础
  getFromApi: API_PREFIX_PMS + '/ToolingInfo/Get',
  // 修改备件基础
  updateApi: API_PREFIX_PMS + '/ToolingInfo/Update',
  // 删除表格
  tableDeleteApi: API_PREFIX_PMS + '/ToolingInfo/Delete',
  // 状态
  getHDStatusApi: API_PREFIX_PMS + '/ToolingInfo/GetHDStatus',
  // 当前状态
  getEnumListApi: API_PREFIX_CONFIG + '/Common/GetEnumList?enumName=ToolingStateEnum',
  // 导入
  importUserApi: API_PREFIX_CONFIG + '/upload/submit?name=ToolingBaseList',
  // 下载
  downloadApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=ToolingBaseList',
  // 获取用户列表 | 导出数据
  getUserListApi: API_PREFIX_PMS + '/user/getlist',
  // 领用,发放,上机,下机详情
  getToolingInfoApi: API_PREFIX_PMS + '/ToolingInfo/GetToolingInfo',
  // 领用提交
  getLendToolingApi: API_PREFIX_PMS + '/ToolingAction/LendTooling',
  // 发放提交
  grantToolingApi: API_PREFIX_PMS + '/ToolingAction/GrantTooling',
  // 上机head
  getSiteIdListApi: API_PREFIX_CONFIG + '/EquipmentBase/GetSiteIdList',
  // 上机提交
  toolingLendOnEqpApi: API_PREFIX_PMS + '/ToolingAction/ToolingLendOnEqp',
  // 下机提交
  toolingGetOffEqpApi: API_PREFIX_PMS + '/ToolingAction/ToolingGetOffEqp',
  // 设备编号查询
  getAllToolingOnEqpApi: API_PREFIX_PMS + '/ToolingInfo/GetAllToolingOnEqp',
  // 维护提交
  maintainToolingApi: API_PREFIX_PMS + '/ToolingAction/MaintainTooling',
  // 归还提交
  returnToolingApi: API_PREFIX_PMS + '/ToolingAction/ReturnTooling',
  // 接收提交
  takebackToolingApi: API_PREFIX_PMS + '/ToolingAction/TakebackTooling',
  // 外修归还提交
  repairReturnApi: API_PREFIX_PMS + '/ToolingAction/RepairReturn',
  // 获取供应商编码
  getSupplierCodeListApi: API_PREFIX_CONFIG + '/Supplier/GetIDAndName',
  // 获取责任人列表
  getResponsibleListApi: API_PREFIX_CONFIG + '/User/GetAllUsers',
  // 获取备件型号树列表
  getSpareModelTreeListApi: API_PREFIX_PMS + '/ToolingInfo/GetTree',
  // 备件详情
  getToolingInfoDetailApi: API_PREFIX_PMS + '/ToolingInfo/GetToolingInfoDetail'
};

export type ListType = {
  id: string;
  name: string;
  disabled?: boolean;
};

// 列表页,新增,编辑
export type SparesBasicInformationType = {
  hdStatus: string;
  toolingModel: string;
  toolingBarcode: string;
  stock: string;
};
export type QueryType = SparesBasicInformationType & {
  currentFlag: string;
  timestamp: string[];
  toolingTypeId: string;
  toolingModelId: string;
};

export type TableListType = SparesBasicInformationType & {
  id: string | number;
  lastPMDate: string;
  nextPMTime: string;
  reason: string;
  remark: string;
  pmCycle: string;
  alarmDay: string;
  toolingType: string;
  currentFlag: string;
};

export type FormType = SparesBasicInformationType & {
  id?: string | number;
  toolingType: string;
  seriesNo: string;
  toolingModelId: string;
  owner: string;
  warningQty: string;
  costCenter: string;
  supply: string;
  lifeTime: string;
  usedTime: string;
  receiveDate: string | null;
  releaseDate: string;
  expireDate: string | null;
  WarningTime: string;
  remark: string;
  flag?: string;
  pmCycle: number;
  alarmDay: number;
};
// 领用,发放,归还,接收类型
export type CollectFormType = {
  id?: string | number;
  toolingBarcode: string;
  ToReturn: string;
  remark: string;
};
export type TableColumnsType = {
  id?: string | number;
  toolingBarcode: string;
  toolingModel: string;
  usedTime: string;
  stock?: string;
};
export type CollectTableColumnsType = TableColumnsType & {
  stock: string;
  actionType: string;
};
export type GrantTableColumnsType = TableColumnsType & {
  stock: string;
  lendDate: string;
  lendId: string;
};

export type ReceiveTableColumnsType = TableColumnsType & {
  stock: string;
  returnDate: string;
  returnId: string;
};
// 上机
export type BoardingFormType = {
  toolingBarcode: string;
  eqpId: string;
  headId: string;
  toolingType: string;
  toolingModel: string;
  usedTime: string;
  lifeTime: string;
  remark: string;
  newStock?: string;
};
// 维护
export type LeftMaintainerFormType = {
  cleanId?: string;
  cleanReason?: string;
  cleanMode?: string;
  maintainRemark?: string;
};
export type LeftUpkeepFormType = {
  repairId?: string;
  isOutRepair?: string;
  repairPart?: string;
  hdStatus?: string;
  isReset?: string;
  repairReason?: string;
  remark?: string;
  toolingImage?: string;
};
export type LeftFormType = {
  toolingBarcode: string;
  isRepair: number;
  isOutRepair?: string;
};
export type RightFormType = {
  id?: string;
  toolingType: string;
  toolingModel: string;
  currentFlag: string;
  time: string;
  usedTime: string;
  toolingBarcode?: string;
};
// 外修归还
export type ExternalRepairRestitutionFormType = {
  toolingBarcode: string;
  repairReturnDate: string;
};

export interface SpareModelTreeListType {
  id: string;
  isLeaf: boolean;
  name: string;
  parentId: string;
  parentName: string;
  children: SpareModelTreeListType[];
}
// 详情-->
export type DetailsFormType = {
  toolingType: string;
  toolingModel: string;
  toolingBarcode: string;
  seriesNo: string;
  hdStatus: string;
  owner: string;
  lifeTime: string;
  warningQty: string;
  supply: string;
  stock: string;
  usedTime: string;
  costCenter: string;
  receiveDate: string;
  releaseDate: string;
  expireDate: string;
  pmCycle: string;
  alarmDay: string;
  remark: string;
};
// 备件上机记录
export type OnRecordsListType = {
  toolingBarcode: string;
  eqpId: string;
  creator: string;
  createTime: string;
};
// 备件保养
export type PmRecordsListType = {
  toolingBarcode: string;
  systemTime: string;
  cleanId: string;
  cleanReason: string;
  cleanMode: string;
  eqpId: string;
  remark: string;
};
// 备件维修记录
export type RepairRecordsListType = {
  toolingBarcode: string;
  systemTime: string;
  repairId: string;
  repairPart: string;
  repairReason: string;
  repairMode: string;
  eqpId: string;
  resetFlag: string;
  remark: string;
};
export type ToolingInfoDetailType = DetailsFormType & {
  onRecords: OnRecordsListType[];
  offRecords: OnRecordsListType[];
  pmRecords: PmRecordsListType[];
  repairRecords: RepairRecordsListType[];
};
