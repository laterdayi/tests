import { API_PREFIX_PMS } from '../../common/common';

export const SparesCombinationConfigurationApis = {
  // 列表
  getPageListApi: API_PREFIX_PMS + '/ToolingGroup/GetPageList',
  // 新增
  addApi: API_PREFIX_PMS + '/ToolingGroup/Add',
  // 详情
  getDetailsApi: API_PREFIX_PMS + '/ToolingGroup/Get',
  // 更新
  updateApi: API_PREFIX_PMS + '/ToolingGroup/Update',
  // 删除
  deleteApi: API_PREFIX_PMS + '/ToolingGroup/Delete'
};

// 列表页
export type QueryType = {
  name: string;
};
export type TableListType = {
  id: string;
  name: string;
  creator: string;
  createTime: string;
  editor: string;
  editTime: string;
  description: string;
  toolingModels: string;
  toolingModelNames: string[];
};
// 新增弹窗
export type AddFormType = {
  id?: string;
  name: string;
  description: string;
};
export type AddTableListType = {
  id: string;
  name: string;
  parentName: string;
};
