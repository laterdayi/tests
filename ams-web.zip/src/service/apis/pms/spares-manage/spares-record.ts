import { API_PREFIX_PMS } from '../../common/common';

export const SparesRecordApis = {
  // 页面表格列表
  getListApi: API_PREFIX_PMS + '/ToolingOnoffRecord/GetList',
  // 导出
  exportToolingOnoffRecordApi: API_PREFIX_PMS + '/ToolingOnoffRecord/ExportToolingOnoffRecord'
};
export type QueryType = {
  toolingBarcode: string;
  eqpId: string;
  actionType: number
};
export type ListType = {
  id: string;
  name: string;
};
export type TableListType = {
  toolingBarcode: string;
  eqpId: string;
  actionType: number;
  creator: string;
  createTime: string;
  remark: string;
};
