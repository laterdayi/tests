import { API_PREFIX_PMS } from '../../common/common';

export const SpareManageCommonApis = {
  // 类别接口-->assembly
  getByTypeModelListApi: API_PREFIX_PMS + '/ToolingType/GetToolingTypeList',
  // 型号接口
  getToolingTypeIdListApi: API_PREFIX_PMS + '/ToolingModels/GetByTypeModelList',
  // 类别/型号接口-->PMS
  getModelsApi: API_PREFIX_PMS + '/ToolingModels/GetModels'
};
