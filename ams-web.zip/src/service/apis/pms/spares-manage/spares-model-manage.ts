import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const SparesModelManageApis = {
  // 列表
  getListApi: API_PREFIX_PMS + '/ToolingModels/GetList',
  // 新增备件分类
  createSpareCategoryApi: API_PREFIX_PMS + '/ToolingModels/Add',
  // 更新备件分类
  updateSpareCategoryApi: API_PREFIX_PMS + '/ToolingModels/Update',
  // 新增备件型号
  createSpareModelApi: API_PREFIX_PMS + '/ToolingModels/AddModels',
  // 更新备件型号
  updateSpareModelApi: API_PREFIX_PMS + '/ToolingModels/UpdateModel',
  // 删除备件型号
  deleteSpareModelApi: API_PREFIX_PMS + '/ToolingModels/DeleteModel',
  // 编辑获取详情
  getSpareDetailDetailApi: API_PREFIX_PMS + '/ToolingModels/Get',
  // 获取子模型列表
  getSubSpareModelListApi: API_PREFIX_PMS + '/ToolingModels/GetChildren',
  // 删除
  deleteApi: API_PREFIX_PMS + '/ToolingModels/Delete',
  // 导入
  importUserApi: API_PREFIX_CONFIG + '/upload/submit?name=ToolingModeList',
  // 下载
  downloadMaterialApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=ToolingModeList'
};
export type ListType = {
  id: string;
  name: string;
};
export type QueryType = {
  toolingModel: string;
};
export type TableListType = {
  createTime: string;
  creator: string;
  description: string;
  editTime: string;
  editor: string;
  id: number;
  modelName: string;
  typeName: string;
  isExpanded?: boolean;
  children?: ModelTableListType[];
};

export type CategoryEditType = {
  id: number;
  typeName: string;
  description: string;
};
export type ModelEditType = {
  modelNames: string;
  parentId: string;
};
export type ModelTableListType = {
  modelName: string | undefined;
  id?: string;
  isEdit: boolean;
};
export interface SparesModelDetailType {
  id: number;
  modelName: string;
  description: string;
}
