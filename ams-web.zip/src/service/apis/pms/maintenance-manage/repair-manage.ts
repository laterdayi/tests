import { API_PREFIX_PMS } from '../../common/common';

export const RepairManageApis = {
  // 获取列表
  getRepairListApi: API_PREFIX_PMS + '/Repair/GetList',
  // 获取单个报修详情
  getRepairDetailApi: API_PREFIX_PMS + '/Repair/Get',
  // 新增
  createRepairApi: API_PREFIX_PMS + '/Repair/add',
  // 更新
  updateRepairApi: API_PREFIX_PMS + '/Repair/update',
  // 删除
  deleteRepairApi: API_PREFIX_PMS + '/Repair/delete',
  // 接手/转手
  takeOverRepairApi: API_PREFIX_PMS + '/Repair/TakeOverRepair',

  // 获取QC表单信息
  getFormInfoApi: API_PREFIX_PMS + '/Repair/GetEFormInfo',
  // QC表单提交
  saveRepairHandlerFormApi: API_PREFIX_PMS + '/Repair/SaveRepairHandlerForm',

  // 设备接收
  saveEqpReceiveFormApi: API_PREFIX_PMS + '/Repair/SaveEqpReceiveForm',

  // 维修确认提交(非维修完成)
  submitFeedbackApi: API_PREFIX_PMS + '/Repair/SubmitFeedback',

  // 维修确认提交(data验证)
  checkSampleLimitApi: API_PREFIX_PMS + '/ConversionForm/CheckSampleLimit',

  // 获取设备状态
  getEquipmentStateApi: API_PREFIX_PMS + '/EqpStateChange/GetEqpStatus',
  // 获取下一状态列表
  getNextStateListApi: API_PREFIX_PMS + '/Repair/GetRepairNextStateList',
  // 获取操作记录
  getOperateRecordListApi: API_PREFIX_PMS + '/Repair/GetOperateHistory',
  // 获取操作记录详情
  getEFormHisApi: API_PREFIX_PMS + '/Repair/GetEFormHis'
};
// 列表页------------------------------------------>
export enum RepairState {
  //  待接单
  toTakeOver = 1,
  // 待维修
  awaitingRepair = 2,
  // MarjorDown
  marjorDowarjorDow = 3,
  // 待QC确认
  toBeConfirmed = 4,
  // 设备接收
  eapReceive = 5,
  // PM
  PM = 6,
  // 修机
  repairMachine = 7,
  // 维修完成
  completeMlaintenance = 8
}
export enum ItemListBelongTo {
  // 设备
  eqp = 1,
  // 组别
  group,
  // 金样
  goldSample
}
// 新增------------------------------------------>
export interface AddFormType {
  id?: string | number
  layoutId: string
  eqpId: string
  alarmInfo: string
  remark: string
}
// 详情------------------------------------------>
export interface DetailFormType {
  creator: string
  createTime: string
  levelName: string
  eqpName: string
  alarmInfo: string
  remark: string
  reason: string
  parameterModification: string
  handleMeasures: string
  sparePartChange: string

  eqpId?: string
  defaultSelection?: number
}
// 接手
export interface TakeOverFormType {
  id: string
  eqpId: string
  secondaryTakeover: number
  isBtnTakeOver: number
  remark: string
}
// 维修确认
export interface MaintenanceType {
  state: number
  reason: string
  handleMeasures: string
  parameterModification: string
  sparePartChange: string
}
