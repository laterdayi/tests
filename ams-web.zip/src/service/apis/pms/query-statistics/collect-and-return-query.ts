import { API_PREFIX_PMS } from '../../common/common';

export const CollectAndReturnQueryApis = {
  // 领还
  getCollectAndReturnApi: API_PREFIX_PMS + '/ToolingLendAndReturnRecord/GetList'
};

// 列表页
export type QueryType = {
  toolingBarcode: string;
  timestamp: string[];
};
export type TableListType = {
  toolingBarcode: string;
  toolingType: string;
  toolingModel: string;
  flag: string;
  applicant: string;
  applyTime: string;
  reason: string;
  confirmer: string;
  confirmTime: string;
  remark: string;
  actionType: string | number;
  resetFlag: string | number;
};
