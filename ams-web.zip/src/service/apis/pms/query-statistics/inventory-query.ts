import { API_PREFIX_PMS } from '../../common/common';

export const InventoryQueryApis = {
  // 库存
  getStockApi: API_PREFIX_PMS + '/ToolingStockSummary/GetStockCountList'
};

// 列表页
export type QueryType = {
  toolingTypeId: string;
  toolingModelId: string[];
};
export type TableListType = {
  toolingBarcode: string;
  toolingType: string;
  toolingModel: string;
  flag: string;
  applicant: string;
  applyTime: string;
  reason: string;
  confirmer: string;
  confirmTime: string;
  remark: string;
  actionType: string | number;
  resetFlag: string | number;
};
