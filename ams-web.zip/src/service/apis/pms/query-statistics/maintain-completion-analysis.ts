import { API_PREFIX_PMS } from '../../common/common';

export const MaintainCompletionAnalysisApis = {
  // 获取列表
  getPMCompletionAnalysisApi: API_PREFIX_PMS + '/PMReport/PMCompletionAnalysis'
};
export type QueryType = {
  treeId: string[];
  eqpName: string[];
  type: number;
  timestamp: string[];
  abscissaLeft: number;
  abscissaRight: number;
};
export type TableListType = {
  name: string;
  executeCount: number;
  planCount: number;
};
