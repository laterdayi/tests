import { API_PREFIX_CONFIG } from '../../common/common';

export const LoginHistoryApis = {
  // 获取接口
  getLoginHistoryApi: API_PREFIX_CONFIG + '/login/GetLoginHistory'
};

// 列表页
export type QueryType = {
  userId: string;
  timestamp: string[];
};
export type TableListType = {
  loginIp: string;
  userId: string;
  loginType: number;
  loginTime: string;
  logOutTime: string;
  remark: string;
};
