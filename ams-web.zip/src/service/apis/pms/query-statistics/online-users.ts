import { API_PREFIX_CONFIG } from '../../common/common';

export const OnlineUsersApis = {
  // 获取接口
  getOnlineUsersApi: API_PREFIX_CONFIG + '/User/GetOnlineUsers'
};

// 列表页
export type QueryType = {
  userId: string;
  timestamp: string[];
};
export type TableListType = {
  id: string;
  ipAddress: string;
  loginTime: string;
  token: string;
  userId: string;
  userType: number;
};
