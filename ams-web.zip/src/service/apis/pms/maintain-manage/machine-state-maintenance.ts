import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const MachineStateMaintenanceApis = {
  // 获取数据列表 | 导出数据
  getMachineStateListApi: API_PREFIX_PMS + '/EqpStateHistory/GetPageList',
  // 获取单个详情
  getMachineStateDetailApi: API_PREFIX_PMS + '/EqpStateHistory/Get',
  // 新增
  createMachineStateApi: API_PREFIX_PMS + '/EqpStateHistory/Add',
  // 获取机台状态
  getStateListApi: API_PREFIX_CONFIG + '/Common/GetEnEnumList?enumName=PMEqpState',
  // 获取设备状态
  getEquipmentStateApi: API_PREFIX_PMS + '/EqpStateHistory/GetState'
};
