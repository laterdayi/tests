import { API_PREFIX_PMS } from '../../common/common';
import type { ItemListType } from '@/utils/project/electronic-form/electronic-form-type';

export const MaintainHistoryQueryApis = {
  // 获取数据列表 | 导出数据
  getPMHistoryPageListApi: API_PREFIX_PMS + '/PM/GetPMHistoryPageList',
  // 获取详情
  getOperateHistoryApi: API_PREFIX_PMS + '/PM/GetOperateHistory',
  // 获取电子表单
  getPMHistoryApi: API_PREFIX_PMS + '/PM/GetPMHistory'
};

export interface QueryType {
  name: string;
  treeIds: string[];
  eqpName: string[];
  timestamp: string[];
  remark: string;
  actualExecutorList: string;
}

export interface TableListType {
  id: string;
  eqpName: string;
  scheduleName: string;
  actualExecutorList: string[];
  actualExecuteTime: string;
  planExecutorList: string[];
  planExecuteTime: string;
  planHours: string;
  formResult: number;
  eFormHistoryId: string;
}

// 详情
export interface DetailFormType {
  line: string;
  actualExecuteTime: string;
  actualExecutorList: string[];
  eqpName: string;
  id?: string;
  planExecuteTime: string;
  planExecutorList: string[];
  planHours: number;
  scheduleName: string;
  histories?: HistoriesType[];
}
// 操作记录
export interface HistoriesType {
  id: string;
  operateTime: string;
  operateType: number;
  operator: string;
  pmeFormId: string;
  remark: string;

  formType?: string;
  fromResult?: number;
  typeTableData?: ItemListType[];
  nameTableData?: ItemListType[];
  goldSampleTableData?: ItemListType[];
  goldSampleTableColumns?: DataTableColumns<ItemListType>;
  goldSampleTableScroll?: number;
}
