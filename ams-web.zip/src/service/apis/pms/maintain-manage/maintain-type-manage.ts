import { API_PREFIX_PMS } from '../../common/common';

export const MaintainTypeManageApis = {
  // 获取数据列表 | 导出数据
  getMaintainTypeListApi: API_PREFIX_PMS + '/PMType/GetPageList',
  // 获取单个详情
  getMaintainTypeDetailApi: API_PREFIX_PMS + '/PMType/get',
  // 新增
  createMaintainTypeApi: API_PREFIX_PMS + '/PMType/add',
  // 更新
  updateMaintainTypeApi: API_PREFIX_PMS + '/PMType/update',
  // 删除
  deleteMaintainTypeApi: API_PREFIX_PMS + '/PMType/delete'
};
