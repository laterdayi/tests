import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const MaintainPlanArrangeApis = {
  // 获取数据列表 | 导出数据
  getMaintainPlanListApi: API_PREFIX_PMS + '/PMScheduling/GetPageList',
  // 获取单个详情
  getMaintainPlanDetailApi: API_PREFIX_PMS + '/PMScheduling/get',
  // 启动保养计划(单个)
  startMaintainPlanApi: API_PREFIX_PMS + '/PMScheduling/Start',
  // 启动保养计划(N个)
  batchStartApi: API_PREFIX_PMS + '/PMScheduling/BatchStart',
  // 获取账号列表
  getAccountListApi: API_PREFIX_CONFIG + '/User/GetAllUsers',
  // 变更执行人
  updateExectorApi: API_PREFIX_PMS + '/PMScheduling/UpdateExecutors',
  // 终止保养计划
  abortMaintainPlanApi: API_PREFIX_PMS + '/PMScheduling/Stop',
  // 获取保养计划名称
  getAllScheduleNamesApi: API_PREFIX_PMS + '/PMSchedule/GetAllScheduleNames'
};

export interface ExectorFormType {
  id?: string;
  executorList: string[];
}

export interface EditType {
  id?: string;
  ids?: string[];
  eqpName: string | string[];
  executorList: string[];
  scheduleName: string | string[];
  startTime: string;
}

export interface QueryType {
  name: string;
  treeIds: string[];
  eqpName: string[];
  formName: string;
  status: number;
  timestamp: string[];
}
export interface TableListType {
  id: string;
  scheduleName: string;
  scheduleTypeName: string;
  line: string;
  eqpName: string;
  formName: string;
  executors: string;
  executorList: string[];
  startTime: string;
  nextTime: string;
  status: number;
}
