import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const MaintainPlanMaintenanceApis = {
  // 获取数据列表 | 导出数据
  getMaintainPlanListApi: API_PREFIX_PMS + '/PMSchedule/GetPageList',
  // 获取单个详情
  getMaintainPlanDetailApi: API_PREFIX_PMS + '/PMSchedule/Get',
  // 新增
  createMaintainPlanApi: API_PREFIX_PMS + '/PMSchedule/Add',
  // 更新
  updateMaintainPlanApi: API_PREFIX_PMS + '/PMSchedule/Update',
  // 删除
  deleteMaintainPlanApi: API_PREFIX_PMS + '/PMSchedule/Delete',
  // 获取设备列表
  getEquipmentListApi: API_PREFIX_CONFIG + '/LayoutStructure/GetTree?check=0&addEqp=1',
  // 获取账号列表
  getAccountListApi: API_PREFIX_CONFIG + '/User/GetAllUsers',
  // 获取保养类型列表
  getMaintainTypeListApi: API_PREFIX_PMS + '/PMType/GetPMSTypeList',
  // 获取检查表单列表
  getCheckFormListApi: API_PREFIX_CONFIG + '/EFormFormCheck/GetPMFormList',
  // 获取频率单位列表
  getUseCountCategoryApi: API_PREFIX_CONFIG + '/Common/GetEnumList?enumName=UseCountCategory'
};

export interface QueryType {
  formId: number;
  name: string;
  executorList: string;
}

export interface EditType {
  id?: string;
  name: string;
  eqpNameList: string[];
  formId: string;
  executorList: string[];
  planHours: number;
  advanceDays: number;
  advanceRate: number;
  description: string;
  guideFile: string;
  workingCategory: string;
  rate: number;
  unit: string;
  tolerance: number
}

export interface TableListType {
  id: string;
  name: string;
  typeName: string;
  formName: string;
  notifyUserGroups: string;
  executorList: string[];
  planHours: number;
  advanceDays: number;
  advanceRate: number;
  description: string;
  guideFile: string;
  workingCategory: string;
  unit: string
}

export interface EquipmentType {
  createTime: string;
  creator: string;
  description: string;
  id: string;
  isLeaf: string;
  levelName: string;
  name: string;
  parentId: string;
  parentName: string;
  source: string;
  children: EquipmentType[];
}
