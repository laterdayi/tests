import { API_PREFIX_PMS } from '../../common/common';

export const MaintainHistoryRecordApis = {
  // 获取数据列表 | 导出数据
  getMaintainHistoryListApi: API_PREFIX_PMS + '/user/getlist',
  // 获取单个详情
  getMaintainHistoryDetailApi: API_PREFIX_PMS + '/user/get',
  // 新增
  createMaintainHistoryApi: API_PREFIX_PMS + '/user/add',
  // 更新
  updateMaintainHistoryApi: API_PREFIX_PMS + '/user/update',
  // 删除
  deleteMaintainHistoryApi: API_PREFIX_PMS + '/user/delete',
  // 导入
  importMaintainHistoryApi: API_PREFIX_PMS + '/upload/submit?name=***',
  // 导出
  exportMaintainHistoryApi: API_PREFIX_PMS + '/dept/getlist',
  // 下载
  downloadMaintainHistoryApi: API_PREFIX_PMS + '/dept/getlist'
};
