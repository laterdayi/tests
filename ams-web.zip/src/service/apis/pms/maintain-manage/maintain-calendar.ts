import { API_PREFIX_PMS } from '../../common/common';

export const MaintainCalendarApis = {
  // 获取数据列表 | 导出数据
  getMaintainListApi: API_PREFIX_PMS + '/PMScheduling/GetPMScheduleOverView',
  // 获取热力图数据
  getHeatmapDataApi: API_PREFIX_PMS + '/PMScheduling/GetPMScheduleSummary',
  // 导出
  exportMaintainApi: API_PREFIX_PMS + '/dept/getlist'
};
