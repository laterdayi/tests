import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const MaterialCategoryApis = {
  // 获取数据列表 | 导出数据
  getMaterialCategoryListApi: API_PREFIX_PMS + '/MaterialType/GetList',
  // 获取单个详情
  getMaterialCategoryDetailApi: API_PREFIX_PMS + '/MaterialType/Get',
  // 新增
  createMaterialCategoryApi: API_PREFIX_PMS + '/MaterialType/Add',
  // 更新
  updateMaterialCategoryApi: API_PREFIX_PMS + '/MaterialType/Update',
  // 删除
  deleteMaterialCategoryApi: API_PREFIX_PMS + '/MaterialType/Delete',
  // 导入
  importMaterialCategoryApi: API_PREFIX_CONFIG + '/upload/submit?name=MaterialTypeList',
  // 导出
  exportMaterialCategoryApi: API_PREFIX_PMS + '/MaterialType/ExportMaterialType',
  // 下载
  downloadMaterialCategoryApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=MaterialTypeList'
};
