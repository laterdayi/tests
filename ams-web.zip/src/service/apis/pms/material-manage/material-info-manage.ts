import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const MaterialInfoManageApis = {
  // 获取数据列表 | 导出数据
  getMaterialInfoListApi: API_PREFIX_PMS + '/MaterialInfo/GetList',
  // 获取单个详情
  getMaterialInfoDetailApi: API_PREFIX_PMS + '/MaterialInfo/get',
  // 新增
  createMaterialInfoApi: API_PREFIX_PMS + '/MaterialInfo/Add',
  // 更新
  updateMaterialInfoApi: API_PREFIX_PMS + '/MaterialInfo/update',
  // 删除
  deleteMaterialInfoApi: API_PREFIX_PMS + '/MaterialInfo/Delete',
  // 导入
  importMaterialInfoApi: API_PREFIX_CONFIG + '/upload/submit?name=MaterialBaseList',
  // 导出
  exportMaterialInfoApi: API_PREFIX_PMS + '/MaterialInfo/GetList',
  // 下载
  downloadMaterialInfoApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=MaterialBaseList',
  // 获取材料类别
  getMaterialCategoryListApi: API_PREFIX_PMS + '/MaterialType/GetAllType',
  // 获取供应商列表
  getSupplierListApi: API_PREFIX_CONFIG + '/Supplier/GetIDAndName',
  // 开始计时
  startTimerApi: API_PREFIX_PMS + '/MaterialInfo/StartCountDown'
};
