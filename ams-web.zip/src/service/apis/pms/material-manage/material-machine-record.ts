import { API_PREFIX_PMS } from '../../common/common';

export const MaterialMachineRecordApis = {
  // 获取数据列表 | 导出数据
  getMaterialMachineListApi: API_PREFIX_PMS + '/MaterialUsedHistory/GetList'
};
