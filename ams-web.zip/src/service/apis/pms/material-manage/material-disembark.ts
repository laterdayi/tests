import { API_PREFIX_CONFIG, API_PREFIX_PMS } from '../../common/common';

export const MaterialDisembarkApis = {
  // 下机
  disembarkApi: API_PREFIX_PMS + '/MaterialInfo/MaterialGetOffEqp',
  // 获取上下机信息
  getMachineInfoApi: API_PREFIX_PMS + '/MaterialInfo/GetMaterialInfo',
  // 获取设备信息
  getEquipmentInfoApi: API_PREFIX_CONFIG + '/EquipmentBase/CheckEqpId'
};
