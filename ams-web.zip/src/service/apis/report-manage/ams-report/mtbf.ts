import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const MtbfApis = {
  // 获取列表 | 导出数据
  getMtbfListApi: API_PREFIX_ASSEMBLY + '/MTBFReport/GetMTBFReportList'
};
