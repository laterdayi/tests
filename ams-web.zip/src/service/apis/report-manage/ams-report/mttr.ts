import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const MttrApis = {
  // 获取列表 | 导出数据
  getMttrListApi: API_PREFIX_ASSEMBLY + '/MTTRReport/GetMTTRReportList'
};
export type QueryType = {
  treeId: string[];
  statisDimension: number;
  timeType: number;
  eqpName: string[];
  site: string;
  customerCode: string;
  productModel: string;
  timestamp: string[];
};
export type TableListType = {
  eqpName: string;
  operateTime: string;
  operateUserID: string;
  purpose: string;
  serverIp: string;
};
export type MTTRResponseDataType = {
  reports: ReportType[];
  pagedList: PagedListType[];
  total: number;
  page: number;
  pagesize: number;
};
export type ReportType = {
  name: string;
  time: string;
  datas: { mtbfStatistics: number }[];
};
export type PagedListType = {
  xName: string;
  mtbfStatistics: number;
  productionTime: number;
  repairTimes: number;
};
