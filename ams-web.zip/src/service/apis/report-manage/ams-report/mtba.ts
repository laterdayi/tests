import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const MtbaApis = {
  // 获取列表 | 导出数据
  getMtbaListApi: API_PREFIX_ASSEMBLY + '/MTBAReport/GetMTBAReportList'
};
