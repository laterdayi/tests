import { API_PREFIX_REPORT_MANAGE } from '../../common/common';

export const TimeUtilizationReportApis = {
  // 获取数据列表 | 导出数据
  getTimeUtilizationListApi: API_PREFIX_REPORT_MANAGE + '/user/getlist',
  // 获取单个详情
  getTimeUtilizationDetailApi: API_PREFIX_REPORT_MANAGE + '/user/get',
  // 新增
  createTimeUtilizationApi: API_PREFIX_REPORT_MANAGE + '/user/add',
  // 更新
  updateTimeUtilizationApi: API_PREFIX_REPORT_MANAGE + '/user/update',
  // 删除
  deleteTimeUtilizationApi: API_PREFIX_REPORT_MANAGE + '/user/delete',
  // 导入
  importTimeUtilizationApi: API_PREFIX_REPORT_MANAGE + '/upload/submit?name=***',
  // 导出
  exportTimeUtilizationApi: API_PREFIX_REPORT_MANAGE + '/dept/getlist',
  // 下载
  downloadTimeUtilizationApi: API_PREFIX_REPORT_MANAGE + '/dept/getlist'
};
