import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const ProduceReportApis = {
  // 获取数据列表 | 导出数据
  getProduceListApi: API_PREFIX_ASSEMBLY + '/ProductionReport/GetReport'
};
