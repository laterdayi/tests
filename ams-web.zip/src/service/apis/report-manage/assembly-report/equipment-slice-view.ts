import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const EquipmentSliceViewApis = {
  // 获取数据列表 | 导出数据
  getLegendListApi: API_PREFIX_ASSEMBLY + '/Status/GetParcolorList',
  // 获取图表列表
  getChartListApi: API_PREFIX_ASSEMBLY + '/EqpStateSlice/GetEqpStateSlice?'
};
