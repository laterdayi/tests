import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const EquipmentStateQueryApis = {
  // 获取数据列表 | 导出数据
  getEquipmentStateListApi: API_PREFIX_ASSEMBLY + '/EqpStateQueryResults/GetEqpStateManageList',
  // 获取设备状态
  getEgpStateTreeApi: API_PREFIX_ASSEMBLY + '/EqpStateChange/GetEqpStateTree'
};
