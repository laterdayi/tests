import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const ProduceReportApis = {
  // 获取数据列表 | 导出数据
  getProduceListApi: API_PREFIX_ASSEMBLY + '/ProductionReport/GetReport',
  // 获取单个详情
  getProduceDetailApi: API_PREFIX_ASSEMBLY + '/user/get',
  // 新增
  createProduceApi: API_PREFIX_ASSEMBLY + '/user/add',
  // 更新
  updateProduceApi: API_PREFIX_ASSEMBLY + '/user/update',
  // 删除
  deleteProduceApi: API_PREFIX_ASSEMBLY + '/user/delete',
  // 导入
  importProduceApi: API_PREFIX_ASSEMBLY + '/upload/submit?name=***',
  // 导出
  exportProduceApi: API_PREFIX_ASSEMBLY + '/dept/getlist',
  // 下载
  downloadProduceApi: API_PREFIX_ASSEMBLY + '/dept/getlist'
};
