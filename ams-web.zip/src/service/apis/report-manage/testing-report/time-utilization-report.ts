import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const TimeUtilizationReportApis = {
  // 获取数据列表 | 导出数据
  getTimeUtilizationListApi: API_PREFIX_ASSEMBLY + '/OEE/GetEqpProductivity'
};
