import { API_PREFIX_ASSEMBLY } from '../../common/common';

export const UphReportApis = {
  // 获取数据列表 | 导出数据
  getUphDataApi: API_PREFIX_ASSEMBLY + '/UphReport/GetReport',
  // 导出
  exportUphApi: API_PREFIX_ASSEMBLY + '/dept/getlist'
};
