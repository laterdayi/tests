import { API_PREFIX_REPORT_MANAGE } from '../../common/common';

export const EquipmentSliceViewApis = {
  // 获取数据列表 | 导出数据
  getEquipmentSliceListApi: API_PREFIX_REPORT_MANAGE + '/user/getlist',
  // 获取单个详情
  getEquipmentSliceDetailApi: API_PREFIX_REPORT_MANAGE + '/user/get',
  // 新增
  createEquipmentSliceApi: API_PREFIX_REPORT_MANAGE + '/user/add',
  // 更新
  updateEquipmentSliceApi: API_PREFIX_REPORT_MANAGE + '/user/update',
  // 删除
  deleteEquipmentSliceApi: API_PREFIX_REPORT_MANAGE + '/user/delete',
  // 导入
  importEquipmentSliceApi: API_PREFIX_REPORT_MANAGE + '/upload/submit?name=***',
  // 导出
  exportEquipmentSliceApi: API_PREFIX_REPORT_MANAGE + '/dept/getlist',
  // 下载
  downloadEquipmentSliceApi: API_PREFIX_REPORT_MANAGE + '/dept/getlist'
};
