import { API_PREFIX_CONFIG } from './common/common';
import type { LocalType } from '@/stores/app';

export const UserApis = {
  // 登录
  loginApi: API_PREFIX_CONFIG + '/login/login',
  // 更新个人信息
  updateUserInfoApi: API_PREFIX_CONFIG + '/user/updateself',
  // 获取用户信息
  getUserInfoApi: API_PREFIX_CONFIG + '/user/info',
  // 更新头像
  updateAvatarApi: API_PREFIX_CONFIG + '/user/UpdateAvatar',
  // 更新密码
  updatePasswordApi: API_PREFIX_CONFIG + '/user/updatePassword',
  // 路由
  getModulesRouteApi: API_PREFIX_CONFIG + '/Menu/GetRoutes',
  // 退出登录
  logoutApi: API_PREFIX_CONFIG + '/login/Logout',

  // 获取账号状态
  getPasswordStatusApi: API_PREFIX_CONFIG + '/Login/GetPasswordStatus',
  // 账号密码修改
  updatePasswordByUserIdApi: API_PREFIX_CONFIG + '/User/UpdatePasswordByUserId'
};

export interface LoginType {
  username: string;
  password: string;
  loginType: 1 | 2 | 3;
}

export interface UserInfoType {
  user: UseUserInfoUserTyper;
  token: string;
  refreshToken: RefreshToken;
  eqpid: string;
  projectName: string;
  projectType: string;
  lang?: LocalType;
  systemPermissions: SystemPermissionType;
}

export type SystemPermissionType = {
  callOpen: OpenStateType;
  chamberPortConfigOpen: OpenStateType;
  isShowChamberPortList: boolean;
  isHiddenHoldInfo: boolean;
  isHiddenRemoveDuplicate: boolean;
  isHiddenIgnoreEqpStatusSwitch: boolean;
};

export interface RefreshToken {
  tokenExpired: number;
  refreshToken: string;
}

export interface UseUserInfoUserTyper {
  id: number;
  userID: string;
  userName: string;
  department: string;
  email: string;
  mobilePhone: string;
  officePhone: string;
  openId: string;
  avatar: string;
  logo: string;
  miniLogo: string;
  passwordStatus: number;
}

export type PasswordType = {
  oldpassword: string;
  newpassword: string;
  confirmpassword: string;

  expireTime: number;
  passwordMaxLength: number;
  passwordMinLength: number;
  passwordPolicy: string;
  regularExpression: string;
  passwordLength: string;
  switch: number;
};
export type PasswordStatusType = {
  passwordStatus: number;
  passwordPolicy: PasswordPolicyType;
};
export type PasswordPolicyType = {
  expireTime: number;
  passwordMaxLength: number;
  passwordMinLength: number;
  passwordPolicy: string;
  regularExpression: string;
};
