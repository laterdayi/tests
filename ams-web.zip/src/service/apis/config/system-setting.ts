import { API_PREFIX_CONFIG } from '../common/common';

export const SystemSettingApis = {
  // 保存
  settingApi: API_PREFIX_CONFIG + '/Mail/Setting',
  // 测试发送
  testMailSendingApi: API_PREFIX_CONFIG + '/Mail/TestMailSending',
  // 数据回填
  getMailApi: API_PREFIX_CONFIG + '/Mail/Get',
  // 更新设置
  updateSettingApi: API_PREFIX_CONFIG + '/SystemSetting/Setting',
  // 获取基本设置
  getSettingApi: API_PREFIX_CONFIG + '/SystemSetting/Get',
  // 获取密码策略文本列表
  getPasswordPolicyListApi: API_PREFIX_CONFIG + '/SystemSetting/GetPasswordPolicyList',
  // 回填密码策略
  getPasswordPolicySettingApi: API_PREFIX_CONFIG + '/SystemSetting/GetPasswordPolicySetting',
  // 密码策略更新
  setPasswordPolicySettingApi: API_PREFIX_CONFIG + '/SystemSetting/SetPasswordPolicySetting'
};
export interface FormDataType {
  smtpHost: string;
  smtpPort: string;
  smtpSenderAddress: string;
  smtpUser: string;
  smtpPassword: string;
  smtpReceiverAddress: string;
}
export type BasicFormDataType = {
  apiSwicth: string;
  resourceSwitch: string;
  tableChangeSwitch: string;
  buttonHistorySwitch: string;
  sendMailHistorySwitch: string;
};
export type PasswordPolicyType = {
  switch: number
  expireTime: number;
  passwordMaxLength: number;
  passwordMinLength: number;
  passwordPolicy: string[];
  regularExpression: string[];
};
export type PasswordPolicyApiType = {
  switch: number
  expireTime: number;
  passwordMaxLength: number;
  passwordMinLength: number;
  passwordPolicy: string;
  regularExpression: string;
};

export type ResetFormType = {
  passwordPolicy: string;
  regularExpression: string;
};
export type PasswordPolicyListDataType = {
  type: number;
  disabled: boolean;
  label: string | null;
  value: string | null;
  [key: string]: string | number | boolean | null;
};
