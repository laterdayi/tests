import { API_PREFIX_CONFIG } from '../../common/common';

export const TableStructureApis = {
  // 页面表格列表
  getListApi: API_PREFIX_CONFIG + '/TableInfo/GetTableList',
  // 查询子属性
  getAttributeNameListApi: API_PREFIX_CONFIG + '/TableInfo/Get',
  // 导出
  exportTablInfoApi: API_PREFIX_CONFIG + '/TableInfo/ExportTablInfo'
};

export type RowType = {
  tableName: string;
  expandIsShow?: boolean;
  isPK: string;
  id: string | number;
  isNullable: number;

  attributeName: string;
  attributeCode: string;
  order: string;
  description: string;
};

export type ListType = {
  index: number;
  id: string | number;
};
