import { API_PREFIX_CONFIG } from '../../common/common';

export const ProjectManageApis = {
  // 获取项目列表
  getProjectListApi: API_PREFIX_CONFIG + '/project/getlist',
  // 获取单个项目详情
  getProjectDetailApi: API_PREFIX_CONFIG + '/project/get',
  // 设置菜单分配
  setMenuAssignmentApi: API_PREFIX_CONFIG + '/project/setProjectFunctions',
  // 获取菜单分配
  getMenuAssignmentApi: API_PREFIX_CONFIG + '/project/GetProjectFunctions',
  // 新增
  createProjectApi: API_PREFIX_CONFIG + '/project/add',
  // 更新
  updateProjectApi: API_PREFIX_CONFIG + '/Project/update',
  // 删除
  deleteProjectApi: API_PREFIX_CONFIG + '/Project/delete',
  // 更新状态
  updateStateApi: API_PREFIX_CONFIG + '/project/changestatus',
  // 上传Logo
  updateLogoApi: API_PREFIX_CONFIG + '/project/changestatus'
};
