import { API_PREFIX_CONFIG } from '../../common/common';

export const MenuManageApis = {
  // 获取菜单
  getMenuListApi: API_PREFIX_CONFIG + '/Menu/Get?pid=0',
  // 新增
  createMenuApi: API_PREFIX_CONFIG + '/Menu/Add',
  // 更新
  updateMenuApi: API_PREFIX_CONFIG + '/Menu/Update',
  // 删除
  deleteMenuApi: API_PREFIX_CONFIG + '/Menu/Delete',
  // 获取节点详情
  getMenuNodeDetailApi: API_PREFIX_CONFIG + '/Menu/GetEntity'
};
