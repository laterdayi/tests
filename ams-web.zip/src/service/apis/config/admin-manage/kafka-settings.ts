import { API_PREFIX_CONFIG } from '../../common/common';

export const KafkaSettingsApis = {
  // 获取菜单
  getListApi: API_PREFIX_CONFIG + '/KafkaSetting/Connect',
  // 新增
  addFormApi: API_PREFIX_CONFIG + '/KafkaSetting/AddTopic',
  // 更新
  updateApi: API_PREFIX_CONFIG + '/KafkaSetting/UpdatePartition'
};
export type FormType = {
  topic: string;
  partitionCount: number;
};

export type RowType = {
  id?: string | number;
  topicName: string;
  partitionCount: number;
};
