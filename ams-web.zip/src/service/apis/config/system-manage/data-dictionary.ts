import { API_PREFIX_CONFIG } from '../../common/common';

export const DataDictionaryApis = {
  // 页面表格列表
  getListApi: API_PREFIX_CONFIG + '/Attributes/GetList',
  // 属性名称列表
  getAttributeNameListApi: API_PREFIX_CONFIG + '/Attributes/GetAttributeNameList',
  // 获取弹窗表格
  getChildrenApi: API_PREFIX_CONFIG + '/Attributes/GetChildren',
  // 获取弹窗表单
  getFromApi: API_PREFIX_CONFIG + '/Attributes/Get',
  // 修改
  updateApi: API_PREFIX_CONFIG + '/Attributes/Update',
  // 新增表单
  addFormApi: API_PREFIX_CONFIG + '/Attributes/Add',
  // 删除表格
  tableDeleteApi: API_PREFIX_CONFIG + '/Attributes/Delete',
  // 获取字典类型
  getAttributeTypeListApi: API_PREFIX_CONFIG + '/Attributes/GetAttributeTypeList'
};
export type FormType = {
  isTopSelect: number;
  id?: string | number;
  attributeName: string;
  attributeCode: string;
  description: string;
  parentAttributeId: number;
  createTime?: string;
  order?: number;
  type?: string;
};

export type TableType = {
  id: string | number;
  timeId: number

  attributeName: string;
  attributeCode: string;
  order: number | null;
  description: string;
  createTime?: string;
  type?: string;
  isLeaf?: boolean;

  editIsShow?: boolean;
  addIsShow?: boolean;

  verifyIsShow1?: boolean;
  verifyIsShow2?: boolean;
  verifyIsShow3?: boolean;
  verifyIsShow4?: boolean;

  expandIsShow?: boolean;
};
export type RowType1 = TableType & {
  isHasChild: boolean;
  creator: string;
  editor: string;
  editTime: string;
};
