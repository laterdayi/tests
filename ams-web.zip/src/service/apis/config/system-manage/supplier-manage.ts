import { API_PREFIX_CONFIG } from '../../common/common';

export const SupplierManageApis = {
  // 获取列表
  getSupplierListApi: API_PREFIX_CONFIG + '/supplier/getlist',
  // 获取单个供应商详情
  getSupplierDetailApi: API_PREFIX_CONFIG + '/supplier/get',
  // 新增
  createSupplierApi: API_PREFIX_CONFIG + '/supplier/add',
  // 更新
  updateSupplierApi: API_PREFIX_CONFIG + '/supplier/update',
  // 删除
  deleteSupplierApi: API_PREFIX_CONFIG + '/supplier/delete',
  // 下载
  downloadSupplierApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=SupplierList',
  // 导入
  importSupplierApi: API_PREFIX_CONFIG + '/upload/submit?name=SupplierList'
};
