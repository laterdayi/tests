import { API_PREFIX_CONFIG } from '../../common/common';

export const ApkUploadApis = {
  // 获取apk列表
  getApkListApi: API_PREFIX_CONFIG + '/AppVersion/GetUploadList',
  // 新增
  createApkApi: API_PREFIX_CONFIG + '/AppVersion/AppUpload',
  // 删除
  deleteApkApi: API_PREFIX_CONFIG + '/AppVersion/Delete',
  // 上传Apk
  uploadApkApi: API_PREFIX_CONFIG + '/file/UploadApk'
};
