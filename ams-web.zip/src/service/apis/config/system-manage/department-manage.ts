import { API_PREFIX_CONFIG } from '../../common/common';

export const DepartmentManageApis = {
  // 获取部门列表
  getDepartmentListApi: API_PREFIX_CONFIG + '/dept/GetDeptTree',
  // 获取单个部门详情
  getDepartmentDetailApi: API_PREFIX_CONFIG + '/dept/get',
  // 新增
  createDepartmentApi: API_PREFIX_CONFIG + '/dept/add',
  // 更新
  updateUserApi: API_PREFIX_CONFIG + '/dept/update',
  // 删除
  deleteDepartmentApi: API_PREFIX_CONFIG + '/dept/Delete',
  // 获取部门类别列表
  getDepartmentCategoryApi: API_PREFIX_CONFIG + '/common/GetEnumList?enumName=DepartmentEnum',
  // 下载
  downloadDepartmentApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=DepartmentList',
  // 导出
  exportDepartmentApi: API_PREFIX_CONFIG + '/dept/getlist',
  // 导入
  importDepartmentApi: API_PREFIX_CONFIG + '/upload/submit?name=DepartmentList'
};
