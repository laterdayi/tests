import { API_PREFIX_AMS, API_PREFIX_CONFIG } from '../../common/common';
import type { WidgetType } from '@/components/project/form-designer/utils/designer-type';

export const FormManageApis = {
  // 获取表单列表
  getListApi: API_PREFIX_CONFIG + '/EFormFormCheck/GetList',
  // 新增
  addApi: API_PREFIX_CONFIG + '/EFormFormCheck/Add',
  // 获取单个表单详情
  getDetailApi: API_PREFIX_CONFIG + '/EFormFormCheck/Get',
  // 获取表单项列表项目
  getItemListApi: API_PREFIX_CONFIG + '/EFormFormCheck/GetItemList',
  // 编辑
  updateFormApi: API_PREFIX_CONFIG + '/EFormFormCheck/Update',
  // 删除
  deleteFormApi: API_PREFIX_CONFIG + '/EFormFormCheck/Delete',
  // 维修确认提交(data验证)
  checkSampleLimitApi: API_PREFIX_AMS + '/Repair/CheckSampleLimit'
};
export interface QueryType {
  formName: string;
  category: string;
  formType: string;
  language: number;
}
export interface EditType {
  id?: string;
  status: number;
  version: string;
  remark: string;
  table: WidgetType;
  formPrefix: string;
  formName: string;
  category: string;
  formType: string;
}

export interface TableListType {
  id: string;
  formName: string;
  category: string;
  formType: string;
  remark: string;
  version: string;
  projectCode: string;
  status: number;
}

export interface FormItemDataType {
  responseCheckItemForTypes: OptionsType[];
  responseCheckItemOrders: string[];
}
