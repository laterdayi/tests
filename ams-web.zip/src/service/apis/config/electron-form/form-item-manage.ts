import { API_PREFIX_CONFIG } from '../../common/common';

export const FormItemManageApis = {
  // 获取表单列表
  getListApi: API_PREFIX_CONFIG + '/EFormItemCheck/GetList',
  // 新增
  addApi: API_PREFIX_CONFIG + '/EFormItemCheck/add',
  // 详情
  getFormItemDetailApi: API_PREFIX_CONFIG + '/EFormItemCheck/GetFormItemDetail',
  // 更新
  updateApi: API_PREFIX_CONFIG + '/EFormItemCheck/update',
  // 删除
  deleteApi: API_PREFIX_CONFIG + '/EFormItemCheck/delete',
  // 导入
  importApi: API_PREFIX_CONFIG + '/upload/submit?name=EFormItemCheckExcelList',
  // 下载模板
  downloadApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=EFormItemCheckExcelList',
  // 获取数据类型的下拉框
  getFormItemDataTypeListApi: API_PREFIX_CONFIG + '/EFormItemCheck/GetFormItemDataTypeList',
  // 获取点检表结果下拉框
  getFormItemFinalResultListApi: API_PREFIX_CONFIG + '/EFormItemCheck/GetFormItemFinalResultList',
  // 项目分类数据列表
  getCategoryListApi: API_PREFIX_CONFIG + '/EFormFormCheck/GetCategoryList',
  // 电子表单 值 ,区间 ,带出值下拉框
  getEnumCheckItemJudgeTypeToListApi: API_PREFIX_CONFIG + '/EFormItemCheck/GetEnumCheckItemJudgeTypeToList',
  // 电子表单 条件下拉框
  getEnumConditionListToListApi: API_PREFIX_CONFIG + '/EFormItemCheck/GetEnumConditionListToList'
};
export type QueryType = {
  itemName: string;
  category: string;
  dateType: string;
  finalResult: string;
  isCheck: string;
  language: number;
};
export type EditType = {
  id?: number;
  itemName: string;
  category: string;
  dataType: string;
  finalResult: string;
  standard: string;
  valid: number;
  remark: string;

  isCheck: number;
  judgeType: string;
  maxItemValue: number;
  failValue: string;
  dataSource: string;
  number: number;
  requestCheckItemSections: JudgeTypeType[];
  checkItemSections?: JudgeTypeType[];
};
export type TableListType = {
  id?: number;
  itemName: string;
  category: string;
  dataTypeView: string;
  belongToView: string;
  applyView: string;
  valid: OpenStateType;
  dateType: string;
  belongTo: string;
  isCheck: string;
  apply: string;
  finalResult: string;
  page: number;
  size: number;
  toexcel: OpenStateType;
  sortName?: string;
  sort?: string;
  judgeTypeView: string;
};

export type JudgeTypeType = {
  conditions: string;
  min: number;
  containMin: number;
  max: number;
  containMax: number;
};
export type JudgeTypeListType = {
  id: string;
  name: string;
  disabled: boolean;
};
