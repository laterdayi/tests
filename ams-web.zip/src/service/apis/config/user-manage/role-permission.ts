import { API_PREFIX_CONFIG } from '../../common/common';
import type { MenuListType } from '../../common/type';
import { service as request } from '@/service';

export function getAllMenu(params: { pid: number }) {
  return request.get<MenuListType[]>(API_PREFIX_CONFIG + '/Menu/Get', { params, showTooltip: false });
}
