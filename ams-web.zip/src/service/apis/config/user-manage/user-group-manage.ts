import { API_PREFIX_CONFIG } from '../../common/common';

export const UserGroupManageApis = {
  // 获取用户组列表
  getUserGroupListApi: API_PREFIX_CONFIG + '/usergroup/getlist',
  // 获取单个用户组详情
  getUserGroupDetailApi: API_PREFIX_CONFIG + '/usergroup/get',
  // 获取用户列表
  getUserListApi: API_PREFIX_CONFIG + '/user/GetAllUsers',
  // 新增
  createUserGroupApi: API_PREFIX_CONFIG + '/usergroup/add',
  // 更新
  updateUserGroupApi: API_PREFIX_CONFIG + '/usergroup/update',
  // 删除
  deleteUserGroupApi: API_PREFIX_CONFIG + '/usergroup/delete',
  // 获取设备列表
  getEquipmentListApi: API_PREFIX_CONFIG + '/LayoutStructure/GetTree?addEqp=1',
  // 父级用户组
  getParentNameTreeApi: API_PREFIX_CONFIG + '/UserGroup/GetTree',
   // 呼叫异常类型
   getFlowTypeApi: API_PREFIX_CONFIG + `/Attributes/GetSelectItemList?type=${AttributeType.AMSFlowType}`
};
export interface QueryType {
  name: string
  parentId: string
  userId: string
  flowType: string
  upInterval: number
  eqpId: string
}

export type UserListType = OptionsType & { userid: string };

export interface TableListType {
  id: string
  name: string
  description: string
  creator: string
  createTime: string
  userNames: string[]
  userIds: string[]
  eqpIds: string[]
  eqpNames: string[]
  upInterval: number
  flowType: string
}

export interface EditType {
  userIds: string[]
  name: string
  description: string
  eqpIds: string[]
  parentId: string
  flowType: string
  upInterval: number
}

export interface EquipmentType {
  createTime: string
  creator: string
  description: string
  id: string
  isLeaf: string
  levelName: string
  name: string
  parentId: string
  parentName: string
  source: string
  children?: EquipmentType[]
}
