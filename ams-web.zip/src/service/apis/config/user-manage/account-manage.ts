import { API_PREFIX_CONFIG } from '../../common/common';

export const AccountManageApis = {
  // 获取账号列表 | 导出数据
  getAccountListApi: API_PREFIX_CONFIG + '/user/getlist',
  // 获取账号组列表
  getUserGroupListApi: API_PREFIX_CONFIG + '/UserGroup/GetAllUserGroups',
  // 获取单个账号详情
  getAccountDetailApi: API_PREFIX_CONFIG + '/user/get',
  // 新增
  createAccountApi: API_PREFIX_CONFIG + '/user/add',
  // 更新
  updateAccountApi: API_PREFIX_CONFIG + '/user/update',
  // 删除
  deleteAccountApi: API_PREFIX_CONFIG + '/user/delete',
  // 获取部门列表
  getDepartmentListApi: API_PREFIX_CONFIG + '/dept/getall',
  // 获取角色列表
  getRoleListApi: API_PREFIX_CONFIG + '/role/getall',
  // 获取主管列表
  getLeaderListApi: API_PREFIX_CONFIG + '/user/getall',
  // 重置密码
  resetAccountPswApi: API_PREFIX_CONFIG + '/User/ResetPassword',
  // 下载模板
  downloadAccountApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=UserList',
  // 导入
  importAccountApi: API_PREFIX_CONFIG + '/upload/submit?name=UserList',
  // OpenID查询
  updateOpenIDApi: API_PREFIX_CONFIG + '/user/UpdateOpenID',
  // 更新状态
  updatestatusApi: API_PREFIX_CONFIG + '/user/Updatestatus'
};
export interface QueryType {
  name: string;
  role: string;
  systemName: string;
}

export interface EditType {
  email: string;
  openId: string;
  leader: string;
  mobilePhone: string;
  officePhone: string;
  roles: string[];
  roleIds: MixedArray;
  userGroupIds: string[];
  userID: string;
  userName: string;
  description: string;
  systemOwnerList: string[];
}

export type TableListType = Omit<EditType, 'roles' | 'leader'> & {
  id: string;
  lastLoginIP: string;
  lastLoginTime: string;
  createTime: string;
  status: number;
  roles: string[];
  roleNames: string[];
  userGroupNames: string[];
  roleIds: MixedArray;
  totalLoginTimes: string;
  systemOwnerList: string[];
};
