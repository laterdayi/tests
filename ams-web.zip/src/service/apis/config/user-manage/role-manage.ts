import { API_PREFIX_CONFIG } from '../../common/common';

export const RoleManageApis = {
  // 获取全部角色
  getAllApi: API_PREFIX_CONFIG + '/role/GetAll',
  // 角色列表
  getListApi: API_PREFIX_CONFIG + '/role/getlist',
  // 新增角色
  addApi: API_PREFIX_CONFIG + '/role/add',
  // 编辑角色
  editApi: API_PREFIX_CONFIG + '/role/update',
  // 编辑角色获取详情
  getDetailApi: API_PREFIX_CONFIG + '/Role/Get',
  // 删除角色
  deleteApi: API_PREFIX_CONFIG + '/role/delete',
  // 菜单分配
  editRoleMenuApi: API_PREFIX_CONFIG + '/role/editrolemenu',
  // 获取对应的菜单
  getMenuIdsByRoleIdApi: API_PREFIX_CONFIG + '/role/GetMenuIdsByRoleId',
  // 复制
  copyRoleMenuApi: API_PREFIX_CONFIG + '/Role/CopyRoleMenu'
};

// type 返回值
// ParamsType 参数
export type GetMenuIdsByRoleIdType = {
  id: string | number
  isLeaf: number
  powersList: MixedArray
}[];

export type GetAllType = {
  id: string | number
  name: string
};

export type QueryType = {
  name: string
};
export type EditType = {
  roleName: null
  description?: null
};
export type TableListType = {
  id: number
  roleName: string
  description: string
  creationTime: string
};
