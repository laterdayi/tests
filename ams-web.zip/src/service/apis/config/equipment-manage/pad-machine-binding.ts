import { API_PREFIX_CONFIG } from '../../common/common';

export const PadMachineBindingApis = {
  // 获取pad机台列表 or 导出
  getPadMachineListApi: API_PREFIX_CONFIG + '/AppBinding/GetPageList',
  // 获取单个pad机台详情
  getPadMachineDetailMApi: API_PREFIX_CONFIG + '/AppBinding/Get',
  // 新增
  createPadMachineApi: API_PREFIX_CONFIG + '/AppBinding/Add',
  // 更新
  updatePadMachineApi: API_PREFIX_CONFIG + '/AppBinding/Update',
  // 删除
  deletePadMachineApi: API_PREFIX_CONFIG + '/AppBinding/Delete'
};
