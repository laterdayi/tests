export const LayoutStructureApis = {
  // 获取部门列表
  queryStructureTreeApi: '/config/LayoutStructure/GetTree',
  // 获取单个部门详情
  getStructureDetailApi: '/config/LayoutStructure/get',
  // 新增
  createStructureApi: '/config/LayoutStructure/AddNode',
  // 更新
  updateStructureApi: '/config/LayoutStructure/Update',
  // 删除
  deleteStructureApi: '/config/LayoutStructure/Delete',
  // 下载
  downloadStructureApi: '/config/download/GetTemplateStream?name=LayoutStructureList',
  // 导出
  exportStructureApi: '/config/LayoutStructure/GetTree',
  // 导入
  importStructureApi: '/config/Upload/Submit?name=LayoutStructureList'
};
