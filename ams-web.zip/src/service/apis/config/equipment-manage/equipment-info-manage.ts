import { API_PREFIX_CONFIG } from '../../common/common';

export const EquipmentInfoManageApis = {
  // 获取数据列表 | 导出数据
  getEquipmentInfoListApi: API_PREFIX_CONFIG + '/EquipmentBase/GetList',
  // 获取单个详情
  getEquipmentInfoDetailApi: API_PREFIX_CONFIG + '/EquipmentBase/Get',
  // 新增
  createEquipmentInfoApi: API_PREFIX_CONFIG + '/EquipmentBase/Add',
  // 更新
  updateEquipmentInfoApi: API_PREFIX_CONFIG + '/EquipmentBase/Update',
  // 删除
  deleteEquipmentInfoApi: API_PREFIX_CONFIG + '/EquipmentBase/Delete',
  // 导入
  importEquipmentInfoApi: API_PREFIX_CONFIG + '/upload/submit?name=EqpBaseList',
  // 导出
  exportEquipmentInfoApi: API_PREFIX_CONFIG + '/EquipmentBase/GetList',
  // 下载
  downloadEquipmentInfoApi: API_PREFIX_CONFIG + '/download/GetTemplateStream?name=EqpBaseList',
  // 获取用户组
  getUserGroupListApi: API_PREFIX_CONFIG + '/UserGroup/GetAllUserGroups'
};
