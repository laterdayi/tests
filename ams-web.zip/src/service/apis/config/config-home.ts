import { API_PREFIX_CONFIG } from '../common/common';

export const ConfigHomeApis = {
  // 获取用户信息
  getUserInfoApi: API_PREFIX_CONFIG + '/User/GetLoginUserInfo'
};
