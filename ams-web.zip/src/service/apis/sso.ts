import { API_PREFIX_CONFIG } from './common/common';

export const SSOApis = {
  // 获取 code
  getAuthCodeApi: API_PREFIX_CONFIG + '/SSO/GetAuthorizationCode',
  // 获取 token
  getAuthTokenApi: API_PREFIX_CONFIG + '/SSO/GetToken',
  // 获取用户信息
  getUserInfoApi: API_PREFIX_CONFIG + '/SSO/GetUserInfoForChangXin',
  // 退出
  logoutApi: API_PREFIX_CONFIG + '/SSO/LogoutForChangXin',
  // 刷新 Token
  refreshTokenApi: API_PREFIX_CONFIG + '/SSO/GetTokenByRefreshToken'
};

export interface SSOTokenType {
  refresh_token: string;
  access_token: string;
  expires_in: number;
  id_token: string;
}
