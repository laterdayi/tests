export type PersonalType = {
  userName: string;
  mobilePhone: string;
  officePhone: string;
  openId: string;
  email: string;
}
export type PasswordType = {
  oldpassword: string;
  newpassword: string;
  confirmpassword: string;
  expireTime: string
  passwordLength: number
  passwordPolicy: string
  regularExpression: string

}
