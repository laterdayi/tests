import { createApp } from 'vue';
import AppProvider from './AppProvider.vue';
import router from './router';
import { setupPlugins } from './plugins/core';

import './style/index.less';

const app = createApp(AppProvider);

// 注册插件
const registerPlugins = async () => {
  try {
    await setupPlugins(app, router);
    app.use(router).mount('#app');
  } catch (error) {
    console.log('注册插件异常：', error);
  }
};
registerPlugins();

// 为应用内抛出的未捕获错误
app.config.errorHandler = (err, instance, info) => {
  console.log('未捕获错误：', err, instance, info);
};

// 运行时警告
app.config.warnHandler = (msg, instance, trace) => {
  console.log('运行时警告', msg, instance, trace);
};
