import type { RouteType } from '@/service/apis/common/type';

export const useRoutes = () => {
  const router = useRouter();

  // 当前权限列表
  const currentRoutePowers = computed(() => (router.currentRoute.value as unknown as RouteType)?.meta?.powers);

  // 是否拥有新增权限
  const hasAddPermission = computed(() => currentRoutePowers.value?.includes('add'));
  // 是否拥有删除权限
  const hasDeletePermission = computed(() => currentRoutePowers.value?.includes('delete'));
  // 是否拥有编辑权限
  const hasEditPermission = computed(() => currentRoutePowers.value?.includes('edit'));
  // 是否拥有查询权限
  const hasSearchPermission = computed(() => currentRoutePowers.value?.includes('search'));
  // 是否拥有导入权限
  const hasImportPermission = computed(() => currentRoutePowers.value?.includes('import'));
  // 是否拥有导出权限
  const hasExportPermission = computed(() => currentRoutePowers.value?.includes('export'));
  // 是否拥有下载权限
  const hasDownloadPermission = computed(() => currentRoutePowers.value?.includes('download'));

  // 是否拥有自定义权限权限
  const hasCustomPermission = (permission: PermissionCustomType) => currentRoutePowers.value?.includes(permission);
  return {
    hasAddPermission,
    hasSearchPermission,
    hasDownloadPermission,
    hasImportPermission,
    hasExportPermission,
    hasDeletePermission,
    currentRoutePowers,
    hasEditPermission,
    hasCustomPermission
  };
};
