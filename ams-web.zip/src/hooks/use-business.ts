import { service } from '@/service';
import { CommonApis } from '@/service/apis/common/common';

/**
 * @description: 按钮点击记录
 * @param {string} buttonName
 * @return {*}
 */
export const useButtonClickRecord = (buttonName: string) => {
  try {
    if (!buttonName) throw new Error('按钮名称不能为空');
    const routeNames = window.location.pathname.split('/');
    const params = {
      buttonName,
      pageName: camelCase(last(routeNames)),
      bussinessModule: camelCase(head(routeNames) || routeNames.at(1))
    };
    service.post(CommonApis.sendButtonClickRecordApi, params, { showTooltip: false });
  } catch (error) {
    throw new Error(`${error}`);
  }
};
