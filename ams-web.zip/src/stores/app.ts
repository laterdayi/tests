import { light } from '@standard-semi/vars';
import { LOCAL_DEFAULT, PAGE_SIZE } from '@/constants/app';

export type LocalType = 'zh-CN' | 'en';
export type ComponentSizeType = 'small' | 'medium' | 'large';

export interface AppStoreState {
  // 语言
  local: LocalType;
  // 系统主题色
  themePrimary: string;
  // 组件大小
  componentSize: ComponentSizeType;
  // 表格设置
  pageSize: number;
}

export const useAppStore = defineStore(
  'app',
  () => {
    // -------------------------------------------------------------------------------------------- > State
    // 语言
    const local = ref<AppStoreState['local']>(LOCAL_DEFAULT);
    // 系统主题色
    const themePrimary = ref<AppStoreState['themePrimary']>(light.common.primaryColor);
    // 组件大小
    const componentSize = ref<AppStoreState['componentSize']>(COMPONENT_SIZE);
    // 表格页数
    const pageSize = ref<AppStoreState['pageSize']>(PAGE_SIZE);

    // -------------------------------------------------------------------------------------------- > Getter
    // 次主题
    const themeSecondary = computed(() => `${themePrimary.value}13`);

    // -------------------------------------------------------------------------------------------- > Action
    const setLocal = (val: LocalType) => (local.value = val);
    const setThemePrimary = (theme: string) => (themePrimary.value = theme);
    const setComponentSize = (size: ComponentSizeType) => (componentSize.value = size);
    const setPageSize = (size: number) => (pageSize.value = size);

    const resetStore = () => {
      setLocal(LOCAL_DEFAULT);
      setThemePrimary(light.common.primaryColor);
      setComponentSize(COMPONENT_SIZE);
      setPageSize(PAGE_SIZE);
    };
    return {
      resetStore,
      local,
      componentSize,
      pageSize,
      themePrimary,
      themeSecondary,
      setLocal,
      setThemePrimary,
      setComponentSize,
      setPageSize
    };
  },
  {
    persist: true
  }
);
