import type { AxiosError } from 'axios';

import router from '@/router';
import { getRoutePathLogin } from '@/router/utils';
import { UserApis } from '@/service/apis/user';
import type { LoginType, SystemPermissionType, UserInfoType } from '@/service/apis/user';

export const useUserStore = defineStore(
  'user',
  () => {
    // -------------------------------------------------------------------------------------------- > State
    // 用户信息
    const userInfo = ref<UserInfoType | null | undefined>(null);
    // Token 过期处理
    const tokenExpireHandle = ref<boolean>(false);
    // 系统权限
    const systemPermissions = ref<SystemPermissionType | null>(null);

    // -------------------------------------------------------------------------------------------- > Gettter
    // 是否有用户信息
    const hasUserInfo = computed(() => !!userInfo.value);

    // -------------------------------------------------------------------------------------------- > Action

    // 设置系统权限
    const setSystemPermissions = (val: SystemPermissionType | null) => (systemPermissions.value = val);

    // 设置用户信息
    const setUserInfo = (user: UserInfoType | null | undefined) => {
      userInfo.value = user;
      setTokenExpireHandle(false);
    };

    // 设置 Token 过期处理
    const setTokenExpireHandle = (val: boolean) => (tokenExpireHandle.value = val);

    // 登录
    const login = async (user: LoginType) => {
      try {
        const { execute } = useAxiosPost<UserInfoType>(UserApis.loginApi, { ...user, ipaddress: '' });
        const { data } = await execute();
        userInfo.value = data?.value ?? null;
      } catch (error) {
        console.log('登录异常：', error);
        return Promise.reject((error as AxiosError).data);
      }
    };

    // 退出
    const logout = async ({ redirect = false }: { redirect?: boolean } = {}) => {
      try {
        await useAxiosGet(UserApis.logoutApi, __, __, {
          immediate: true
        });
        resetStore();
        const ssoStore = useSSOStore();
        if (window.$CONFIG?.projectConfig?.sso?.open && ssoStore.ssoToken) {
          // 如果 SSO & url存在logout时，重置 SSO 仓库
          ssoStore.resetStore();
        }
        const ROUTE_PATH_LOGIN = getRoutePathLogin();
        const options: RouteLocationRaw = { path: ROUTE_PATH_LOGIN };
        if (redirect) options.query = { redirectUrl: window.location.pathname };
        router.replace(options);
      } catch (error) {
        console.log('退出异常：', error);
      }
    };

    // 获取用户信息
    const getUserInfo = async () => {
      try {
        const { data } = await useAxiosGet<UserInfoType>(UserApis.getUserInfoApi, undefined, undefined, {
          immediate: true
        });
        userInfo.value = { ...userInfo.value, user: data.value?.user } as UserInfoType;
        setSystemPermissions(data.value?.systemPermissions ?? null);
      } catch (error) {
        console.log('获取用户信息异常：', error);
      }
    };

    const resetStore = () => {
      const routeStore = useRouteStore();
      routeStore.resetStore();
      setUserInfo(null);
      setTokenExpireHandle(false);
      setSystemPermissions(null);
    };

    return {
      userInfo,
      tokenExpireHandle,
      hasUserInfo,
      login,
      logout,
      getUserInfo,
      setUserInfo,
      setTokenExpireHandle,
      systemPermissions,
      resetStore
    };
  },
  {
    persist: true
  }
);
