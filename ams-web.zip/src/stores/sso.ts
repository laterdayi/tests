import type { AxiosError } from 'axios';
import router from '@/router';
import { Routes } from '@/router/routes';
import { getRoutePathLogin } from '@/router/utils';
import { SSOApis } from '@/service/apis/sso';
import type { SSOTokenType } from '@/service/apis/sso';
import type { UserInfoType } from '@/service/apis/user';

export const useSSOStore = defineStore(
  'sso',
  () => {
    // -------------------------------------------------------------------------------------------- > State
    const ssoToken = ref<SSOTokenType | null | undefined>(null);
    const ssoAuthErrorCode = ref<number>(1048);

    // -------------------------------------------------------------------------------------------- > Action
    const skipSSOAuth = () => (window.location.href = `${BASE_API}${SSOApis.getAuthCodeApi}`);

    const getSSOToken = async (code: string, state: string) => {
      try {
        const { data } = await useAxiosGet<SSOTokenType>(
          SSOApis.getAuthTokenApi,
          __,
          { params: { code, redirectUrl: state } },
          { immediate: true }
        );
        if (data.value?.access_token) {
          ssoToken.value = data.value;
          getSSOUserInfo();
        }
      } catch (error) {
        console.log('获取SSOToken异常：', error);
      }
    };

    const refreshToken = async () => {
      try {
        const { data } = await useAxiosGet<SSOTokenType>(
          SSOApis.refreshTokenApi,
          __,
          { params: { refreshToken: ssoToken.value?.refresh_token } },
          {
            immediate: true
          }
        );
        if (data.value?.access_token) {
          ssoToken.value = data.value;
          getSSOUserInfo();
        }
      } catch (error) {
        console.log(error);
      }
    };

    const getSSOUserInfo = async () => {
      try {
        const { data } = await useAxiosGet<UserInfoType>(
          SSOApis.getUserInfoApi,
          __,
          { params: { token: ssoToken.value?.access_token } },
          {
            immediate: true
          }
        );
        const userStore = useUserStore();
        userStore.setUserInfo(data.value);
        if (data.value?.lang) {
          const appStore = useAppStore();
          appStore.setLocal(data.value?.lang);
          location.replace(Routes.WORKBENCH);
        }
      } catch (error) {
        console.log('获取用户信息异常：', error);
        if ((error as AxiosError)?.data === ssoAuthErrorCode.value) {
          // 如果 SSO Token错误, 重置 SSO & 用户仓库 & 跳转登录
          const userStore = useUserStore();
          resetStore();
          userStore.resetStore();
          const ROUTE_PATH_LOGIN = getRoutePathLogin();
          router.replace(ROUTE_PATH_LOGIN);
        }
      }
    };

    const logout = () => (window.location.href = `${BASE_API}${SSOApis.logoutApi}?idToken=${ssoToken.value?.id_token}`);

    const resetStore = () => {
      ssoToken.value = null;
      ssoAuthErrorCode.value = 1048;
    };

    return {
      ssoToken,
      refreshToken,
      ssoAuthErrorCode,
      skipSSOAuth,
      getSSOToken,
      getSSOUserInfo,
      logout,
      resetStore
    };
  },
  {
    persist: true
  }
);
