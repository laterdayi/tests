import type { RouteLocationNormalizedLoaded, RouteRecordRaw } from 'vue-router';
import { UserApis } from '@/service/apis/user';
import { generateAsyncRouter } from '@/router/utils';
import router from '@/router';
import { Routes, fixedRouteList } from '@/router/routes';
import type { RouteType } from '@/service/apis/common/type';

export const useRouteStore = defineStore(
  'route',
  () => {
    // -------------------------------------------------------------------------------------------- > State
    // 路由
    const routes = ref<RouteType[]>([]);
    // 当前选择模块
    const currentModule = ref<string>('');
    // 标签列表
    const tabsViewList = ref<Partial<RouteLocationNormalizedLoaded>[]>([]);
    // 筛选列 Key
    const filteredColumnKeys = ref<{ [k: string]: string[] }>({});

    // -------------------------------------------------------------------------------------------- > Getter
    // 是否存在路由
    const hasRoutes = computed(() => !!routes.value.length);
    // 工作台列表
    const workbenchList = computed(() =>
      routes.value.map(item => ({ ...item, label: i18nt(item.name), children: __ }))
    );
    // 模块列表
    const modulesList = computed(() => routes.value.map(item => item.name));
    // 是否为最后一个 Tab
    const isLastTab = computed(() => last(tabsViewList.value)?.path === router.currentRoute.value.path);
    // 是否为第一个 Tab
    const isFirstTab = computed(() => head(tabsViewList.value)?.path === router.currentRoute.value.path);

    // -------------------------------------------------------------------------------------------- > Action

    // 更新筛选列 Key
    const setFilteredColumnKeys = (page: string, keys: string[]) => (filteredColumnKeys.value[page] = keys);

    // 更新工作台
    const setCurrentModule = (module: string) => (currentModule.value = module);

    // 获取动态路由
    const getDynamicRoutes = async () => {
      try {
        const { execute } = useAxiosGet<RouteType[]>(UserApis.getModulesRouteApi);
        const { data } = await execute();
        let result: RouteRecordRaw[] = [];
        if (data.value && Array.isArray(data.value)) {
          result = generateAsyncRouter('/', data.value);
          routes.value = data.value;
        }
        return result;
      } catch (error) {
        console.log('获取动态路由', error);
      }
    };

    // 新增 Tabs View
    const addTabsView = (tab: Partial<RouteLocationNormalizedLoaded>) => {
      const isExist = tabsViewList.value.find(item => item?.path === tab.path);
      if (!isExist) tabsViewList.value.push(tab);
    };

    // 删除 Tabs View
    const deleteTabsView = (tab: Partial<RouteLocationNormalizedLoaded>, index: number, isCurrentTab: boolean) => {
      const isLast = last(tabsViewList.value)?.path === tab.path;
      remove(tabsViewList.value, item => item.path === tab.path);
      if (isCurrentTab) {
        router.push(
          tabsViewList.value.length
            ? tabsViewList.value.at(isLast ? index - 1 : index)?.path ?? Routes.WORKBENCH
            : Routes.WORKBENCH
        );
      }
    };

    // 更新 Tabs View
    const setTabsView = (tabs: Partial<RouteLocationNormalizedLoaded>[]) => (tabsViewList.value = toRaw(tabs));

    // 清空路由数据
    const resetRoutes = () => {
      const routes = router.getRoutes();
      routes.forEach(route => {
        if (!fixedRouteList.includes(route.path)) router.removeRoute(route.name ?? '');
      });
    };

    // 重置仓库
    const resetStore = () => {
      resetRoutes();
      routes.value = [];
      setCurrentModule('');
      setTabsView([]);
    };

    // 返回所有数据
    return {
      routes,
      currentModule,
      tabsViewList,
      hasRoutes,
      workbenchList,
      modulesList,
      isFirstTab,
      isLastTab,
      setCurrentModule,
      getDynamicRoutes,
      addTabsView,
      deleteTabsView,
      setTabsView,
      resetStore,
      resetRoutes,
      filteredColumnKeys,
      setFilteredColumnKeys
    };
  },
  {
    persist: {
      paths: ['tabsViewList', 'filteredColumnKeys']
    }
  }
);
