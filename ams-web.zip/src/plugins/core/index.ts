import type { App } from 'vue';
import type { Router } from 'vue-router';
import { setupI18n } from './vue-i18n';
import { setupStore } from './pinia';
import { setupConfig } from './config';
import { setupRouterGuard } from '@/router/guard';
import { setupDirective } from '@/directive';
import '@standard-semi/vars/base.css';

import './unocss';

export const setupPlugins = async (app: App<Element>, router: Router) => {
  try {
    // 注册配置
    await setupConfig();
    // 注册i18n
    setupI18n(app);
    // 路由守卫
    setupRouterGuard(router);
    // 注册pinia
    setupStore(app);
    // 注册自定义指令
    setupDirective(app);
  } catch (error) {
    console.log(error);
  }
};
