import axios from 'axios';

export async function setupConfig() {
  try {
    const result = await axios.get('/config/config.json', { params: { t: +new Date() } });
    window.$CONFIG = result.data;
  } catch (error) {
    console.log('读取配置文件异常：', error);
  }
}
