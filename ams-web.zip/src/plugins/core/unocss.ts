// 样式重置
import '@unocss/reset/normalize.css';
import 'uno.css';
import initUnocssRuntime from '@unocss/runtime';
import presetIcons from '@unocss/preset-icons/browser';
import presetUno from '@unocss/preset-uno';
import presetAttributify from '@unocss/preset-attributify';
import { ICONS } from '@/assets/icons';

initUnocssRuntime({
  defaults: {
    presets: [
      presetUno(),
      presetAttributify(),
      presetIcons({
        extraProperties: { display: 'inline-block', 'vertical-align': 'middle' },
        collections: {
          carbon: () => import('@iconify-json/carbon/icons.json').then(i => i.default)
        }
      })
    ],
    // 安全列表
    safelist: [
      ...ICONS,
      `w-${TREE_WIDTH_CONTAINER}px!`,
      `w-${TABS_PANE_WIDTH}px!`,
      `px-${standardVars.dialogPaddingLeft}`,
      `pr-${standardVars.dialogPaddingRight}`,
      `min-w-${standardVars.tabsViewItemMinWidth}!`,
      `max-w-${standardVars.tabsViewItemMaxWidth}!`,
      `max-w-${TOOLTIP_MAX_WIDTH}`,
      `max-h-${TOOLTIP_MAX_HEIGHT}`,
      'h-full',
      'w-full',
      'w-240px',
      'w-274px',
      'w-auto',
      'h-auto',
      'w-min!',
      'ml-5px',
      'mr-5px',
      'px-0',
      'w-1/2',
      'flex',
      'flex-center',
      'items-center',
      'text-center',
      'flex-wrap',
      'min-component-width'
    ]
  }
});
