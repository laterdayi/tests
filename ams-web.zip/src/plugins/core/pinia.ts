import { createPersistedState } from 'pinia-plugin-persistedstate';
import type { App } from 'vue';

const pinia = createPinia();
pinia.use(
  createPersistedState({
    key: id => `${__PROJECT_SIGN__}${id}`
  })
);

export function setupStore(app: App) {
  app.use(pinia);
}
