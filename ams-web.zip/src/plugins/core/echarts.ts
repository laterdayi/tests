// 引入 echarts 核心模块
import * as echarts from 'echarts/core';

// 系列类型的定义后缀都为 SeriesOption
// 引入柱状图图表
import {
  BarChart,
  type BarSeriesOption,
  CustomChart,
  type CustomSeriesOption,
  GaugeChart,
  type GaugeSeriesOption,
  HeatmapChart,
  type HeatmapSeriesOption,
  LineChart,
  type LineSeriesOption,
  PieChart,
  type PieSeriesOption,
  ScatterChart,
  type ScatterSeriesOption
} from 'echarts/charts';

// 组件类型的定义后缀都为 ComponentOption
import {
  CalendarComponent,
  DataZoomComponent,
  DataZoomInsideComponent,
  DataZoomSliderComponent,
  GraphicComponent,
  GridComponent,
  LegendComponent,
  MarkPointComponent,
  TitleComponent,
  ToolboxComponent,
  TooltipComponent,
  VisualMapComponent
} from 'echarts/components';

import type {
  CalendarComponentOption,
  DataZoomComponentOption,
  GraphicComponentOption,
  GridComponentOption,
  LegendComponentOption,
  MarkPointComponentOption,
  TitleComponentOption,
  ToolboxComponentOption,
  TooltipComponentOption
} from 'echarts/components';

import { LabelLayout, UniversalTransition } from 'echarts/features';

// 引入 Canvas 渲染器
import { CanvasRenderer } from 'echarts/renderers';

export type ECOption = echarts.ComposeOption<
  | ScatterSeriesOption
  | HeatmapSeriesOption
  | CalendarComponentOption
  | CustomSeriesOption
  | GraphicComponentOption
  | MarkPointComponentOption
  | ToolboxComponentOption
  | GaugeSeriesOption
  | BarSeriesOption
  | LineSeriesOption
  | PieSeriesOption
  | TitleComponentOption
  | TooltipComponentOption
  | GridComponentOption
  | LegendComponentOption
  | DataZoomComponentOption
>;

// 注册必须的组件
echarts.use([
  // 日历
  ScatterChart,
  HeatmapChart,
  VisualMapComponent,
  CalendarComponent,
  // Global
  GraphicComponent,
  CustomChart,
  MarkPointComponent,
  ToolboxComponent,
  GaugeChart,
  PieChart,
  LegendComponent,
  BarChart,
  GridComponent,
  CanvasRenderer,
  TitleComponent,
  TooltipComponent,
  BarChart,
  LineChart,
  LabelLayout,
  UniversalTransition,
  CanvasRenderer,
  DataZoomComponent,
  DataZoomInsideComponent,
  DataZoomSliderComponent
]);

export default echarts;
