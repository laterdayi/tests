import path from 'node:path';
import type { Plugin } from 'vite';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import Unocss from 'unocss/vite';
import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite';

import autoImportApi from './unplugin-auto-import';
import autoImportComponents from './unplugin-vue-components';

export const createVitePlugins = (): Plugin[] => {
  const plugins: Plugin[] = [
    vue(),
    // vite-plugin-vue-devtools
    // VueDevTools(),
    // plugin-vue-jsx
    vueJsx(),
    // unocss
    Unocss({}),
    // unplugin-vue-components
    autoImportComponents,
    // unplugin-auto-import
    autoImportApi,
    // unplugin-vue-i18n
    VueI18nPlugin({
      runtimeOnly: true,
      compositionOnly: true,
      strictMessage: false,
      include: [path.resolve(process.cwd(), 'locales/**')]
    })
  ];
  return plugins;
};
