import path from 'node:path';
import AutoImport from 'unplugin-auto-import/vite';

export default AutoImport({
  // 生成对应.d.ts文件的文件路径
  dts: path.resolve(process.cwd(), 'auto-imports.d.ts'),
  // 包含转换目标的规则
  include: [/\.[tj]sx?$/, /\.vue$/, /\.vue\?vue/],
  // 预设名称或自定义
  imports: [
    'vue',
    'vue-router',
    'vue-i18n',
    'pinia',
    {
      '@standard-semi/hooks/sortable': ['useSortable']
    },
    {
      '@standard-semi/utils/echarts': [
        'CHART_COLOR_LIST',
        'useChartDataZoomOption',
        'useChartTooltipOverflow',
        'useChartTooltipMarker',
        'useChartTooltipValue'
      ],
      '@standard-semi/utils/localstorage': [
        'setLocalStorage',
        'getLocalStorage',
        'removeLocalStorage',
        'clearLocalStorage'
      ],
      '@standard-semi/utils/extra': ['useOmitExtraParams'],
      '@standard-semi/utils/color': ['hexToRgb', 'randomHex'],
      '@standard-semi/utils/extends': ['asyncEmit'],
      '@standard-semi/utils/axios': ['useParamsSerializer', 'useOmitNilRequestParams'],
      '@standard-semi/utils/print': ['usePrint'],
      '@standard-semi/utils/datetime': [
        'useFormatDateTimeParams',
        'useFormatTime',
        'useFormatDate',
        'useFormatDateRange'
      ]
    },
    {
      '@vueuse/core': [
        'useMemory',
        'useResizeObserver',
        'useWindowSize',
        'useNow',
        'useIntervalFn',
        'useDateFormat',
        'useFullscreen',
        'reactiveComputed',
        'useTitle',
        'tryOnMounted',
        'tryOnUnmounted',
        'useEventListener',
        'useElementSize'
      ]
    },
    {
      'lodash-es': [
        'compact',
        'includes',
        'some',
        'chunk',
        'omitBy',
        'every',
        'omit',
        'find',
        'map',
        'cloneDeep',
        'pull',
        'compact',
        'dropRight',
        'drop',
        'filter',
        'initial',
        'remove',
        'last',
        'findIndex',
        'upperFirst',
        'pullAt',
        'intersection',
        'difference',
        'xor',
        'head',
        'pick',
        'mapValues',
        'pullAll',
        'without',
        'pickBy',
        'isEmpty',
        'isNil',
        'isRegExp',
        'clone',
        'toLower',
        'toUpper',
        'camelCase',
        'kebabCase'
      ]
    },
    { '@standard-semi/vars': ['light', 'standardVars'] },
    { '@/service/': ['useAxiosGet', 'useAxiosPost'] },
    { 'naive-ui': ['useDialog', 'useMessage', 'useNotification', 'useLoadingBar'] },
    { '@/plugins/core/vue-i18n': ['i18nt', 'i18nte', 'i18nLocal'] }
  ],
  // 自动导入目录的路径
  dirs: [
    'src/constants',
    'src/utils',
    'src/hooks',
    'src/stores/*',
    'src/components/base-ui/base-drawer/',
    'src/components/base-ui/base-dropdown/',
    'src/components/base-ui/base-popover/',
    'src/components/base-ui/base-form/',
    'src/components/base-ui/base-modal/',
    'src/components/base-ui/base-table/',
    'src/components/base-ui/base-tree/',
    'src/components/base-ui/base-upload/',
    'src/service/modules/'
  ],
  //  Vue 模板中自动导入
  vueTemplate: true,
  // 生成对应的 .eslintrc-auto-import.json 文件
  eslintrc: {
    enabled: true,
    filepath: path.resolve(process.cwd(), '.eslintrc-auto-import.json')
  }
});
