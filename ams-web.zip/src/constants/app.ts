// Crypto
export const AES_IV = '1234567812345678';
export const AES_KEY = 'semitech-ams2024';

// -------------------------------------------------------------------------------------------- > 占位
export const __ = undefined;
export const __PROJECT_SIGN__ = '__AMS__';

// -------------------------------------------------------------------------------------------- > 环境模式
export const __DEV__ = import.meta.env.DEV;
export const __PROD__ = import.meta.env.PROD;

// -------------------------------------------------------------------------------------------- > Service
export const BASE_API = import.meta.env.VITE_BASE_API;
// 服务超时时间
export const SERVICE_TIME_OUT = 150000;
// 服务认证错误码
export const SERVICE_AUTH_ERROR_CODES = [1011, 1012];

// -------------------------------------------------------------------------------------------- > 主题设置

// 默认语言
export const LOCAL_DEFAULT = 'zh-CN';
// 默认组件大小
export const COMPONENT_SIZE = 'medium';
// 默认表格分页设置 (?/页)
export const PAGE_SIZE = 10;

// Layout 名称
export const BLANK_LAYOUT = 'BlankLayout';
export const BASE_LAYOUT = 'Layout';

// 头部 内容区 内边距
export const LAYOUT_PADDING = standardVars.layoutPadding;

// -------------------------------------------------------------------------------------------- > 宽度

// 表格 > 固定列操作按钮
export const TABLE_WIDTH_ACTION = 80;
// 表格 > 序号
export const TABLE_WIDTH_INDEX = 50;
// 表格 > 日期 + 时间
export const TABLE_WIDTH_DATETIME = 160;
// 表格 > 日期 + 时间 + 毫秒
export const TABLE_WIDTH_DATETIME_MILLISECOND = 190;
// 表格 > 日期 | 时间
export const TABLE_WIDTH_DATE = 120;
// 表格 > IP
export const TABLE_WIDTH_IP = 130;
// 表格 > 信息类
export const TABLE_WIDTH_INFO = 140;
// 表格 > 状态类
export const TABLE_WIDTH_STATE = 100;
// 表格 > 系统级模块
export const TABLE_WIDTH_MODULE = 130;
// 表格 > 人员名称 | 工单号
export const TABLE_WIDTH_NAME = 120;
// 表格 > 滚动 > 极小
export const TABLE_WIDTH_SCROLL_MINI = 1600;
// 表格 > 滚动 > 小
export const TABLE_WIDTH_SCROLL_SMALL = 1920;
// 表格 > 滚动 > 中等
export const TABLE_WIDTH_SCROLL_MIDDLE = 2560;
// 表格 > 滚动 > 大
export const TABLE_WIDTH_SCROLL_LARGE = 3840;

// Tree
export const TREE_WIDTH = 240;
// Tree 容器 = Tree 宽度 + 边框 + 边距
export const TREE_WIDTH_CONTAINER = TREE_WIDTH + 34;

// Tabs Pane
export const TABS_PANE_WIDTH = 1000;

// 二维码宽度
export const QRCODE_SIZE = 160;

// 公用图片宽度
export const COMMON_IMAGE_WIDTH = standardVars.commonImgWidth;

// -------------------------------------------------------------------------------------------- > 高度

// Layout 头部高度
export const LAYOUT_HEADER_HEIGHT = standardVars.layoutHeaderHeight;
// Layout Tabs View 高度
export const LAYOUT_TABS_VIEW_HEIGHT = standardVars.layoutTabsViewHeight;

// -------------------------------------------------------------------------------------------- > Tooltip

export const TOOLTIP_MAX_WIDTH = '50vw';
export const TOOLTIP_MAX_HEIGHT = '60vh';
export const TOOLTIP = {
  tooltip: { scrollable: true, class: [`max-w-${TOOLTIP_MAX_WIDTH}`, `max-h-${TOOLTIP_MAX_HEIGHT}`] }
};

// -------------------------------------------------------------------------------------------- > Input

// 表单文本域描述最长限制
export const MAX_LENGTH_DESCRIPTION = 200;
// 表单文本 Input 最长限制
export const MAX_LENGTH_INPUT = 50;
// 表单数字 Input 最长限制
export const MAX_LENGTH_INPUT_NUMBER = 9;

// -------------------------------------------------------------------------------------------- > Dialog or Notification or Message

// 提示框延时
export const MESSAGE_DURATION = 3000;
export const NOTIFICATION_DURATION = 8000;

// -------------------------------------------------------------------------------------------- > Chart

// 水平 Bar 宽度
export const BAR_WIDTH_HORIZONTAL = 20;
// 垂直 Bar 宽度
export const BAR_WIDTH_VERTICAL = 30;
