// 是否开启状态
export enum OpenState {
  // 打开
  open = 1,
  // 关闭
  close = 0
}

// 标签状态
export enum TagState {
  default = 'default',
  warning = 'warning',
  primary = 'primary',
  success = 'success',
  error = 'error'
}

// 编辑表单入口
export enum EditModalEntry {
  // 标题编辑
  title = 1,
  // 按钮编辑
  button
}

// 布局
export enum LayoutType {
  // 标准布局
  default = 1,
  // 空布局
  blank
}

// 数据字典类型
export enum AttributeType {
  // -------------------------------------------------------------------------------------------- > Assembly
  // 备件区域
  toolingArea = 'Assembly_ToolingArea',
  // 备件站别
  toolingStage = 'Assembly_ToolingStage',
  // 存放位置
  warehouseLocation = 'Assembly_WarehouseLocation',
  // 归还库房
  returnLocation = 'Assembly_ReturnLocation',
  // 保养库位
  pMStock = 'Assembly_PMStock',
  // 保养方式
  maintainMode = 'Assembly_MaintainMode',
  // 保养原因
  maintainReason = 'Assembly_MaintainReason',
  // 改机信息
  conversionProgramType = 'Assembly_ConversionProgramType',
  // -------------------------------------------------------------------------------------------- > AMS
  // 不收集设备报警状态
  noCollectEquipmentAlarmState = 'AMS_MesEqpStates',
  // 系统名称
  systemName = 'AMS_SystemName',
  // 报警状态
  machineState = 'AMS_AlarmState',
  // 机台状态
  holdEqpState = 'AMS_HoldEqpState',
  // 报警类型
  alarmType = 'PMS_AlarmType',
  // 报警等级
  alarmLevel = 'PMS_AlarmLevel',
  // 处理方式
  handleMeasures = 'PMS_HandleMeasures',
  // 模版名称
  templateType = 'AMS_TemplateType',
  // 呼叫类型
  AMSFlowType = 'AMS_FlowType',
  // 呼叫类型
  AMSCallType = 'AMS_CallType',
  // -------------------------------------------------------------------------------------------- > PMS
  // 备件区域
  toolingAreaPms = 'PMS_ToolingArea',
  // 备件站别
  toolingStagePms = 'PMS_ToolingStage',
  // 存放位置
  warehouseLocationPms = 'PMS_WarehouseLocation',
  // 归还库房
  returnLocationPms = 'PMS_ReturnLocation',
  // 保养库位
  pMStockPms = 'PMS_PMStock',
  // 保养方式
  maintainModePms = 'PMS_MaintainMode',
  // 保养原因
  maintainReasonPms = 'PMS_MaintainReason',
  // 原因码
  reasonCode = 'PMS_ReasonCode',
  // 改机信息
  conversionProgramTypePms = 'PMS_ConversionProgramType',
  // 复机条件
  recoveryCondition = 'AMS_RecoveryCondition',
  // 故障条件
  faultType = 'PMS_FaultType',
  // -------------------------------------------------------------------------------------------- > Config
  // 电子表单项目分类
  configEFormCategory = 'Config_EFormCategory',
  // 表单类型
  configEFormType = 'Config_EFormType'
}
