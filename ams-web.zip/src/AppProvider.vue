<script setup lang="ts">
import { type GlobalThemeOverrides, dateZhCN, zhCN } from 'naive-ui';
import App from './App.vue';
import { LOCAL_DEFAULT } from '@/constants/app';

const appStore = useAppStore();
const { themePrimary, local } = storeToRefs(appStore);

const lightThemeOverrides = (): GlobalThemeOverrides => {
  const { common, ...componentTheme } = light;
  return {
    common: {
      ...common,
      primaryColor: themePrimary.value,
      primaryColorHover: `${themePrimary.value}D9`,
      primaryColorPressed: themePrimary.value
    },
    ...componentTheme,
    Layout: {
      headerColor: themePrimary.value
    },
    Menu: {
      ...componentTheme.Menu,
      itemColorActive: themePrimary.value,
      itemColorActiveCollapsed: themePrimary.value,
      itemColorActiveHover: themePrimary.value,
      itemColorHover: `${themePrimary.value}13`
    }
  };
};
</script>

<template>
  <n-config-provider
    inline-theme-disabled
    :locale="local === LOCAL_DEFAULT ? zhCN : null"
    :date-locale="local === LOCAL_DEFAULT ? dateZhCN : null"
    :theme-overrides="lightThemeOverrides()"
  >
    <n-loading-bar-provider>
      <n-modal-provider>
        <n-dialog-provider>
          <n-notification-provider>
            <n-message-provider>
              <app />
            </n-message-provider>
          </n-notification-provider>
        </n-dialog-provider>
      </n-modal-provider>
    </n-loading-bar-provider>
  </n-config-provider>
</template>
