import type {
  DialogProviderInst,
  LoadingBarProviderInst,
  MessageProviderInst,
  NotificationProviderInst
} from 'naive-ui';

interface ConfigType {
  projectName: string;
  websiteTitleSuffix: string;
  copyrightName: string;
  versionNumber: string;
}
interface SSOConfigType {
  open: boolean;
}

declare global {
  declare interface Window {
    $loadingBar: LoadingBarProviderInst;
    $dialog: DialogProviderInst;
    $message: MessageProviderInst;
    $notification: NotificationProviderInst;
    $CONFIG?: {
      'zh-CN'?: ConfigType;
      en?: ConfigType;
      projectConfig?: {
        sign?: string;
        sso?: SSOConfigType;
        ossUrl?: string;
        tableFilterColumnCache?: boolean;
      };
    };
  }
}
