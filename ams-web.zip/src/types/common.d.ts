export declare global {
  // 开启状态
  type OpenStateType = 0 | 1;

  // Select keys
  type KeysType = string | number;
}
