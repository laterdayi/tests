<script lang="ts">
import { MaterialDisembarkApis } from '@/service/apis/assembly/material-manage/material-disembark';

interface MachineType {
  materialNo: string;
  supplierID: string;
  supplierName: string;
  supplierBatchNumber: string;
  purchaseOrder: string;
  productionDate: string;
  expireDate: string;
  iniLength: string;
  currentLength: string;
  eqpId: string;
  materialCode: string;
  remark: string;
}

// 初始化表单
const initFormSchemas = (
  machineInfo: Ref<MachineType | undefined>,
  handleGetMachineInfo?: (scanCode: string) => Promise<void>,
  isLoadingMachineInfo?: Ref<boolean>,
  initFormData?: Nullable<MachineType>,
  updateField?: (data: Nullable<MachineType>) => void
): FormSchemaType => [
  {
    type: 'input',
    model: 'materialCode',
    formItemProps: {
      label: i18nt('materialNumber'),
      rule: [useRules('input', i18nt('materialNumber')), useRuleStringLength()]
    },
    componentProps: computed(() => ({
      loading: isLoadingMachineInfo?.value,
      onKeydown: (e: KeyboardEvent) =>
        e.key === 'Enter' && handleGetMachineInfo?.((e.target as HTMLInputElement).value),
      onUpdateValue: (val: string) => (
        updateField?.({ ...initFormData, materialCode: val } as MachineType), (machineInfo.value = __)
      )
    }))
  },
  {
    type: 'input',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'materialNo',
    formItemProps: { label: i18nt('materialCode'), rule: useRuleStringLength() },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'supplierName',
    formItemProps: { label: i18nt('supplierName') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'supplierBatchNumber',
    formItemProps: { label: i18nt('supplierBatchNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'purchaseOrder',
    formItemProps: { label: i18nt('purchaseOrderNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'date-picker',
    model: 'productionDate',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('productionDate') },
    componentProps: { disabled: true }
  },
  {
    type: 'date-picker',
    model: 'expireDate',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('expireDate') },
    componentProps: { disabled: true }
  },
  {
    type: 'input-number',
    model: 'iniLength',
    formItemProps: { label: i18nt('initCount') },
    componentProps: { disabled: true, min: 0 }
  },
  {
    type: 'input-number',
    model: 'currentLength',
    formItemProps: { label: i18nt('currentCount') },
    componentProps: { disabled: true, min: 0 }
  },
  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark'),
    componentProps: { disabled: true }
  })
];
</script>

<script setup lang="ts">
const initFormData = {
  materialNo: null,
  supplierID: null,
  supplierName: null,
  supplierBatchNumber: null,
  purchaseOrder: null,
  productionDate: null,
  expireDate: null,
  iniLength: null,
  currentLength: null,
  eqpId: null,
  materialCode: null,
  remark: null
};

// 表单模型
const { formData, resetField, validate, formRef, updateField } = useForm<Nullable<MachineType>>(initFormData);

const { isLoading: isLoadingMachine, execute: executeMachine } = useAxiosPost();

// 获取机器信息
const {
  isLoading: isLoadingMachineInfo,
  execute: executeGetMachineInfo,
  data: machineInfo
} = useAxiosGet<MachineType>(MaterialDisembarkApis.getMachineInfoApi);
const handleGetMachineInfo = async (scanCode: string) => {
  try {
    const { data } = await executeGetMachineInfo(__, { params: { scanCode, type: 2 } });
    updateField(data.value ?? __);
  } catch (error) {
    formData.value.materialCode = null;
    console.log('获取机器信息异常：', error);
  }
};

// 操作下机
const handleDisembark = async () => {
  try {
    await validate();
    await executeMachine(MaterialDisembarkApis.disembarkApi, {
      data: useOmitNilRequestParams(formData.value)
    });
    resetField();
  } catch (error) {
    console.log('下机异常：', error);
  }
};

const formSchemas = initFormSchemas(machineInfo, handleGetMachineInfo, isLoadingMachineInfo, initFormData, updateField);
</script>

<template>
  <div id="material-disembark">
    <base-spin :show="isLoadingMachine">
      <base-card :title="$t('materialDisembark')">
        <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="formSchemas" />
        <section class="text-right">
          <base-button button-name="save" :disabled="!machineInfo?.materialCode" @click="handleDisembark">
            {{ $t('save') }}
          </base-button>
        </section>
      </base-card>
    </base-spin>
  </div>
</template>
