<script lang="ts">
import BaseTag from '@c/base-ui/base-tag/base-tag.vue';
import { MaterialInfoManageApis } from '@/service/apis/assembly/material-manage/material-info-manage';

interface QueryType {
  code: string
  materialNo: string
  materialTypeId: string
}

interface EditType {
  effectiveTime: string
  expireDate: string
  expireUseDays: string
  iniLength: string
  materialCode: string
  materialNo: string
  materialTypeID: string
  productionDate: string
  purchaseOrder: string
  remark: string
  supplierID: string
}

interface TableListType {
  id: string
  createTime: string
  creator: string
  currentLength: string
  effectiveTime: string
  eqpId: string
  estimateExpireTime: string
  expireDate: string
  expireTime: string
  expireUseDays: string
  iniLength: string
  iniLengths: number
  isStart: string
  materialCode: string
  materialNo: string
  materialTypeName: string
  onEqpTime: string
  productionDate: string
  productionTime: string
  purchaseOrder: string
  remark: string
  startTime: string
  supplierBatchNumber: string
  supplierID: string
  supplierName: string
}

// 初始化查询表单
const initQueryFormSchemas = (
  materialCategoryList: Ref<OptionsType[] | undefined>,
  isLoadingMaterialCategoryList: Ref<boolean>
): FormSchemaType => [
  { type: 'input', model: 'code', formItemProps: { label: i18nt('materialNumber') } },
  { type: 'input', model: 'materialNo', formItemProps: { label: i18nt('materialCode') } },
  {
    type: 'select',
    model: 'materialTypeId',
    formItemProps: { label: i18nt('materialCategory') },
    componentProps: computed(() => ({
      options: materialCategoryList.value,
      loading: isLoadingMaterialCategoryList.value,
      labelField: 'name',
      valueField: 'id'
    }))
  }
];

// 初始化表单
const initFormSchemas = (
  curdRef?: CurdRefType<QueryType, EditType, TableListType>,
  materialCategoryList?: OptionsType[],
  isLoadingMaterialCategoryList?: boolean,
  supplierList?: OptionsType[],
  isLoadingSupplierList?: boolean
): FormSchemaType => [
  {
    type: 'input',
    model: 'materialCode',
    formItemProps: {
      label: i18nt('materialNumber'),
      rule: [useRules('input', i18nt('materialNumber')), useRuleStringLength()]
    },
    componentProps: { disabled: curdRef?.isEditMode }
  },
  {
    type: 'select',
    model: 'materialTypeID',
    formItemProps: { label: i18nt('materialCategory'), rule: useRules('input', i18nt('materialCategory')) },
    componentProps: {
      options: materialCategoryList,
      loading: isLoadingMaterialCategoryList,
      labelField: 'name',
      valueField: 'id'
    }
  },
  {
    type: 'input',
    model: 'materialNo',
    formItemProps: { label: i18nt('materialCode'), rule: useRuleStringLength() }
  },
  {
    type: 'select',
    model: 'supplierID',
    formItemProps: { label: i18nt('supplierName') },
    componentProps: {
      options: supplierList,
      loading: isLoadingSupplierList,
      labelField: 'name',
      valueField: 'id'
    }
  },
  {
    type: 'input',
    model: 'purchaseOrder',
    formItemProps: { label: i18nt('purchaseOrderNumber'), rule: useRuleStringLength(0, 100) }
  },
  {
    type: 'date-picker',
    model: 'productionDate',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('productionDate'), rule: useRules('change', i18nt('productionDate')) }
  },
  {
    type: 'date-picker',
    model: 'expireDate',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('expireDate'), rule: useRules('change', i18nt('expireDate')) }
  },
  {
    type: 'input-number',
    model: 'iniLength',
    formItemProps: {
      label: i18nt('initCount'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('initCount') }),
        useRuleNumberLength()
      ]
    }
  },
  {
    type: 'input-number',
    model: 'expireUseDays',
    formItemProps: {
      label: i18nt('expireUseDay'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('expireUseDay') }),
        useRuleNumberLength(0, 3)
      ]
    },
    componentProps: { min: 0 }
  },
  {
    type: 'input-number',
    model: 'effectiveTime',
    formItemProps: {
      label: i18nt('effectiveTime', { val: '(h)' }),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', {
          required: false,
          message: i18nt('effectiveTime', { val: '(h)' })
        }),
        useRuleNumberLength()
      ]
    }
  },
  useRenderFormTextarea({ model: 'remark', label: i18nt('remark') })
];

const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  curdRef: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('materialNumber'),
    key: 'materialCode',
    sorter: true,
    render: rowData =>
      useRenderTableTitleEdit(
        rowData.materialCode,
        () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title)
      )
  },
  { title: i18nt('materialCategory'), key: 'materialTypeName', sorter: true },
  { title: i18nt('equipmentNumber'), key: 'eqpId', sorter: true },
  { title: i18nt('materialCode'), key: 'materialNo', sorter: true },
  { title: i18nt('initCount'), key: 'iniLength', sorter: true },
  { title: i18nt('currentCount'), key: 'currentLength' },
  { title: i18nt('expireUseDay'), key: 'expireUseDays', width: TABLE_WIDTH_INFO },
  { title: i18nt('effectiveTime'), key: 'effectiveTime', width: TABLE_WIDTH_STATE },
  {
    title: i18nt('isStartTimer'),
    key: 'isStart',
    width: TABLE_WIDTH_INFO,
    render: rowData => {
      const isStart = rowData.isStart === '1';
      return h(
        BaseTag,
        { type: isStart ? 'success' : 'info' },
        { default: () => h('span', null, i18nt(isStart ? 'yes' : 'no')) }
      );
    }
  },
  { title: i18nt('startTimerTime'), key: 'startTime', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: i18nt('estimateExpireTime'), key: 'estimateExpireTime', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: i18nt('boardingTime'), key: 'onEqpTime', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: i18nt('productionDate'), key: 'productionDate', sorter: true, width: TABLE_WIDTH_DATE },
  { title: i18nt('expireDate'), key: 'expireDate', sorter: true, width: TABLE_WIDTH_DATE },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('supplierName'), key: 'supplierName' },
  { title: i18nt('purchaseOrderNumber'), key: 'purchaseOrder' }
];
</script>

<script setup lang="ts">
// 获取材料类别列表
const {
  data: materialCategoryList,
  isLoading: isLoadingMaterialCategoryList,
  execute: executeGetMaterialCategoryList
} = useAxiosGet<OptionsType[]>(MaterialInfoManageApis.getMaterialCategoryListApi);
executeGetMaterialCategoryList();

// 获取供应商列表
const {
  data: supplierList,
  isLoading: isLoadingSupplierList,
  execute: executeGetSupplierList
} = useAxiosGet<OptionsType[]>(MaterialInfoManageApis.getSupplierListApi);
executeGetMaterialCategoryList();

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas(materialCategoryList, isLoadingMaterialCategoryList);
// 查询表单参数
const queryFormParams: Nullable<QueryType> = { code: null, materialNo: null, materialTypeId: null };
// 查询表单数据 -> 响应式

const curdRefPagination = computed(() => curdRef.value?.pagination);

// 表单模型
const formSchemas = computed(() =>
  initFormSchemas(
    curdRef.value,
    materialCategoryList.value,
    isLoadingMaterialCategoryList.value,
    supplierList.value,
    isLoadingSupplierList.value
  )
);
// 表单参数
const formParams = {
  effectiveTime: null,
  expireDate: null,
  expireUseDays: null,
  iniLength: null,
  materialCode: null,
  materialNo: null,
  materialTypeID: null,
  productionDate: null,
  purchaseOrder: null,
  remark: null,
  supplierID: null
};

const tableColumns = createColumns(curdRefPagination, curdRef);

// 查询所有列表
const queryAllSelectList = () => (executeGetMaterialCategoryList(), executeGetSupplierList());

// 开始计时
const { isLoading: isLoadingStartTimer, execute: executeStartTimer } = useAxiosPost(
  MaterialInfoManageApis.startTimerApi
);
const handleStartTimer = async () => {
  try {
    await executeStartTimer(__, {
      data: { ids: curdRef?.value?.tableRef?.selectedKeys }
    });
    curdRef?.value?.executeQueryList();
    curdRef?.value?.tableRef?.clearSelected();
  } catch (error) {
    console.log('开始计时异常:', error);
  }
};

// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    startTimer: handleStartTimer
  };
  permissionAction[permission]?.();
};
</script>

<template>
  <div id="material-info-manage">
    <base-curd
      ref="curdRef"
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_MIDDLE }"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :form-permission-disable="{ startTimer: curdRef?.tableRef?.selectedKeys?.length === 0 }"
      :columns="tableColumns"
      :create-api="MaterialInfoManageApis.createMaterialInfoApi"
      :update-api="MaterialInfoManageApis.updateMaterialInfoApi"
      :read-api="MaterialInfoManageApis.getMaterialInfoListApi"
      :delete-api="MaterialInfoManageApis.deleteMaterialInfoApi"
      :edit-detail-api="MaterialInfoManageApis.getMaterialInfoDetailApi"
      :export-api="MaterialInfoManageApis.getMaterialInfoListApi"
      :download-api="MaterialInfoManageApis.downloadMaterialInfoApi"
      :import-api="MaterialInfoManageApis.importMaterialInfoApi"
      :permission-button-loading-props="{ startTimerLoading: isLoadingStartTimer }"
      modal-title="materialInfo"
      @before-open-add-modal="queryAllSelectList"
      @before-open-edit-modal="queryAllSelectList"
      @handle="handlePermission"
    />
  </div>
</template>
