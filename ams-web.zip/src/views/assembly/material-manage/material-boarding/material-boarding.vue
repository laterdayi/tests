<script lang="ts">
import { MaterialBoardingApis } from '@/service/apis/assembly/material-manage/material-boarding';

interface MachineType {
  materialNo: string;
  supplierID: string;
  supplierName: string;
  supplierBatchNumber: string;
  purchaseOrder: string;
  productionDate: string;
  expireDate: string;
  iniLength: string;
  currentLength: string;
  eqpId: string;
  materialCode: string;
  remark: string;
}

// 初始化表单
const initFormSchemas = (
  machineInfo: Ref<MachineType | undefined>,
  handleGetMachineInfo?: (scanCode: string) => Promise<void>,
  isLoadingMachineInfo?: Ref<boolean>,
  handleGetEquipmentInfo?: (eqpName: string) => Promise<void>,
  isLoadingGetEquipmentInfo?: Ref<boolean>,
  initFormData?: Nullable<MachineType>,
  formData?: Ref<Nullable<MachineType> | undefined>,
  updateField?: (data: Nullable<MachineType>) => void
): FormSchemaType => [
  {
    type: 'input',
    model: 'materialCode',
    formItemProps: {
      label: i18nt('materialNumber'),
      rule: [useRules('input', i18nt('materialNumber')), useRuleStringLength()]
    },
    componentProps: computed(() => ({
      loading: isLoadingMachineInfo?.value,
      onKeydown: (e: KeyboardEvent) =>
        e.key === 'Enter' && handleGetMachineInfo?.((e.target as HTMLInputElement).value),
      onUpdateValue: (val: string) => (
        updateField?.({ ...initFormData, materialCode: val, eqpId: formData?.value?.eqpId } as MachineType),
        (machineInfo.value = __)
      )
    }))
  },
  {
    type: 'input',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber'), rule: useRules('change', i18nt('equipmentNumber')) },
    componentProps: computed(() => ({
      loading: isLoadingGetEquipmentInfo?.value,
      onKeydown: (e: KeyboardEvent) =>
        e.key === 'Enter' && handleGetEquipmentInfo?.((e.target as HTMLInputElement).value)
    }))
  },
  {
    type: 'input',
    model: 'materialNo',
    formItemProps: { label: i18nt('materialCode'), rule: useRuleStringLength() },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'supplierName',
    formItemProps: { label: i18nt('supplierName') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'supplierBatchNumber',
    formItemProps: { label: i18nt('supplierBatchNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'purchaseOrder',
    formItemProps: { label: i18nt('purchaseOrderNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'date-picker',
    model: 'productionDate',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('productionDate') },
    componentProps: { disabled: true }
  },
  {
    type: 'date-picker',
    model: 'expireDate',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('expireDate') },
    componentProps: { disabled: true }
  },
  {
    type: 'input-number',
    model: 'iniLength',
    formItemProps: { label: i18nt('initCount') },
    componentProps: { disabled: true, min: 0 }
  },
  {
    type: 'input-number',
    model: 'currentLength',
    formItemProps: { label: i18nt('currentCount') },
    componentProps: { disabled: true, min: 0 }
  },
  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark'),
    componentProps: { disabled: true }
  })
];
</script>

<script setup lang="ts">
// 获取设备编号信息
const { isLoading: isLoadingGetEquipmentInfo, execute: executeGetEquipmentInfo } = useAxiosGet<MachineType>(
  MaterialBoardingApis.getEquipmentInfoApi
);
const handleGetEquipmentInfo = async (eqpName: string) => {
  try {
    if (!formData.value?.eqpId) return;
    await executeGetEquipmentInfo(__, { params: { eqpName } });
    formData.value.eqpId = null;
  } catch (error) {
    console.log('获取设备编号信息', error);
  }
};

// 表单模型
const initFormData: Nullable<MachineType> = {
  materialNo: null,
  supplierID: null,
  supplierName: null,
  supplierBatchNumber: null,
  purchaseOrder: null,
  productionDate: null,
  expireDate: null,
  iniLength: null,
  currentLength: null,
  eqpId: null,
  materialCode: null,
  remark: null
};
const { formData, resetField, validate, formRef, updateField } = useForm<Nullable<MachineType>>(initFormData);

// 获取机器信息
const {
  isLoading: isLoadingMachineInfo,
  execute: executeGetMachineInfo,
  data: machineInfo
} = useAxiosGet<MachineType>(MaterialBoardingApis.getMachineInfoApi);
const handleGetMachineInfo = async (scanCode: string) => {
  try {
    if (!formData.value?.materialCode) return;
    const { data, error } = await executeGetMachineInfo(__, { params: { scanCode, type: 1 } });
    updateField({ ...data.value, eqpId: formData.value.eqpId } as MachineType);
  } catch (error) {
    formData.value.materialCode = null;
    console.log('获取机器信息异常：', error);
  }
};

// 操作上机
const { isLoading: isLoadingMachine, execute: executeMachine } = useAxiosPost();
const handleBoarding = async () => {
  try {
    await validate();
    await executeMachine(MaterialBoardingApis.boardingApi, {
      data: useOmitNilRequestParams(formData.value)
    });
    resetField();
  } catch (error) {
    console.log('上机异常：', error);
  }
};

const formSchemas = initFormSchemas(
  machineInfo,
  handleGetMachineInfo,
  isLoadingMachineInfo,
  handleGetEquipmentInfo,
  isLoadingGetEquipmentInfo,
  initFormData,
  formData,
  updateField
);
</script>

<template>
  <div id="material-boarding">
    <base-spin :show="isLoadingMachine">
      <base-card :title="$t('materialBoarding')">
        <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="formSchemas" />
        <section class="text-right">
          <base-button button-name="save" :disabled="!machineInfo?.materialCode" @click="handleBoarding">
            {{ $t('save') }}
          </base-button>
        </section>
      </base-card>
    </base-spin>
  </div>
</template>
