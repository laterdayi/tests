<script lang="ts">
import { MaterialCategoryApis } from '@/service/apis/assembly/material-manage/material-category';

interface QueryType {
  name: string;
}

interface EditType {
  materialType: string;
  description: string;
  id: string;
}

interface TableListType {
  id: string;
  createTime: string;
  creator: string;
  description: string;
  editTime: string;
  editor: string;
  materialType: string;
  projectCode: string;
  status: string;
}

// 初始化查询表单
const initQueryFormSchemas = (): FormSchemaType => [
  { type: 'input', model: 'name', formItemProps: { label: i18nt('materialCategory') } }
];

// 初始化表单
const initFormSchemas = (): FormSchemaType => [
  {
    type: 'input',
    model: 'materialType',
    formItemProps: {
      label: i18nt('materialCategory'),
      rule: [useRules('input', i18nt('materialCategory')), useRuleStringLength(0, 20)]
    }
  },
  useRenderFormTextarea()
];

const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  curdRef: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('materialCategory'),
    key: 'materialType',
    sorter: true,
    render: rowData =>
      useRenderTableTitleEdit(
        rowData.materialType,
        () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title)
      ),
    width: TABLE_WIDTH_STATE * 4
  },
  { title: i18nt('description'), key: 'description' },
  { title: i18nt('creator'), key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), sorter: true, key: 'createTime', width: TABLE_WIDTH_DATETIME }
];
</script>

<script setup lang="ts">
// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas();
// 查询表单参数
const queryFormParams: Nullable<QueryType> = { name: null };
const curdRefPagination = computed(() => curdRef.value?.pagination);

// 表单模型
const formSchemas = initFormSchemas();
// 表单参数
const formParams = { materialType: null, description: null };

const tableColumns = createColumns(curdRefPagination, curdRef);
</script>

<template>
  <div id="material-category">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :create-api="MaterialCategoryApis.createMaterialCategoryApi"
      :update-api="MaterialCategoryApis.updateMaterialCategoryApi"
      :read-api="MaterialCategoryApis.getMaterialCategoryListApi"
      :delete-api="MaterialCategoryApis.deleteMaterialCategoryApi"
      :edit-detail-api="MaterialCategoryApis.getMaterialCategoryDetailApi"
      :export-api="MaterialCategoryApis.getMaterialCategoryListApi"
      :download-api="MaterialCategoryApis.downloadMaterialCategoryApi"
      :import-api="MaterialCategoryApis.importMaterialCategoryApi"
      modal-title="materialCategory"
    />
  </div>
</template>
