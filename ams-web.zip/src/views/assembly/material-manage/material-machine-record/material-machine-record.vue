<script lang="tsx">
import { MaterialMachineRecordApis } from '@/service/apis/assembly/material-manage/material-machine-record';
import { CommonApis } from '@/service/apis/common/common';

interface QueryType {
  actionType: string
  materialCode: string
  itemNumber: string
  eqpId: string
}

interface TableListType {
  id: string
  materialCode: string
  materialId: string
  eqpName: string
  eqpId: string
  purchaseOrder: string
  creator: string
  createTime: string
  iniLength: number
  currentLength: number
  actionType: number
  materialNo: string
  actionTypeName: string
}

// 初始化查询表单
const initQueryFormSchemas = (
  equipmentNumberList?: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberList?: Ref<boolean>,
  operateTypeList?: SelectOption[]
): FormSchemaType => [
  { type: 'input', model: 'materialCode', formItemProps: { label: i18nt('materialNumber') } },
  { type: 'input', model: 'itemNumber', formItemProps: { label: i18nt('materialCode') } },
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      options: equipmentNumberList?.value,
      loading: isLoadingEquipmentNumberList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'select',
    model: 'actionType',
    formItemProps: { label: i18nt('operateType') },
    componentProps: { options: operateTypeList }
  }
];
// 备件tag
export const tagColor: {
  [key: string]: {
    textColor: string
    background: string
  }
} = {
  上机: {
    textColor: '#FF0000',
    background: 'rgb(255,0,0,0.1)'
  },
  下机: {
    textColor: '#008000',
    background: 'rgb(0,128,0,0.1)'
  }
};
const createColumns = (pagination: ComputedRef<PaginationProps | undefined>): DataTableColumns<TableListType> => [
  useRenderTableIndex(pagination),
  { title: i18nt('materialNumber'), key: 'materialCode', sorter: true },
  { title: i18nt('equipmentNumber'), key: 'eqpId', sorter: true },
  { title: i18nt('materialCode'), key: 'materialNo', sorter: true },
  {
    title: i18nt('operateType'),
    key: 'actionTypeName',
    render(rowData) {
      const types: { [key: number]: string } = {
        1: TagState.error,
        2: TagState.success
      };
      return useRenderTableSingleTag(types[rowData.actionType] as TagStateType, i18nt(rowData.actionTypeName));
    },
    width: TABLE_WIDTH_STATE
  },
  { title: i18nt('operator'), key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('operateTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: i18nt('currentLength'), key: 'currentLength' }
];
</script>

<script setup lang="tsx">
// 获取设备编号列表
const {
  data: equipmentNumberList,
  isLoading: isLoadingEquipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
executeGetEquipmentNumberList();

const operateTypeList = [
  { value: '1,2', label: i18nt('all') },
  { value: '1', label: i18nt('boarding') },
  { value: '2', label: i18nt('disembark') }
];

// 模板引用
const curdRef = ref<CurdRefType<QueryType, never, TableListType>>();

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas(equipmentNumberList, isLoadingEquipmentNumberList, operateTypeList);
// 查询表单参数
const queryFormParams: Nullable<QueryType> = { actionType: '1,2', eqpId: null, materialCode: null, itemNumber: null };
// 查询表单数据 -> 响应式

const curdRefPagination = computed(() => curdRef.value?.pagination);

const tableColumns = createColumns(curdRefPagination);
</script>

<template>
  <div id="material-machine-record">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :read-api="MaterialMachineRecordApis.getMaterialMachineListApi"
      :export-api="MaterialMachineRecordApis.getMaterialMachineListApi"
    />
  </div>
</template>
