<script setup lang="tsx">
import { SparesStatisticalQueryApis } from '@/service/apis/assembly/spares-manage/spares-statistical-query';
import type {
  ListType,
  QueryType,
  TableListType
} from '@/service/apis/assembly/spares-manage/spares-statistical-query';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';
import { CommonApis } from '@/service/apis/common/common';

// 区域列表
const { data: areaList } = useAxiosGet<ListType[]>(
  CommonApis.getSelectItemListApi,
  { type: AttributeType.toolingArea },
  __,
  {
    immediate: true
  }
);
// 站别列表
const { data: stageList } = useAxiosGet<ListType[]>(
  CommonApis.getSelectItemListApi,
  { type: AttributeType.toolingStage },
  __,
  {
    immediate: true
  }
);
// 类别列表
const { data: toolingTypeList } = useAxiosGet<ListType[]>(SparesStatisticalQueryApis.getToolingTypeIdListApi, __, __, {
  immediate: true
});
// 型号列表
const { data: toolingModelList, execute: getToolingModelList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getToolingTypeIdListApi
);
getToolingModelList();
// 公共按钮大小
const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// tabs配置
const teTabsIndex = ref<number>(0);
// 公共api
const apis: { [key: number]: string } = {
  // 领还
  0: SparesStatisticalQueryApis.getCollectAndReturnApi,
  // 保养
  1: SparesStatisticalQueryApis.getPreserveApi,
  // 维护
  2: SparesStatisticalQueryApis.getRepairApi,
  // 库存
  3: SparesStatisticalQueryApis.getStockApi
};

const updateTabs = (value: number) => {
  resetQueryField();
  teTabsIndex.value = value;
  baseTableObj.value.pageParams.sort = null;
  baseTableObj.value.pageParams.sortName = null;
  // tableRef?.value?.tableRef?.handleClearSorter();
  tableRef?.value?.tableRef?.clearSorter();
  getList();
};
// 表单配置项
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryType>>({
  area: null,
  stage: null,
  toolingBarcode: null,
  toolingMode: null,
  toolingType: null,
  timestamp: useFormatDateRange(30)
});
// 领还/保养/维修表单
const collectAndReturnSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'area',
    formItemProps: { label: i18nt('region') },
    componentProps: {
      options: areaList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'stage',
    formItemProps: { label: i18nt('standBy') },
    componentProps: {
      options: stageList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: { label: i18nt('number') }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: teTabsIndex.value === 0 ? i18nt('collectionTime') : i18nt('maintenanceTime') },
    componentProps: { type: 'datetimerange' }
  }
]);
// 库存表单
const stockSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'area',
    formItemProps: { label: i18nt('region') },
    componentProps: {
      options: areaList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'stage',
    formItemProps: { label: i18nt('standBy') },
    componentProps: {
      options: stageList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'toolingType',
    formItemProps: { label: i18nt('category') },
    componentProps: {
      options: toolingTypeList.value,
      valueField: 'id',
      labelField: 'name',
      onUpdateValue: async (value: string) => {
        try {
          await getToolingModelList({
            params: {
              ToolingType: toolingTypeList.value?.find(ele => ele.id === value)?.name
            }
          });
          formData.value.toolingMode = null;
        } catch (error) {
          console.log(error);
        }
      }
    }
  },
  {
    type: 'select',
    model: 'toolingMode',
    formItemProps: { label: i18nt('model') },
    componentProps: {
      options: toolingModelList.value,
      valueField: 'id',
      labelField: 'name'
    }
  }
]);
// 表格ref
const tableRef = ref<TableRefType<TableListType> | null>(null);
// 表格查询传值更改
const refactorFormQueryParams = (data: QueryType) => {
  if (!data.timestamp) return;
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
// 表格公共配置
const baseTableObj = ref();
// 获取表格数据
const getList = () => {
  const data = useTable<TableListType[]>(apis[teTabsIndex.value as number], {
    queryFormParams: formData,
    refactorFormQueryParams
  });
  data.executeQueryList();
  baseTableObj.value = data;
};
getList();

// 公共表格
const tableColumns = computed<DataTableColumns<TableListType>>(() => {
  const columnsList: { [key: number]: DataTableColumns<TableListType> } = {
    0: collectAndReturnTableColumns,
    1: preserveTableColumns,
    2: repairTableColumns,
    3: stockTableColumns
  };
  return columnsList[teTabsIndex.value as number];
});
// 领还表格
const collectAndReturnTableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(baseTableObj.value.pagination),
  {
    title: i18nt('number'),
    key: 'toolingBarcode',
    sorter: true,
    width: 250
  },
  {
    title: i18nt('currentState'),
    key: 'actionType',
    render(row: TableListType) {
      return <>{row.actionType === 1 ? i18nt('collect') : i18nt('restitution')}</>;
    },
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('recipient'),
    key: 'lendToId'
  },
  {
    title: i18nt('collectionTime'),
    key: 'lendTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('collectingRemarks'), key: 'lendRemark' },
  {
    title: i18nt('returnee'),
    key: 'returnId',
    sorter: true
  },
  {
    title: i18nt('returnTime'),
    key: 'returnTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('returnRemarks'), key: 'returnRemark' },
  {
    title: i18nt('issuedBy'),
    key: 'grantId'
  },
  {
    title: i18nt('issuingTime'),
    key: 'grantTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('releaseRemarks'), key: 'grantRemark' },
  {
    title: i18nt('recipientQuery'),
    key: 'takerId'
  },
  {
    title: i18nt('receivingTime'),
    key: 'takebackTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('receiveRemarks'), key: 'takebackRemark' }
];
// 保养表格
const preserveTableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(baseTableObj.value.pagination),
  {
    title: i18nt('number'),
    key: 'toolingBarcode',
    sorter: true,
    width: 250
  },
  {
    title: i18nt('maintenanceTime'),
    key: 'systemTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('maintainerAccountBumber'),
    key: 'cleanId',
    sorter: true
  },
  {
    title: i18nt('maintenanceReason'),
    key: 'cleanReason'
  },
  {
    title: i18nt('maintenanceMethod'),
    key: 'cleanMode'
  },
  {
    title: i18nt('eqpId'),
    key: 'eqpId',
    sorter: true
  },
  { title: i18nt('preserveRemark'), key: 'remark' }
];
// 维修表格
const repairTableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(baseTableObj.value.pagination),
  {
    title: i18nt('number'),
    key: 'toolingBarcode',
    sorter: true,
    width: 250
  },
  {
    title: i18nt('maintenanceTime'),
    key: 'systemTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('maintainerAccountNumber'),
    key: 'repairId',
    sorter: true
  },
  {
    title: i18nt('repairsReplaceParts'),
    key: 'repairPart'
  },
  { title: i18nt('repairsReason'), key: 'maintainReason' },
  {
    title: i18nt('maintenanceMode'),
    key: 'repairMode'
  },
  {
    title: i18nt('eqpId'),
    key: 'eqpId',
    sorter: true
  },
  {
    title: i18nt('resetOrNot'),
    key: 'resetFlag',
    sorter: true,
    render(row: TableListType) {
      return (
        <>
          <base-switch checked-value={1} disabled unchecked-value={0} v-model:value={row.resetFlag} />
        </>
      );
    }
  },
  { title: i18nt('repairsRemark'), key: 'remark' }
];
// 库存表格
const stockTableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(baseTableObj.value.pagination),
  {
    title: i18nt('model'),
    key: 'toolingMode',
    sorter: true
  },
  {
    title: i18nt('category'),
    key: 'toolingType',
    sorter: true
  },
  {
    title: i18nt('totalCount'),
    key: 'allQty',
    sorter: true
  },
  {
    title: i18nt('numberOfGoodProducts'),
    key: '',
    children: [
      {
        title: i18nt('totalNumberOfGoodProducts'),
        align: 'center',
        key: 'allGoodQty'
      },
      {
        title: i18nt('numberOfWarehouses'),
        align: 'center',
        key: 'stockQty'
      },
      {
        title: i18nt('onlineQuantity'),
        align: 'center',
        key: 'lendQty'
      }
    ]
  },
  {
    title: i18nt('totalScrapped'),
    key: 'scrapQty',
    sorter: true
  }
];
// 导出数据
const isLoadingExportData = ref();
// 导出数据
const handleExport = () => {
  const { isLoading, execute: executeExportData } = useDownloadFile(apis[teTabsIndex.value]);
  isLoadingExportData.value = isLoading.value;
  let params = { ...baseTableObj.value.queryFormData };
  if (formData) params = refactorFormQueryParams?.(params);
  executeExportData?.(params);
};
// 页面按钮事件
const handleButton = (permission: PermissionType) => {
  switch (permission) {
    case 'reset':
      resetQueryField();
      getToolingModelList();
      baseTableObj.value.handleResetPageSize();
      getList();
      break;
    case 'search':
      baseTableObj.value.handleResetPageSize();
      getList();
      break;
    default:
      break;
  }
};

const { hasExportPermission, hasCustomPermission } = useRoutes();
</script>

<template>
  <div id="spares-statistical-query">
    <base-card>
      <n-tabs type="line" :default-value="teTabsIndex" animated @update:value="updateTabs">
        <n-tab-pane
          v-if="hasCustomPermission('collectAndReturn')"
          display-directive="show"
          :name="0"
          :tab="$t('collectAndReturn')"
        />
        <n-tab-pane v-if="hasCustomPermission('preserve')" display-directive="show" :name="1" :tab="$t('preserve')" />
        <n-tab-pane v-if="hasCustomPermission('repair')" display-directive="show" :name="2" :tab="$t('repairs')" />
        <n-tab-pane v-if="hasCustomPermission('stock')" display-directive="show" :name="3" :tab="$t('stock')" />
      </n-tabs>
      <!-- 查询 -->
      <base-form
        ref="formRef"
        v-model="formData"
        type="query"
        :schemas="teTabsIndex === 3 ? stockSchemas : collectAndReturnSchemas"
        label-align="right"
        layout="page"
      >
        <template #header-action>
          <permission-button
            :loading-props="{ searchLoading: baseTableObj.isLoadingQuery }"
            form
            @handle="handleButton"
          />
        </template>
      </base-form>
      <!-- 表格 -->
      <base-table
        ref="tableRef"
        remote
        :scroll-x="teTabsIndex === 0 ? TABLE_WIDTH_SCROLL_MIDDLE : 0"
        :columns="tableColumns"
        :data="baseTableObj.tableData ?? []"
        :loading="baseTableObj.isLoadingQuery || isLoadingExportData"
        :pagination="baseTableObj.pagination"
        @update:sorter="baseTableObj.handleSorterChange"
      >
        <template #header>
          <base-button
            v-if="hasExportPermission"
            :loading="isLoadingExportData"
            :size="componentSize"
            type="primary"
            button-name="export"
            @click="handleExport"
          >
            <base-icon icon="i-carbon:document-export" />
            {{ $t('export') }}
          </base-button>
        </template>
      </base-table>
    </base-card>
  </div>
</template>
