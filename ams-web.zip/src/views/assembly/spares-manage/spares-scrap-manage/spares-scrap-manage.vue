<script setup lang="tsx">
import scrapForm from './components/scrap-form.vue';
import { SparesScrapManageApis } from '@/service/apis/assembly/spares-manage/spares-scrap-manage';
import type { ListType, QueryType, TableListType } from '@/service/apis/assembly/spares-manage/spares-scrap-manage';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';

// 类别列表
const { data: toolingTypeList } = useAxiosGet<ListType[]>(SpareManageCommonApis.getByTypeModelListApi, __, __, {
  immediate: true
});
// 型号列表
const { data: toolingModelList, execute: getToolingModelList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getToolingTypeIdListApi
);
getToolingModelList();
// 表单
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryType>>({
  toolingType: null,
  toolingModel: null,
  toolingBarcode: null,
  flag: null,
  timestamp: null
});
// 状态列表
const flagList: ListType[] = [
  { id: '1', name: i18nt('applyForScrapping') },
  { id: '2', name: i18nt('rejected') },
  { id: '3', name: i18nt('scrapped') }
];
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'toolingType',
    formItemProps: { label: i18nt('category') },
    componentProps: {
      options: toolingTypeList.value,
      valueField: 'id',
      labelField: 'name',
      onUpdateValue: async (value: string) => {
        try {
          await getToolingModelList({
            params: {
              ToolingType: toolingTypeList.value?.find(ele => ele.id === value)?.name
            }
          });
          formData.value.toolingModel = null;
        } catch (error) {
          console.log(error);
        }
      }
    }
  },
  {
    type: 'select',
    model: 'toolingModel',
    formItemProps: { label: i18nt('model') },
    componentProps: {
      options: toolingModelList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: { label: i18nt('number') }
  },
  {
    type: 'select',
    model: 'flag',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      options: flagList,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('confirmScrappingDate') },
    componentProps: { type: 'datetimerange' }
  }
]);
const scrapFormRef = ref();
// 表格查询传值更改
const refactorFormQueryParams = (data: QueryType) => {
  if (!data.timestamp) return;
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  tableData,
  tableRef,
  executeQueryList: getList
} = useTable<TableListType[]>(SparesScrapManageApis.getListApi, { queryFormParams: formData, refactorFormQueryParams });
// 获取表格数据
getList();

const tagColor: {
  [key: string]: {
    textColor: string;
    background: string;
  };
} = {
  1: {
    // 申请报废
    textColor: '#008000',
    background: 'rgb(0,128,0,0.1)'
  },
  2: {
    // 已驳回
    textColor: '#FF0000',
    background: 'rgb(255,0,0,0.1)'
  },
  3: {
    // 已报废
    textColor: '#808080',
    background: 'rgb(128,128,128,0.1)'
  }
};
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('number'),
    key: 'toolingBarcode',
    width: 250,
    sorter: true
  },
  {
    title: i18nt('category'),
    key: 'toolingType',
    sorter: true
  },
  {
    title: i18nt('model'),
    key: 'toolingModel',
    width: TABLE_WIDTH_STATE,
    sorter: true
  },
  {
    title: i18nt('currentState'),
    key: 'flag',
    width: TABLE_WIDTH_STATE,
    render: (row: TableListType) => {
      let flagStr = '';
      if (row.flag === '1') {
        flagStr = i18nt('applyForScrapping');
      } else if (row.flag === '2') {
        flagStr = i18nt('rejected');
      } else if (row.flag === '3') {
        flagStr = i18nt('scrapped');
      }
      const colorObj = tagColor[row.flag as string];
      return (
        <base-tag
          color={{
            textColor: colorObj.textColor
          }}
          size="small"
          style={{
            background: colorObj.background,
            borderColor: colorObj.background
          }}
        >
          {flagStr}
        </base-tag>
      );
    },
    sorter: true
  },
  {
    title: i18nt('applicant'),
    key: 'creator',
    sorter: true
  },
  {
    title: i18nt('applicationTime'),
    key: 'createTime',
    width: TABLE_WIDTH_DATETIME,
    sorter: true
  },
  { title: i18nt('reasonForScrapping'), key: 'reason' },
  {
    title: i18nt('confirmedBy'),
    key: 'editor',
    sorter: true
  },
  {
    title: i18nt('confirmationTime'),
    key: 'editTime',
    width: TABLE_WIDTH_DATETIME,
    sorter: true
  },
  { title: i18nt('remark'), key: 'remark' }
];
// 删除
const deleteLoading = ref<boolean>(false);
const handleDelete = async (resolve?: AsyncEmitResolveType) => {
  try {
    const { execute } = useAxiosPost(SparesScrapManageApis.tableDeleteApi);
    isLoadingQuery.value = true;
    deleteLoading.value = true;
    await execute(__, {
      data: {
        ids: tableRef?.value?.selectedKeys
      }
    });
    isLoadingQuery.value = false;
    deleteLoading.value = false;
    pagination.value.page = 1;
    resetTable();
    resolve?.(true);
  } catch (error) {
    resolve?.(false);
  }
};
// 刷新表格
const resetTable = () => {
  tableRef?.value?.clearSelected();
  getList();
};
const handleButton = (
  permission: PermissionType | 'applyForScrapping' | 'confirmScrap',
  resolve?: AsyncEmitResolveType
) => {
  switch (permission) {
    case 'reset':
      resetQueryField();
      getToolingModelList();
      pagination.value.page = 1;
      getList();
      break;
    case 'search':
      pagination.value.page = 1;
      getList();
      break;
    case 'applyForScrapping':
      scrapFormRef.value.open(permission, []);
      break;
    case 'confirmScrap':
      scrapFormRef.value.open(permission, tableRef?.value?.selectedRows.map(ele => ele.toolingBarcode));
      break;
    case 'delete':
      handleDelete(resolve);
      break;
    default:
      break;
  }
};
// 按钮权限过滤
const disableCondition = () => {
  if (!tableRef.value) return;
  const list = tableRef.value?.selectedRows.filter(item => item !== undefined);
  return {
    confirmScrap: list.some((ele: TableListType) => ele.flag !== '1'),
    delete: list.length !== 0 ? list.some((ele: TableListType) => ele.flag !== '1') : true
  };
};
</script>

<template>
  <base-card id="spares-scrap-manage">
    <!-- 搜索 -->
    <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
      <template #header-action>
        <permission-button form :loading-props="{ searchLoading: isLoadingQuery }" @handle="handleButton" />
      </template>
    </base-form>
    <!-- 表格 -->
    <base-table
      ref="tableRef"
      remote
      :scroll-x="TABLE_WIDTH_SCROLL_SMALL"
      :columns="tableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery"
      :pagination="pagination"
      @update:sorter="handleSorterChange"
    >
      <template #header>
        <permission-button
          :disable-condition="disableCondition()"
          :loading-props="{ deleteLoading }"
          :select-length="tableRef?.selectedKeys?.length"
          @handle="handleButton"
        />
      </template>
    </base-table>
    <!-- 报废 -->
    <scrapForm ref="scrapFormRef" @reset-table="resetTable" />
  </base-card>
</template>
