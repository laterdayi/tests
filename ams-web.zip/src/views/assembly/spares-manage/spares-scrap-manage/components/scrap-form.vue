<script setup lang="tsx">
import { SparesScrapManageApis } from '@/service/apis/assembly/spares-manage/spares-scrap-manage';
import type {
  ApplyForScrappingTableColumnsType,
  ConfirmScrapTableColumnsType,
  ScrapFormType,
  TableColumnsType
} from '@/service/apis/assembly/spares-manage/spares-scrap-manage';
import type { ListType } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { AttributeType } from '@/constants/enum';
import { CommonApis } from '@/service/apis/common/common';

// 显示设置
const emit = defineEmits<{
  'reset-table': [];
}>();
const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 存放位置列表
const { data: stockList, execute: getStockList } = useAxiosGet<ListType[]>(CommonApis.getSelectItemListApi);
// 接口设置
const modalUrl = ref<string>('');
// 弹窗title
const modalTitle = ref<string>();
// 申请or确认
const modalTitleIsShow = ref<boolean>(true);
const confirmScrapList = ref<(string | null)[]>([]);
// 弹窗开启
const modalIsShow = ref<boolean>(false);
// 打开弹窗
const open = async (title: string, toolingBarcodeList: string[]) => {
  modelTableColumns.value = [
    ...tableColumns,
    ...(title === 'applyForScrapping' ? applyForScrappingTableColumns : confirmScrapTableColumns)
  ];
  modalUrl.value =
    title === 'applyForScrapping'
      ? SparesScrapManageApis.applyScrapToolingApi
      : SparesScrapManageApis.confirmScrapToolingApi;
  modalTitleIsShow.value = title === 'applyForScrapping';
  modalTitle.value = i18nt(title);
  modalIsShow.value = true;
  if (toolingBarcodeList.length !== 0) {
    confirmScrapList.value = toolingBarcodeList;
    numberQuery();
  } else {
    await getStockList({ params: { type: AttributeType.warehouseLocation } });
  }
};
// 表单是否输入编号
const numberIsShow = ref<boolean>(false);
// 表单配置
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingBarcde',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      }
    },
    class: 'w-95%!'
  },
  modalTitleIsShow.value
    ? __
    : {
        type: 'custom-form-item',
        render() {
          return <div></div>;
        },
        class: 'w-95%!'
      },
  numberIsShow.value
    ? {
        type: 'input',
        model: modalTitleIsShow.value ? 'applicant' : 'confirmer',
        formItemProps: {
          label: i18nt(`${modalTitleIsShow.value ? 'applicant' : 'confirmedBy'}`),
          rule: [
            useRules('input', i18nt(`${modalTitleIsShow.value ? 'applicant' : 'confirmedBy'}`)),
            useRuleStringLength(0)
          ]
        },
        componentProps: {
          onBlur: () => verifierBlur(),
          onKeyup: keyboardEvent => {
            if (keyboardEvent.key === 'Enter') {
              verifierBlur();
            }
          }
        },
        class: 'w-95%!'
      }
    : __,
  numberIsShow.value && !modalTitleIsShow.value
    ? {
        type: 'input',
        model: 'remark',
        formItemProps: {
          label: i18nt('remark')
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __
]);
const { formRef, validate, formData, resetField } = useForm<Nullable<ScrapFormType>>({
  toolingBarcde: null,
  applicant: null,
  confirmer: null,
  remark: null
});
// 表格配置项
const tableData = ref();
const isLoadingQuery = ref(false);
// 编号查询
const numberQuery = async () => {
  try {
    if (modalTitleIsShow.value) {
      isLoadingQuery.value = true;
      // 申请报废
      const { execute } = useAxiosGet<TableColumnsType>(SparesScrapManageApis.getToolingInfoApi);
      const { data } = await execute({
        params: { ...formData.value }
      });
      isLoadingQuery.value = false;
      if (!data.value) return;
      tableData.value = [];
      const isShow = tableData.value.some((ele: { id: string | number }) => ele.id === data?.value?.id);
      if (isShow) {
        $message.warning(i18nt('1015'));
      } else {
        tableData.value.push({ ...data.value });
      }
      if (!numberIsShow.value) {
        numberIsShow.value = true;
      }
      formData.value.toolingBarcde = '';
    } else if (formData.value.toolingBarcde !== '') {
      const isShow = confirmScrapList.value.includes(formData.value.toolingBarcde);
      if (isShow) {
        formData.value.toolingBarcde = '';
        return $message.warning(i18nt('1015'));
      } else if (formData.value.toolingBarcde !== null) {
        confirmScrapList.value.push(formData.value.toolingBarcde);
      }
      isLoadingQuery.value = true;
      const { execute } = useAxiosPost(SparesScrapManageApis.toolongScrapInfoApi);
      const { data } = await execute(__, {
        data: {
          toolingBarcodes: confirmScrapList.value
        }
      });
      isLoadingQuery.value = false;
      tableData.value = data.value;
      formData.value.toolingBarcde = '';
      if (!numberIsShow.value) {
        numberIsShow.value = true;
      }
    }
  } catch (error) {
    console.log(error);
    if (formData.value.toolingBarcde !== '') {
      formData.value.toolingBarcde = '';
      const index = confirmScrapList.value.findIndex(ele => ele === formData.value.toolingBarcde);
      confirmScrapList.value.splice(index, 1);
    }
  }
};
// 表格查询列表
const modelTableColumns = ref();
// 公共表格数组
const tableColumns: DataTableColumns<TableColumnsType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX,
    render(row: TableColumnsType, index: number) {
      return <>{index + 1}</>;
    }
  },
  {
    title: i18nt('number'),
    key: 'toolingBarcode'
  },
  {
    title: i18nt('category'),
    key: 'toolingType'
  },
  {
    title: i18nt('model'),
    key: 'toolingModel'
  }
];
// 申请报废表格
const applyForScrappingTableColumns: DataTableColumns<ApplyForScrappingTableColumnsType> = [
  {
    title: i18nt('storageLocation'),
    key: 'stock',
    width: 260,
    render(row: ApplyForScrappingTableColumnsType) {
      return (
        <>
          <base-select label-field="name" options={stockList.value} v-model:value={row.stock} value-field="id" />
        </>
      );
    }
  },
  {
    title: i18nt('spareState'),
    key: 'hdStatus',
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('reasonForScrapping'),
    key: 'reason',
    width: 120,
    render(row: ApplyForScrappingTableColumnsType) {
      return (
        <>
          <base-input onInput={() => rowInput(1, row.reason, row)} type="text" v-model:value={row.reason} />
          <div
            class="slotError"
            style={{
              display: row.reasonIsShow ? 'block' : 'none'
            }}
          >
            {i18nt('reasonForScrappingTips')}
          </div>
        </>
      );
    }
  },
  {
    title: i18nt('operator'),
    key: 'userId',
    render() {
      return <>{useUserStore()?.userInfo?.user.userName}</>;
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: ApplyForScrappingTableColumnsType, index: number) {
      return (
        <>
          <base-button button-name="delete" onClick={() => tableRowClick(index)} type="error">
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 表格输入框验证
const rowInput = (index: number, value: string | number, row: ApplyForScrappingTableColumnsType) => {
  let isShow = false;
  if (value?.toString().length > 100) {
    isShow = true;
  } else {
    isShow = false;
  }
  row.reasonIsShow = isShow;
};
// 确认报废表格
const confirmScrapTableColumns: DataTableColumns<ConfirmScrapTableColumnsType> = [
  {
    title: i18nt('storageLocation'),
    key: 'stock'
  },
  {
    title: i18nt('spareState'),
    key: 'hdStatus',
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('scrapper'),
    key: 'creator'
    // render() {
    //   return <>{useUserStore()?.userInfo?.user.userName}</>;
    // }
  },
  {
    title: i18nt('applicationForScrappingTime'),
    key: 'createTime',
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: ConfirmScrapTableColumnsType, index: number) {
      return (
        <>
          <base-button button-name="delete" onClick={() => tableRowClick(index)} type="error">
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 表格删除事件
const tableRowClick = (index: number) => {
  tableData.value.splice(index, 1);
  if (!modalTitleIsShow.value) {
    confirmScrapList.value.splice(index, 1);
  }
};
// 人员是否验证
const userIdIsShow = ref<boolean>(true);
// 人员验证
const verifierBlur = async () => {
  const { data } = await useAxiosGet(
    SparesScrapManageApis.checkUserApi,
    {
      userId: modalTitleIsShow.value ? formData.value.applicant : formData.value.confirmer
    },
    __,
    { immediate: true }
  );
  if (!data.value) {
    formData.value.applicant = '';
    formData.value.confirmer = '';
    userIdIsShow.value = true;
  } else {
    userIdIsShow.value = false;
  }
};
// 驳回
const rejectLoading = ref<boolean>(false);
const rejectClick = async () => {
  try {
    await validate();
    rejectLoading.value = true;
    const obj = {
      toolingBarcodes: confirmScrapList.value,
      confirmer: formData.value.confirmer,
      remark: formData.value.remark
    };
    await useAxiosPost(SparesScrapManageApis.rejectScrapToolingApi, { ...obj }, __, { immediate: true });
    rejectLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const confirmLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    verifierBlur();
    await validate();
    if (modalTitleIsShow.value) {
      const validStock = tableData.value.some(
        (ele: ApplyForScrappingTableColumnsType) => ele.stock === '' || ele.stock === null
      );
      if (validStock) {
        return $message.warning(i18nt('pleaseImprove') + i18nt('storageLocation'));
      }
      const validReason = tableData.value.some(
        (ele: ApplyForScrappingTableColumnsType) => ele.reason === '' || ele.reason === null
      );
      if (validReason) {
        return $message.warning(i18nt('pleaseImprove') + i18nt('reasonForScrapping'));
      }
      const reasonIsShow = tableData.value.some((ele: ApplyForScrappingTableColumnsType) => ele.reasonIsShow);
      if (reasonIsShow) {
        return $message.warning(i18nt('reasonForScrapping') + i18nt('reasonForScrappingTips'));
      }
    }
    confirmLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: modalTitleIsShow.value
        ? tableData.value.map((ele: ApplyForScrappingTableColumnsType & TableColumnsType) => {
            return {
              ...ele,
              applicant: formData.value.applicant
            };
          })
        : {
            toolingBarcodes: confirmScrapList.value,
            confirmer: formData.value.confirmer,
            remark: formData.value.remark
          }
    });
    confirmLoading.value = false;
    cancelModal();
  } catch (error) {
    confirmLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗1
const cancelModal = () => {
  numberIsShow.value = false;
  tableData.value = [];
  confirmScrapList.value = [];
  modalIsShow.value = false;
  userIdIsShow.value = true;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    id="spares-basic-information-dialog"
    :show="modalIsShow"
    class="w-70%!"
    preset="confirm"
    :title="modalTitle"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
    <base-table
      v-if="numberIsShow"
      remote
      :style="{ height: `520px` }"
      flex-height
      :columns="modelTableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery"
    />
    <template v-if="numberIsShow" #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        v-if="!modalTitleIsShow"
        :loading="rejectLoading"
        :disabled="userIdIsShow || rejectLoading"
        :size="componentSize"
        type="primary"
        button-name="reject"
        @click="rejectClick"
      >
        {{ $t('reject') }}
      </base-button>
      <base-button
        :size="componentSize"
        :disabled="userIdIsShow || confirmLoading"
        :loading="confirmLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t(modalTitleIsShow ? 'applyScrap' : 'confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>

<style lang="less">
#spares-basic-information-dialog {
  .w-full {
    display: flex;
    flex-wrap: wrap;
    .n-form-item.n-form-item--left-labelled {
      width: 50%;
    }
  }
  .n-dialog__content {
    z-index: 9;
  }
}
</style>

<style scoped lang="less">
:deep(.n-data-table-tr) {
  .slotError {
    color: #f56c6c;
    font-size: 10px;
    height: 10px;
    line-height: 10px;
    text-align: left;
    margin-top: 5px;
  }
  .n-data-table-td--last-row {
    border-bottom: 1px solid var(--n-merged-border-color) !important;
  }
}
</style>
