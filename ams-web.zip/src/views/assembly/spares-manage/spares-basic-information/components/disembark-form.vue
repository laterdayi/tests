<script setup lang="tsx">
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type { BoardingFormType, ListType } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 保养库位
const { data: newStockList, execute: getStockList } = useAxiosGet<ListType[]>(CommonApis.getSelectItemListApi);
// 弹窗开启
const modalIsShow = ref(false);
// 打开弹窗
const open = async () => {
  modalIsShow.value = true;
  await getStockList({ params: { type: AttributeType.pMStock } });
};
const tabsIndex = ref<string>('0');
// tabs切换
const tabsClick = (value: string) => {
  tabsIndex.value = value;
  // 重置表单并去除验证
  resetField();
  toolingBarcodeNew.value = '';
  eqpIdNew.value = '';
  toolingBarcodeList.value = [];
  toolingBarcodeIsShow.value = true;
};
// 备份编号
const toolingBarcodeNew = ref<string>('');
const toolingBarcodeIsShow = ref<boolean>(true);
// 清除编号带出的值
const clearReset = () => {
  toolingBarcodeIsShow.value = true;
  formData.value.eqpId = null;

  formData.value.toolingType = null;
  formData.value.toolingModel = null;
  formData.value.usedTime = null;
  formData.value.lifeTime = null;
};
//  备件表单
const sparePartSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRules('input', i18nt('number')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      },
      onClear: () => {
        clearReset();
      },
      onUpdateValue: (value: string) => {
        if (toolingBarcodeNew.value === '') return;
        if (toolingBarcodeNew.value !== value) {
          clearReset();
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'eqpId',
    formItemProps: {
      label: i18nt('eqpName'),
      rule: [useRules('input', i18nt('eqpName')), useRuleStringLength(0)]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  }
]);
const toolingBarcodeList = ref<ListType[]>([]);
// 备份设备编号
const eqpIdNew = ref<string | null>('');
// const toolingBarcodeIsShow = ref<boolean>(true);
// 清除设备编号带出的值
const eqpIdClearReset = (isShow?: boolean) => {
  toolingBarcodeIsShow.value = true;
  if (!isShow) {
    toolingBarcodeList.value = [];
  }

  formData.value.toolingBarcode = null;
  formData.value.toolingType = null;
  formData.value.toolingModel = null;
  formData.value.usedTime = null;
  formData.value.lifeTime = null;
};
// 设备表单
const equipmentSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'eqpId',
    formItemProps: {
      label: i18nt('eqpName'),
      rule: [useRules('input', i18nt('eqpName')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          eqpIdBlur();
        }
      },
      onClear: () => {
        eqpIdClearReset();
      },
      onUpdateValue: (value: string) => {
        if (eqpIdNew.value === '') return;
        if (eqpIdNew.value !== value) {
          eqpIdClearReset();
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRules('change', i18nt('number'))]
    },
    componentProps: {
      disabled: toolingBarcodeList.value.length === 0,
      options: toolingBarcodeList.value,
      valueField: 'id',
      labelField: 'name',
      onUpdateValue: (value: string) => {
        if (value) {
          numberQuery(value);
        }
      },
      onClear: () => {
        eqpIdClearReset(true);
      }
    },
    class: 'w-95%!'
  }
]);
// 备件编号查询/ 设备编号下拉
const numberQuery = async (value?: string) => {
  const { execute } = useAxiosGet<BoardingFormType>(SparesBasicInformationApis.getToolingInfoApi);
  const { data } = await execute({
    params: {
      toolingBarcde: value || formData.value.toolingBarcode,
      actionType: 7
    }
  });

  if (!data.value) {
    formData.value.toolingBarcode = '';
    toolingBarcodeNew.value = '';
    toolingBarcodeIsShow.value = true;
  } else {
    if (tabsIndex.value === '0') {
      restoreValidation();
    }
    toolingBarcodeNew.value = data.value.toolingBarcode;
    toolingBarcodeIsShow.value = false;
    formData.value = { ...formData.value, ...data.value };
  }
};
// 备件设变编号获取编号
const eqpIdBlur = async () => {
  const { execute } = useAxiosGet<ListType[]>(SparesBasicInformationApis.getAllToolingOnEqpApi);
  const { data } = await execute({
    params: {
      eqpId: formData.value.eqpId
    }
  });
  if (!data.value) {
    formData.value.eqpId = '';
    eqpIdNew.value = '';
    toolingBarcodeIsShow.value = true;
  } else {
    if (tabsIndex.value === '1') {
      restoreValidation();
      eqpIdNew.value = formData.value.eqpId;
    }
    toolingBarcodeList.value = data.value;
  }
};
// 备件,设备公共表单
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'usedTime',
    formItemProps: {
      label: i18nt('currentUsageNumber'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('currentUsageNumber') }),
        useRuleNumberLength()
      ]
    },
    componentProps: {
      disabled: true,
      min: 0
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'lifeTime',
    formItemProps: {
      label: i18nt('upperLifeLimit'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('upperLifeLimit') }),
        useRuleNumberLength()
      ]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'newStock',
    formItemProps: {
      label: i18nt('maintenanceLocation'),
      rule: [useRules('change', i18nt('maintenanceLocation'))]
    },
    componentProps: {
      options: newStockList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'remark',
    formItemProps: {
      label: i18nt('remark')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    class: 'w-95%!'
  }
]);
// 公共表单
const publicSchemas = computed<FormSchemaType>(() => {
  let list: FormSchemaType = [];
  if (tabsIndex.value === '0') {
    list = [...sparePartSchemas.value, ...modalSchemas.value];
  } else {
    list = [...equipmentSchemas.value, ...modalSchemas.value];
  }
  return list;
});
const { formRef, validate, formData, resetField, restoreValidation } = useForm<Nullable<BoardingFormType>>({
  toolingBarcode: null,
  eqpId: null,
  headId: null,
  toolingType: null,
  toolingModel: null,
  usedTime: null,
  lifeTime: null,
  remark: null,
  newStock: null
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost(SparesBasicInformationApis.toolingGetOffEqpApi);
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    console.log(formData.value.newStock);
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd({
      data: {
        ...formData.value
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  tabsIndex.value = '0';
  modalIsShow.value = false;
  toolingBarcodeNew.value = '';
  eqpIdNew.value = '';
  toolingBarcodeIsShow.value = true;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-60%!"
    preset="confirm"
    :title="$t('disembark')"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <div class="tabs-area">
      <n-tabs type="segment" :on-update:value="tabsClick">
        <n-tab-pane name="0" :tab="$t('cleaningSpareParts')" />
        <n-tab-pane name="1" :tab="$t('scanningEquipment')" />
      </n-tabs>
    </div>
    <base-form ref="formRef" v-model="formData" class="form" layout="dialog" :schemas="publicSchemas" />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        :size="componentSize"
        :disabled="saveFormLoading || toolingBarcodeIsShow"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>

<style scoped lang="less">
.tabs-area :deep(.n-tabs) {
  margin-left: 120px;
  width: 200px !important;
}
.tabs-area :deep(.n-tabs .n-tabs-rail .n-tabs-tab-wrapper .n-tabs-tab.n-tabs-tab--active) {
  background-color: #1890ff !important;
  color: #ffffff;
}
</style>
