<script setup lang="tsx">
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type {
  CollectFormType,
  CollectTableColumnsType,
  GrantTableColumnsType,
  ListType,
  ReceiveTableColumnsType,
  TableColumnsType
} from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { SparesScrapManageApis } from '@/service/apis/assembly/spares-manage/spares-scrap-manage';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 接口设置
const modalUrl = ref<string>('');
// 弹窗title
const modalTitle = ref<string>();
// 弹窗开启
const modalIsShow = ref(false);
// 状况标识
const openTitle = ref<string>('');
// 状况标识下标
const modalType = ref<number>(1);
const ruleTitle = ref<string>('');
// 状况处理对象
const apis: {
  [key: string]: {
    handleOpen: () => void;
    handleData: (tableData: TableColumnsType[], formData: Nullable<CollectFormType>) => void;
  };
} = {
  // 领用
  collect: {
    handleOpen: () => {
      modalType.value = 1;
      ruleTitle.value = 'recipient';
      modalUrl.value = SparesBasicInformationApis.getLendToolingApi;
      modelTableColumns.value = [...tableColumns, ...collectTableColumns];
    },
    handleData: (tableData: TableColumnsType[], formData: Nullable<CollectFormType>) => {
      return tableData.map(ele => {
        return {
          ...ele,
          lendTo: formData.ToReturn,
          lendRemark: formData.remark
        };
      });
    }
  },
  // 发放
  grant: {
    handleOpen: () => {
      modalType.value = 8;
      ruleTitle.value = 'issuedBy';
      modalUrl.value = SparesBasicInformationApis.grantToolingApi;
      modelTableColumns.value = [...tableColumns, ...grantTableColumns];
    },
    handleData: (tableData: TableColumnsType[], formData: Nullable<CollectFormType>) => {
      return {
        userId: formData.ToReturn,
        remark: formData.remark,
        toolingInfoList: tableData.map(ele => {
          return {
            toolingBarcode: ele.toolingBarcode,
            stock: ele.stock
          };
        })
      };
    }
  },
  // 归还
  restitution: {
    handleOpen: () => {
      modalType.value = 2;
      ruleTitle.value = 'returnee';
      modalUrl.value = SparesBasicInformationApis.returnToolingApi;
      modelTableColumns.value = [...tableColumns, ...restitutionTableColumns];
    },
    handleData: (tableData: TableColumnsType[], formData: Nullable<CollectFormType>) => {
      return tableData.map(ele => {
        return {
          ...ele,
          toReturn: formData.ToReturn,
          returnRemark: formData.remark
        };
      });
    }
  },
  // 接收
  receive: {
    handleOpen: async () => {
      modalType.value = 9;
      ruleTitle.value = 'recipientQuery';
      await getStockList({ params: { type: AttributeType.returnLocation } });
      modalUrl.value = SparesBasicInformationApis.takebackToolingApi;
      modelTableColumns.value = [...tableColumns, ...receiveTableColumns];
    },
    handleData: (tableData: TableColumnsType[], formData: Nullable<CollectFormType>) => {
      return {
        userId: formData.ToReturn,
        remark: formData.remark,
        toolingInfoList: tableData.map(ele => {
          return {
            toolingBarcode: ele.toolingBarcode,
            stock: ele.stock
          };
        })
      };
    }
  }
};
// 归还位置列表
const { data: stockList, execute: getStockList } = useAxiosGet<ListType[]>(CommonApis.getSelectItemListApi);
// 打开弹窗
const open = (title: string) => {
  apis[title as string].handleOpen();
  openTitle.value = title;
  modalTitle.value = i18nt(title);
  modalIsShow.value = true;
};
// 表单是否输入编号
const numberIsShow = ref<boolean>(false);
// 表单配置
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'custom-form-item',
    render() {
      return <div></div>;
    },
    class: 'w-95%!'
  },
  numberIsShow.value
    ? {
        type: 'input',
        model: 'ToReturn',
        formItemProps: {
          label: i18nt(`${ruleTitle.value}`),
          rule: [useRules('input', i18nt(ruleTitle.value)), useRuleStringLength(0)]
        },
        componentProps: {
          onKeyup: keyboardEvent => {
            if (keyboardEvent.key === 'Enter') {
              toReturnQuery();
            }
          },
          onBlur: () => {
            toReturnQuery();
          }
        },
        class: 'w-95%!'
      }
    : __,
  numberIsShow.value
    ? {
        type: 'input',
        model: 'remark',
        formItemProps: {
          label: i18nt('remark')
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __
]);
const { formRef, validate, formData, resetField } = useForm<Nullable<CollectFormType>>({
  toolingBarcode: null,
  ToReturn: null,
  remark: null
});

// 编号查询
const numberQuery = async () => {
  const { execute } = useAxiosGet<TableColumnsType>(SparesBasicInformationApis.getToolingInfoApi);
  const { data } = await execute({
    params: {
      toolingBarcde: formData.value.toolingBarcode,
      actionType: modalType.value
    }
  });
  if (!data.value) {
    formData.value.toolingBarcode = '';
  } else {
    if (!data.value) return;
    const nameIsShow = tableData.value.some(ele => ele.id === data?.value?.id);
    if (nameIsShow) {
      $message.warning(i18nt('numberMessageWarning'));
    } else {
      tableData.value.push({ ...data.value });
      numberIsShow.value = true;
    }
    formData.value.toolingBarcode = '';
  }
};
// 人员是否验证
const toReturnIsShow = ref<boolean>(true);
// 人员验证
const toReturnQuery = async () => {
  const { execute } = useAxiosGet(SparesScrapManageApis.checkUserApi);
  const { data } = await execute({
    params: {
      userId: formData.value.ToReturn
    }
  });
  if (!data.value) {
    formData.value.ToReturn = '';
    toReturnIsShow.value = true;
  } else {
    toReturnIsShow.value = false;
  }
};
// 表格配置项
const isLoadingQuery = ref<boolean>(false);
const tableData = ref<TableColumnsType[]>([]);
// 表格查询列表
const modelTableColumns = ref();
// 公共表格数组
const tableColumns: DataTableColumns<TableColumnsType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX,
    render(row: TableColumnsType, index: number) {
      return <>{index + 1}</>;
    }
  },
  {
    title: i18nt('number'),
    key: 'toolingBarcode'
  },
  {
    title: i18nt('model'),
    key: 'toolingModel'
  },
  {
    title: i18nt('currentUsageNumber'),
    key: 'usedTime',
    width: 150
  }
];
// 领用表格
const collectTableColumns: DataTableColumns<CollectTableColumnsType> = [
  {
    title: i18nt('storageLocation'),
    key: 'stock'
  },
  {
    title: i18nt('operateType'),
    key: 'actionType',
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('operator'),
    key: '',
    render() {
      return <>{useUserStore()?.userInfo?.user.userName}</>;
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: CollectTableColumnsType, index: number) {
      return (
        <>
          <base-button button-name="delete" onClick={() => tableRowClick(index)} type="error">
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 发放表格
const grantTableColumns: DataTableColumns<GrantTableColumnsType> = [
  {
    title: i18nt('storageLocation'),
    key: 'stock'
  },
  {
    title: i18nt('applicationCollectionTime'),
    key: 'lendDate',
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('recipient'),
    key: 'lendId'
  },
  {
    title: i18nt('operator'),
    key: '',
    render() {
      return <>{useUserStore()?.userInfo?.user.userName}</>;
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: GrantTableColumnsType, index: number) {
      return (
        <>
          <base-button button-name="delete" onClick={() => tableRowClick(index)} type="error">
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 归还表格
const restitutionTableColumns: DataTableColumns<TableColumnsType> = [
  {
    title: i18nt('operator'),
    key: '',
    render() {
      return <>{useUserStore()?.userInfo?.user.userName}</>;
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: TableColumnsType, index: number) {
      return (
        <>
          <base-button button-name="delete" onClick={() => tableRowClick(index)} type="error">
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 接收表格
const receiveTableColumns: DataTableColumns<ReceiveTableColumnsType> = [
  {
    title: i18nt('returnWarehouseLocation'),
    key: 'stock',
    width: 260,
    render(row: ReceiveTableColumnsType) {
      return (
        <>
          <base-select label-field="name" options={stockList.value} v-model:value={row.stock} value-field="id" />
        </>
      );
    }
  },
  {
    title: i18nt('applicationReturnTime'),
    key: 'returnDate',
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('returnee'),
    key: 'returnId'
  },
  {
    title: i18nt('operator'),
    key: '',
    render() {
      return <>{useUserStore()?.userInfo?.user.userName}</>;
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: ReceiveTableColumnsType, index: number) {
      return (
        <>
          <base-button button-name="delete" onClick={() => tableRowClick(index)} type="error">
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 表格删除
const tableRowClick = (index: number) => {
  tableData.value.splice(index, 1);
  if (tableData.value.length === 0) {
    numberIsShow.value = false;
    resetField();
  }
};
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    toReturnQuery();
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: apis[openTitle.value as string].handleData(tableData.value, formData.value)
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  numberIsShow.value = false;
  isLoadingQuery.value = false;
  toReturnIsShow.value = true;
  tableData.value = [];
  // 重置表单并去除验证
  resetField();
  modalIsShow.value = false;
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    id="spares-basic-information-dialog"
    :show="modalIsShow"
    class="w-70%!"
    preset="confirm"
    :title="modalTitle"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
    <base-table
      v-if="numberIsShow"
      remote
      :style="{ height: `520px` }"
      flex-height
      :columns="modelTableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery"
    />
    <template v-if="numberIsShow" #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        :size="componentSize"
        :disabled="toReturnIsShow || saveFormLoading"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ modalTitle }}
      </base-button>
    </template>
  </base-modal>
</template>

<style lang="less">
#spares-basic-information-dialog {
  .w-full {
    display: flex;
    flex-wrap: wrap;
    .n-form-item.n-form-item--left-labelled {
      width: 50%;
    }
  }
  .n-dialog__content {
    z-index: 9;
  }
}
</style>

<style scoped lang="less">
:deep(.n-data-table-tr) {
  .n-data-table-td--last-row {
    border-bottom: 1px solid var(--n-merged-border-color) !important;
  }
}
</style>
