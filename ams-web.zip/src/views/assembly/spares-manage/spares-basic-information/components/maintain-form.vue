<script setup lang="tsx">
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type {
  LeftFormType,
  LeftMaintainerFormType,
  LeftUpkeepFormType,
  ListType,
  RightFormType
} from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 弹窗开启
const modalIsShow = ref<boolean>(false);
// 维护状态列表
const hdStatusList = ref<ListType[]>([]);
// 打开弹窗
const open = (list: ListType[]) => {
  hdStatusList.value = list;
  leftFormData.value = { ...leftFormData.value, ...leftMaintainerFormData };
  modalIsShow.value = true;
};
// 保养原因
const { data: cleanReasonList, execute: getCleanReasonList } = useAxiosGet<ListType[]>(CommonApis.getSelectItemListApi);
// 保养方式
const { data: cleanModeList, execute: getCleanModeList } = useAxiosGet<ListType[]>(CommonApis.getSelectItemListApi);
// 左侧表单
const leftModalForm = computed<FormSchemaType>(() =>
  leftFormData.value.isRepair === 0
    ? [...modalForm.value, ...maintainerForm.value]
    : [...modalForm.value, ...upkeepForm.value]
);
const toolingBarcodeNew = ref<string>('');
const toolingBarcodeIsShow = ref<boolean>(true);
const modalForm = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRules('input', i18nt('number')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      },
      onClear: () => {
        rightResetField();
        toolingBarcodeIsShow.value = true;
        if (leftFormData.value.isRepair === 1) {
          leftFormData.value.hdStatus = null;
        } else {
          leftFormData.value.cleanReason = null;
          leftFormData.value.cleanMode = null;
          cleanReasonList.value = [];
          cleanModeList.value = [];
        }
      },
      onUpdateValue: (value: string) => {
        if (toolingBarcodeNew.value === '') return;
        if (toolingBarcodeNew.value !== value) {
          rightResetField();
          toolingBarcodeIsShow.value = true;
          if (leftFormData.value.isRepair === 1) {
            leftFormData.value.hdStatus = null;
          } else {
            leftFormData.value.cleanReason = null;
            leftFormData.value.cleanMode = null;
            cleanReasonList.value = [];
            cleanModeList.value = [];
          }
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'custom-form-item',
    render() {
      return (
        <>
          <div
            style={{
              marginLeft: '80px'
            }}
          >
            <span
              class="mr"
              style={{
                color: leftFormData.value.isRepair === 0 ? '#409eff' : ''
              }}
            >
              {i18nt('preserve')}
            </span>
            <n-switch
              checked-value={1}
              onUpdate:value={(value: number) => {
                leftResetField();
                rightResetField();
                toolingBarcodeNew.value = '';
                toolingBarcodeIsShow.value = true;
                leftFormData.value.cleanReason = null;
                leftFormData.value.cleanMode = null;
                cleanReasonList.value = [];
                cleanModeList.value = [];
                leftFormData.value = {
                  toolingBarcode: null,
                  isRepair: value
                };
                if (leftFormData.value.isRepair === 0) {
                  leftFormData.value = { ...leftFormData.value, ...leftMaintainerFormData };
                } else {
                  leftFormData.value = { ...leftFormData.value, ...leftUpkeepFormData };
                }
              }}
              unchecked-value={0}
              v-model:value={leftFormData.value.isRepair}
            />
            <span
              class="ml"
              style={{
                color: leftFormData.value.isRepair === 1 ? '#409eff' : ''
              }}
            >
              {i18nt('repairs')}
            </span>
          </div>
        </>
      );
    }
  }
]);
// 保养人列表
const maintainerForm = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'cleanId',
    formItemProps: {
      label: i18nt('maintainerAccountBumber'),
      rule: [useRules('input', i18nt('maintainerAccountBumber')), useRuleStringLength(0)]
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'cleanReason',
    formItemProps: {
      label: i18nt('maintenanceReason'),
      rule: [useRules('change', i18nt('maintenanceReason'))]
    },
    componentProps: {
      options: cleanReasonList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'cleanMode',
    formItemProps: {
      label: i18nt('maintenanceMethod'),
      rule: [useRules('change', i18nt('maintenanceMethod'))]
    },
    componentProps: {
      options: cleanModeList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'maintainRemark',
    formItemProps: {
      label: i18nt('remark')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    class: 'w-95%!'
  }
]);
// 维修方式列表
const isOutRepairList: ListType[] = [
  {
    id: '0',
    name: i18nt('internalMaintenance')
  },
  {
    id: '1',
    name: i18nt('externalMaintenance')
  }
];
// 维修人列表
const upkeepForm = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'repairId',
    formItemProps: {
      label: i18nt('maintainerAccountNumber'),
      rule: [useRules('input', i18nt('maintainerAccountNumber')), useRuleStringLength(0)]
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'isOutRepair',
    formItemProps: {
      label: i18nt('maintenanceMode'),
      rule: [useRules('change', i18nt('maintenanceMode'))]
    },
    componentProps: {
      onUpdateValue: () => {
        leftFormData.value.repairPart = null;
        leftFormData.value.hdStatus = null;
        leftFormData.value.toolingImage = null;
        leftFormData.value.isReset = '0';
        leftFormData.value.repairReason = null;
      },
      options: isOutRepairList,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  leftFormData.value.isOutRepair === '0'
    ? {
        type: 'input',
        model: 'repairPart',
        formItemProps: {
          label: i18nt('repairsReplaceParts'),
          rule: [useRules('input', i18nt('repairsReplaceParts')), useRuleStringLength(0)]
        },
        class: 'w-95%!'
      }
    : __,
  leftFormData.value.isOutRepair === '0'
    ? {
        type: 'select',
        model: 'hdStatus',
        formItemProps: {
          label: i18nt('spareState'),
          rule: [useRules('change', i18nt('spareState'))]
        },
        componentProps: {
          disabled: rightFormData.value.currentFlag !== '待用',
          // options: hdStatusList.value,
          options: hdStatusList.value?.map((ele: ListType) => {
            return {
              ...ele,
              disabled: ele.id === '4'
            };
          }),
          valueField: 'id',
          labelField: 'name'
        },
        class: 'w-95%!'
      }
    : __,
  leftFormData.value.isOutRepair === '0'
    ? {
        type: 'switch',
        model: 'isReset',
        formItemProps: {
          label: i18nt('resetOrNot')
        },
        componentProps: {
          checkedValue: '1',
          uncheckedValue: '0'
        },
        class: 'w-95%! justify-start!'
      }
    : __,
  leftFormData.value.isOutRepair === '0'
    ? {
        type: 'input',
        model: 'repairReason',
        formItemProps: {
          label: i18nt('repairsReason'),
          rule: [useRules('input', i18nt('repairsReason'))]
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __,
  leftFormData.value.isOutRepair === '0'
    ? useRenderFormUpload({
        model: 'toolingImage',
        label: i18nt('picture'),
        rule: ASTRICT_IMG_RULE,
        componentProps: {
          action: CommonApis.uploadFileApi,
          listType: 'image-card'
        },
        formData: leftFormData
      })
    : __,
  {
    type: 'input',
    model: 'maintainRemark',
    formItemProps: {
      label: i18nt('remark')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    class: 'w-95%!'
  }
]);
// 编号查询
const numberQuery = async () => {
  const { execute } = useAxiosGet<LeftUpkeepFormType & RightFormType>(SparesBasicInformationApis.getToolingInfoApi);
  const { data } = await execute({
    params: {
      toolingBarcde: leftFormData.value.toolingBarcode,
      actionType: 3
    }
  });
  if (!data.value) {
    leftFormData.value.toolingBarcode = '';
    leftFormData.value.hdStatus = '';
    toolingBarcodeNew.value = '';
    toolingBarcodeIsShow.value = true;
  } else {
    if (!data.value) return;
    if (data.value.toolingType) {
      await getCleanReasonList({ params: { type: AttributeType.maintainReason, value: data.value.toolingType } });
      await getCleanModeList({ params: { type: AttributeType.maintainMode, value: data.value.toolingType } });
    }
    if (leftFormData.value.isRepair === 0) {
      leftFormData.value.cleanReason = null;
      leftFormData.value.cleanMode = null;
      leftFormData.value.hdStatus = null;
    } else {
      if (!data.value.hdStatus) return;
      leftFormData.value.hdStatus = data?.value?.hdStatus.toString();
    }
    data.value.usedTime = data.value.usedTime?.toString();
    rightFormData.value = { ...data.value };
    rightFormData.value.time = useFormatDate();
    if (!data.value.toolingBarcode) return;
    toolingBarcodeNew.value = data.value.toolingBarcode;
    toolingBarcodeIsShow.value = false;
  }
};
// 公共表单值
const {
  formRef: leftFormRef,
  validate,
  formData: leftFormData,
  resetField: leftResetField
} = useForm<Nullable<LeftFormType & LeftUpkeepFormType & LeftMaintainerFormType>>({
  toolingBarcode: null,
  isRepair: 0
});
// 保养表单值
const leftMaintainerFormData: Nullable<LeftMaintainerFormType> = {
  cleanId: null,
  cleanReason: null,
  cleanMode: null,
  maintainRemark: null
};
// 维修表单值
const leftUpkeepFormData: Nullable<LeftUpkeepFormType> = {
  repairId: null,
  isOutRepair: '0',
  repairPart: null,
  hdStatus: null,
  isReset: '1',
  repairReason: null,
  remark: null,
  toolingImage: null
};
// 右侧表单
const rightModalForm = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category')
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model')
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'currentFlag',
    formItemProps: {
      label: i18nt('currentState')
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'time',
    formItemProps: {
      label: i18nt('time')
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'usedTime',
    formItemProps: {
      label: i18nt('currentUsageNumber')
    },
    class: 'w-95%!'
  }
]);
const {
  formRef: rightFormRef,
  formData: rightFormData,
  resetField: rightResetField
} = useForm<Nullable<RightFormType>>({
  toolingType: null,
  toolingModel: null,
  currentFlag: null,
  time: null,
  usedTime: null
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost(SparesBasicInformationApis.maintainToolingApi);
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    console.log({
      ...leftFormData.value,
      toolingBarcode: rightFormData.value.toolingBarcode,
      id: rightFormData.value.id
    });
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd({
      data: {
        ...leftFormData.value,
        toolingBarcode: rightFormData.value.toolingBarcode,
        id: rightFormData.value.id
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  toolingBarcodeNew.value = '';
  toolingBarcodeIsShow.value = true;
  // 重置表单并去除验证
  leftResetField();
  // 重置表单并去除验证
  rightResetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-60%!"
    preset="confirm"
    :title="$t('maintain')"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <n-row gutter="12">
      <n-col :span="16">
        <base-form ref="leftFormRef" v-model="leftFormData" class="form" layout="dialog" :schemas="leftModalForm" />
      </n-col>
      <n-col :span="8">
        <base-form
          ref="rightFormRef"
          v-model="rightFormData"
          class="form"
          layout="base"
          disabled
          :schemas="rightModalForm"
        />
      </n-col>
    </n-row>
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        :size="componentSize"
        :disabled="saveFormLoading || toolingBarcodeIsShow"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>
