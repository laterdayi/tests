<script setup lang="tsx">
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type { FormType, ListType } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 是否拥有编辑权限
const hasEditPermissionIsShow = ref<boolean>(true);
// 接口设置
const modalUrl = ref<string>('');
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
// 区域,站别,状态,存放位置列表
const areaList = ref<ListType[]>([]);
const stageList = ref<ListType[]>([]);
const hdStatusList = ref<ListType[]>([]);
const stockList = ref<ListType[]>([]);
// 类别列表
const { data: toolingTypeList, execute: getToolingTypeList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getByTypeModelListApi
);
// 型号列表
const { data: toolingModelList, execute: getToolingModelList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getToolingTypeIdListApi
);
// 获取详情
const { execute: getFrom } = useAxiosGet<FormType>(SparesBasicInformationApis.getFromApi);
// 打开弹窗
const open = async (row: string, isShow = true, selectList: { [key: string]: ListType[] }) => {
  try {
    areaList.value = selectList.areaList;
    stageList.value = selectList.stageList;
    hdStatusList.value = selectList.hdStatusList;
    stockList.value = selectList.stockList;
    getToolingTypeList();
    getToolingModelList();
    hasEditPermissionIsShow.value = isShow;
    if (row) {
      modalTitle.value = isShow ? i18nt('edit') + i18nt('sparesBasicInformation') : i18nt('viewDetail');
      const { data } = await getFrom({
        params: {
          id: row
        }
      });
      if (!data.value) return;
      if (data.value.receiveDate === '') {
        data.value.receiveDate = null;
      }
      if (data.value.expireDate === '') {
        data.value.expireDate = null;
      }
      modalForm.value = data.value;
      modalUrl.value = SparesBasicInformationApis.updateApi;
    } else {
      modalTitle.value = i18nt('add') + i18nt('sparesBasicInformation');
      modalUrl.value = SparesBasicInformationApis.addFormApi;
    }
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'area',
    formItemProps: {
      label: i18nt('region'),
      rule: [useRules('change', i18nt('region'))]
    },
    componentProps: {
      options: areaList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'stage',
    formItemProps: {
      label: i18nt('standBy'),
      rule: [useRules('change', i18nt('standBy'))]
    },
    componentProps: {
      options: stageList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category'),
      rule: [useRules('change', i18nt('category'))]
    },
    componentProps: {
      disabled: !!modalForm.value.id,
      options: toolingTypeList.value,
      valueField: 'id',
      labelField: 'name',
      onUpdateValue: async (value: string) => {
        await getToolingModelList({
          params: {
            ToolingType: toolingTypeList.value?.find(ele => ele.id === value)?.name
          }
        });
        modalForm.value.toolingModel = null;
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model'),
      rule: [useRules('change', i18nt('model'))]
    },
    componentProps: {
      disabled: !!modalForm.value.id,
      options: toolingModelList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRules('input', i18nt('number')), useRuleStringLength(0, 100)]
    },
    componentProps: {
      disabled: !!modalForm.value.id
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'hdStatus',
    formItemProps: {
      label: i18nt('spareState'),
      rule: [useRules('change', i18nt('spareState'))]
    },
    componentProps: {
      disabled: hasEditPermissionIsShow.value ? (modalForm.value.id ? modalForm.value.flag !== '1' : false) : true,
      options: hdStatusList.value?.map((ele: ListType) => {
        return {
          ...ele,
          disabled: ele.id === '4'
        };
      }),
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'poNo',
    formItemProps: {
      label: 'PO No',
      rule: [useRules('input', 'onlyNotChineseRule', { required: false }), useRuleStringLength(0, 50)]
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'trackId',
    formItemProps: {
      label: 'Track ID',
      rule: [useRules('input', 'onlyNotChineseRule', { required: false }), useRuleStringLength(0, 50)]
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'lifeTime',
    formItemProps: {
      label: i18nt('upperLifeLimit'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('upperLifeLimit') }),
        useRuleNumberLength()
      ]
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'usedTime',
    formItemProps: {
      label: i18nt('numberOfUses'),
      rule: [
        useRules('input-number', 'onlyPositiveIntZeroRule', { required: false, message: i18nt('numberOfUses') }),
        useRuleNumberLength()
      ]
    },
    componentProps: {
      min: 0
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'stock',
    formItemProps: {
      label: i18nt('storageLocation')
    },
    componentProps: {
      options: stockList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'date-picker',
    model: 'receiveDate',
    modelValue: 'formatted-value',
    formItemProps: {
      label: 'Receive Date'
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    },
    class: 'w-95%!'
  },
  {
    type: 'date-picker',
    model: 'releaseDate',
    modelValue: 'formatted-value',
    formItemProps: {
      label: 'Release Date'
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    },
    class: 'w-95%!'
  },
  {
    type: 'date-picker',
    model: 'expireDate',
    modelValue: 'formatted-value',
    formItemProps: {
      label: 'Expire Date'
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'pmCycle',
    formItemProps: {
      label: i18nt('maintenanceCycle'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('maintenanceCycle') }),
        useRuleNumberLength()
      ]
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'alarmDay',
    formItemProps: {
      label: i18nt('warningTime'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('warningTime') }),
        useRuleNumberLength()
      ]
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'remark',
    formItemProps: {
      label: i18nt('remark')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    class: 'w-95%!'
  }
]);
const {
  formRef,
  validate,
  formData: modalForm,
  resetField
} = useForm<Nullable<FormType>>({
  area: null,
  stage: null,
  toolingType: null,
  toolingModel: null,
  toolingBarcode: null,
  trackId: null,
  poNo: null,
  hdStatus: null,
  lifeTime: null,
  usedTime: null,
  stock: null,
  receiveDate: `${useFormatDate()} ${useFormatTime()}`,
  releaseDate: null,
  expireDate: `${useFormatDate()} ${useFormatTime()}`,
  pmCycle: null,
  WarningTime: null,
  remark: null
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    if (modalForm.value.id) {
      modalUrl.value = SparesBasicInformationApis.updateApi;
    } else {
      modalUrl.value = SparesBasicInformationApis.addFormApi;
    }
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: {
        ...modalForm.value
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-60%!"
    preset="confirm"
    :title="modalTitle"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form
      ref="formRef"
      v-model="modalForm"
      class="form"
      layout="dialog"
      :schemas="modalSchemas"
      :disabled="!hasEditPermissionIsShow"
    />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        v-if="hasEditPermissionIsShow"
        :size="componentSize"
        :disabled="saveFormLoading"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>
