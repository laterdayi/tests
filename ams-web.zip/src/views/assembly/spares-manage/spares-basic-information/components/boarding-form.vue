<script setup lang="tsx">
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type { BoardingFormType } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { MaterialBoardingApis } from '@/service/apis/assembly/material-manage/material-boarding';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 弹窗开启1
const modalIsShow = ref(false);
// 打开弹窗
const open = () => {
  modalIsShow.value = true;
};
//  表单配置
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRules('input', i18nt('number')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      },
      onClear: () => {
        clearReset();
      },
      onUpdateValue: (value: string) => {
        if (toolingBarcodeNew.value === '') return;
        if (toolingBarcodeNew.value !== value) {
          clearReset();
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'eqpId',
    formItemProps: {
      label: i18nt('eqpName'),
      rule: [useRules('input', i18nt('eqpName')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: async keyboardEvent => {
        try {
          if (keyboardEvent.key === 'Enter') {
            await executeGetEquipmentInfo({ params: { eqpName: formData.value.eqpId } });
          }
        } catch (error) {
          formData.value.eqpId = '';
          console.log(error);
        }
      },
      onBlur: async () => {
        try {
          await executeGetEquipmentInfo({ params: { eqpName: formData.value.eqpId } });
        } catch (error) {
          formData.value.eqpId = '';
          console.log(error);
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'usedTime',
    formItemProps: {
      label: i18nt('numberOfUses'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('numberOfUses') }),
        useRuleNumberLength()
      ]
    },
    componentProps: {
      disabled: true,
      min: 0
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'lifeTime',
    formItemProps: {
      label: i18nt('upperLifeLimit'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: false, message: i18nt('upperLifeLimit') }),
        useRuleNumberLength()
      ]
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'remark',
    formItemProps: {
      label: i18nt('remark')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    class: 'w-95%!'
  }
]);
// 备份编号
const toolingBarcodeNew = ref<string>('');
const toolingBarcodeIsShow = ref<boolean>(true);
// 编号查询
const numberQuery = async () => {
  try {
    const { execute } = useAxiosGet<BoardingFormType>(SparesBasicInformationApis.getToolingInfoApi);
    const { data } = await execute({
      params: {
        toolingBarcde: formData.value.toolingBarcode,
        actionType: 6
      }
    });
    if (!data.value) return;
    toolingBarcodeNew.value = data.value.toolingBarcode;
    formData.value.toolingType = data.value.toolingType;
    formData.value.toolingModel = data.value.toolingModel;
    formData.value.usedTime = data.value.usedTime;
    formData.value.lifeTime = data.value.lifeTime;
    formData.value.toolingBarcode = data.value.toolingBarcode;
    toolingBarcodeIsShow.value = false;
  } catch (error) {
    console.log(error);
    formData.value.toolingBarcode = '';
    toolingBarcodeNew.value = '';
    toolingBarcodeIsShow.value = true;
  }
};
// 获取设备编号信息
const { execute: executeGetEquipmentInfo } = useAxiosGet(MaterialBoardingApis.getEquipmentInfoApi);
const { formRef, validate, formData, resetField } = useForm<Nullable<BoardingFormType>>({
  toolingBarcode: null,
  eqpId: null,
  headId: null,
  toolingType: null,
  toolingModel: null,
  usedTime: null,
  lifeTime: null,
  remark: null
});
// 清除带出的值
const clearReset = () => {
  formData.value.toolingType = null;
  formData.value.toolingModel = null;
  formData.value.usedTime = null;
  formData.value.lifeTime = null;
  toolingBarcodeIsShow.value = true;
};

// 保存表单
const { execute: saveFormAdd } = useAxiosPost(SparesBasicInformationApis.toolingLendOnEqpApi);
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd({ data: { ...formData.value } });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  toolingBarcodeNew.value = '';
  toolingBarcodeIsShow.value = true;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-60%!"
    preset="confirm"
    :title="$t('boarding')"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" class="form" layout="dialog" :schemas="modalSchemas" />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        :size="componentSize"
        :disabled="saveFormLoading || toolingBarcodeIsShow"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>
