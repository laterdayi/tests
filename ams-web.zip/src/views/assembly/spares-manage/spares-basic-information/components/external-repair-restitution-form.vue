<script setup lang="tsx">
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type { ExternalRepairRestitutionFormType } from '@/service/apis/assembly/spares-manage/spares-basic-information';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 弹窗开启
const modalIsShow = ref(false);
// 打开弹窗
const open = () => {
  modalIsShow.value = true;
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRules('input', i18nt('number')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          saveForm();
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'date-picker',
    model: 'repairReturnDate',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('externalRepairReturnDate')
    },
    componentProps: {
      disabled: true,
      valueFormat: 'yyyy-MM-dd'
    },
    class: 'w-95%!'
  }
]);
const { formRef, validate, formData, resetField } = useForm<Nullable<ExternalRepairRestitutionFormType>>({
  toolingBarcode: '',
  repairReturnDate: useFormatDate()
});
// 保存表单
const { execute: saveFormAdd } = useAxiosGet('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd(SparesBasicInformationApis.repairReturnApi, {
      params: {
        toolingBarcode: formData.value.toolingBarcode
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};

// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-30%!"
    preset="confirm"
    :title="$t('externalRepairRestitution')"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form
      ref="formRef"
      v-model="formData"
      class="form"
      :label-width="100"
      layout="dialog"
      :schemas="modalSchemas"
    />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        :size="componentSize"
        :disabled="saveFormLoading"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>
