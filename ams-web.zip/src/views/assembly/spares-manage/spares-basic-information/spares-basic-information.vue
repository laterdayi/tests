<script setup lang="tsx">
import type { PaginationProps } from 'naive-ui';
import addForm from './components/add-form.vue';
import collectForm from './components/collect-form.vue';
import boardingForm from './components/boarding-form.vue';
import disembarkForm from './components/disembark-form.vue';
import maintainForm from './components/maintain-form.vue';
import externalRepairRestitutionForm from './components/external-repair-restitution-form.vue';
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type {
  ListType,
  QueryType,
  TableListType
} from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { AttributeType } from '@/constants/enum';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';
import { CommonApis } from '@/service/apis/common/common';

const { hasEditPermission } = useRoutes();
const addFormRef = ref();
const collectFormRef = ref();
const boardingFormRef = ref();
const disembarkFormRef = ref();
const maintainFormRef = ref();
const externalRepairRestitutionFormRef = ref();

// 区域列表
const { data: areaList, execute: getAreaList } = useAxiosGet<ListType[]>(
  CommonApis.getSelectItemListApi
);
// 站别列表
const { data: stageList, execute: getStageList } = useAxiosGet<ListType[]>(
  CommonApis.getSelectItemListApi
);
// 状态列表
const { data: hdStatusList, execute: getHdStatusList } = useAxiosGet<ListType[]>(
  SparesBasicInformationApis.getHDStatusApi
);
// 当前状态列表
const { data: currentFlagList, execute: getCurrentFlagList } = useAxiosGet<ListType[]>(
  SparesBasicInformationApis.getEnumListApi
);
// 型号列表
const { data: toolingModelList, execute: getToolingModelList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getToolingTypeIdListApi
);
// 存放位置列表
const { data: stockList, execute: getStockList } = useAxiosGet<ListType[]>(
  CommonApis.getSelectItemListApi
);
// 弹窗统一传递公共下拉框
const selectList = ref<{ [key: string]: ListType[] | undefined }>({});
const selectListApis = async () => {
  await getAreaList({ params: { type: AttributeType.toolingArea } });
  await getStageList({ params: { type: AttributeType.toolingStage } });
  await getHdStatusList();
  await getCurrentFlagList();
  await getToolingModelList();
  await getStockList({ params: { type: AttributeType.warehouseLocation } });
  selectList.value = {
    areaList: areaList.value,
    stageList: stageList.value,
    hdStatusList: hdStatusList.value,
    stockList: stockList.value
  };
};
selectListApis();
// 表单
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryType>>({
  area: null,
  stage: null,
  hdStatus: null,
  currentFlag: null,
  toolingModel: null,
  toolingBarcode: null,
  stock: null,
  trackId: null,
  poNo: null,
  timestamp: null
});
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'area',
    formItemProps: { label: i18nt('region') },
    componentProps: {
      options: areaList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'stage',
    formItemProps: { label: i18nt('standBy') },
    componentProps: {
      options: stageList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'hdStatus',
    formItemProps: { label: i18nt('spareState') },
    componentProps: {
      options: hdStatusList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'currentFlag',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      options: currentFlagList.value?.map((ele: ListType) => {
        return {
          ...ele,
          name: i18nt(ele.name)
        };
      }),
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'toolingModel',
    formItemProps: { label: i18nt('model') },
    componentProps: {
      options: toolingModelList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'input',
    model: 'toolingBarcode',
    formItemProps: { label: i18nt('number') }
  },
  {
    type: 'select',
    model: 'stock',
    formItemProps: { label: i18nt('storageLocation') },
    componentProps: {
      options: stockList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'input',
    model: 'trackId',
    formItemProps: { label: 'Track ID' }
  },
  {
    type: 'input',
    model: 'poNo',
    formItemProps: { label: 'PO No' }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: 'Receive Date' },
    componentProps: { type: 'datetimerange' }
  }
]);
// 表格配置项
// 表格查询传值更改
const refactorFormQueryParams = (data: QueryType) => {
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
const {
  handleSorterChange,
  pagination,
  handleResetPageSize,
  isLoadingQuery,
  tableData,
  mergedQueryFormData,
  tableRef,
  executeQueryList: getList
} = useTable<TableListType[]>(SparesBasicInformationApis.getListApi, {
  queryFormParams: formData,
  refactorFormQueryParams
});
// 获取表格数据
getList();
const renderIndex = computed<PaginationProps>(() => ({
  page: pagination?.value?.page,
  pageSize: pagination.value.pageSize
}));
// 备件tag
const tagColor: {
  [key: string]: {
    textColor: string;
    background: string;
  };
} = {
  'EnumHdStatus_Good': {
    // Good
    textColor: '#008000',
    background: 'rgb(0,128,0,0.1)'
  },
  'EnumHdStatus_Fail': {
    // Fail
    textColor: '#FF0000',
    background: 'rgb(255,0,0,0.1)'
  },
  'EnumHdStatus_Engineer': {
    // Engineer
    textColor: '#0000FF',
    background: 'rgb(0,0,255,0.1)'
  },
  'EnumHdStatus_Scrap': {
    // Scrap
    textColor: '#808080',
    background: 'rgb(128,128,128,0.1)'
  },
  'EnumHdStatus_ShutDown': {
    // ShutDown
    textColor: '#FFA500',
    background: 'rgb(255,165,0,0.1)'
  },
  'ToolingStateEnum_Free': {
    textColor: '#0000FF',
    background: 'rgb(0,0,255,0.1)'
  },
  'ToolingStateEnum_WaitGrant': {
    textColor: '#008000',
    background: 'rgb(0,128,0,0.1)'
  },
  'ToolingStateEnum_WaitLendOn': {
    textColor: '#9400D3',
    background: 'rgb(148,0,211,0.1)'
  },
  'ToolingStateEnum_OnEqp': {
    textColor: '#FF0000',
    background: 'rgb(255,0,0,0.1)'
  },
  'ToolingStateEnum_WaitPM': {
    textColor: '#00FFFF',
    background: 'rgb(0,255,255,0.1)'
  },
  'ToolingStateEnum_WaitReturn': {
    textColor: '#800080',
    background: 'rgb(128,0,128,0.1)'
  },
  'ToolingStateEnum_WaitTakeBack': {
    textColor: '#808080',
    background: 'rgb(128,128,128,0.1)'
  },
  'ToolingStateEnum_RepairSendBack': {
    textColor: '#F4A460',
    background: 'rgb(244,164,96,0.1)'
  }
};
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(renderIndex),
  {
    title: i18nt('region'),
    key: 'area',
    width: 100,
    render(rowData: TableListType) {
      return useRenderTableTitleEdit(
        rowData.area,
        () =>
          addFormRef?.value?.open?.(
            rowData.id,
            rowData.hdStatus === 'EnumHdStatus_Scrap' ? false : hasEditPermission.value,
            selectList.value
          )
      );
    }
  },
  {
    title: i18nt('standBy'),
    key: 'stage',
    width: 150
  },
  {
    title: i18nt('category'),
    key: 'toolingType',
    width: 120
  },
  {
    title: i18nt('model'),
    key: 'toolingModel',
    width: TABLE_WIDTH_STATE,
    sorter: true
  },
  {
    title: i18nt('number'),
    key: 'toolingBarcode',
    width: 420,
    sorter: true
  },
  {
    title: i18nt('currentState'),
    key: 'currentFlag',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(row: TableListType) {
      const colorObj = tagColor[row.currentFlag as string];
      return (
        <base-tag
          color={{
            textColor: colorObj.textColor
          }}
          size="small"
          style={{
            background: colorObj.background,
            borderColor: colorObj.background
          }}
        >
          {i18nt(`${row.currentFlag}`)}
        </base-tag>
      );
    }
  },
  {
    title: i18nt('storageLocation'),
    key: 'stock',
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('spareState'),
    key: 'hdStatus',
    width: TABLE_WIDTH_STATE,
    sorter: true,
    render(row: TableListType) {
      const colorObj = tagColor[row.hdStatus as string];
      return (
        <base-tag
          color={{
            textColor: colorObj.textColor
          }}
          size="small"
          style={{
            background: colorObj.background,
            borderColor: colorObj.background
          }}
        >
          {i18nt(`${row.hdStatus}`)}
        </base-tag>
      );
    }
  },
  {
    title: i18nt('lastMaintenanceTime'),
    key: 'lastPMDate',
    width: TABLE_WIDTH_DATETIME,
    sorter: true
  },
  {
    title: i18nt('lastMaintenancePersonnel'),
    key: 'lastPMOperator',
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('nextMaintenanceTime'),
    key: 'nextPMTime',
    width: TABLE_WIDTH_DATETIME,
    sorter: true
  },
  {
    title: i18nt('reason'),
    key: 'reason',
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('maintenanceCycle'),
    key: 'pmCycle',
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('warningTime'),
    key: 'alarmDay',
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('remark'),
    key: 'remark',
    width: TABLE_WIDTH_INFO
  }
];
// 删除
const deleteLoading = ref<boolean>(false);
const handleDelete = async (resolve?: AsyncEmitResolveType) => {
  try {
    const { execute } = useAxiosPost(SparesBasicInformationApis.tableDeleteApi);
    isLoadingQuery.value = true;
    deleteLoading.value = true;
    await execute(__, {
      data: {
        ids: tableRef?.value?.selectedKeys
      }
    });
    resolve?.(true);
    isLoadingQuery.value = false;
    deleteLoading.value = false;
    pagination.value.page = 1;
    resetTable();
  } catch (error) {
    resolve?.(false);
  }
};
// 刷新表格
const resetTable = () => {
  tableRef?.value?.clearSelected();
  getList();
};
// 导入按钮api
provide('importApi', SparesBasicInformationApis.importUserApi);
// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = useDownloadFile(
  SparesBasicInformationApis.getListApi
);
const handleExport = () => {
  let params = { ...mergedQueryFormData.value };
  if (formData) params = refactorFormQueryParams?.(params);
  executeExportData?.(params);
};
// 下载
const { execute: executeDownload, isLoading: isLoadingDownload } = useDownloadFile(
  SparesBasicInformationApis.downloadApi
);
// 按钮事件
const handleButton = (
  permission:
    | PermissionType
    | 'collect'
    | 'grant'
    | 'restitution'
    | 'receive'
    | 'boarding'
    | 'disembark'
    | 'maintain'
    | 'externalRepairRestitution',
  resolve?: AsyncEmitResolveType
) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      resetQueryField();
      handleResetPageSize();
      getList();
    },
    search: () => {
      handleResetPageSize();
      getList();
    },
    add: () => addFormRef.value.open(__, hasEditPermission.value, selectList.value),
    edit: () => addFormRef.value.open(tableRef?.value?.selectedKeys[0], hasEditPermission.value, selectList.value),
    delete: () => handleDelete(resolve),
    export: () => handleExport(),
    download: () => executeDownload(),
    boarding: () => boardingFormRef.value.open(),
    disembark: () => disembarkFormRef.value.open(),
    maintain: () => maintainFormRef.value.open(hdStatusList.value),
    externalRepairRestitution: () => externalRepairRestitutionFormRef.value.open(permission),
    collect: () => collectFormRef.value.open(permission),
    grant: () => collectFormRef.value.open(permission),
    restitution: () => collectFormRef.value.open(permission),
    receive: () => collectFormRef.value.open(permission)
  };
  columnsList[permission as string]();
};
</script>

<template>
  <base-card id="spares-basic-information">
    <!-- 搜索 -->
    <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
      <template #header-action>
        <permission-button form :loading-props="{ searchLoading: isLoadingQuery }" @handle="handleButton" />
      </template>
    </base-form>
    <!-- 表格 -->
    <base-table
      ref="tableRef"
      remote
      :scroll-x="TABLE_WIDTH_SCROLL_MIDDLE"
      :columns="tableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery || isLoadingExportData"
      :pagination="pagination"
      @update:sorter="handleSorterChange"
    >
      <template #header>
        <permission-button
          :loading-props="{
            exportLoading: isLoadingExportData,
            downloadLoading: isLoadingDownload,
            deleteLoading
          }"
          :select-length="tableRef?.selectedKeys?.length"
          :disable-condition="{
            edit: tableRef?.selectedRows.length !== 1 ? true : (tableRef?.selectedRows[0].hdStatus === 'EnumHdStatus_Scrap'),
            delete: tableRef?.selectedRows.length !== 0 ? (tableRef?.selectedRows.some((ele:TableListType) => ele.hdStatus === 'EnumHdStatus_Scrap')) : true
          }"
          @handle="handleButton"
        />
      </template>
    </base-table>
    <!-- 新增 -->
    <addForm ref="addFormRef" @reset-table="resetTable" />
    <!-- 领用 -->
    <collectForm ref="collectFormRef" @reset-table="resetTable" />
    <!-- 上机 -->
    <boardingForm ref="boardingFormRef" @reset-table="resetTable" />
    <!-- 下机 -->
    <disembarkForm ref="disembarkFormRef" @reset-table="resetTable" />
    <!-- 维护 -->
    <maintainForm ref="maintainFormRef" @reset-table="resetTable" />
    <!-- 外修归还 -->
    <externalRepairRestitutionForm ref="externalRepairRestitutionFormRef" @reset-table="resetTable" />
  </base-card>
</template>
