<script setup lang="tsx">
import collectingApplication from './components/collecting-application.vue';
import grantForm from './components/grant-form.vue';
import { SparesCollectingDocApis } from '@/service/apis/assembly/spares-manage/spares-collecting-doc';
import type {
  ListType,
  QueryFormType,
  TableListType
} from '@/service/apis/assembly/spares-manage/spares-collecting-doc';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';

const { hasEditPermission } = useRoutes();
// 类别列表
const { data: toolingTypeList } = useAxiosGet<ListType[]>(SpareManageCommonApis.getByTypeModelListApi, __, __, {
  immediate: true
});
// 型号列表
const { data: toolingModelList, execute: getToolingModelList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getToolingTypeIdListApi
);
getToolingModelList();
// 当前状态
const flagList: ListType[] = [
  { id: '1', name: i18nt('requested') },
  { id: '2', name: i18nt('rejected') },
  { id: '3', name: i18nt('issued') }
];
// 表单
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryFormType>>({
  toolingType: null,
  toolingModel: null,
  flag: null,
  timestamp: useFormatDateRange(30)
});
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'toolingType',
    formItemProps: { label: i18nt('category') },
    componentProps: {
      options: toolingTypeList.value,
      valueField: 'id',
      labelField: 'name',
      onUpdateValue: async (value: string) => {
        try {
          await getToolingModelList({
            params: {
              ToolingType: toolingTypeList.value?.find(ele => ele.id === value)?.name
            }
          });
          formData.value.toolingModel = null;
        } catch (error) {
          console.log(error);
        }
      }
    }
  },
  {
    type: 'select',
    model: 'toolingModel',
    formItemProps: { label: i18nt('model') },
    componentProps: {
      options: toolingModelList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'flag',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      options: flagList,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('applicationTime') },
    componentProps: { type: 'datetimerange' }
  }
]);
// 表格配置项
const collectingApplicationRef = ref();
const grantFormRef = ref();
// 表格查询传值更改
const refactorFormQueryParams = (data: QueryFormType) => {
  if (!data.timestamp) return;
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  tableData,
  executeQueryList: getList,
  tableRef
} = useTable<TableListType[]>(SparesCollectingDocApis.getListApi, {
  queryFormParams: formData,
  refactorFormQueryParams
});
getList();

const tagColor: {
  [key: string]: {
    textColor: string;
    background: string;
  };
} = {
  1: {
    // 已申请
    textColor: '#008000',
    background: 'rgb(0,128,0,0.1)'
  },
  2: {
    // 已驳回
    textColor: '#FF0000',
    background: 'rgb(255,0,0,0.1)'
  },
  3: {
    // 已发放
    textColor: '#808080',
    background: 'rgb(128,128,128,0.1)'
  }
};
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('collectingDocNo'),
    key: 'applyNo',
    width: 250,
    sorter: true,
    render(rowData: TableListType) {
      return rowData.flag === '1' ? (
        useRenderTableTitleEdit(
          rowData.applyNo,
          () => collectingApplicationRef?.value?.open?.(rowData.id, hasEditPermission.value)
        )
      ) : (
        <span>{rowData.applyNo}</span>
      );
    }
  },
  {
    title: i18nt('category'),
    key: 'toolingType',
    width: TABLE_WIDTH_STATE,
    sorter: true
  },
  {
    title: i18nt('model'),
    key: 'toolingModel',
    sorter: true
  },
  {
    title: i18nt('currentState'),
    key: 'flag',
    width: TABLE_WIDTH_STATE,
    render(row: TableListType) {
      let str = '';
      if (row.flag === '1') {
        str = i18nt('requested');
      } else if (row.flag === '2') {
        str = i18nt('rejected');
      } else if (row.flag === '3') {
        str = i18nt('issued');
      }
      const colorObj = tagColor[row.flag as string];
      return (
        <base-tag
          color={{
            textColor: colorObj.textColor
          }}
          size="small"
          style={{
            background: colorObj.background,
            borderColor: colorObj.background
          }}
        >
          {str}
        </base-tag>
      );
    },
    sorter: true
  },
  {
    title: i18nt('applicant'),
    key: 'applyId',
    sorter: true
  },
  {
    title: i18nt('applicationTime'),
    key: 'applyTime',
    width: TABLE_WIDTH_DATETIME,
    sorter: true
  },
  {
    title: i18nt('pickingQuantity'),
    key: 'applyQty',
    sorter: true
  },
  {
    title: i18nt('issuedBy'),
    key: 'grantId'
  },
  {
    title: i18nt('issuingTime'),
    key: 'grantTime',
    width: TABLE_WIDTH_DATETIME,
    sorter: true
  },
  {
    title: i18nt('issueSpareParts'),
    key: 'grantBarcodeList',
    ...useRenderTableMultiTag('grantBarcodeList')
  }
];
// 删除
const deleteLoading = ref<boolean>(false);
const handleDelete = async (resolve?: AsyncEmitResolveType) => {
  try {
    const { execute } = useAxiosPost(SparesCollectingDocApis.tableDeleteApi);
    isLoadingQuery.value = true;
    deleteLoading.value = true;
    await execute(__, {
      data: {
        ids: tableRef?.value?.selectedKeys
      }
    });
    isLoadingQuery.value = false;
    deleteLoading.value = false;
    pagination.value.page = 1;
    resetTable();
    resolve?.(true);
  } catch (error) {
    console.log(error);
    resolve?.(false);
  }
};
// 刷新表格
const resetTable = () => {
  tableRef?.value?.clearSelected();
  getList();
};
// 按钮事件
const handleButton = (
  permission: PermissionType | 'collectingApplication' | 'grant',
  resolve?: AsyncEmitResolveType
) => {
  if (permission === 'reset') {
    resetQueryField();
    getToolingModelList();
    pagination.value.page = 1;
    getList();
  } else if (permission === 'search') {
    pagination.value.page = 1;
    getList();
  } else if (permission === 'collectingApplication') {
    collectingApplicationRef.value.open();
  } else if (permission === 'edit') {
    collectingApplicationRef.value.open(tableRef?.value?.selectedKeys[0], hasEditPermission.value);
  } else if (permission === 'delete') {
    handleDelete(resolve);
  } else if (permission === 'grant') {
    grantFormRef.value.open(tableRef?.value?.selectedRows[0]);
  }
};
</script>

<template>
  <base-card id="spares-collecting-doc">
    <!-- 搜索 -->
    <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas">
      <template #header-action>
        <permission-button :loading-props="{ searchLoading: isLoadingQuery }" form @handle="handleButton" />
      </template>
    </base-form>
    <!-- 表格 -->
    <base-table
      ref="tableRef"
      remote
      :scroll-x="TABLE_WIDTH_SCROLL_SMALL"
      :columns="tableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery"
      :pagination="pagination"
      @update:sorter="handleSorterChange"
    >
      <template #header>
        <permission-button
          :disable-condition="{
            edit: tableRef?.selectedRows.length === 1
              ? (tableRef?.selectedRows[0].flag !== '1')
              : true,
            grant:
              tableRef?.selectedRows.length === 1
                ? (tableRef?.selectedRows[0].flag !== '1')
                : true,
            delete: tableRef?.selectedRows.length !== 0 ? (tableRef?.selectedRows.some((ele:TableListType) => ele.flag !== '1')) : true
          }"
          :loading-props="{ deleteLoading }"
          :select-length="tableRef?.selectedKeys?.length"
          @handle="handleButton"
        />
      </template>
    </base-table>
    <!-- 领用申请 -->
    <collectingApplication ref="collectingApplicationRef" @reset-table="resetTable" />
    <!-- 发放 -->
    <grantForm ref="grantFormRef" @reset-table="resetTable" />
  </base-card>
</template>
