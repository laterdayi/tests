<script setup lang="tsx">
import { SparesCollectingDocApis } from '@/service/apis/assembly/spares-manage/spares-collecting-doc';
import type {
  AvailableQueryType,
  GrantFormType,
  GrantTableColumnsType,
  TableListType
} from '@/service/apis/assembly/spares-manage/spares-collecting-doc';
import { SparesBasicInformationApis } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import type { ListType } from '@/service/apis/assembly/spares-manage/spares-basic-information';
import { SparesScrapManageApis } from '@/service/apis/assembly/spares-manage/spares-scrap-manage';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 弹窗开启
const modalIsShow = ref(false);
// 状态列表
const { data: hdStatusList, execute: getHdStatusList } = useAxiosGet<ListType[]>(
  SparesBasicInformationApis.getHDStatusApi
);
// 获取表单详情
const { execute: getFrom } = useAxiosGet<GrantFormType>(SparesCollectingDocApis.getFromApi);
// 打开弹窗
const open = async (row: TableListType) => {
  try {
    await getHdStatusList();
    const { data } = await getFrom({
      params: {
        id: row.id
      }
    });
    if (!data.value) return;
    formData.value = { ...data.value };
    availableQueryForm.value = { toolingType: row.toolingType, toolingModel: row.toolingModel };
    availableGetList();
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
// 表单配置
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'applyNo',
    formItemProps: {
      label: i18nt('collectingDocNo')
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category')
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model')
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'applyId',
    formItemProps: {
      label: i18nt('applicant')
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'applyQty',
    formItemProps: {
      label: i18nt('pickingQuantity')
    },
    componentProps: {
      disabled: true
    },
    class: 'w-95%!'
  },
  {
    type: 'custom-form-item',
    render() {
      return <div></div>;
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'toolingBarcde',
    formItemProps: {
      label: i18nt('number'),
      rule: [useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'grantId',
    formItemProps: {
      label: i18nt('issuedBy'),
      rule: [useRules('input', i18nt('issuedBy')), useRuleStringLength(0)]
    },
    componentProps: {
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          grantIdQuery();
        }
      },
      onBlur: () => {
        grantIdQuery();
      }
    },
    class: 'w-95%!'
  }
]);
const { formRef, validate, formData, resetField } = useForm<Nullable<GrantFormType>>({
  applyQty: null,
  toolingType: null,
  toolingModel: null,
  applyId: null,
  toolingBarcde: null,
  grantId: null
});
// 编号查询发放列表
const numberQuery = async () => {
  try {
    const { execute: getToolingInfo } = useAxiosGet<GrantTableColumnsType>(SparesCollectingDocApis.getToolingInfoApi);
    const { data } = await getToolingInfo({
      params: {
        toolingBarcde: formData.value.toolingBarcde,
        toolingType: formData.value.toolingType,
        toolingModel: formData.value.toolingModel
      }
    });
    if (!data.value) return;
    const nameIsShow = grantTableData.value.some(ele => ele.id === data?.value?.id);
    if (nameIsShow) {
      $message.warning(i18nt('numberMessageWarning'));
    } else {
      grantTableData.value.push({ ...data.value });
    }
    formData.value.toolingBarcde = '';
  } catch (error) {
    console.log(error);
  }
};
// 人员是否验证
const userIdIsShow = ref<boolean>(true);
// 发放人验证
const grantIdQuery = async () => {
  const { execute } = useAxiosGet(SparesScrapManageApis.checkUserApi);
  const { data } = await execute({
    params: {
      userId: formData.value.grantId
    }
  });
  if (!data.value) {
    formData.value.grantId = '';
    userIdIsShow.value = true;
  } else {
    userIdIsShow.value = false;
  }
};
// 发放表格列表
const grantIsLoadingQuery = ref<boolean>(false);
const grantTableData = ref<GrantTableColumnsType[]>([]);
const grantTableColumns: DataTableColumns<GrantTableColumnsType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX,
    render(row: GrantTableColumnsType, index: number) {
      return <>{index + 1}</>;
    }
  },
  {
    title: i18nt('number'),
    key: 'toolingBarcode'
  },
  {
    title: i18nt('category'),
    key: 'toolingType'
  },
  {
    title: i18nt('model'),
    key: 'toolingModel'
  },
  {
    title: i18nt('storageLocation'),
    key: 'stock'
  },
  {
    title: i18nt('spareState'),
    key: 'hdStatus',
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('action'),
    key: '',
    width: 150,
    render(row: GrantTableColumnsType, index: number) {
      return (
        <>
          <base-button
            button-name="delete"
            onClick={() => tableRowClick(row, index)}
            size={componentSize.value}
            type="error"
          >
            <base-icon class="mr" color="#FFFFFF" icon="i-carbon:trash-can" />
            {i18nt('delete')}
          </base-button>
        </>
      );
    }
  }
];
// 表格删除事件
const tableRowClick = (row: GrantTableColumnsType, index: number) => {
  grantTableData.value.splice(index, 1);
};
// 可用列表
const availableQueryForm = ref<AvailableQueryType>({
  toolingType: '',
  toolingModel: ''
});
const {
  pagination,
  isLoadingQuery: availableIsLoadingQuery,
  tableData: availableTableData,
  executeQueryList: availableGetList,
  tableRef
} = useTable<TableListType[]>(SparesCollectingDocApis.getQueryListApi, { queryFormParams: availableQueryForm });

const availableTableColumns: DataTableColumns<GrantTableColumnsType> = [
  useRenderTableIndex(pagination),
  {
    title: i18nt('number'),
    key: 'toolingBarcode'
  },
  {
    title: i18nt('category'),
    key: 'toolingType'
  },
  {
    title: i18nt('model'),
    key: 'toolingModel'
  },
  {
    title: i18nt('storageLocation'),
    key: 'stock'
  },
  {
    title: i18nt('currentState'),
    key: 'currentFlag',
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('spareState'),
    key: 'hdStatus',
    width: TABLE_WIDTH_STATE,
    render(row: GrantTableColumnsType) {
      const str = hdStatusList?.value?.find((ele: ListType) => ele.id === row.hdStatus)?.name;
      return <>{str}</>;
    }
  }
];
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const loadingIndex = ref<number>(1);
const saveForm = async (index: number) => {
  try {
    grantIdQuery();
    await validate();
    loadingIndex.value = index;
    let modalUrl = '';
    let obj = {};
    if (index === 1) {
      modalUrl = SparesCollectingDocApis.applyGrantRejectApi;
      obj = {
        id: formData.value.id,
        rejectId: formData.value.grantId
      };
    } else {
      modalUrl = SparesCollectingDocApis.applyGrantToolingApi;
      obj = {
        id: formData.value.id,
        toolingBarcodes: grantTableData.value.map((ele: GrantTableColumnsType) => ele.toolingBarcode),
        grantId: formData.value.grantId
      };
    }
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl, { data: { ...obj } });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  // 重置表单并去除验证
  resetField();
  pagination.value.page = 1;
  loadingIndex.value = 0;
  grantTableData.value = [];
  modalIsShow.value = false;
  userIdIsShow.value = true;
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    id="grant-form"
    :show="modalIsShow"
    class="w-70%!"
    preset="confirm"
    :title="$t('grant')"
    :mask-closable="false"
    :show-icon="false"
    :negative-text="$t('cancel')"
    positive-text=""
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
    <div class="formTitle">{{ $t('listOfSparePartsIssued') }}</div>
    <!-- 发放Tooling列表 -->
    <base-table
      remote
      :columns="grantTableColumns"
      :data="grantTableData ?? []"
      :loading="grantIsLoadingQuery"
      :style="{ height: `350px` }"
      flex-height
    />
    <!-- 可用列表 -->
    <div class="formTitle">{{ $t('listOfAvailableSpareParts') }}</div>
    <base-table
      ref="tableRef"
      remote
      :columns="availableTableColumns"
      :data="availableTableData ?? []"
      :loading="availableIsLoadingQuery"
      :pagination="pagination"
      :style="{ height: `350px` }"
      flex-height
    />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        :loading="saveFormLoading && loadingIndex === 1"
        :disabled="userIdIsShow || (saveFormLoading && loadingIndex === 1)"
        :size="componentSize"
        type="primary"
        button-name="reject"
        @click="saveForm(1)"
      >
        {{ $t('reject') }}
      </base-button>
      <base-button
        :loading="saveFormLoading && loadingIndex === 2"
        :disabled="userIdIsShow || (saveFormLoading && loadingIndex === 2)"
        :size="componentSize"
        type="primary"
        button-name="confirm"
        @click="saveForm(2)"
      >
        {{ $t('grant') }}
      </base-button>
    </template>
  </base-modal>
</template>

<style lang="less">
#grant-form {
  .n-dialog__content {
    z-index: 9;
  }
}
</style>

<style scoped lang="less">
.formTitle {
  width: 105px;
  padding-right: 15px;
  text-align: right;
  line-height: 1.25;
  color: var(--n-label-text-color);
}
:deep(.n-data-table-tr) {
  .n-data-table-td--last-row {
    border-bottom: 1px solid var(--n-merged-border-color) !important;
  }
}
</style>
