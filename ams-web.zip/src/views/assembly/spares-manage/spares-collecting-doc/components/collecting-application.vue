<script setup lang="tsx">
import { SparesCollectingDocApis } from '@/service/apis/assembly/spares-manage/spares-collecting-doc';
import type {
  CollectingApplicationFormType,
  ListType
} from '@/service/apis/assembly/spares-manage/spares-collecting-doc';
import { SparesScrapManageApis } from '@/service/apis/assembly/spares-manage/spares-scrap-manage';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 是否拥有编辑权限
const hasEditPermissionIsShow = ref<boolean>(true);
// 接口设置
const modalUrl = ref<string>('');
// 是否编辑
const editIsShow = ref<boolean>(false);
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
// 类别列表
const { data: toolingTypeList, execute: getToolingTypeList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getByTypeModelListApi
);
// 型号列表
const { data: toolingModelList, execute: getToolingModelList } = useAxiosGet<ListType[]>(
  SpareManageCommonApis.getToolingTypeIdListApi
);
// 获取表单
const { execute: getFrom } = useAxiosGet<CollectingApplicationFormType>(SparesCollectingDocApis.getFromApi);
// 打开弹窗
const open = async (row: string, isShow = true) => {
  try {
    getToolingTypeList();
    getToolingModelList();
    hasEditPermissionIsShow.value = isShow;
    if (row) {
      editIsShow.value = true;
      modalTitle.value = isShow ? i18nt('edit') + i18nt('collectingApplication') : i18nt('viewDetail');
      const { data } = await getFrom({
        params: {
          id: row
        }
      });
      if (!data.value) return;
      modalForm.value = data.value;
      modalUrl.value = SparesCollectingDocApis.updateApi;
    } else {
      modalTitle.value = i18nt('add') + i18nt('collectingApplication');
      modalUrl.value = SparesCollectingDocApis.addFormApi;
    }
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category'),
      rule: [useRules('change', i18nt('category'))]
    },
    componentProps: {
      disabled: editIsShow.value,
      options: toolingTypeList.value,
      valueField: 'id',
      labelField: 'name',
      onUpdateValue: async (value: string) => {
        try {
          await getToolingModelList({
            params: {
              ToolingType: toolingTypeList.value?.find(ele => ele.id === value)?.name
            }
          });
          modalForm.value.toolingModel = null;
        } catch (error) {
          console.log(error);
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model'),
      rule: [useRules('change', i18nt('model'))]
    },
    componentProps: {
      disabled: editIsShow.value,
      options: toolingModelList.value,
      valueField: 'id',
      labelField: 'name'
    },
    class: 'w-95%!'
  },
  {
    type: 'input',
    model: 'applyId',
    formItemProps: {
      label: i18nt('applicant'),
      rule: [useRules('input', i18nt('applicant')), useRuleStringLength(0)]
    },
    componentProps: {
      disabled: editIsShow.value,
      onKeyup: keyboardEvent => {
        if (keyboardEvent.key === 'Enter') {
          numberQuery();
        }
      },
      onBlur: () => {
        numberQuery();
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'input-number',
    model: 'applyQty',
    formItemProps: {
      label: i18nt('pickingQuantity'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: true, message: i18nt('pickingQuantity') }),
        useRuleNumberLength()
      ]
    },
    class: 'w-95%!'
  }
]);
// 人员是否验证
const userIdIsShow = ref<boolean>(true);
// 申请人验证
const numberQuery = async () => {
  const { execute } = useAxiosGet(SparesScrapManageApis.checkUserApi);
  const { data } = await execute({
    params: {
      userId: modalForm.value.applyId
    }
  });
  if (!data.value) {
    userIdIsShow.value = true;
    modalForm.value.applyId = '';
  } else {
    userIdIsShow.value = false;
  }
};
const {
  formRef,
  validate,
  formData: modalForm,
  resetField
} = useForm<Nullable<CollectingApplicationFormType>>({
  applyQty: null,
  toolingType: null,
  toolingModel: null,
  applyId: null
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    numberQuery();
    await validate();
    if (modalForm.value.id) {
      modalUrl.value = SparesCollectingDocApis.updateApi;
    } else {
      modalUrl.value = SparesCollectingDocApis.addFormApi;
    }
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: {
        ...modalForm.value
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    saveFormLoading.value = false;
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  editIsShow.value = false;
  userIdIsShow.value = true;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-60%!"
    preset="confirm"
    :title="modalTitle"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form
      ref="formRef"
      v-model="modalForm"
      layout="dialog"
      :schemas="modalSchemas"
      :disabled="!hasEditPermissionIsShow"
    />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        v-if="hasEditPermissionIsShow"
        :size="componentSize"
        :disabled="userIdIsShow || saveFormLoading"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('applyScrap') }}
      </base-button>
    </template>
  </base-modal>
</template>
