<script setup lang="ts">
import { SparesModelManageApis } from '@/service/apis/assembly/spares-manage/spares-model-manage';
import type {
  EditType,
  ListType,
  QueryType,
  TableListType
} from '@/service/apis/assembly/spares-manage/spares-model-manage';
import { SpareManageCommonApis } from '@/service/apis/pms/spares-manage/common';

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
// 查询表单配置
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model')
    }
  }
]);
const queryFormParams: Nullable<QueryType> = {
  toolingModel: null
};
const curdRefPagination = computed(() => curdRef.value?.pagination);
// 表格数据配置
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('model'),
    key: 'toolingModel',
    sorter: true,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(
        rowData.toolingModel,
        () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title)
      )
  },
  {
    title: i18nt('category'),
    key: 'toolingType',
    sorter: true
  },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('modifier'), key: 'editor', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('modifyTime'), key: 'editTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];
// 类别列表
const { data: toolingTypeList, execute: getAll } = useAxiosGet<ListType[]>(SpareManageCommonApis.getByTypeModelListApi);
getAll();
// 弹窗表单配置
const formParams: Nullable<EditType> = {
  toolingModel: null,
  toolingType: null
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'toolingType',
    formItemProps: {
      label: i18nt('category'),
      rule: [useRules('change', i18nt('category'))]
    },
    componentProps: {
      options: toolingTypeList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'input',
    model: 'toolingModel',
    formItemProps: {
      label: i18nt('model'),
      rule: [useRules('input', i18nt('model')), useRuleStringLength()]
    },
    class: 'w-100%!'
  }
]);
</script>

<template>
  <div id="spares-model-manage">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :read-api="SparesModelManageApis.getListApi"
      :delete-api="SparesModelManageApis.deleteApi"
      modal-title="sparesModelManage"
      :create-api="SparesModelManageApis.addApi"
      :edit-detail-api="SparesModelManageApis.editDetailApi"
      :update-api="SparesModelManageApis.getEditApi"
      :import-api="SparesModelManageApis.importUserApi"
      :export-api="SparesModelManageApis.getListApi"
      :download-api="SparesModelManageApis.downloadMaterialApi"
    />
  </div>
</template>
