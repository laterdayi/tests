<template>
  <div id="assembly-home" />
</template>
