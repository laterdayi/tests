<template>
  <div id="assembly-data-collection" />
</template>
