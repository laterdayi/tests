<script lang="tsx">
import type { FormItemRule, FormValidationError } from 'naive-ui';
import type { AxiosError } from 'axios';
import { EquipmentOverviewApis } from '@/service/apis/assembly/production-manage/equipment-overview';
import { UserApis } from '@/service/apis/user';
import type { UserInfoType } from '@/service/apis/user';
import RepairAddForm from '@/views/assembly/production-manage/repair-manage/components/add-form.vue';
import RepairDetailForm from '@/views/assembly/production-manage/repair-manage/components/detail-form.vue';
import ChangeMachineAddForm from '@/views/assembly/production-manage/change-machine-order/components/add-form.vue';
import changeMachineDetailForm from '@/views/assembly/production-manage/change-machine-order/components/detail-form.vue';
import type { RouteType } from '@/service/apis/common/type';

enum IsSecondLoginType {
  noLogin,
  login
}

enum ClientOperateState {
  all,
  // 报修
  repair,
  // 改机
  changeMachine,
  // 切换状态
  swtichState
}

enum WillOperateState {
  empty,
  // 报修详情
  repairDetail,
  // 改机详情
  changeMachineDetail,
  // 切换状态
  swtichState,
  // 新增报修
  addRepair,
  // 新增改机
  addChangeMachine
}

interface ParentStateListType {
  id: string;
  color: string | undefined;
  statusName: string;
  selectedIsShow: boolean;
}

interface EquipmentType {
  id: string;
  eqpId: string;
  layoutId: string;
  eqpNameSort: number;
  name: string;
  parentStatusName: string;
  parentStatusTime: number;
  runningState: number;
  sort: number;
  statusCode: number;
  statusColor: string;
  statusName: string;
  statusTime: number;
}

interface EquipmentListType {
  id: string;
  levelName: string;
  levelCount: string;
  order: number;
  datas: EquipmentType[];
}

interface LevelStateListType {
  description: string;
  parentStr: string;
  statusCode: number;
  statusColor: string;
  statusName: string;
  children: LevelStateListType[];
}

interface OperateEquipmentDataType {
  currentOperator: string;
  currentRemarks: string;
  currentStateTime: string;
  lotID: string;
  productName: string;
  eqpName: string;
  eqpId: string;
  operation: number;
  username: string;
  password: string;
  runningState: number;
}

interface LoginType {
  username: string;
  password: string;
}

interface WillOperateDataType {
  currentRemarks: string;
  eqpName: string;
  id: string;
  operation: number;
  secondState: number;
  secondStateName: string;
  state: number;
  topState: number;
  topStateName: string;
  workOrder: string;
}

interface SwitchStateType {
  state: string;
  currentRemarks: string;
  eqpName: string;
  parentStatusCode: number;
  statusCode: number;
  remark: string;
  currentLevelIndex: number;
  LevelTwoStateDescription: string;
}

const notDisabledCondition: { [key in number]: number[] } = {
  [ClientOperateState.all]: [
    ClientOperateState.repair,
    ClientOperateState.changeMachine,
    ClientOperateState.swtichState
  ],
  [ClientOperateState.repair]: [ClientOperateState.repair],
  [ClientOperateState.changeMachine]: [ClientOperateState.changeMachine],
  [ClientOperateState.swtichState]: [ClientOperateState.swtichState]
};

const handleDisabledCondition = (operation: number | undefined, type: number) =>
  !notDisabledCondition[operation as number]?.includes(type);

// 初始设备操作表单(操作表单切状态,报修,改机)
const initEquipmentActionFormSchemas = (
  switchStateFormData: Ref<Nullable<OperateEquipmentDataType>>,
  equipmentDetailData: Ref<OperateEquipmentDataType | undefined>
): FormSchemaType => [
  {
    type: 'input',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'currentOperator',
    formItemProps: { label: i18nt('stateSwitcher') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'lotID',
    formItemProps: { label: 'Lot ID' },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'currentStateTime',
    formItemProps: { label: i18nt('stateSwitchTime') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'productName',
    formItemProps: { label: i18nt('productType') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'username',
    formItemProps: { label: i18nt('accounts'), rule: [useRules('input', i18nt('accounts')), useRuleStringLength()] }
  },
  {
    type: 'input',
    model: 'password',
    formItemProps: { label: i18nt('password'), rule: [useRules('input', i18nt('password')), useRuleStringLength()] },
    componentProps: { type: 'password' }
  },
  {
    type: 'custom-form-item',
    model: 'operation',
    formItemProps: {
      label: i18nt('action'),
      rule: {
        ...useRules('change', i18nt('action')),
        validator: (rule, value) => (!value || value === 0 ? new Error(`${rule.message}`) : undefined)
      }
    },
    render() {
      return (
        <n-radio-group
          disabled={switchStateFormData.value.runningState === 1}
          v-model:value={switchStateFormData.value.operation}
        >
          <base-radio
            disabled={handleDisabledCondition(equipmentDetailData.value?.operation, ClientOperateState.swtichState)}
            label={i18nt('switchState')}
            value={ClientOperateState.swtichState}
          />
          <base-radio
            disabled={handleDisabledCondition(equipmentDetailData.value?.operation, ClientOperateState.repair)}
            label={i18nt('repair')}
            value={ClientOperateState.repair}
          />
          <base-radio
            disabled={handleDisabledCondition(equipmentDetailData.value?.operation, ClientOperateState.changeMachine)}
            label={i18nt('changeMachine')}
            value={ClientOperateState.changeMachine}
          />
        </n-radio-group>
      );
    }
  }
];

// 登录表单
const initLoginFormSchemas = (): FormSchemaType => [
  {
    type: 'input',
    model: 'username',
    formItemProps: { label: i18nt('accounts'), rule: [useRules('input', i18nt('accounts')), useRuleStringLength()] }
  },
  {
    type: 'input',
    model: 'password',
    formItemProps: { label: i18nt('password'), rule: [useRules('input', i18nt('password')), useRuleStringLength()] },
    componentProps: { type: 'password' }
  }
];

// 切状态表单
const initSwitchStateFormSchemas = (
  switchStateFormData: Nilable<SwitchStateType>,
  validateSwitchState: (
    validateCallback?: (errors?: FormValidationError[]) => void,
    shouldRuleBeApplied?: (rule: FormItemRule) => boolean
  ) => Promise<{ warnings: unknown[] | undefined }> | undefined,
  levelOneStateList?: LevelStateListType[]
): FormSchemaType => [
  {
    type: 'input',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'state',
    formItemProps: { label: i18nt('currentState') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'currentRemarks',
    formItemProps: { label: i18nt('currentStateRemark') },
    componentProps: { disabled: true }
  },
  {
    type: 'custom-form-item',
    model: 'parentStatusCode',
    formItemProps: {
      label: i18nt('LevelOneState'),
      rule: { ...useRules('change', i18nt('LevelOneState')), type: 'number', key: 'LevelOneState' }
    },
    render() {
      return (
        <div>
          {levelOneStateList?.map((item, index) => (
            <base-button
              button-name={item.statusName}
              class="mr"
              color={item.statusColor}
              key={item.statusCode}
              onClick={async () => {
                switchStateFormData.parentStatusCode = item.statusCode;
                switchStateFormData.currentLevelIndex = index;
                switchStateFormData.LevelTwoStateDescription = null;
                switchStateFormData.statusCode = null;
                await validateSwitchState(__, (rule: FormItemRule) => rule.key === 'LevelOneState');
              }}
              quaternary={switchStateFormData.parentStatusCode !== item.statusCode}
            >
              {item.statusName}
            </base-button>
          ))}
        </div>
      );
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'custom-form-item',
    model: 'statusCode',
    formItemProps: {
      label: i18nt('LevelTwoState'),
      rule: { ...useRules('change', i18nt('LevelTwoState')), type: 'number', key: 'LevelTwoState' }
    },
    render() {
      return (
        !isNil(switchStateFormData.currentLevelIndex) && (
          <div>
            {levelOneStateList?.[switchStateFormData.currentLevelIndex]?.children?.map(item => (
              <base-button
                button-name={item.statusName}
                class="mr"
                color={item.statusColor}
                key={item.statusCode}
                onClick={async () => {
                  switchStateFormData.statusCode = item.statusCode;
                  switchStateFormData.LevelTwoStateDescription = item.description;
                  await validateSwitchState(__, (rule: FormItemRule) => rule.key === 'LevelTwoState');
                }}
                quaternary={switchStateFormData.statusCode !== item.statusCode}
              >
                {item.statusName}
              </base-button>
            ))}
          </div>
        )
      );
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'LevelTwoStateDescription',
    formItemProps: { label: i18nt('LevelTwoStateDescription') },
    componentProps: { disabled: true }
  },
  useRenderFormTextarea({ model: 'remark', label: i18nt('remark'), formItemClass: 'col-span-2!' })
];
</script>

<script setup lang="tsx">
const appStore = useAppStore();
const { themePrimary } = storeToRefs(appStore);

// 获取父级状态
const {
  data: parentStateList,
  isLoading: isLoadingParentStateList,
  execute: executeGetParentStateList
} = useAxiosGet<ParentStateListType[]>(EquipmentOverviewApis.getParentStateListApi);

// 获取设备列表(页面)
const {
  isLoading: isLoadingEquipmentList,
  data: equipmentList,
  execute: executeGetEquipmentList
} = useAxiosGet<EquipmentListType[]>(EquipmentOverviewApis.getEquipmentListApi);

// 当前一级状态(查询重置栏)
const currentParentStateId = ref<string | null>(null);
const handleQueryChildEquipment = (item: ParentStateListType) => {
  if (!item.selectedIsShow) {
    parentStateList.value?.forEach(ele => {
      ele.selectedIsShow = false;
    });
  }
  item.selectedIsShow = !item.selectedIsShow;
  currentParentStateId.value = item.selectedIsShow ? item.id : null;

  handleGetEquipmentList();
};
// 刷新页面
const handleGetEquipmentList = async () => {
  const { username, password } = loginFormData.value;
  const params: {
    isSecondLogin?: number;
    username?: string;
    password?: string;
    parentStatusCode?: string | null;
  } = {};
  if (currentParentStateId.value) params.parentStatusCode = currentParentStateId.value;
  if (username && password) {
    params.isSecondLogin = IsSecondLoginType.login;
    params.username = username;
    params.password = password;
  } else {
    params.isSecondLogin = IsSecondLoginType.noLogin;
  }
  await executeGetEquipmentList(__, { params });
};
// 定时刷新
const { pause, resume } = useIntervalFn(handleGetEquipmentList, 300000);

// 进入页面刷新
tryOnMounted(() => (executeGetParentStateList(), executeGetEquipmentList()));

//  登录表单
const { showModal: showLoginModal, openModal: openLoginModal } = useModal();
// 表单参数
const {
  formData: loginFormData,
  formRef: loginFormRef,
  resetField: resetLoginField,
  validate: validateLogin
} = useForm<Nullable<LoginType>>({
  username: null,
  password: null
});

// 二次登录
const handleSubmitLogin = async () => {
  try {
    await validateLogin();
    await handleGetEquipmentList();
    // closeLoginModal();
    loginCloseLoginModal();
  } catch (error) {
    console.log(error);
  }
};
const loginCloseLoginModal = () => {
  resetLoginField();
  showLoginModal.value = false;
};
//  操作设备
const currenOperatetEquipment = ref<EquipmentType>();

// 获取设备详情
const { execute: executeGetOperateEquipmentData, data: operateEquipmentData } = useAxiosGet<OperateEquipmentDataType>(
  EquipmentOverviewApis.getOperateEquipmentDataApi
);

// 获取即将操作类型
const {
  execute: executeGetWillOperateData,
  data: willOperateData,
  error: willOperateDataError
} = useAxiosPost<WillOperateDataType>(EquipmentOverviewApis.getWillOperateDataApi, __, { showTooltip: false });
// 打开改机/报修 新增详情表单
const handleSubmitEquipmentAction = async () => {
  try {
    await validateEquipmentAction();
    const { eqpId, eqpName, username, password, operation } = equipmentActionFormData.value;
    await executeGetWillOperateData(__, {
      data: { eqpId, eqpName, username, password, loginType: 1, operation }
    });
    closeEquipmentActionModal();
    const willOperateAction: { [keys in WillOperateState]: () => void } = {
      [WillOperateState.empty]: () => {
        console.log('empty');
      },
      // 报修详情
      [WillOperateState.repairDetail]: () => handleOpenRepairDetailModal(username, password),
      // 改机详情
      [WillOperateState.changeMachineDetail]: () => handleOpenChangeMachineDetailModal(username, password),
      [WillOperateState.swtichState]: handleOpenSwitchStateModal,
      // 新增报修
      [WillOperateState.addRepair]: () => handleOpenRepairAddModal(username, password),
      // 新增改机
      [WillOperateState.addChangeMachine]: () => handleOpenChangeMachineAddModal(username, password)
    };
    willOperateAction[willOperateData.value?.operation as WillOperateState]?.();
  } catch (error) {
    $message.warning(i18nt((willOperateDataError.value as AxiosError).message));
    console.log('操作设备异常1：', error);
  }
};

// 表单参数
const {
  formData: equipmentActionFormData,
  formRef: equipmentActionFormRef,
  resetField: resetEquipmentActionField,
  validate: validateEquipmentAction,
  updateField: updateEquipmentActionField
} = useForm<Nullable<OperateEquipmentDataType>>({
  currentOperator: null,
  currentRemarks: null,
  currentStateTime: null,
  lotID: null,
  productName: null,
  operation: null,
  eqpName: null,
  eqpId: null,
  username: null,
  password: null,
  runningState: 0
});

// 表单模型
const equipmentActionFormSchemas = initEquipmentActionFormSchemas(equipmentActionFormData, operateEquipmentData);

const {
  showModal: showEquipmentActionModal,
  openModal: openEquipmentActionModal,
  closeModal: closeEquipmentActionModal
} = useModal();

const handleOpenEquipmentActionModal = async (item: EquipmentType) => {
  try {
    currenOperatetEquipment.value = item;
    openEquipmentActionModal();
    const { data } = await executeGetOperateEquipmentData(__, { params: { eqpName: item.name } });
    equipmentActionFormData.value.runningState = item.runningState;
    if (data.value) updateEquipmentActionField(data.value);
  } catch (error) {
    console.log('打开详情弹框异常：', error);
  }
};

// 查询表单模型
const loginFormSchemas = initLoginFormSchemas();

// -------------------------------------------------------------------------------------------- > 切状态

// 获取一级状态列表
const { execute: executeGetLevelOneStateList, data: levelOneStateList } = useAxiosGet<LevelStateListType[]>(
  EquipmentOverviewApis.getLevelOneStateListApi
);

const handleOpenSwitchStateModal = async () => {
  try {
    openSwitchStateModal();
    const { currentRemarks, secondState, eqpName, topStateName, secondStateName } = willOperateData.value ?? {};
    updatewitchStateField({
      currentRemarks,
      state: !topStateName && !secondStateName ? '' : `${topStateName} | ${secondStateName}`,
      eqpName
    });
    await executeGetLevelOneStateList(__, { params: { curStateCode: secondState } });
  } catch (error) {
    console.log('打开切状态异常：', error);
  }
};
// 获取设备列表(页面)
const { execute: executeCreateSwitchStateApi } = useAxiosPost(EquipmentOverviewApis.createSwitchStateApi);

// 切状态保存
const handleSubmitSwitchState = async () => {
  try {
    await validateSwitchState();
    const { eqpName, parentStatusCode, statusCode, remark } = switchStateFormData.value;
    const { data } = await executeCreateSwitchStateApi(__, {
      data: { eqpName, parentStatusCode, statusCode, remark }
    });
    closeSwitchStateModal();
    handleGetEquipmentList();
  } catch (error) {
    console.log(error);
  }
};

// 表单参数
const {
  formData: switchStateFormData,
  formRef: switchStateFormRef,
  validate: validateSwitchState,
  resetField: resetSwitchStateField,
  updateField: updatewitchStateField
} = useForm<Nilable<SwitchStateType>>({
  state: null,
  currentRemarks: null,
  eqpName: null,
  parentStatusCode: null,
  statusCode: null,
  remark: null,
  currentLevelIndex: null,
  LevelTwoStateDescription: null
});

const {
  showModal: showSwitchStateModal,
  closeModal: closeSwitchStateModal,
  openModal: openSwitchStateModal
} = useModal();

// 表单模型
const switchStateFormSchemas = computed(() =>
  initSwitchStateFormSchemas(switchStateFormData.value, validateSwitchState, levelOneStateList.value)
);

// 新增报修
const repairAddFormRef = ref();
const handleOpenRepairAddModal = async (username: string | null, password: string | null) => {
  const hasPermission = await handleSubmitCheckPermission(username, password, 'repairManage', 'add');
  if (hasPermission) {
    const { layoutId, eqpId } = currenOperatetEquipment.value ?? {};
    repairAddFormRef.value?.handleOpenModal(null, { layoutId, eqpId });
  }
};
//  报修详情
const repairDetailFormRef = ref();
const handleOpenRepairDetailModal = async (username: string | null, password: string | null) => {
  const hasPermission = await handleSubmitCheckPermission(username, password, 'repairManage', 'workOrder', true);
  if (hasPermission) {
    repairDetailFormRef.value?.handleOpenModal(
      { id: willOperateData.value?.id as string },
      true,
      currentRoutePowers.value
    );
  }
};

// 新增改机
const changeMachineAddRef = ref();
const handleOpenChangeMachineAddModal = async (username: string | null, password: string | null) => {
  const hasPermission = await handleSubmitCheckPermission(username, password, 'changeMachineOrder', 'add');
  if (hasPermission) {
    const { layoutId, eqpId } = currenOperatetEquipment.value ?? {};
    changeMachineAddRef.value?.handleOpenModal(null, { layoutId, eqpId });
  }
};

//  改机详情
const changeMachineDetailFormRef = ref();
const handleOpenChangeMachineDetailModal = async (username: string | null, password: string | null) => {
  const hasPermission = await handleSubmitCheckPermission(username, password, 'changeMachineOrder', 'workOrder', true);
  if (hasPermission) {
    changeMachineDetailFormRef.value?.handleOpenModal(
      { id: willOperateData.value?.id as string },
      true,
      currentRoutePowers.value
    );
  }
};
const currentRoutePowers = ref<string[]>();
// 检查权限验证
const handleSubmitCheckPermission = async (
  username: string | null,
  password: string | null,
  pageName: string,
  permission: string,
  isShow = false
) => {
  try {
    const { data: loginData } = await useAxiosPost<UserInfoType>(
      UserApis.loginApi,
      { username, password },
      { showTooltip: false },
      { immediate: true }
    );
    const { data: routerData } = await useAxiosGet<RouteType[]>(
      UserApis.getModulesRouteApi,
      __,
      { headers: { Token: loginData.value?.token }, useDefaultToken: false, showTooltip: false },
      { immediate: true }
    );
    currentRoutePowers.value = handleButtonPermission(routerData.value, pageName);
    if (!isShow) {
      if (handleDeepCheckPermission(routerData.value, pageName, permission)) {
        return true;
      }
      $message.warning(i18nt('noPermission'));
    }
    return !!isShow;
  } catch (error) {
    console.log('检查权限异常：', error);
  }
};
// 获取按钮
const handleButtonPermission = (data: RouteType[] | undefined, pageName: string): string[] | undefined => {
  if (!data?.length) return undefined;
  for (let i = 0; i < data.length; i++) {
    const { name, children } = data[i];
    if (name === pageName) {
      return data[i].meta.powers;
    }
    const item = handleButtonPermission(children || [], pageName);
    if (item) return item;
  }
};
const handleDeepCheckPermission = (data: RouteType[] | undefined, pageName: string, permission: string) => {
  if (!data?.length) return;
  for (let i = 0; i < data.length; i++) {
    const item = data[i];
    if (item.name === pageName) {
      return item.meta?.powers?.includes(permission) || false;
    } else if (item.children) {
      const res = handleDeepCheckPermission(item.children, pageName, permission) as boolean;
      if (res) return res;
    }
  }
};

// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    search: () => {
      openLoginModal();
      pause();
    },
    reset: () => (resetLoginField(), (currentParentStateId.value = null), handleGetEquipmentList())
  };
  permissionAction[permission]?.();
};
</script>

<template>
  <div id="equipment-overview">
    <base-card v-if="parentStateList?.length" class="mb">
      <base-spin :show="isLoadingParentStateList">
        <div class="flex item-center">
          <section class="flex flex-1 flex-wrap mr">
            <base-button
              v-for="item in parentStateList"
              :key="item.id"
              class="mr"
              :button-name="item.statusName"
              :quaternary="currentParentStateId !== item.id"
              :color="item.color"
              @click="handleQueryChildEquipment(item)"
            >
              {{ item.statusName }}
            </base-button>
          </section>
          <permission-button form :space-props="{ wrap: false }" @handle="handlePermission" />
        </div>
      </base-spin>
    </base-card>
    <base-empty v-else />

    <base-spin :show="isLoadingEquipmentList" class="mt-20px">
      <div v-if="equipmentList?.length">
        <base-card v-for="item in equipmentList" :key="item.id" class="mb">
          <template #header>
            {{ item.levelName }}
            <base-tag>{{ item.levelCount }}</base-tag>
          </template>
          <div class="flex flex-wrap">
            <div
              v-for="subItem in item.datas"
              :key="subItem.id"
              class="cursor-pointer flex flex-col h-72px item justify-around mb mr p-5px rounded w-146px"
              :style="{ border: `1px solid ${subItem.statusColor ?? '#dcdfe6'}` }"
              @click="handleOpenEquipmentActionModal(subItem)"
            >
              <div class="flex items-center justify-around">
                <div
                  v-if="subItem.statusColor"
                  :style="{ backgroundColor: subItem.statusColor }"
                  class="h-16px mr-5px rounded-full w-16px"
                />
                <base-ellipsis
                  :line-clamp="2"
                  class="flex-1 font-bold"
                  :class="{ 'text-center': !subItem.statusColor }"
                >
                  {{ subItem.name }}
                </base-ellipsis>
              </div>
              <div v-if="subItem.parentStatusTime || subItem.statusName" class="overflow-hidden">
                <div class="info roll-animate">
                  {{ subItem.statusName }}
                  {{ `( ${subItem.parentStatusTime} - ${subItem.statusTime} )` }}
                </div>
              </div>
              <div v-else class="info text-center">-</div>
            </div>
          </div>
        </base-card>
      </div>
      <base-empty v-else />
    </base-spin>

    <!-- 二次登录 -->
    <base-modal
      :show="showLoginModal"
      :title="$t('login')"
      :loading="isLoadingEquipmentList"
      @close="loginCloseLoginModal"
      @negative-click="loginCloseLoginModal"
      @after-leave="resume"
      @positive-click="handleSubmitLogin"
    >
      <base-form ref="loginFormRef" v-model="loginFormData" layout="dialog" :schemas="loginFormSchemas" />
    </base-modal>

    <!-- 设备操作 -->
    <base-modal
      :show="showEquipmentActionModal"
      :title="$t('action')"
      @after-leave="resetEquipmentActionField"
      @close="closeEquipmentActionModal"
      @negative-click="closeEquipmentActionModal"
      @positive-click="handleSubmitEquipmentAction"
    >
      <base-form
        ref="equipmentActionFormRef"
        v-model="equipmentActionFormData"
        layout="dialog"
        :schemas="equipmentActionFormSchemas"
      />
    </base-modal>

    <!-- 切状态 -->
    <base-modal
      :show="showSwitchStateModal"
      :title="$t('switchState')"
      @close="closeSwitchStateModal"
      @after-leave="resetSwitchStateField"
      @negative-click="closeSwitchStateModal"
      @positive-click="handleSubmitSwitchState"
    >
      <base-form
        ref="switchStateFormRef"
        v-model="switchStateFormData"
        layout="dialog"
        :schemas="switchStateFormSchemas"
      />
    </base-modal>

    <!-- 新增报修 -->
    <repair-add-form ref="repairAddFormRef" @areset-table="handleGetEquipmentList" />
    <!-- 报修详情 -->
    <repair-detail-form ref="repairDetailFormRef" @areset-table="handleGetEquipmentList" />
    <!-- 新增改机 -->
    <change-machine-add-form ref="changeMachineAddRef" @areset-table="handleGetEquipmentList" />
    <!-- 改机详情 -->
    <change-machine-detail-form ref="changeMachineDetailFormRef" @areset-table="handleGetEquipmentList" />
  </div>
</template>

<style lang="less" scoped>
#equipment-overview {
  .item {
    transition: all var(--duration);
    &:hover {
      border: 1px solid v-bind(themePrimary);
      .roll-animate {
        animation-play-state: paused;
      }
    }
    .roll-animate {
      white-space: nowrap;
      display: inline-block;
      animation: 10s wordsLoopAnimate linear infinite normal;
    }
    .info {
      color: grey;
    }
    @keyframes wordsLoopAnimate {
      0% {
        transform: translateX(-100%);
      }
      100% {
        transform: translateX(100%);
      }
    }
  }
}
</style>
