<script setup lang="tsx">
import { RepairManageApis } from '@/service/apis/assembly/production-manage/repair-manage';
import type { AddFormType, EquipmentStateType } from '@/service/apis/assembly/production-manage/repair-manage';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'reset-table': [];
  'areset-table': [];
}>();
// 接口设置
const modalUrl = ref<string>('');
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
// 产线层级
const {
  data: productLineList,
  isLoading: isLoadingProductLineList,
  execute: handleProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelApi);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });
// 获取设备状态
const { isLoading: isLoadingEquipmentState, execute: executeGetEquipmentState } = useAxiosGet<EquipmentStateType>(
  RepairManageApis.getEquipmentStateApi
);
// 获取下一状态列表
const {
  data: nextStateList,
  isLoading: isLoadingNextStateList,
  execute: executeGetNextStateList
} = useAxiosGet<OptionsType[]>(RepairManageApis.getNextStateListApi);
// 下一状态编辑
const nextStateListIsShow = ref<boolean>(true);
// 获取详情
const { execute: getFrom } = useAxiosGet<AddFormType>(RepairManageApis.getRepairDetailApi);
// 设备总览
const overviewIsShow = ref<boolean>(false);
//  打开弹窗
const handleOpenModal = async (
  row: string,
  overviewObj: {
    layoutId: string;
    eqpId: string;
  }
) => {
  try {
    handleProductLineList(__, { params: { check: 1, isNormal: 1 } });
    handleQueryEquipmentList();
    if (row) {
      modalTitle.value = i18nt('edit') + i18nt('repair');
      modalUrl.value = RepairManageApis.updateRepairApi;
      const { data } = await getFrom({
        params: {
          id: row
        }
      });
      if (!data.value) return;
      formData.value = data.value;
      nextStateListIsShow.value = false;
    } else {
      modalTitle.value = i18nt('add') + i18nt('repair');
      modalUrl.value = RepairManageApis.createRepairApi;
      // 是否设备总览
      if (overviewObj) {
        overviewIsShow.value = true;
        formData.value.layoutId = overviewObj.layoutId;
        formData.value.eqpId = overviewObj.eqpId;
        eqpIdQuery(formData.value.eqpId);
      }
    }
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
// 表单
const { validate, formData, resetField, restoreValidation, formRef } = useForm<Nullable<AddFormType>>({
  layoutId: null,
  eqpId: null,
  eqpStateName: null,
  lotId: null,
  productName: null,
  nextEqpStateCode: null,
  alarmInfo: null,
  remark: null
});
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'layoutId',
    formItemProps: { label: i18nt('productionLineLevel'), rule: useRules('change', i18nt('productionLineLevel')) },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      disabled: overviewIsShow.value || !nextStateListIsShow.value,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        formData.value.eqpId = null;

        formData.value.nextEqpStateCode = null;
        formData.value.eqpStateName = null;
        formData.value.lotId = null;
        formData.value.productName = null;
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
              params: { layoutIds: value }
            })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber'), rule: useRules('change', i18nt('equipmentNumber')) },
    componentProps: {
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'id',
      disabled: overviewIsShow.value || !nextStateListIsShow.value,
      onUpdateValue: (value: string) => {
        formData.value.nextEqpStateCode = null;
        formData.value.eqpStateName = null;
        formData.value.lotId = null;
        formData.value.productName = null;
        nextStateList.value = [];
        if (value) {
          eqpIdQuery(value);
        }
      }
    }
  },
  {
    type: 'input',
    model: 'eqpStateName',
    formItemProps: { label: i18nt('equipmentState') },
    componentProps: { disabled: true, loading: isLoadingEquipmentState?.value }
  },
  {
    type: 'input',
    model: 'lotId',
    formItemProps: { label: 'Lot ID' },
    componentProps: { disabled: true, loading: isLoadingEquipmentState?.value }
  },
  {
    type: 'input',
    model: 'productName',
    formItemProps: { label: i18nt('productType') },
    componentProps: { disabled: true, loading: isLoadingEquipmentState?.value }
  },
  nextStateListIsShow.value
    ? {
        type: 'select',
        model: 'nextEqpStateCode',
        formItemProps: { label: i18nt('nextState'), rule: useRules('change', i18nt('nextState')) },
        componentProps: {
          loading: isLoadingNextStateList?.value,
          options: nextStateList?.value,
          labelField: 'name',
          valueField: 'id'
        }
      }
    : __,
  useRenderFormTextarea({
    label: i18nt('equipmentAlarmInfo'),
    model: 'alarmInfo',
    formItemClass: 'col-span-2!'
  }),
  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark'),
    formItemProps: { rule: useRules('input', i18nt('remark')) },
    formItemClass: 'col-span-2!'
  })
]);
// 设备编号查询
const eqpIdQuery = async (eqpId: string) => {
  try {
    await executeGetNextStateList?.(__, {
      params: { eqpId, check: 0 }
    });
    if (nextStateList.value && nextStateList.value.length === 1) {
      formData.value.nextEqpStateCode = nextStateList.value[0].id;
    }
    const { data } = await executeGetEquipmentState(__, {
      params: { eqpId }
    });
    if (!data.value) return;
    formData.value.eqpStateName = data?.value?.eqpStateName;
    formData.value.lotId = data?.value?.lotId;
    formData.value.productName = data?.value?.productName;
    restoreValidation();
  } catch (error) {
    console.log(error);
  }
};
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: {
        ...formData.value
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  nextStateListIsShow.value = true;
  overviewIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
  emit('areset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="modalTitle"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
  </base-modal>
</template>
