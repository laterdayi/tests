<script setup lang="tsx">
import maintenanceDrawer from './maintenance-drawer.vue';
import { RepairManageApis } from '@/service/apis/assembly/production-manage/repair-manage';
import type {
  DetailFormType,
  FormItemListSaveType,
  MaintenanceFormDataType,
  MaintenanceType
} from '@/service/apis/assembly/production-manage/repair-manage';

const emit = defineEmits<{
  'reset-from': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 弹窗开启
const modalIsShow = ref(false);
const { isLoading: isLoadingNextStateList, execute: executeGetNextStateList } = useAxiosGet<OptionsType[]>(
  RepairManageApis.getNextStateListApi
);
const nextStateList = ref<OptionsType[]>();
// 存储数据
const modelForm = ref();
//  打开弹窗
const handleOpenModal = (row: DetailFormType) => {
  modelForm.value = row;
  stateChecked(row.defaultSelection);
  formData.value.state = row.defaultSelection;
  modalIsShow.value = true;
};

// 表单
const { formData, resetField, formRef, validate } = useForm<Nilable<MaintenanceType>>({
  state: null,
  reason: null,
  handleMeasures: null,
  parameterModification: null,
  sparePartChange: null,
  nextEqpStateCode: null
});
// 维修确认列表
const maintenanceResultsList = [
  {
    id: 3,
    value: 'isBtnMajorDown',
    label: 'MajorDown  '
  },
  {
    id: 6,
    value: 'isBtnPM',
    label: 'PM '
  },
  {
    id: 7,
    value: 'isBtnRepairMachine',
    label: '修机'
  },
  {
    id: 8,
    value: 'isBtnRepairComplete',
    label: '维修完成'
  }
];
// 维修确认点击
const stateChecked = async (value: number | undefined) => {
  resetField();
  const { data } = await executeGetNextStateList({
    params: { eqpId: modelForm.value.eqpId, check: value === 6 || value === 8 ? (value === 6 ? 2 : 3) : 1 }
  });
  if (!data.value) return;
  nextStateList.value = data.value;
  if (nextStateList.value.length === 1) {
    formData.value.nextEqpStateCode = nextStateList.value[0].id;
  }
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    render() {
      return (
        <div
          style={{
            marginLeft: '50px'
          }}
        >
          <span class="mr">{i18nt('maintenanceResults')}</span>
          <n-radio-group name="radiogroup" onUpdateValue={stateChecked} v-model:value={formData.value.state}>
            <n-space>
              {maintenanceResultsList.map(ele => {
                return modelForm.value[ele.value as keyof DetailFormType] ? (
                  <n-radio value={ele.id}>{ele.label}</n-radio>
                ) : (
                  __
                );
              })}
            </n-space>
          </n-radio-group>
        </div>
      );
    }
  },
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'reason',
        formItemProps: {
          label: i18nt('primaryCause'),
          rule: useRules('input', i18nt('primaryCause'))
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'handleMeasures',
        formItemProps: {
          label: i18nt('repairsMeasure'),
          rule: useRules('input', i18nt('repairsMeasure'))
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'parameterModification',
        formItemProps: {
          label: i18nt('paramsModify')
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'sparePartChange',
        formItemProps: {
          label: i18nt('spareReplace')
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        class: 'w-95%!'
      }
    : __,
  {
    type: 'select',
    model: 'nextEqpStateCode',
    formItemProps: { label: i18nt('nextState'), rule: useRules('change', i18nt('nextState')) },
    class: 'w-95%!',
    componentProps: {
      loading: isLoadingNextStateList?.value,
      options: nextStateList?.value,
      labelField: 'name',
      valueField: 'id'
    }
  },
  formData.value.state === 8
    ? {
        type: 'custom-form-item',
        render() {
          return (
            <div
              style={{
                marginLeft: '50px'
              }}
            >
              <span
                style={{
                  color: '#f56c6c',
                  marginRight: '5px'
                }}
              >
                *
              </span>
              <span class="mr">{i18nt('maintenanceConfirmation')}</span>
              <base-button
                buttonName={maintenanceFormData.value ? '已确认' : '未确认'}
                class="mr"
                onClick={maintenanceConfirmationClick}
                size={componentSize.value}
                type="primary"
              >
                {maintenanceFormData.value ? '已确认' : '未确认'}
              </base-button>
            </div>
          );
        }
      }
    : __
]);
const maintenanceDrawerRef = ref();
// 维修确认点击
const maintenanceConfirmationClick = () => {
  maintenanceDrawerRef.value?.handleOpenModal(modelForm.value, maintenanceFormData.value);
};
// 抽屉传值
const maintenanceFormData = ref<MaintenanceFormDataType>();
const drawerFrom = (item?: MaintenanceFormDataType) => {
  maintenanceFormData.value = item;
};

const { execute: executeFormConfirm } = useAxiosPost<FormItemListSaveType>(RepairManageApis.saveRepairHandlerFormApi);
const { execute: saveFormAdd } = useAxiosPost(RepairManageApis.submitFeedbackApi);
// 保存表单
const saveForm = async () => {
  try {
    await validate();
    if (formData.value.state === 8) {
      if (!maintenanceFormData.value) {
        return $message.warning(i18nt('notEmpty', { val: i18nt('maintenanceConfirmation') }));
      }
      const { eFormId, prefix, repairHandleType } = maintenanceFormData.value?.formInfoData ?? {};
      await executeFormConfirm(__, {
        data: {
          ...formData.value,
          id: modelForm.value.id,
          eFormId,
          prefix,
          repairHandleType,
          selectType: 1,
          eFormItemList: maintenanceFormData.value?.eFormItemList,
          nextEqpStateCode: formData.value.nextEqpStateCode
        }
      });
    } else {
      await saveFormAdd({
        data: {
          state: formData.value.state,
          repairId: modelForm.value.id,
          nextEqpStateCode: formData.value.nextEqpStateCode
        }
      });
    }
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  maintenanceFormData.value = undefined;
  // 重置表单并去除验证
  resetField();
  emit('reset-from');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="i18nt('maintenanceConfirmation')"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="base" :schemas="formSchemas" />
    <!-- 维修确认 -->
    <maintenanceDrawer ref="maintenanceDrawerRef" @drawer-from="drawerFrom" @drawer-from-back-up="drawerFrom" />
  </base-modal>
</template>
