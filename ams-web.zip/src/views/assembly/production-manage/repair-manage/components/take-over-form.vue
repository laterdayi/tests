<script setup lang="tsx">
import { RepairManageApis } from '@/service/apis/assembly/production-manage/repair-manage';
import type { TakeOverFormType } from '@/service/apis/assembly/production-manage/repair-manage';

const emit = defineEmits<{
  'reset-from': [];
}>();

// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
// 获取后一状态列表
const { isLoading: isLoadingNextStateList, execute: executeGetNextStateList } = useAxiosGet<OptionsType[]>(
  RepairManageApis.getNextStateListApi
);
const nextStateList = ref<OptionsType[]>([]);
//  打开弹窗
const handleOpenModal = async (detailFormRow: TakeOverFormType) => {
  modalTitle.value = detailFormRow.isBtnTakeOver === 1 ? i18nt('takeOver') : i18nt('changedHand');
  const { data } = await executeGetNextStateList({
    params: { eqpId: detailFormRow.eqpId, check: 1 }
  });

  if (!data.value) return;
  nextStateList.value = data.value;
  formData.value = detailFormRow;
  if (nextStateList.value.length === 1) {
    formData.value.nextEqpStateCode = nextStateList.value[0].id;
  }
  updateField({
    ...formData.value,
    remark: null
  });
  modalIsShow.value = true;
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  formData.value.secondaryTakeover === 0
    ? {
        type: 'select',
        model: 'nextEqpStateCode',
        formItemProps: { label: i18nt('nextState'), rule: useRules('change', i18nt('nextState')) },
        componentProps: {
          loading: isLoadingNextStateList?.value,
          options: nextStateList?.value,
          labelField: 'name',
          valueField: 'id'
        }
      }
    : __,
  useRenderFormTextarea({
    label: i18nt('remark'),
    model: 'remark',
    formItemClass: 'col-span-2!'
  })
]);
const { validate, formData, resetField, formRef, updateField } = useForm<Nullable<TakeOverFormType>>({
  id: null,
  eqpId: null,
  nextEqpStateCode: null,
  remark: null,
  secondaryTakeover: 0,
  isBtnTakeOver: 1
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost(RepairManageApis.takeOverRepairApi);
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    const { id, remark, isBtnTakeOver, nextEqpStateCode } = formData.value;
    await saveFormAdd({
      data: {
        repairId: id,
        remark,
        nextEqpStateCode,
        operateType: isBtnTakeOver === 1 ? 1 : 2
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-from');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="modalTitle"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
  </base-modal>
</template>
