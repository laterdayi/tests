<script setup lang="tsx">
import addForm from './components/add-form.vue';
import detailForm from './components/detail-form.vue';
import { RepairManageApis, RepairState } from '@/service/apis/assembly/production-manage/repair-manage';
import type { QueryType, TableListType } from '@/service/apis/assembly/production-manage/repair-manage';
import { CommonApis } from '@/service/apis/common/common';

const { currentRoutePowers } = useRoutes();
// 模板引用
const curdRef = ref<CurdRefType<QueryType, TableListType>>();
// 新增弹窗
const addFormRef = ref();
// 详情弹窗
const detailFormRef = ref();
//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelApi,
  __,
  { params: { check: 1, isNormal: 1 } },
  {
    immediate: true
  }
);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
handleQueryEquipmentList();
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });
// 搜索栏
const queryFormParams: Nullable<QueryType> = {
  eqpNames: null,
  treeIds: null,
  remark: null,
  state: null,
  timestamp: useFormatDateRange()
};
// 重置搜索栏
const refactorFormQueryParams = (data: QueryType) => {
  return {
    ...data,
    eqpNames: data.eqpNames
      ? data.eqpNames.map(ele => {
        if (multiChildEquipmentList.value) {
          return multiChildEquipmentList.value.find(ele1 => ele1.id === ele)?.name;
        }
        return undefined;
      })
      : null,
    ...useFormatDateTimeParams(data.timestamp)
  };
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        if (curdRef?.value?.queryFormData) curdRef.value.queryFormData.eqpNames = [];
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
            params: { layoutIds: value }
          })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpNames',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'id'
    }
  },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('state') },
    componentProps: {
      options: [
        {
          id: 1,
          name: i18nt('RepairOperateStateEnum_ToTakeOver')
        },
        {
          id: 2,
          name: i18nt('RepairOperateStateEnum_AwaitingRepair')
        },
        {
          id: 3,
          name: i18nt('RepairOperateStateEnum_MarjorDown')
        },
        {
          id: 4,
          name: i18nt('RepairOperateStateEnum_ToBeConfirmed')
        },
        {
          id: 5,
          name: i18nt('RepairOperateStateEnum_EqpReceive')
        },
        {
          id: 6,
          name: i18nt('RepairOperateStateEnum_PM')
        },
        {
          id: 7,
          name: i18nt('RepairOperateStateEnum_RepairMachine')
        },
        {
          id: 8,
          name: i18nt('RepairOperateStateEnum_CompleteMaintenance')
        }
      ],
      labelField: 'name',
      valueField: 'id'
    }
  },
  { type: 'input', model: 'remark', formItemProps: { label: i18nt('remark') } },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('repairTime') },
    componentProps: { type: 'datetimerange' }
  }
]);
const curdRefPagination = computed(() => curdRef.value?.pagination);

// 列表
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('workOrderNumber'),
    key: 'repairFormNo',
    sorter: true,
    width: TABLE_WIDTH_NAME,
    render(rowData: TableListType) {
      return rowData.state === RepairState.completeMlaintenance
        ? rowData.repairFormNo
        : useRenderTableTitleEdit(
          rowData.repairFormNo,
          () => detailFormRef.value?.handleOpenModal(rowData, false, currentRoutePowers.value)
        );
    }
  },
  {
    title: i18nt('state'),
    key: 'stateStr',
    render(rowData) {
      const types: { [key: number]: string } = {
        [RepairState.toTakeOver]: TagState.warning,
        [RepairState.awaitingRepair]: TagState.primary,
        [RepairState.marjorDowarjorDow]: TagState.primary,
        [RepairState.toBeConfirmed]: TagState.primary,
        [RepairState.eapReceive]: TagState.primary,
        [RepairState.PM]: TagState.primary,
        [RepairState.repairMachine]: TagState.warning,
        [RepairState.completeMlaintenance]: TagState.success
      };
      return useRenderTableSingleTag(types[rowData.state] as TagStateType, i18nt(rowData.stateStr));
    },
    width: TABLE_WIDTH_STATE
  },
  { title: i18nt('equipmentNumber'), key: 'eqpName', sorter: true, width: TABLE_WIDTH_INFO },
  { title: i18nt('remark'), key: 'remark', width: TABLE_WIDTH_INFO },
  { title: i18nt('repairApplicant'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('repairTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('currentResponsiblePerson'), key: 'responser', width: TABLE_WIDTH_NAME },
  { title: i18nt('productType'), key: 'productName', width: TABLE_WIDTH_STATE },
  { title: i18nt('alarmInfo'), key: 'alarmInfo', width: TABLE_WIDTH_INFO },
  { title: i18nt('lastDisposeTime'), key: 'lastUpdateTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('totalDisposeTime'), key: 'totalDealTime', width: TABLE_WIDTH_DATETIME },

  useRenderTableActionColumn({
    render: rowData =>
      useRenderTableFixedButton('viewDetail', {
        onClick: () => detailFormRef.value?.handleOpenModal(rowData, false, [])
      })
  })
];
// 按钮权限控制
const formDisableCondition = computed(() => {
  const selectedRows = curdRef?.value?.tableRef?.selectedRows;
  const { state } = selectedRows?.at(0) ?? {};
  return {
    edit: selectedRows?.length !== 1 || state !== RepairState.toTakeOver,
    delete: selectedRows?.length !== 1 || state !== RepairState.toTakeOver
  };
});
// 操作按钮;
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    add: () => addFormRef.value?.handleOpenModal(null),
    edit: () => addFormRef.value?.handleOpenModal(curdRef?.value?.tableRef?.selectedKeys[0])
  };
  if (permissionAction[permission]) permissionAction[permission]();
};
// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="repair-manage">
    <base-curd
      ref="curdRef"
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL }"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :form-permission-disable="formDisableCondition"
      :ignore-form-permission-list="[
        'takeOver',
        'changedHand',
        'maintenanceConfirmation',
        'qcConfirm',
        'equipmentReceive'
      ]"
      modal-title="repair"
      :read-api="RepairManageApis.getRepairListApi"
      :delete-api="RepairManageApis.deleteRepairApi"
      :export-api="RepairManageApis.getRepairListApi"
      @handle="handlePermission"
    />
    <!-- 新增报修 -->
    <addForm ref="addFormRef" @reset-table="resetTable" />
    <!-- 查看详情 -->
    <detailForm ref="detailFormRef" @reset-table="resetTable" />
  </div>
</template>
