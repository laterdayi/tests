enum ValidateFormItemResult {
  // 不通过
  fail,
  // 通过
  pass
}

export const validateFormItemResultStateText: { [keys in ValidateFormItemResult]: string } = {
  [ValidateFormItemResult.pass]: 'Pass',
  [ValidateFormItemResult.fail]: 'Fail'
};
export const validateFormItemResultStateType: { [keys in ValidateFormItemResult]: string } = {
  [ValidateFormItemResult.pass]: 'success',
  [ValidateFormItemResult.fail]: 'error'
};
