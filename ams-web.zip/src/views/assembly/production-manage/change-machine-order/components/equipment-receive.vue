<script setup lang="tsx">
import type {
  FormInfoDataType,
  FormItemListSaveType,
  MaintenanceModalType,
  NextStateFormType,
  NextStateListType,
  QcConfirmModalType
} from '@/service/apis/assembly/production-manage/repair-manage';
import { ChangeMachineOrderApis } from '@/service/apis/assembly/production-manage/change-machine-order';

import { ElectronicFormApis, ItemListBelongTo } from '@/utils/project/electronic-form/electronic-form-type';
import type {
  FormItemListType,
  ItemListType,
  RenderComponentType
} from '@/utils/project/electronic-form/electronic-form-type';
import {
  handleGoldSampleTableData,
  handleTableColSpan,
  handleTableColSpanBackfill,
  handleTableColumns,
  handleTableData,
  handleValidateChangeMachineForm,
  handleValidateFormIsMaxItemValue,
  handleValidateFormIsPass,
  useRenderFormItemComponent,
  validSampleItem,
  validSampleLimit
} from '@/utils/project/electronic-form/electronic-form-method';

const emit = defineEmits<{
  'reset-from': [];
}>();

const showDrawer = ref<boolean>(false);
// 表单信息
const { data: formInfoData, execute: executeGetQcConfirmForm } = useAxiosGet<FormInfoDataType>(
  ChangeMachineOrderApis.getFormInfoApi
);
// 获取表单列表信息
const { execute: executeGetFormItemList } = useAxiosPost<FormItemListType>(
  ElectronicFormApis.getFormItemListApi,
  __,
  __,
  { shallow: false }
);
// 获取后一状态列表
const { isLoading: isLoadingNextStateList, execute: executeGetNextStateList } = useAxiosGet<NextStateListType[]>(
  ChangeMachineOrderApis.getNextStateListApi
);
const nextStateList = ref<NextStateListType[]>([]);
// 抽屉存储
const drawerForm = ref<QcConfirmModalType>();
// 弹窗title
const modalTitle = ref<string>('');
// 接口设置
const modalUrl = ref<string>('');
// 下一状态显隐
const nextEqpStateCodeIsShow = ref<boolean>(true);
// 金样显隐
const eFormTypeIndex = ref<number>(5);
const handleList: { [key: string]: () => void } = {
  isBtnParmConfirm: () => {
    modalTitle.value = i18nt('changeMachineConfirm');
    modalUrl.value = ChangeMachineOrderApis.formConfirmApi;
    eFormTypeIndex.value = 5;
  },
  isBtnQCConfirm: () => {
    modalTitle.value = i18nt('qcConfirm');
    modalUrl.value = ChangeMachineOrderApis.formConfirmApi;

    eFormTypeIndex.value = 6;
  },
  isBtnEqpReceive: () => {
    modalTitle.value = i18nt('equipmentReceive');
    nextEqpStateCodeIsShow.value = false;
    modalUrl.value = ChangeMachineOrderApis.equipmentReceiveConfirmApi;
    eFormTypeIndex.value = 7;
  }
};
// 样品/测量数
const sampleNum = ref<number>(0);
const testNum = ref<number>(0);
const confirmFormItemList = ref();
//  打开弹窗
const handleOpenModal = async (detailFormRow: MaintenanceModalType, nameType: string) => {
  try {
    drawerForm.value = detailFormRow;
    handleList[nameType as string]();
    if (nextEqpStateCodeIsShow.value) {
      const { data } = await executeGetNextStateList({
        params: { eqpId: detailFormRow.eqpId, check: 0 }
      });
      if (!data.value) return;
      // 下一状态409当全部pass,默认选中,有fail默认不能选,只有一条数据默认选中(不包括409)
      nextStateList.value = data?.value?.map((ele: NextStateListType) => {
        ele.disabled = ele.id === '409';
        return ele;
      });
      if (!nextStateList.value) return;
      if (nextStateList?.value.length === 1 && nextStateList.value[0].id !== '409') {
        nextStateFormData.value.nextEqpStateCode = nextStateList.value[0].id;
      }
    }
    // 获取表单信息
    await executeGetQcConfirmForm(__, {
      params: {
        id: detailFormRow.id,
        eFormType: eFormTypeIndex.value
      }
    });
    if (!formInfoData.value) return;
    sampleNum.value = formInfoData.value.sampleNum || 1;
    testNum.value = formInfoData.value.testNum || 5;
    if (formInfoData.value.itemList.length > 0) {
      confirmFormItemList.value = formInfoData.value;
    } else {
      // 获取表单列表信息
      const { data } = await executeGetFormItemList(__, {
        data: { formId: formInfoData.value.eFormId },
        showTooltip: false
      });
      if (!data.value) return;
      confirmFormItemList.value = data.value;
    }
    // 上表格类型
    typeTableData.value = handleTableData(confirmFormItemList.value.itemList);
    // 上表格名称
    nameTableData.value = handleTableData(confirmFormItemList.value.itemList, true);

    // 下表格
    goldSampleTableDataBackUp.value = confirmFormItemList.value.itemList
      .filter((item: ItemListType) => item.belongTo === ItemListBelongTo.goldSample)
      .map((item: ItemListType) => ({ ...item }));
    goldSampleTableData.value =
      formInfoData.value.itemList.length > 0
        ? handleTableColSpanBackfill(goldSampleTableDataBackUp.value || [], {
            sampleNum: sampleNum.value,
            testNum: testNum.value
          })
        : handleTableColSpan(goldSampleTableDataBackUp.value || [], {
            sampleNum: sampleNum.value,
            testNum: testNum.value
          });
    // 动态表头
    goldSampleDataColumns.value = handleTableColumns({ testNum: testNum.value }, true) || [];
    goldSampleTableScroll.value = testNum.value * 120 + 720;

    showDrawer.value = true;
  } catch (error) {
    console.log(error);
  }
};
// 表单(后一状态)
const {
  formData: nextStateFormData,
  validate,
  resetField,
  formRef
} = useForm<Nullable<NextStateFormType>>({
  nextEqpStateCode: null
});
const nextStateFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'nextEqpStateCode',
    formItemProps: { label: i18nt('nextState'), rule: useRules('change', i18nt('nextState')) },
    componentProps: {
      loading: isLoadingNextStateList.value,
      options: nextStateList.value,
      labelField: 'name',
      valueField: 'id'
    }
  }
]);
const renderFormItemComponent: RenderComponentType = useRenderFormItemComponent();
// 上表格类型
const typeTableData = ref<ItemListType[]>();
const typeTableColumns: DataTableColumns<ItemListType> = [
  { title: i18nt('equipmentShutdownType'), key: 'itemName' },
  {
    title: i18nt('content'),
    key: 'itemValue',
    render: (rowData, index) => renderFormItemComponent[rowData.dataType].render(typeTableData, rowData, index)
  },
  { title: i18nt('remark'), key: 'remark' }
];
//  还机给OP是否置灰
const nextEqpStateCodeWatchIsShow = computed<boolean>(() => {
  // if (!typeTableData.value) return false;
  // const isShow = typeTableData.value.some(ele => ele.operateIsShow);
  // const list = isShow
  //   ? typeTableData.value
  //   : typeTableData.value?.filter(ele => ele.dataType !== ItemListDataType.boolean);
  // return list.every(itemValue => itemValue.itemValue && itemValue.result === 1);
  if (!typeTableData.value || typeTableData.value.length === 0) return false;
  return typeTableData.value.every(itemValue => itemValue.itemValue && itemValue.result === 1);
});
watch(nextEqpStateCodeWatchIsShow, newValue => {
  // if (!nextStateList.value) return;
  // resetField();
  // const obj = nextStateList.value.find(ele => ele.id === '409');
  // const id = nextStateList.value.length === 0 ? null : obj ? obj.id : null;
  // nextStateFormData.value.nextEqpStateCode = newValue ? id : null;
  if (!nextStateList.value) return;
  resetField();
  const obj = nextStateList.value.find(ele => ele.id === '409');
  const id = nextStateList.value.length === 0 ? null : obj ? obj.id : null;
  nextStateFormData.value.nextEqpStateCode = newValue ? id : null;
  nextStateList?.value?.forEach((ele: NextStateListType) => {
    ele.disabled = newValue ? false : ele.id === '409';
    return ele;
  });
});

// 样品数/测量数监听
const handleGoldSampleInput = (value: number, type: number) => {
  if (type === 1) {
    sampleNum.value = value ? Number(value.toString().replace(/\D/g, '')) : 1;
  } else {
    testNum.value = value ? Number(value.toString().replace(/\D/g, '')) : 5;
  }
  if (!formInfoData.value) return;
  goldSampleTableData.value = handleTableColSpan(goldSampleTableDataBackUp.value || [], {
    sampleNum: sampleNum.value,
    testNum: testNum.value
  });
  goldSampleTableScroll.value = testNum.value * 120 + 720;
  goldSampleDataColumns.value = handleTableColumns({ testNum: testNum.value }, true) || [];
};
// 上表格名称
const nameTableData = ref<ItemListType[]>();
const nameTableDataColumns: DataTableColumns<ItemListType> = [
  { title: i18nt('equipmentShutdownType'), key: 'itemName', width: 300 },
  {
    title: i18nt('content'),
    key: 'itemValue',
    render: (rowData, index) => renderFormItemComponent[rowData.dataType].render(nameTableData, rowData, index)
  },
  {
    title: 'Visual',
    key: 'remark',
    children: [
      { title: 'Ball', key: 'Ball' },
      { title: 'Stitch', key: 'Stitch' },
      { title: 'Loop', key: 'Loop' }
    ]
  },
  { title: 'Wire Pull & Ball Shear', key: 'WirePullBallShear' }
];

// 下表格
const goldSampleTableScroll = ref<number>(0);
const goldSampleTableMaxHeight = ref<number>(510);
const goldSampleTableData = ref<ItemListType[]>();
const goldSampleTableDataBackUp = ref<ItemListType[]>();
const goldSampleTableColumns = computed(() => {
  return goldSampleTableColumnsOld.value.concat(goldSampleDataColumns.value) as DataTableColumns<ItemListType>;
});

const goldSampleTableColumnsOld = ref<DataTableColumns<ItemListType>>([
  {
    title: i18nt('checkItemName'),
    key: 'itemName',
    width: 120,
    rowSpan: (rowData, rowIndex) => (rowIndex % (sampleNum.value || 1) === 0 ? sampleNum.value || 1 : 1)
  },
  {
    title: i18nt('unit'),
    width: 60,
    key: 'unit',
    rowSpan: (rowData, rowIndex) => (rowIndex % (sampleNum.value || 1) === 0 ? sampleNum.value || 1 : 1)
  },
  {
    title: i18nt('method'),
    width: 100,
    key: 'standard',
    rowSpan: (rowData, rowIndex) => (rowIndex % (sampleNum.value || 1) === 0 ? sampleNum.value || 1 : 1)
  },
  // 下限
  {
    title: i18nt('standardLowerLimit'),
    key: 'lowLimit',
    width: 150,
    render(row) {
      return (
        <base-input-number
          class="w-80%!"
          min={undefined}
          on-update:value={(value: number) => lowLimitUpdated(value, row)}
          placeholder=""
          v-model:value={row.lowLimit}
        >
        </base-input-number>
      );
    }
  },
  // 上限
  {
    title: i18nt('standardUpperLimit'),
    key: 'highLimit',
    width: 150,
    render(row) {
      return (
        <base-input-number
          class="w-80%!"
          min={undefined}
          on-update:value={(value: number) => highLimitUpdated(value, row)}
          placeholder=""
          v-model:value={row.highLimit}
        >
        </base-input-number>
      );
    }
  },
  // 样品
  {
    title: i18nt('sample'),
    width: 60,
    key: 'sampleNo',
    render: row => <span>{row.sampleNo ?? 1}</span>
  }
]);
const goldSampleDataColumns = ref<DataTableColumns<ItemListType>>([]);
// 下限限制
const lowLimitUpdated = (value: number, row: ItemListType) => {
  row.lowLimit = value;
  row.dataList?.forEach(ele => {
    ele.dataValue = '';
    ele.dataResult = 0;
  });
  if (!row.highLimit || !row.lowLimit) {
    row.disabled = true;
  } else {
    row.disabled = row.lowLimit > row.highLimit;
    if (row.lowLimit > row.highLimit) {
      $message.warning(i18nt('standardTips'));
      row.lowLimit = null;
    }
  }
};
// 上限限制
const highLimitUpdated = (value: number, row: ItemListType) => {
  row.highLimit = value;
  row.dataList?.forEach(ele => {
    ele.dataValue = '';
    ele.dataResult = 0;
  });
  if (!row.highLimit || !row.lowLimit) {
    row.disabled = true;
  } else {
    row.disabled = row.highLimit < row.lowLimit;
    if (row.highLimit < row.lowLimit) {
      $message.warning(i18nt('standardTips1'));
      row.highLimit = null;
    }
  }
};
// 确认
const { execute: executeFormConfirm } = useAxiosPost<FormItemListSaveType>('');
const handleSubmitFormConfirm = async () => {
  try {
    // 上表格长度超出验证
    if (handleValidateFormIsMaxItemValue(typeTableData)) return;
    // 上表格类型验证
    if (!handleValidateChangeMachineForm(typeTableData)) return;
    if (!handleValidateFormIsPass(typeTableData)) return;
    if (goldSampleTableData.value && goldSampleTableData.value.length !== 0) {
      // 下表格验证
      if (!validSampleLimit(goldSampleTableData.value)) return;
      if (!validSampleItem(goldSampleTableData.value)) return;
    }
    if (nextEqpStateCodeIsShow.value) {
      await validate();
    }
    const { eFormId, prefix, conversionHandleType } = formInfoData.value ?? {};
    await executeFormConfirm(modalUrl.value, {
      data: {
        id: drawerForm?.value?.id,
        conversionHandleType,
        prefix,
        eFormId,
        eFormItemList: [
          ...(typeTableData.value?.map(ele => {
            return ele.dataType === 9
              ? {
                  ...ele,
                  itemValue: '',
                  attachmentFile: ele.itemValue
                }
              : { ...ele };
          }) || []),
          ...(nameTableData.value || []),
          ...(handleGoldSampleTableData(goldSampleTableData.value) || [])
        ],
        selectType: 0,
        nextEqpStateCode: nextStateFormData.value.nextEqpStateCode
      }
    });
    cancelDrawer();
  } catch (error) {
    console.log(error);
  }
};
// 关闭抽屉
const cancelDrawer = () => {
  showDrawer.value = false;
  nextEqpStateCodeIsShow.value = true;
  typeTableData.value = [];
  resetField();
  emit('reset-from');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <!--  维修完成 -->
  <base-drawer v-model:show="showDrawer" width="60%" :title="modalTitle" @mask-click="cancelDrawer">
    <base-scrollbar>
      <!-- 样品 -->
      <div
        v-if="formInfoData && goldSampleTableData && goldSampleTableData.length !== 0"
        class="flex flex-col items-end"
      >
        <n-form-item :label="$t('sampleCount')" label-placement="left">
          <base-input-number v-model:value="sampleNum" @update:value="handleGoldSampleInput(sampleNum, 1)" />
        </n-form-item>
        <n-form-item :label="$t('measurementNumber')" label-placement="left">
          <base-input-number v-model:value="testNum" @update:value="handleGoldSampleInput(testNum, 2)" />
        </n-form-item>
      </div>
      <!-- 样品(上表格类型) -->
      <base-table
        v-if="typeTableData && typeTableData.length !== 0"
        :data="typeTableData"
        :columns="typeTableColumns"
      />
      <!-- 样品(上表格名称) -->
      <base-table
        v-if="nameTableData && nameTableData.length !== 0"
        class="mt"
        :data="nameTableData"
        :columns="nameTableDataColumns"
      />
      <!-- 金样(下表格) -->
      <base-table
        v-if="goldSampleTableData && goldSampleTableData.length !== 0"
        :row-key="(rowData: ItemListType) => rowData.idNew!"
        :data="goldSampleTableData"
        :scroll-x="goldSampleTableScroll"
        :max-height="goldSampleTableMaxHeight"
        class="mt"
        :columns="goldSampleTableColumns"
      />
      <!-- 后一状态 -->
      <base-form
        v-if="nextEqpStateCodeIsShow"
        ref="formRef"
        v-model="nextStateFormData"
        layout="base"
        class="mt"
        :schemas="nextStateFormSchemas"
      />
    </base-scrollbar>
    <template #footer>
      <base-button class="m-r" button-name="cancel" ghost @click="cancelDrawer">
        {{ $t('cancel') }}
      </base-button>
      <base-button button-name="confirm" type="primary" ghost @click="handleSubmitFormConfirm">
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-drawer>
</template>
