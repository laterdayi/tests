<script setup lang="tsx">
import type {
  ChangeMachineInfoListType,
  EditAddType,
  EquipmentStateType
} from '@/service/apis/assembly/production-manage/repair-manage';
import { ChangeMachineOrderApis } from '@/service/apis/assembly/production-manage/change-machine-order';
import { CommonApis } from '@/service/apis/common/common';
import BaseTable from '@/components/base-ui/base-table/base-table.vue';
import BaseInput from '@/components/base-ui/base-input/base-input.vue';
import { AttributeType } from '@/constants/enum';

const emit = defineEmits<{
  'reset-table': [];
  'areset-table': [];
}>();

// 接口设置
const modalUrl = ref<string>('');
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
// 产线层级
const {
  data: productLineList,
  isLoading: isLoadingProductLineList,
  execute: handleProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelApi);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi);
// // 获取设备状态
const { isLoading: isLoadingEquipmentState, execute: executeGetEquipmentState } = useAxiosGet<EquipmentStateType>(
  ChangeMachineOrderApis.getEquipmentStateApi
);
// 获取下一状态列表
const {
  data: nextStateList,
  isLoading: isLoadingNextStateList,
  execute: executeGetNextStateList
} = useAxiosGet<OptionsType[]>(ChangeMachineOrderApis.getNextStateListApi);
// 下一状态编辑
const nextStateListIsShow = ref<boolean>(true);
// 获取改机信息
const { isLoading: isLoadingChangeMachineInfoList, execute: executeGetChangeMachineInfoList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getSelectItemListApi);
// 获取详情
const { execute: getFrom } = useAxiosGet<EditAddType>(ChangeMachineOrderApis.getChangeMachineDetailApi);
// 设备总览
const overviewIsShow = ref<boolean>(false);
//  打开弹窗
const handleOpenModal = async (
  row: string,
  overviewObj: {
    layoutId: string;
    eqpId: string;
  }
) => {
  try {
    await handleProductLineList(__, { params: { check: 1, isNormal: 1 } });
    await handleQueryEquipmentList();
    const { data: conversionProgramTypeList } = await executeGetChangeMachineInfoList(__, {
      params: { type: AttributeType.conversionProgramType }
    });
    tableData.value =
      conversionProgramTypeList.value?.map(item => ({
        ...item,
        type: item.name,
        from: '',
        to: '',
        fromDisabled: false,
        toDisabled: false
      })) ?? [];
    if (row) {
      modalTitle.value = i18nt('edit') + i18nt('changeMachineOrder');
      modalUrl.value = ChangeMachineOrderApis.updateChangeMachineApi;
      const { data } = await getFrom({
        params: {
          id: row
        }
      });
      if (!data.value) return;
      formData.value = data.value;
      const { data: eqpData } = await executeGetEquipmentState(__, {
        params: { eqpId: data.value.eqpId }
      });
      if (!eqpData.value) return;
      eqpIdQuery(data.value.eqpId, data?.value?.list, data?.value?.lotId);
      nextStateListIsShow.value = false;
    } else {
      modalTitle.value = i18nt('add') + i18nt('changeMachineOrder');
      modalUrl.value = ChangeMachineOrderApis.createChangeMachineApi;
      // 是否设备总览
      if (overviewObj) {
        overviewIsShow.value = true;
        formData.value.layoutId = overviewObj.layoutId;
        formData.value.eqpId = overviewObj.eqpId;
        eqpIdQuery(formData.value.eqpId);
      }
    }
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
// 表单
const { validate, formData, resetField, restoreValidation, formRef } = useForm<Nullable<EditAddType>>({
  layoutId: null,
  eqpId: null,
  eqpStateName: null,
  lotId: null,
  lotIdIsShow: false,
  nextEqpStateCode: null,
  remark: null,
  list: []
});
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'layoutId',
    formItemProps: { label: i18nt('productionLineLevel'), rule: useRules('change', i18nt('productionLineLevel')) },
    componentProps: {
      disabled: overviewIsShow.value || !nextStateListIsShow.value,
      options: productLineList?.value,
      loading: isLoadingProductLineList.value,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        formData.value.eqpId = null;

        formData.value.nextEqpStateCode = null;
        formData.value.eqpStateName = null;
        formData.value.lotId = null;
        formData.value.lotIdIsShow = false;
        formData.value.remark = null;

        tableData.value.forEach(ele => {
          ele.from = '';
          ele.to = '';
          ele.fromDisabled = false;
          ele.toDisabled = false;
        });
        console.log(tableData.value);

        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList({
              params: { layoutIds: value }
            })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber'), rule: useRules('change', i18nt('equipmentNumber')) },
    componentProps: {
      disabled: overviewIsShow.value || !nextStateListIsShow.value,
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'id',
      onUpdateValue: (value: string) => {
        formData.value.nextEqpStateCode = null;
        formData.value.eqpStateName = null;
        formData.value.lotId = null;
        formData.value.lotIdIsShow = false;
        formData.value.remark = null;
        nextStateList.value = [];
        if (value) {
          eqpIdQuery(value);
        }
      }
    }
  },
  {
    type: 'input',
    model: 'eqpStateName',
    formItemProps: { label: i18nt('equipmentState') },
    componentProps: {
      disabled: true,
      loading: isLoadingEquipmentState?.value
    }
  },
  nextStateListIsShow.value
    ? {
        type: 'select',
        model: 'nextEqpStateCode',
        formItemProps: { label: i18nt('nextState'), rule: useRules('change', i18nt('nextState')) },
        componentProps: {
          loading: isLoadingNextStateList.value,
          options: nextStateList?.value,
          labelField: 'name',
          valueField: 'id'
        }
      }
    : __,
  {
    type: 'input',
    model: 'lotId',
    formItemProps: { label: 'Lot ID' },
    componentProps: {
      disabled: true
    }
  },
  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark'),
    formItemProps: { rule: useRules('input', i18nt('remark')) },
    formItemClass: 'col-span-2!'
  }),
  {
    type: 'custom-node',
    render() {
      return h('div', { class: 'card-title col-span-2!' }, i18nt('changeMachineInfo'));
    }
  },
  {
    type: 'custom-node',
    render() {
      return h(
        BaseTable,
        {
          class: 'col-span-2!',
          columns: tableColumns,
          data: tableData.value,
          loading: isLoadingChangeMachineInfoList.value
        },
        {}
      );
    }
  }
]);
const tableData = ref<ChangeMachineInfoListType[]>([]);
// 改机信息列表
const tableColumns: DataTableColumns<ChangeMachineInfoListType> = [
  { key: 'type' },
  {
    title: i18nt('from'),
    key: 'form',
    render: (rowData, index) =>
      h(BaseInput, {
        value: rowData.from,
        maxlength: 200,
        disabled: rowData.fromDisabled,
        onUpdateValue: (val: string) => (tableData.value[index].from = val)
      })
  },
  {
    title: i18nt('convertTo'),
    key: 'to',
    render: (rowData, index) =>
      h(BaseInput, {
        value: rowData.to,
        maxlength: 200,
        disabled: rowData.toDisabled,
        onUpdateValue: (val: string) => (tableData.value[index].to = val)
      })
  }
];
// 设备编号查询
const eqpIdQuery = async (eqpId: string, eqpList?: ChangeMachineInfoListType[], lotId?: string) => {
  try {
    await executeGetNextStateList?.(__, {
      params: { eqpId, check: 1 }
    });
    if (nextStateList.value && nextStateList.value.length === 1) {
      formData.value.nextEqpStateCode = nextStateList.value[0].id;
    }
    const { data } = await executeGetEquipmentState(__, {
      params: { eqpId }
    });
    if (!data.value) return;
    formData.value.eqpStateName = data?.value?.eqpStateName;
    formData.value.lotId = data?.value?.lotId ? data?.value?.lotId : lotId || '';
    formData.value.lotIdIsShow = !!data?.value?.lotId;
    tableData.value.forEach((ele, index) => {
      if (index === 0) {
        ele.fromDisabled = !!data?.value?.programNameFrom;
        ele.toDisabled = !!data?.value?.programNameTo;

        ele.from = data?.value?.programNameFrom ? data?.value?.programNameFrom : eqpList ? eqpList?.[index].from : '';
        ele.to = data?.value?.programNameTo ? data?.value?.programNameTo : eqpList ? eqpList?.[index].to : '';
      } else {
        ele.from = eqpList?.[index].from || '';
        ele.to = eqpList?.[index].to || '';
      }
    });

    restoreValidation();
  } catch (error) {
    console.log(error);
  }
};
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: { ...formData.value, list: tableData.value }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  nextStateListIsShow.value = true;
  overviewIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
  emit('areset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="modalTitle"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
  </base-modal>
</template>
