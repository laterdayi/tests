<script setup lang="tsx">
import verifierForm from './verifier.vue';
import equipmentReceiveForm from './equipment-receive.vue';
import type {
  ChangeMachineInfoListType,
  MachineDetailType,
  OperateRecordListType,
  TableListTypes
} from '@/service/apis/assembly/production-manage/repair-manage';

import { ChangeMachineOrderApis } from '@/service/apis/assembly/production-manage/change-machine-order';

import { ItemListBelongTo } from '@/utils/project/electronic-form/electronic-form-type';
import type { FormItemListType, ItemListType } from '@/utils/project/electronic-form/electronic-form-type';
import {
  handleTableColSpanBackfill,
  handleTableColumns,
  handleTableData
} from '@/utils/project/electronic-form/electronic-form-method';

const emit = defineEmits<{
  'reset-table': [];
  'areset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const currentRoutePowers = ref<string[]>();
// 是否详情可编辑
const negativeIsShow = ref<boolean>(true);
// 弹窗备份
const detailFormRow = ref<TableListTypes>();
// 弹窗开启
const modalIsShow = ref(false);
// 获取详情
const { isLoading: isLoadingCurrentEditData, execute: executeGetCurrentEditData } = useAxiosGet<MachineDetailType>(
  ChangeMachineOrderApis.getChangeMachineDetailApi
);
//  获取操作记录
const operateRecordList = ref<OperateRecordListType[]>();
const { isLoading: isLoadingOperateRecordList, execute: executeGetOperateRecordList } = useAxiosGet<
  OperateRecordListType[]
>(ChangeMachineOrderApis.getOperateRecordListApi);
//  打开弹窗
const handleOpenModal = (row: TableListTypes, isShow: boolean, currentRoutePowersList: string[]) => {
  detailFormRow.value = row;
  negativeIsShow.value = isShow;
  currentRoutePowers.value = currentRoutePowersList;
  resetFrom();
  modalIsShow.value = true;
};
// 刷新表单
const resetFrom = async () => {
  const { data: detailData } = await executeGetCurrentEditData(__, { params: { id: detailFormRow.value?.id } });
  if (!detailData.value) return;
  formData.value = detailData.value;
  changeMachineInfoList.value = detailData.value.list || [];
  const { data: operateRecorData } = await executeGetOperateRecordList(__, { params: { id: detailFormRow.value?.id } });
  operateRecordList.value = operateRecorData.value;
};
// 表单
const { formData, resetField, formRef } = useForm<Nilable<MachineDetailType>>({
  creator: null,
  createTime: null,
  levelName: null,
  eqpName: null,
  lotId: null,
  responseDeptName: null,
  verifior: null,
  verifyTime: null,
  eqpStateName: null
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-node',
    render() {
      return h('div', { class: 'card-title col-span-2!' }, i18nt('applyInfo'));
    }
  },
  { type: 'input', model: 'creator', formItemProps: { label: i18nt('creator') }, componentProps: { disabled: true } },
  {
    type: 'input',
    model: 'createTime',
    formItemProps: { label: i18nt('createTime') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'levelName',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: { disabled: true }
  },
  { type: 'input', model: 'lotId', formItemProps: { label: 'Lot ID' }, componentProps: { disabled: true } },
  {
    type: 'input',
    model: 'responseDeptName',
    formItemProps: { label: i18nt('responsibleDepartment') },
    componentProps: { disabled: true }
  },
  { type: 'input', model: 'verifier', formItemProps: { label: i18nt('verifier') }, componentProps: { disabled: true } },
  {
    type: 'input',
    model: 'verifyTime',
    formItemProps: { label: i18nt('verifyTime') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'eqpStateName',
    formItemProps: { label: i18nt('equipmentState') },
    componentProps: { disabled: true }
  }
]);
// 改机信息
const changeMachineInfoTableColumns: DataTableColumns<ChangeMachineInfoListType> = [
  { key: 'type' },
  { title: i18nt('from'), key: 'from' },
  { title: i18nt('convertTo'), key: 'to' }
];
// 改机列表
const changeMachineInfoList = ref<ChangeMachineInfoListType[]>([]);
const tagStateType: { [keys in number]: string } = {
  1: 'success',
  0: 'error'
};
const tagStateText: { [keys in number]: string } = {
  1: 'Pass',
  0: 'Fail'
};
// 操作记录
const tableColumns: DataTableColumns<OperateRecordListType> = [
  {
    title: i18nt('index'),
    key: 'index',
    titleColSpan: 2,
    colSpan: () => 2,
    ellipsis: {
      tooltip: true
    },
    width: TABLE_WIDTH_INDEX,
    render: (rowData, rowIndex) => <span>{rowIndex + 1}</span>
  },
  {
    type: 'expand',
    expandable: () => true,
    renderExpand: rowData => {
      return (
        <div class="px py">
          {/* 上表格类型 */}
          <div class="card-title">
            {i18nt(rowData.formType || '')}
            <base-tag class="ml" type={tagStateType[rowData.fromResult || 0]}>
              {tagStateText[rowData.fromResult || 0]}
            </base-tag>
          </div>
          {/* 上表格类型 */}
          {rowData.typeTableData && rowData.typeTableData.length !== 0 ? (
            <>
              <h4>Check After Repair and Power On/修理后或重新开机后确认</h4>
              <base-table columns={typeTableColumns} data={rowData?.typeTableData} default-expand-all />
            </>
          ) : (
            __
          )}
          {/* 上表格名称 */}
          {rowData.nameTableData && rowData.nameTableData.length !== 0 ? (
            <>
              <div class="card-title mt">checkList</div>
              <h4>Machine Confirmation Check After Adjustment / 机器调整后确认状况</h4>
              <base-table columns={nameTableDataColumns} data={rowData?.nameTableData} default-expand-all />
            </>
          ) : (
            __
          )}
          {/* 下表格 */}
          {rowData.goldSampleTableData && rowData?.goldSampleTableData.length !== 0 ? (
            <base-table
              class="mt"
              columns={rowData?.goldSampleTableColumns}
              data={rowData?.goldSampleTableData}
              default-expand-all
              scroll-x={rowData?.goldSampleTableScroll}
            />
          ) : (
            __
          )}
        </div>
      );
    }
  },
  { title: i18nt('operator'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('operateTime'), key: 'operateTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('state'), key: 'eqpStateName' },
  { title: i18nt('remark'), key: 'remark' },
  {
    title: i18nt('action'),
    key: 'actionType',
    width: TABLE_WIDTH_INFO,
    render: rowData => {
      return (
        <base-tag onClick={() => tableRowClick(rowData)} type={rowData.conEFormId ? 'primary' : 'default'}>
          {i18nt(rowData.operateType)}
        </base-tag>
      );
    }
  }
];
// 操作记录详情
const sampleNum = ref<number>(0);
const { execute: executeGetEFormHisApi } = useAxiosGet<FormItemListType>(
  ChangeMachineOrderApis.getOperateRecordDetailApi
);
const tableRowClick = async (row: OperateRecordListType) => {
  if (!row.conEFormId) return;
  const index = expandedList.value.findIndex(ele => ele === row.id);
  if (index === -1) {
    const { data } = await executeGetEFormHisApi({ params: { conEFormId: row.conEFormId } });
    if (!data.value) return;
    expandedList.value = [row.id];
    row.formType = data.value.formType;
    row.fromResult = data.value.fromResult;
    sampleNum.value = data.value.sampleNum;
    // 上表格类型
    row.typeTableData = handleTableData(data.value.itemList);
    // 上表格名称
    row.nameTableData = handleTableData(data.value.itemList, true);
    //  下表格操作
    const itemList = data.value.itemList.filter((item: ItemListType) => item.belongTo === ItemListBelongTo.goldSample);
    row.goldSampleTableData = handleTableColSpanBackfill(itemList, data.value);
    row.goldSampleTableScroll = data.value.testNum * 120 + 720;
    row.goldSampleTableColumns = goldSampleTableColumnsOld.value.concat(
      handleTableColumns(data.value)
    ) as DataTableColumns<ItemListType>;
  } else {
    expandedList.value[index] = '';
  }
};
// 操作记录展开
const expandedList = ref<string[]>([]);
// 上表格类型
const typeTableColumns: DataTableColumns<ItemListType> = [
  { title: i18nt('checkItemName'), key: 'itemName' },
  {
    title: i18nt('checkItemResult'),
    key: 'itemValue',
    render: row => {
      return row.attachmentFile ? <img class="w-30px h-30px" src={row.attachmentFile} /> : <span>{row.itemValue}</span>;
    }
  }
];
// 上表格名称
const nameTableDataColumns: DataTableColumns<ItemListType> = [
  { title: i18nt('equipmentShutdownTypeRepairManage'), key: 'itemName' },
  {
    title: i18nt('checkItemResult'),
    key: 'itemValue',
    render: row => <span>{row.itemValue === '1' ? i18nt('checked') : i18nt('notChecked')}</span>
  },
  {
    title: 'Visual',
    key: 'remark',
    align: 'center',
    children: [
      { title: 'Ball', align: 'center', key: 'Ball' },
      { title: 'Stitch', align: 'center', key: 'Stitch' },
      { title: 'Loop', align: 'center', key: 'Loop' }
    ]
  },
  { title: 'Wire Pull & Ball Shear', key: 'WirePullBallShear' }
];
// 下表格
const goldSampleTableColumnsOld = ref<DataTableColumns<ItemListType>>([
  {
    title: i18nt('checkItemName'),
    key: 'itemName',
    width: 120,
    rowSpan: (rowData, rowIndex) => (rowIndex % (sampleNum.value || 1) === 0 ? sampleNum.value || 1 : 1)
  },
  {
    title: i18nt('unit'),
    key: 'unit',
    rowSpan: (rowData, rowIndex) => (rowIndex % (sampleNum.value || 1) === 0 ? sampleNum.value || 1 : 1)
  },
  {
    title: i18nt('method'),
    key: 'standard',
    rowSpan: (rowData, rowIndex) => (rowIndex % (sampleNum.value || 1) === 0 ? sampleNum.value || 1 : 1)
  },
  // 下限
  {
    title: i18nt('standardLowerLimit'),
    key: 'lowLimit'
  },
  // 上限
  {
    title: i18nt('standardUpperLimit'),
    key: 'highLimit'
  },
  // 样品
  {
    title: i18nt('sample'),
    key: 'sampleNo',
    render: row => <span>{row.sampleNo ?? 1}</span>
  }
]);
// 审核/接手/转手
const verifierFormRef = ref();
// 设备接收
const equipmentReceiveFormRef = ref();
// 按钮权限
const operateButtonPermissionList = [
  {
    key: 'isBtnVerify',
    text: 'review',
    click: () => {
      expandedList.value = [];
      verifierFormRef.value?.handleOpenModal(formData.value, 'isBtnVerify');
    }
  },
  {
    key: 'isBtnTakeOver',
    text: 'takeOver',
    click: () => {
      expandedList.value = [];
      verifierFormRef.value?.handleOpenModal(formData.value, 'isBtnTakeOver');
    }
  },
  {
    key: 'isBtnHandOver',
    text: 'changedHand',
    click: () => {
      expandedList.value = [];
      verifierFormRef.value?.handleOpenModal(formData.value, 'isBtnHandOver');
    }
  },
  {
    key: 'isBtnParmConfirm',
    text: 'changeMachineConfirm',
    click: () => {
      expandedList.value = [];
      equipmentReceiveFormRef.value?.handleOpenModal(formData.value, 'isBtnParmConfirm');
    }
  },
  {
    key: 'isBtnQCConfirm',
    text: 'qcConfirm',
    click: () => {
      expandedList.value = [];
      equipmentReceiveFormRef.value?.handleOpenModal(formData.value, 'isBtnQCConfirm');
    }
  },
  {
    key: 'isBtnEqpReceive',
    text: 'equipmentReceive',
    click: () => {
      expandedList.value = [];
      equipmentReceiveFormRef.value?.handleOpenModal(formData.value, 'isBtnEqpReceive');
    }
  }
];
// 验证是否拥有按钮权限
const verifyButton = (text: string) => {
  if (!currentRoutePowers.value) return;
  return currentRoutePowers.value.findIndex(ele => ele === text) !== -1;
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  expandedList.value = [];
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
  emit('areset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="$t('viewDetail')"
    :positive-text="__"
    :negative-text="__"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
  >
    <div class="h-full overflow-auto">
      <base-spin :show="isLoadingCurrentEditData">
        <base-form ref="formRef" v-model="formData" disabled layout="dialog" :schemas="formSchemas" />
      </base-spin>
      <div class="card-title">{{ $t('changeMachineInfo') }}</div>
      <base-table
        :loading="isLoadingCurrentEditData"
        :columns="changeMachineInfoTableColumns"
        :data="changeMachineInfoList"
      />
      <div class="card-title mt">{{ $t('operateRecord') }}</div>
      <base-table
        :loading="isLoadingOperateRecordList"
        :expanded-row-keys="expandedList"
        :columns="tableColumns"
        :data="operateRecordList"
      />
    </div>
    <template #action>
      <div v-if="negativeIsShow" class="flex justify-between w-full">
        <div>
          <template v-for="item in operateButtonPermissionList" :key="item.key">
            <base-button
              v-if="formData?.[item.key as keyof MachineDetailType] && verifyButton(item.text)"
              class="mr"
              :size="componentSize"
              type="primary"
              :button-name="item.text"
              @click="item.click()"
            >
              {{ $t(item.text) }}
            </base-button>
          </template>
        </div>
      </div>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">
        {{ $t('cancel') }}
      </base-button>
    </template>
    <!-- 审核/接手/转手 -->
    <verifierForm ref="verifierFormRef" @reset-from="resetFrom" />
    <!-- 改机确认/QC确认/ 设备接收 -->
    <equipmentReceiveForm ref="equipmentReceiveFormRef" @reset-from="resetFrom" />
  </base-modal>
</template>
