<script setup lang="tsx">
import type { VerifyType } from '@/service/apis/assembly/production-manage/repair-manage';
import { ChangeMachineOrderApis } from '@/service/apis/assembly/production-manage/change-machine-order';

const emit = defineEmits<{
  'reset-from': [];
}>();

// 接口设置
const modalUrl = ref<string>('');
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
// 获取后一状态列表
const { isLoading: isLoadingNextStateList, execute: executeGetNextStateList } = useAxiosGet<OptionsType[]>(
  ChangeMachineOrderApis.getNextStateListApi
);
const nextStateList = ref<OptionsType[]>([]);
const handleList: { [key: string]: () => void } = {
  isBtnVerify: () => {
    modalTitle.value = i18nt('review');
    modalUrl.value = ChangeMachineOrderApis.executeReviewApi;
  },
  isBtnTakeOver: () => {
    modalTitle.value = i18nt('takeOver');
    modalUrl.value = ChangeMachineOrderApis.executeTakeOverApi;
  },
  isBtnHandOver: () => {
    modalTitle.value = i18nt('changedHand');
    modalUrl.value = ChangeMachineOrderApis.handOverApi;
  }
};
//  打开弹窗
const handleOpenModal = async (detailFormRow: VerifyType, nameType: string) => {
  handleList[nameType as string]();
  const { data } = await executeGetNextStateList({
    params: { eqpId: detailFormRow.eqpId, check: 0 }
  });

  if (!data.value) return;
  nextStateList.value = data.value;
  formData.value = detailFormRow;
  if (nextStateList.value.length === 1) {
    formData.value.nextEqpStateCode = nextStateList.value[0].id;
  }
  updateField({
    ...formData.value,
    remark: null
  });
  modalIsShow.value = true;
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  formData.value.secondaryTakeover === 0
    ? {
        type: 'select',
        model: 'nextEqpStateCode',
        formItemProps: { label: i18nt('nextState'), rule: useRules('change', i18nt('nextState')) },
        componentProps: {
          loading: isLoadingNextStateList?.value,
          options: nextStateList?.value,
          labelField: 'name',
          valueField: 'id'
        }
      }
    : __,
  useRenderFormTextarea({
    label: i18nt('remark'),
    model: 'remark',
    formItemClass: 'col-span-2!'
  })
]);
const { validate, formData, resetField, formRef, updateField } = useForm<Nullable<VerifyType>>({
  id: null,
  eqpId: null,
  nextEqpStateCode: null,
  remark: null
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    const { id, remark, nextEqpStateCode } = formData.value;
    await saveFormAdd(modalUrl.value, {
      data: {
        id,
        remark,
        nextEqpStateCode
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-from');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="modalTitle"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
  </base-modal>
</template>
