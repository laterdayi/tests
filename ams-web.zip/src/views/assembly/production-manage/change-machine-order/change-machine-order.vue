<script setup lang="tsx">
import addForm from './components/add-form.vue';
import detailForm from './components/detail-form.vue';
import { CommonApis } from '@/service/apis/common/common';
import { ChangeMachineOrderApis } from '@/service/apis/assembly/production-manage/change-machine-order';
import { ChangeMachineState } from '@/service/apis/assembly/production-manage/repair-manage';
import type { QueryType, TableListTypes } from '@/service/apis/assembly/production-manage/repair-manage';

const { currentRoutePowers } = useRoutes();
// 模板引用
const curdRef = ref<CurdRefType<QueryType, TableListTypes>>();
// 新增弹窗
const addFormRef = ref();
// 详情弹窗
const detailFormRef = ref();
//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelApi,
  __,
  { params: { check: 1, isNormal: 1 } },
  {
    immediate: true
  }
);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
handleQueryEquipmentList();
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });
// 搜索栏
const queryFormParams: Nullable<QueryType> = {
  eqpNames: null,
  treeIds: null,
  remark: null,
  state: null,
  timestamp: useFormatDateRange()
};
// 重置搜索栏
const refactorFormQueryParams = (data: QueryType) => ({
  ...data,
  eqpNames: data.eqpNames
    ? data.eqpNames.map(ele => {
      if (multiChildEquipmentList.value) {
        return multiChildEquipmentList.value.find(ele1 => ele1.id === ele)?.name;
      }
      return null;
    })
    : null,
  ...useFormatDateTimeParams(data.timestamp)
});
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        if (curdRef?.value?.queryFormData) curdRef.value.queryFormData.eqpNames = [];
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
            params: { layoutIds: value }
          })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpNames',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'id'
    }
  },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('state') },
    componentProps: {
      options: [
        {
          id: 1,
          name: i18nt('ConversionOperateStateEnum_NotVerify')
        },
        {
          id: 2,
          name: i18nt('ConversionOperateStateEnum_WaitTakeOver')
        },
        {
          id: 3,
          name: i18nt('ConversionOperateStateEnum_WaitHandle')
        },
        {
          id: 4,
          name: i18nt('ConversionOperateStateEnum_ConversionEnd')
        },
        {
          id: 5,
          name: i18nt('ConversionOperateStateEnum_WaitEqpReceive')
        }
      ],
      labelField: 'name',
      valueField: 'id'
    }
  },
  { type: 'input', model: 'remark', formItemProps: { label: i18nt('remark') } },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('changeMachineTime') },
    componentProps: { type: 'datetimerange' }
  }
]);
// 列表
const curdRefPagination = computed(() => curdRef.value?.pagination);

const tableColumns: DataTableColumns<TableListTypes> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('workOrderNumber'),
    key: 'conversionFormNo',
    sorter: true,
    width: TABLE_WIDTH_NAME,
    render: rowData => {
      return rowData.conversionState !== ChangeMachineState.changeMachineComplete
        ? useRenderTableTitleEdit(
          rowData.conversionFormNo,
          () => detailFormRef.value?.handleOpenModal(rowData, false, currentRoutePowers.value)
        )
        : h('span', rowData.conversionFormNo);
    }
  },
  {
    title: i18nt('state'),
    key: 'stateStr',
    render(rowData) {
      const types: { [key: number]: string } = {
        [ChangeMachineState.awaitReview]: TagState.warning,
        [ChangeMachineState.awaitTakeOver]: TagState.default,
        [ChangeMachineState.awaitDispose]: TagState.primary,
        [ChangeMachineState.changeMachineComplete]: TagState.success,
        [ChangeMachineState.awaitEquipmentReceive]: TagState.success
      };
      return useRenderTableSingleTag(types[rowData.conversionState] as TagStateType, i18nt(rowData.conversionStateStr));
    },
    width: TABLE_WIDTH_STATE
  },
  { title: i18nt('equipmentNumber'), key: 'eqpName', sorter: true },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('verifier'), key: 'verifier', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('verifyTime'), key: 'verifyTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('currentResponsiblePerson'), key: 'responser', width: TABLE_WIDTH_NAME },
  { title: i18nt('currentResponsibleDepartment'), key: 'responseDeptName' },
  { title: i18nt('receiverOfEquipment'), key: 'eqpReceiver', width: TABLE_WIDTH_NAME },
  { title: i18nt('receiptTime'), key: 'eqpReceiveTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('remark'), key: 'remark', width: TABLE_WIDTH_INFO },
  { title: i18nt('totalDisposeTime'), key: 'totalDealTime', width: TABLE_WIDTH_DATETIME },
  useRenderTableActionColumn({
    render: rowData =>
      useRenderTableFixedButton('viewDetail', {
        onClick: () => detailFormRef.value?.handleOpenModal(rowData, false, [])
      })
  })
];
// 按钮权限控制
const formDisableCondition = computed(() => {
  const selectedRows = curdRef?.value?.tableRef?.selectedRows;
  const { conversionState } = selectedRows?.at(0) ?? {};
  return {
    edit: selectedRows?.length !== 1 || conversionState !== ChangeMachineState.awaitReview,
    delete: selectedRows?.length !== 1 || conversionState !== ChangeMachineState.awaitReview,
    abolitionAndRestructuring:
      selectedRows?.length !== 1 || conversionState === ChangeMachineState.changeMachineComplete
  };
});
// 操作按钮;
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    add: () => addFormRef.value?.handleOpenModal(null),
    edit: () => addFormRef.value?.handleOpenModal(curdRef?.value?.tableRef?.selectedKeys[0]),
    abolitionAndRestructuring: () => {
      $dialog.warning({
        content: i18nt('whether') + i18nt('abolitionAndRestructuring'),
        onPositiveClick: async () => {
          try {
            const { execute: saveFormAdd } = useAxiosPost(ChangeMachineOrderApis.abandonConversionApi);
            await saveFormAdd({
              data: { id: curdRef?.value?.tableRef?.selectedKeys[0] }
            });
            resetTable();
          } catch (error) {
            console.log(error);
            return false;
          }
        }
      });
      console.log(curdRef?.value?.tableRef?.selectedKeys[0]);
    }
  };
  if (permissionAction[permission]) permissionAction[permission]();
};
// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="change-machine-order">
    <base-curd
ref="curdRef" :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL }" params-serializer-query
      :query-form-params="queryFormParams" :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams" :columns="tableColumns" :ignore-form-permission-list="[
        'review',
        'takeOver',
        'changedHand',
        'changeMachineConfirm',
        'qcConfirm',
        'equipmentReceive'
      ]" :form-permission-disable="formDisableCondition" modal-title="changeMachine"
      :read-api="ChangeMachineOrderApis.getChangeMachineListApi"
      :delete-api="ChangeMachineOrderApis.deleteChangeMachineApi"
      :export-api="ChangeMachineOrderApis.getChangeMachineListApi" @handle="handlePermission"
/>
    <!-- 新增报修 -->
    <addForm ref="addFormRef" @reset-table="resetTable" />
    <!-- 查看详情 -->
    <detailForm ref="detailFormRef" @reset-table="resetTable" />
  </div>
</template>
