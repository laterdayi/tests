<template>
  <div id="system-config" />
</template>
