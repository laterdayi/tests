<script lang="ts">
import { OutputReportSettingApis } from '@/service/apis/assembly/basic-config/output-report-setting';

interface QueryType {
  key?: string
}
interface EditType {
  reportInterval: string
  reportTime: string
  shift: string
  reportType: string
}

interface TableListType {
  id: string
  createTime: string
  creator: string
  editTime: string
  editor: string
  reportInterval: number
  reportTime: string
  reportType: string
  shift: string
}

// 初始化查询表单
const initQueryFormSchemas = (): FormSchemaType => [
  { type: 'input', model: 'key', formItemProps: { label: i18nt('keyword') } }
];

const initFormSchemas = (
  curdRef: CurdRefType<QueryType, EditType, TableListType> | undefined,
  outputTypeList: OptionsType[] | undefined,
  isLoadingOutputTypeList: boolean
): FormSchemaType => [
  {
    type: 'select',
    model: 'reportType',
    formItemProps: { label: i18nt('type'), rule: useRules('change', i18nt('type')) },
    componentProps: computed(() => ({
      options: outputTypeList?.map(item => ({ label: i18nt(item.name), value: item.id })),
      loading: isLoadingOutputTypeList
    }))
  },
  {
    type: 'input-number',
    model: 'reportInterval',
    formItemProps: {
      label: i18nt('frequencyMillisecond'),
      rule: [
        useRules('input-number', 'onlyPositiveIntZeroRule', { required: true, message: i18nt('frequencyMillisecond') }),
        useRuleNumberLength()
      ]
    }
  },
  curdRef?.formData?.reportType === '1'
    ? {
        type: 'input',
        model: 'shift',
        formItemProps: { label: i18nt('shift'), rule: [useRules('input', i18nt('shift')), useRuleStringLength()] }
      }
    : __,
  curdRef?.formData?.reportType === '1'
    ? {
        type: 'time-picker',
        model: 'reportTime',
        modelValue: 'formatted-value',
        formItemProps: { label: i18nt('time'), rule: { ...useRules('change', i18nt('time')) } }
      }
    : __
];

const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  curdRef: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('type'),
    width: TABLE_WIDTH_INFO,
    key: 'reportType',
    sorter: true,
    render: rowData =>
      useRenderTableTitleEdit(
        rowData.reportType,
        () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title),
        { translate: true }
      )
  },
  { title: i18nt('time'), key: 'reportTime', sorter: true, width: TABLE_WIDTH_DATE },
  { title: i18nt('shift'), key: 'shift', sorter: true, width: TABLE_WIDTH_STATE },
  { title: i18nt('frequencyMillisecond'), key: 'reportInterval', sorter: true },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('modifier'), key: 'editor', width: TABLE_WIDTH_NAME },
  { title: i18nt('modifyTime'), key: 'editTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];
</script>

<script setup lang="ts">
// 获取产量类型列表
const {
  data: outputTypeList,
  execute: executeGetOutputTypeList,
  isLoading: isLoadingOutputTypeList
} = useAxiosGet<OptionsType[]>(OutputReportSettingApis.getOutputTypeListApi);

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
// 查询表单模型
const queryFormSchemas = initQueryFormSchemas();
const queryFormParams: Nullable<QueryType> = { key: null };
const curdRefPagination = computed(() => curdRef.value?.pagination);
const formParams = { reportInterval: null, reportTime: null, reportType: '1', shift: null };
const formSchemas = computed(() => initFormSchemas(curdRef.value, outputTypeList.value, isLoadingOutputTypeList.value));
const tableColumns = createColumns(curdRefPagination, curdRef);

watch(
  () => curdRef.value?.formData?.reportType,
  val => curdRef.value?.formData && (curdRef.value.formData.reportTime = val === '1' ? useFormatTime() : null)
);

// 查询所有列表
const queryAllSelectList = () => executeGetOutputTypeList();

const handleAddBefore = () => {
  curdRef.value?.formData && (curdRef.value.formData.reportTime = useFormatTime());
  queryAllSelectList();
};
</script>

<template>
  <div id="output-report">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :create-api="OutputReportSettingApis.createOutputReportApi"
      :update-api="OutputReportSettingApis.updateOutputApi"
      :read-api="OutputReportSettingApis.getOutputListApi"
      :delete-api="OutputReportSettingApis.deleteOutputApi"
      :edit-detail-api="OutputReportSettingApis.getOutputDetailApi"
      modal-title="outputReport"
      @before-open-add-modal="handleAddBefore"
      @before-open-edit-modal="queryAllSelectList"
    />
  </div>
</template>
