<script lang="ts">
import { StateStandardDefinitionApis } from '@/service/apis/assembly/basic-config/state-standard-definition';

interface QueryType {
  statusName: null;
  description: null;
}
interface EditType {
  id?: string;
  eapEventList: string[];
  description: string;
  mesStatus: string;
  parentCode: string;
  sort: string;
  statusName: string;
  statusCode: string;
  statusColor: string;
  timeRateCategory: string;
  switchableRoleList: string[];
  visibleRoleList: string[];
}

interface TableListType {
  id: string;
  createTime: string;
  creator: string;
  description: string;
  eapStatusStr: string;
  mesStatus: string;
  nextStatusId: string;
  parentName: string;
  preStatusId: string;
  statusColor: string;
  statusName: string;
  timeRateCategory: string;
  statusCode: string;
  visibleRoleList: string[];
  switchableRoleList: string[];
}

interface StateInfoType {
  code: string;
  description: string;
  parentCode: string;
  statusName: string;
}

interface AssociateSettingType {
  id: string;
  nextStatusCodeList: string[];
  parentStatusStr: string;
  preStatusCodeList: string[];
  secStatusStr: string;
  statusCode: string;
}

// 初始化查询表单
const initQueryFormSchemas = (): FormSchemaType => [
  { type: 'input', model: 'statusName', formItemProps: { label: i18nt('stateName') } },
  { type: 'input', model: 'description', formItemProps: { label: i18nt('description') } }
];

const initFormSchemas = (
  executeGetStateNameList: ExecuteFunctionType<OptionsType[]>,
  executeGetStateInfoData: ExecuteFunctionType<StateInfoType>,
  curdRef?: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>,
  parentStateList?: Ref<OptionsType[] | undefined>,
  isLoadingParentState?: Ref<boolean>,
  eapEventList?: Ref<OptionsType[] | undefined>,
  isLoadingEapEventList?: Ref<boolean>,
  timeGrainClassifyList?: Ref<OptionsType[] | undefined>,
  isLoadingTimeGrainClassifyList?: Ref<boolean>,
  stateNameList?: Ref<OptionsType[] | undefined>,
  isLoadingStateName?: Ref<boolean>,
  isLoadingtStateInfoData?: Ref<boolean>,
  roleList?: Ref<OptionsType[] | undefined>,
  isLoadingRoleList?: Ref<boolean>
): FormSchemaType => [
  {
    type: 'select',
    model: 'parentCode',
    formItemProps: { label: i18nt('parentState'), rule: useRules('change', i18nt('parentState')) },
    componentProps: computed(() => ({
      disabled: curdRef?.value?.isEditMode,
      options: parentStateList?.value,
      loading: isLoadingParentState?.value,
      labelField: 'name',
      valueField: 'id',
      onUpdateValue: (value: (string | number | null)[]) => {
        const formData = curdRef?.value?.formData;
        if (formData) {
          [formData.statusCode, formData.statusName, formData.description] = [null, null, null];
        }
        if (!value) return;
        executeGetStateNameList(__, { params: { parentStatusCode: value } });
      }
    }))
  },
  {
    type: 'select',
    model: 'statusName',
    formItemProps: {
      label: i18nt('stateName'),
      rule: [useRules('change', i18nt('stateName')), useRuleStringLength(0, 100)]
    },
    componentProps: computed(() => ({
      options: stateNameList?.value,
      loading: isLoadingStateName?.value || isLoadingParentState?.value,
      labelField: 'name',
      valueField: 'id',
      disabled: curdRef?.value?.isEditMode,
      onUpdateValue: async (value: (string | number | null)[]) => {
        try {
          const formData = curdRef?.value?.formData;
          if (formData) {
            [formData.statusCode, formData.description] = [null, null];
          }
          if (!value) return;
          const { data } = await executeGetStateInfoData(__, { params: { statusCode: value } });
          if (data.value && formData) {
            formData.statusCode = data.value.code;
            formData.description = data.value.description;
          }
        } catch (error) {
          console.log('状态代码异常：', error);
        }
      }
    }))
  },
  {
    type: 'input',
    model: 'statusCode',
    formItemProps: { label: i18nt('stateCode'), rule: useRules('input', i18nt('stateCode')) },
    componentProps: computed(() => ({
      disabled: true,
      loading: isLoadingtStateInfoData?.value
    }))
  },
  {
    type: 'select',
    model: 'eapEventList',
    formItemProps: { label: 'EAP Event' },
    componentProps: computed(() => ({
      options: eapEventList?.value,
      loading: isLoadingEapEventList?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }))
  },
  {
    type: 'select',
    model: 'timeRateCategory',
    formItemProps: { label: i18nt('timeGrainClassify') },
    componentProps: computed(() => ({
      options: timeGrainClassifyList?.value,
      loading: isLoadingTimeGrainClassifyList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  { type: 'color-picker', model: 'statusColor', formItemProps: { label: i18nt('backgroundColor') } },
  {
    type: 'input',
    model: 'mesStatus',
    formItemProps: { label: i18nt('mesState'), rule: useRuleStringLength() }
  },
  {
    type: 'select',
    model: 'visibleRoleList',
    formItemProps: { label: i18nt('visibleRole') },
    componentProps: computed(() => ({
      options: roleList?.value,
      loading: isLoadingRoleList?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }))
  },
  {
    type: 'select',
    model: 'switchableRoleList',
    formItemProps: { label: i18nt('switchRole') },
    componentProps: computed(() => ({
      options: roleList?.value,
      loading: isLoadingRoleList?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }))
  },
  {
    type: 'input',
    model: 'description',
    formItemProps: { label: i18nt('description') },
    componentProps: computed<BaseForm.Schema.ComponentPropsType['input']>(() => ({
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true,
      type: 'textarea'
    }))
  }
];

const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  curdRef: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('stateCode'),
    key: 'statusCode',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render: rowData =>
      useRenderTableTitleEdit(rowData.statusCode, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  { title: i18nt('parentState'), key: 'parentName' },
  { title: i18nt('stateName'), key: 'statusName', sorter: true },
  { title: i18nt('description'), key: 'description' },
  {
    title: i18nt('backgroundColor'),
    key: 'statusColor',
    ellipsis: false,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return h('div', { class: 'w-full h-20px ', style: { backgroundColor: rowData.statusColor } });
    }
  },
  { title: 'EAP Event', key: 'eapEventList', ...useRenderTableMultiTag('eapEventList') },
  { title: i18nt('mesState'), key: 'mesStatus' },
  {
    title: i18nt('visibleRole'),
    key: 'visibleRoleList',
    ...useRenderTableMultiTag('visibleRoleList')
  },
  {
    title: i18nt('switchRole'),
    key: 'switchableRoleList',
    ...useRenderTableMultiTag('switchableRoleList')
  },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];

const initAssociateFormSchemas = (
  associateStateList: Ref<OptionsType[] | undefined>,
  isLoadingAssociateStateList: Ref<boolean>
): FormSchemaType => [
  {
    type: 'input',
    model: 'parentStatusStr',
    formItemProps: { label: i18nt('currentLevelOneState') },
    componentProps: { disabled: true }
  },
  {
    type: 'input',
    model: 'secStatusStr',
    formItemProps: { label: i18nt('currentLeveTwoState') },
    componentProps: { disabled: true }
  },
  {
    type: 'select',
    model: 'preStatusCodeList',
    formItemProps: { label: i18nt('prevState') },
    componentProps: computed(() => ({
      options: associateStateList.value,
      loading: isLoadingAssociateStateList?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }))
  },
  {
    type: 'select',
    model: 'nextStatusCodeList',
    formItemProps: { label: i18nt('nextState'), rule: { ...useRules('change', i18nt('nextState')), type: 'array' } },
    componentProps: computed(() => ({
      options: associateStateList.value,
      loading: isLoadingAssociateStateList?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }))
  }
];
</script>

<script setup lang="ts">
// 获取父级状态列表
const {
  data: parentStateList,
  execute: executeGetParentStateList,
  isLoading: isLoadingParentState
} = useAxiosGet<OptionsType[]>(StateStandardDefinitionApis.getParentStateListApi);

// 获取状态名称列表
const {
  data: stateNameList,
  execute: executeGetStateNameList,
  isLoading: isLoadingStateNameList
} = useAxiosGet<OptionsType[]>(StateStandardDefinitionApis.getStateNameListApi);

// 获取角色列表
const {
  data: roleList,
  execute: executeGetRoleList,
  isLoading: isLoadingRoleList
} = useAxiosGet<OptionsType[]>(StateStandardDefinitionApis.getRoleListApi);

// 获取状态信息
const { execute: executeGetStateInfoData, isLoading: isLoadingtStateInfoData } = useAxiosGet<StateInfoType>(
  StateStandardDefinitionApis.getStateInfoListApi
);

// 获取EAP事件
const {
  data: eapEventList,
  execute: executeGetEapEventList,
  isLoading: isLoadingEapEventList
} = useAxiosGet<OptionsType[]>(StateStandardDefinitionApis.getEapEventListApi);

// 获取时间稼动分类
const {
  data: timeGrainClassifyList,
  execute: executeGetTimeGrainClassify,
  isLoading: isLoadingTimeGrainClassifyList
} = useAxiosGet<OptionsType[]>(StateStandardDefinitionApis.getTimeGrainClassifyListApi);

// 查询所有列表
const queryAllSelectList = () => (
  executeGetParentStateList(), executeGetEapEventList(), executeGetTimeGrainClassify(), executeGetRoleList()
);

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
// 查询表单模型
const queryFormSchemas = initQueryFormSchemas();
const queryFormParams: Nullable<QueryType> = {
  statusName: null,
  description: null
};
const curdRefPagination = computed(() => curdRef.value?.pagination);
const formParams: Nullable<EditType> = {
  eapEventList: null,
  description: null,
  mesStatus: null,
  parentCode: null,
  sort: null,
  statusName: null,
  statusCode: null,
  statusColor: null,
  timeRateCategory: null,
  visibleRoleList: null,
  switchableRoleList: null
};
const formSchemas = initFormSchemas(
  executeGetStateNameList,
  executeGetStateInfoData,
  curdRef,
  parentStateList,
  isLoadingParentState,
  eapEventList,
  isLoadingEapEventList,
  timeGrainClassifyList,
  isLoadingTimeGrainClassifyList,
  stateNameList,
  isLoadingStateNameList,
  isLoadingtStateInfoData,
  roleList,
  isLoadingRoleList
);

const tableColumns = createColumns(curdRefPagination, curdRef);

const refactorFormSubmitParams = (data: EditType): Nilable<EditType> & { parentName?: string } => {
  return {
    ...data,
    parentName: find(parentStateList.value, v => v.id === data.parentCode)?.name,
    statusName: find(stateNameList.value, v => v.id === data.statusCode)?.name
  };
};

// 关联设置

// 获取关联数据
const { execute: executeGetAssociateInfoData, data: associateInfoData } = useAxiosGet<AssociateSettingType>(
  StateStandardDefinitionApis.getAssociateInfoDataApi
);
const handleQueryAssociateInfoData = async () => {
  try {
    const { data } = await executeGetAssociateInfoData(__, {
      params: { statusCode: curdRef.value?.tableRef?.selectedRows?.at(0)?.statusCode }
    });
    data.value && updateAssociateField(data.value);
  } catch (error) {
    console.log('获取关联数据', error);
  }
};

// 获取关联状态列表
const {
  data: associateStateList,
  execute: executeGetAssociateStateList,
  isLoading: isLoadingAssociateStateList
} = useAxiosGet<OptionsType[]>(StateStandardDefinitionApis.getAssociateStateListApi);

const {
  formData: associateFormData,
  resetField: resetAssociateField,
  validate: associateValidate,
  formRef: associateFormRef,
  updateField: updateAssociateField
} = useForm<Nullable<AssociateSettingType>>({
  id: null,
  nextStatusCodeList: null,
  parentStatusStr: null,
  preStatusCodeList: null,
  secStatusStr: null,
  statusCode: null
});

const associateFormSchemas = initAssociateFormSchemas(associateStateList, isLoadingAssociateStateList);

const handleAssociateModalClose = () => {
  closeModal();
  resetAssociateField();
};

const { showModal, openModal, closeModal } = useModal();

// 关联设置提交
const { isLoading: isLoadingCreateAssociateSetting, execute: executeCreateAssociateSetting } = useAxiosPost();
const handleAssociateSubmit = async () => {
  try {
    await associateValidate();
    await executeCreateAssociateSetting(
      associateInfoData.value?.id
        ? StateStandardDefinitionApis.updateAssociateSettingApi
        : StateStandardDefinitionApis.createAssociateSettingApi,
      { data: associateFormData.value }
    );
    handleAssociateModalClose();
  } catch (error) {
    console.log('关联设置异常：', error);
  }
};

// 操作权限
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    associateSetting: () => (openModal(), executeGetAssociateStateList(), handleQueryAssociateInfoData())
  };
  if (permissionAction[permission]) permissionAction[permission]();
};
</script>

<template>
  <div id="state-standard-definition">
    <base-curd
      ref="curdRef"
      :refactor-form-submit-params="refactorFormSubmitParams"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-permission-disable="{ associateSetting: curdRef?.tableRef?.selectedKeys?.length !== 1 }"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :create-api="StateStandardDefinitionApis.createStateDefinitionApi"
      :update-api="StateStandardDefinitionApis.updateStateApi"
      :read-api="StateStandardDefinitionApis.getStateDefinitionListApi"
      :delete-api="StateStandardDefinitionApis.deleteStateApi"
      :edit-detail-api="StateStandardDefinitionApis.getStateDetailApi"
      modal-title="stateStandard"
      @handle="handlePermission"
      @after-open-add-modal="queryAllSelectList"
      @after-open-edit-modal="queryAllSelectList"
      @modal-closed="stateNameList = []"
    />
    <base-modal
      :loading="isLoadingCreateAssociateSetting"
      :title="$t('associateSetting')"
      :show="showModal"
      @after-leave="resetAssociateField"
      @close="closeModal"
      @negative-click="closeModal"
      @positive-click="handleAssociateSubmit"
    >
      <base-form ref="associateFormRef" v-model="associateFormData" :schemas="associateFormSchemas" layout="dialog" />
    </base-modal>
  </div>
</template>
