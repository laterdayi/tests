<script lang="tsx">
import type { PaginationProps } from 'naive-ui';
import { TheoryUphMaintainApis } from '@/service/apis/assembly/basic-config/theory-uph-maintain';
import { CommonApis } from '@/service/apis/common/common';

type ConfigType = '1' | '2' | '3';

interface QueryType {
  treeId: string[];
  eapIds: string[];
  recipe: string;
  uph: string;
}

interface EditType {
  configCategory: ConfigType;
  eqpID: string;
  recipe: string;
  remark: string;
  uph: number;
  id: string;
}

interface TableListType {
  id: string;
  configCategory: string;
  confirmationTimes: string;
  createTime: string;
  createTimeDt: string;
  creator: string;
  editTime: string;
  editTimeDt: string;
  editor: string;
  eqpID: string;
  layoutId: string;
  name: string;
  recipe: string;
  remark: string;
  uph: number;
}

interface TableListLogType {
  id: string;
  businessName: string;
  changeType: string;
  createTime: string;
  creator: string;
  keyId: string;
  new: string;
  old: string;
}

// 初始化查询表单
const initQueryFormSchemas = (
  executeGetEquipmentNumberChildList: ExecuteFunctionType<OptionsType[]>,
  handleQueryEquipmentNumberList: () => Promise<void>,
  productLineList?: OptionsType[],
  isLoadingProductLineList?: boolean,
  equipmentNumberChildList?: OptionsType[],
  isLoadingEquipmentNumberChildList?: boolean,
  curdRef?: CurdRefType<QueryType, EditType, TableListType, EditType>
): FormSchemaType => [
  {
    type: 'tree-select',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList,
      loading: isLoadingProductLineList,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: (value: (string | number | null)[]) => {
        if (curdRef?.queryFormData) curdRef.queryFormData.eapIds = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
              params: { layoutIds: value }
            })
          : handleQueryEquipmentNumberList();
      }
    }
  },
  {
    type: 'select',
    model: 'eapIds',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: equipmentNumberChildList,
      loading: isLoadingEquipmentNumberChildList,
      labelField: 'name',
      valueField: 'name'
    }
  },
  { type: 'input', model: 'recipe', formItemProps: { label: 'Recipe' } },
  { type: 'input', model: 'uph', formItemProps: { label: i18nt('theoryUph') } }
];

// 初始化表单
const initFormSchemas = (
  hasEditPermission?: boolean,
  curdRef?: CurdRefType<QueryType, EditType, TableListType>,
  equipmentNumberList?: OptionsType[],
  isLoadingEquipmentNumberList?: boolean
): FormSchemaType => [
  {
    type: 'select',
    model: 'eqpID',
    formItemProps: { label: i18nt('equipmentNumber'), rule: useRules('change', i18nt('equipmentNumber')) },
    componentProps: computed(() => ({
      loading: isLoadingEquipmentNumberList,
      options: equipmentNumberList,
      labelField: 'name',
      valueField: 'name',
      disabled: curdRef?.isEditMode
    }))
  },
  {
    type: 'input',
    model: 'recipe',
    formItemProps: { label: 'Recipe', rule: [useRules('input', i18nt('recipe')), useRuleStringLength(0, 100)] },
    componentProps: { disabled: curdRef?.isEditMode }
  },
  {
    type: 'input-number',
    model: 'uph',
    formItemProps: {
      label: i18nt('theoryUph'),
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: true, message: i18nt('theoryUph') }),
        useRuleNumberLength()
      ]
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: 'Config' },
    model: 'configCategory',
    render() {
      return curdRef?.formData?.configCategory ? (
        <n-radio-group
          disabled={!hasEditPermission || (curdRef?.tableRef?.selectedKeys?.length ?? 0) > 1}
          v-model:value={curdRef.formData.configCategory}
        >
          <base-radio label="1" value="1" />
          <base-radio label="2" value="2" />
          <base-radio label="3" value="3" />
        </n-radio-group>
      ) : (
        <div />
      );
    }
  },
  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark')
  })
];

const createColumns = (
  pagination: MaybeComputedRef<PaginationProps>,
  curdRef: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>,
  openModal: () => void,
  executeGetLogList: () => Promise<void>,
  handeleCurrentOperateId: (id: string) => string
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('equipmentNumber'),
    key: 'eqpID',
    sorter: true,
    width: TABLE_WIDTH_INFO,
    render: rowData =>
      useRenderTableTitleEdit(rowData.eqpID, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  { title: 'Recipe', key: 'recipe', sorter: true },
  { title: 'Config', key: 'configCategory', sorter: true, width: TABLE_WIDTH_STATE },
  { title: i18nt('theoryUph'), key: 'uph', sorter: true, width: TABLE_WIDTH_INFO },
  { title: i18nt('remark'), key: 'remark' },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('modifier'), key: 'editor', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('modifyTime'), key: 'editTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  useRenderTableActionColumn({
    width: TABLE_WIDTH_STATE,
    render: rowData =>
      useRenderTableFixedButton('modifyRecord', {
        onClick: () => (openModal(), handeleCurrentOperateId(rowData.id), executeGetLogList())
      })
  })
];
// 修改记录列表
const createColumnsLog = (pagination: Ref<PaginationProps>): DataTableColumns<TableListLogType> => [
  useRenderTableIndex(pagination),
  { title: i18nt('tableName'), key: 'businessName', width: TABLE_WIDTH_STATE * 2 },
  {
    title: i18nt('operateType'),
    key: 'changeType',
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      const types: { [key: string]: string } = {
        Update: TagState.warning,
        Insert: TagState.success,
        Delete: TagState.error
      };
      return useRenderTableSingleTag(types[rowData.changeType] as TagStateType, rowData.changeType);
    }
  },
  { title: i18nt('beforeChange'), key: 'old' },
  { title: i18nt('afterChange'), key: 'new' },
  { title: i18nt('operator'), key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME }
];
</script>

<script setup lang="tsx">
// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelApi);
const handleQuery = () => executeGetProductLineList(__, { params: { check: 2, isNormal: 1 } });

// 获取设备编号列表
const {
  data: equipmentNumberList,
  isLoading: isLoadingEquipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};

// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(CommonApis.getEqpsByLayoutIdsApi, undefined, {
  paramsSerializer: useParamsSerializer()
});

tryOnMounted(() => (handleQuery(), handleQueryEquipmentNumberList()));

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();

// 查询表单数据 -> 响应式
const paginationRef = computed(() => curdRef.value?.pagination);

// 查询表单模型
const queryFormSchemas = computed(() =>
  initQueryFormSchemas(
    executeGetEquipmentNumberChildList,
    handleQueryEquipmentNumberList,
    productLineList.value,
    isLoadingProductLineList.value,
    equipmentNumberChildList.value,
    isLoadingEquipmentNumberChildList.value,
    curdRef.value
  )
);

// 查询表单参数
const queryFormParams: Nullable<QueryType> = {
  treeId: null,
  eapIds: null,
  recipe: null,
  uph: null
};
const { hasEditPermission } = useRoutes();
// 表单模型
const formSchemas = computed(() =>
  initFormSchemas(hasEditPermission.value, curdRef.value, equipmentNumberList.value, isLoadingEquipmentNumberList.value)
);
// 表单参数
const formParams = {
  configCategory: '1',
  eqpID: null,
  recipe: null,
  remark: null,
  uph: null
};

// 查询所有列表
const queryAllSelectList = () => executeGetEquipmentNumberList();

const refactorFormSubmitParams = (data: EditType) => {
  const selectedKeys = curdRef?.value?.tableRef?.selectedKeys;
  return {
    ...data,
    ids: curdRef?.value?.openEditModalEntry === EditModalEntry.button ? selectedKeys : [data.id]
  };
};

// -------------------------------------------------------------------------------------------- > 修改记录
const { showModal, openModal, closeModal } = useModal();
const currentOperateId = ref('');
const handeleCurrentOperateId = (id: string) => (currentOperateId.value = id);
const { pagination, isLoadingQuery, tableData, executeQueryList, handleResetPageSize } = useTable<TableListLogType[]>(
  TheoryUphMaintainApis.modifyRecordApi,
  {
    refactorFormQueryParams: data => ({ ...data, key: currentOperateId.value, tableName: 'UPHSettingEntity' })
  }
);
const tableColumnsLog = createColumnsLog(pagination);

const tableColumns = createColumns(paginationRef, curdRef, openModal, executeQueryList, handeleCurrentOperateId);
</script>

<template>
  <div id="theory-uph-maintain">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :form-permission-disable="{ edit: curdRef?.tableRef?.selectedKeys.length === 0 }"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :create-api="TheoryUphMaintainApis.createUphMaintainApi"
      :update-api="TheoryUphMaintainApis.updateUphMaintainApi"
      :read-api="TheoryUphMaintainApis.getUphMaintainListApi"
      :delete-api="TheoryUphMaintainApis.deleteUphMaintainApi"
      :edit-detail-api="TheoryUphMaintainApis.getUphMaintainDetailApi"
      :export-api="TheoryUphMaintainApis.getUphMaintainListApi"
      :download-api="TheoryUphMaintainApis.downloadUphMaintainApi"
      :import-api="TheoryUphMaintainApis.importUphMaintainApi"
      :refactor-form-submit-params="refactorFormSubmitParams"
      modal-title="theoryUph"
      @after-open-add-modal="queryAllSelectList"
      @after-open-edit-modal="queryAllSelectList"
    />
    <base-modal
      :show="showModal"
      :positive-text="undefined"
      :title="$t('modifyRecord')"
      @negative-click="closeModal"
      @close="closeModal(), handleResetPageSize(), (tableData = [])"
      @after-leave="handleResetPageSize(), (tableData = [])"
    >
      <base-table
        remote
        :pagination="pagination"
        :data="tableData"
        :columns="tableColumnsLog"
        :loading="isLoadingQuery"
      />
    </base-modal>
  </div>
</template>
