<script setup lang="ts">
import type { AlarmStatisticsDataType } from './constants';
import type { ECOption } from '@/plugins/core/echarts';
import { AlarmHomeApis } from '@/service/apis/ams/alarm-home';
import { AMSCommonApis } from '@/service/apis/ams/common';

interface AlarmProps {
  // 今日报警次数
  todayAlarmCount: number;
  // 进行中
  onGoingCount: number;
  // 已关闭
  closeAlarmCount: number;
  // 报警设备占比
  alarmEqpPercent: number;
  // 近15天报警趋势
  dailyAlarms: { date: string; totalAlarmCount: number }[];
  // 今日设备报警时长
  eqpDurations: { eqpId: string; totalEqpDuration: number }[];
}

const alarmList: { name: keyof Omit<AlarmProps, 'dailyAlarms' | 'eqpDurations'> }[] = [
  { name: 'todayAlarmCount' },
  { name: 'onGoingCount' },
  { name: 'closeAlarmCount' },
  { name: 'alarmEqpPercent' }
];

// 处理图片
const handleImg = (name: string) => {
  return new URL(`../../assets/images/common/${name}`, import.meta.url).href;
};
// 图片列表
const projectObj: Record<string, string> = {
  todayAlarmCount: handleImg('alarm.png'),
  onGoingCount: handleImg('underway.png'),
  closeAlarmCount: handleImg('close.png'),
  alarmEqpPercent: handleImg('proportion.png')
};

const initOptions: ECOption = {
  yAxis: {
    type: 'value',
    name: i18nt('minute'),
    position: 'left',
    alignTicks: true,
    axisLine: {
      show: true
    }
  },
  grid: {
    bottom: 48
  },
  xAxis: {
    type: 'category',
    name: i18nt('equipmentNumber'),
    axisTick: { alignWithLabel: true },
    axisLabel: {
      interval: 0,
      rotate: -15,
      margin: 20
    }
  },
  series: [
    {
      type: 'bar',
      barWidth: BAR_WIDTH_HORIZONTAL,
      label: {
        show: true,
        position: 'top'
      }
    }
  ]
};

function defaultEchartValues(): AlarmProps {
  return {
    todayAlarmCount: 0,
    onGoingCount: 0,
    closeAlarmCount: 0,
    alarmEqpPercent: 0,
    dailyAlarms: [],
    eqpDurations: []
  };
}

const alarmCharts = ref<AlarmProps>(defaultEchartValues());

const { isLoading, execute } = useAxiosGet<AlarmProps>(AlarmHomeApis.getAlarmAnalysisApi, undefined, undefined, {
  immediate: false
});

const fetchData = async () => {
  try {
    const res = await execute();
    alarmCharts.value = res.data.value as AlarmProps;
  } catch (error) {
    alarmCharts.value = defaultEchartValues();
  }
};

// 获取统计信息
const { data: alarmStatisticsData, execute: executeGetStatisticsData } = useAxiosGet<AlarmStatisticsDataType>(
  AMSCommonApis.getAlarmStatisticsDataApi
);

const xAxisEqpDurations = computed(() => alarmCharts.value.eqpDurations.map(v => v.eqpId));
const seriesDataEqpDurations = computed(() => alarmCharts.value.eqpDurations.map(v => v.totalEqpDuration));

const xAxisDailyAlarms = computed(() => alarmCharts.value.dailyAlarms.map(v => v.date));
const seriesDailyAlarms = computed(() => alarmCharts.value.dailyAlarms.map(v => v.totalAlarmCount));

const alarmNums = computed(() => {
  return {
    todayAlarmCount: alarmStatisticsData.value?.totalAlarmCount,
    onGoingCount: alarmStatisticsData.value?.onGoingCount,
    closeAlarmCount: alarmStatisticsData.value?.closeAlarmCount,
    alarmEqpPercent: `${((alarmStatisticsData.value?.alarmEqpPercent ?? 0) * 100).toFixed(1)}%`
  };
});

tryOnMounted(executeGetStatisticsData);

fetchData();
</script>

<template>
  <div id="ams-page">
    <div class="flex flex-wrap">
      <base-card v-for="item in alarmList" :key="item.name" hoverable class="cursor-pointer mb mr w-282px">
        <div class="flex items-center">
          <img :src="projectObj[item.name]" alt="" class="h-68px w-68px" />
          <div>
            <div :class="`text-${light.common.fontSizeHuge}`">
              {{ alarmNums[item.name] }}
            </div>
            <div :class="`text-${light.common.fontSizeHuge}`">
              {{ $t(item.name) }}
            </div>
          </div>
        </div>
      </base-card>
    </div>
    <base-card>
      <base-chart
        title="eqpAlarmDuration"
        title-align="left"
        type="bar"
        :x-axis-data="xAxisEqpDurations"
        :series-data="seriesDataEqpDurations"
        :init-options="initOptions"
        :loading="isLoading"
        class="h-280px!"
      />
    </base-card>
    <base-card class="mt">
      <base-chart
        title="day15Tendency"
        title-align="left"
        type="bar"
        :x-axis-data="xAxisDailyAlarms"
        :series-data="seriesDailyAlarms"
        :init-options="{
          yAxis: {
            type: 'value',
            name: $t('chart.single'),
            position: 'left',
            alignTicks: true,
            axisLine: {
              show: true
            }
          },
          grid: {
            bottom: 30
          },
          xAxis: {
            type: 'category',
            name: i18nt('alarmDate'),
            axisTick: { alignWithLabel: true },
            axisLabel: {
              interval: 0,
              rotate: -15
            }
          },
          series: [
            {
              type: 'bar',
              barWidth: BAR_WIDTH_HORIZONTAL,
              label: {
                show: true,
                position: 'top'
              }
            }
          ]
        }"
        :loading="isLoading"
        class="h-280px!"
      />
    </base-card>
  </div>
</template>

<style lang="less" scoped>
#ams-page {
  width: 100%;
  box-sizing: border-box;
  .eqp-status {
    display: flex;
    .eqp-item {
      width: 300px;
      height: 120px;
      margin-right: 20px;
      display: flex;
      justify-content: flex-end;
      .item-status {
        width: 70%;
        height: 100%;
        font-size: 20px;
        color: #fff;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        word-break: break-all;
        background-color: #f5f5f531;
        .item-num {
          padding-top: 10px;
          font-size: 40px;
        }
      }
    }
    .todayAlarmCount {
      background-color: var(--error-color);
    }
    .onGoingCount {
      background-color: var(--warning-color);
    }
    .closeAlarmCount {
      background-color: var(--success-color);
    }
    .alarmEqpPercent {
      background-color: var(--primary-color);
    }
  }
}
</style>
