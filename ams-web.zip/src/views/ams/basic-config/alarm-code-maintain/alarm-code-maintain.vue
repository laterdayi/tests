<script lang="ts">
import type { PaginationProps } from 'naive-ui';
import { CommonApis } from '@/service/apis/common/common';
import { AlarmCodeMaintainApis } from '@/service/apis/ams/basic-config/alarm-code-maintain';

interface QueryInfoType {
  eqpId: string[]
  alarmId: string
  systemName: string
}

interface AlarmCodeInfo {
  id: number
  eqpId: string
  alarmID: string
  alarmDesc: string
  mtba: string
  isSave: number
  isEqpAlarm: number
  isDeleted: number
  creator: string
  createTime: string
  editor: string
  editTime: string
  projectCode: string
  systemName: string
}

interface EditType {
  eqpId: string
  alarmID: string
  isEqpAlarm: OpenStateType
  alarmDesc: string
  systemName: string
  isNeedClose: number
}

type AlarmCodeListType = AlarmCodeInfo & QueryInfoType;

// 初始化查询表单
const initQueryFormSchemas = (
  equipmentNumberList?: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberList?: Ref<boolean>,
  systemNameList?: Ref<OptionsType[] | undefined>,
  isLoadingSystemNameList?: Ref<boolean>
): FormSchemaType => [
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      multiple: true,
      options: equipmentNumberList?.value,
      loading: isLoadingEquipmentNumberList?.value,
      labelField: 'name',
      valueField: 'name'
    }))
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      loading: isLoadingSystemNameList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: {
      label: i18nt('alarmCode')
    }
  }
];

const initFormSchemas = (
  equipmentNumberList?: OptionsType[] | undefined,
  isLoadingEquipmentNumberList?: boolean,
  systemNameEapList?: OptionsType[] | undefined,
  systemNameNoEapList?: OptionsType[] | undefined,
  isLoadingSystemNameList?: boolean,
  curdRef?: CurdRefType<QueryInfoType, AlarmCodeInfo, AlarmCodeListType>
): FormSchemaType => [
  useRenderFormSwitch({
    key: 'isEqpAlarm',
    label: i18nt('machineAlarm'),
    formItemClass: 'col-span-2!',
    componentProps: {
      disabled: curdRef?.isEditMode,
      onUpdateValue: (value: number) => {
        curdRef?.resetField();
        if (!curdRef?.formData) return;
        curdRef.formData.isEqpAlarm = value;
        if (value) {
          const obj = systemNameEapList?.find(ele => ele.id === 'EAP');
          curdRef.formData.systemName = obj ? obj.id : null;
        } else {
          if (!systemNameNoEapList) return;
          curdRef.formData.systemName = systemNameNoEapList.length !== 0 ? systemNameNoEapList[0].id : null;
        }
      }
    }
  }),
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: {
      label: i18nt('equipmentNumber'),
      rule: curdRef?.formData?.isEqpAlarm === 1 ? useRules('change', i18nt('equipmentNumber')) : undefined
    },
    componentProps: {
      options: equipmentNumberList,
      loading: isLoadingEquipmentNumberList,
      labelField: 'name',
      valueField: 'name',
      disabled: curdRef?.isEditMode
    }
  },
  {
    type: 'input',
    model: 'alarmID',
    formItemProps: {
      label: i18nt('alarmCode'),
      rule: [useRules('input', i18nt('alarmCode')), useRuleStringLength(0, 30)]
    },
    componentProps: { disabled: curdRef?.isEditMode }
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName'), rule: useRules('change', i18nt('systemName')) },
    componentProps: {
      options: curdRef?.formData?.isEqpAlarm ? systemNameEapList : systemNameNoEapList,
      loading: isLoadingSystemNameList,
      disabled: curdRef?.isEditMode,
      labelField: 'name',
      valueField: 'id'
    }
  },
  useRenderFormTextarea({
    model: 'alarmDesc',
    label: i18nt('alarmDescription'),
    formItemProps: {
      rule: useRules('input', i18nt('alarmDescription'))
    },
    formItemClass: 'col-span-2!'
  }),
  useRenderFormSwitch({
    key: 'isNeedClose',
    label: i18nt('requiresManualClosure')
  })
];

const createColumns = (
  curdRef: Ref<CurdRefType<QueryInfoType, AlarmCodeInfo, AlarmCodeListType> | undefined>,
  pagination: ComputedRef<PaginationProps | undefined>
): DataTableColumns<AlarmCodeListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  { title: i18nt('eqpId'), key: 'eqpId', width: TABLE_WIDTH_STATE * 2, sorter: true },
  {
    title: i18nt('alarmCode'),
    key: 'alarmID',
    sorter: true,
    render: rowData =>
      useRenderTableTitleEdit(rowData.alarmID, () => {
        curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title);
      })
  },
  { title: i18nt('alarmDescription'), key: 'alarmDesc', sorter: true },
  {
    title: i18nt('systemName'),
    key: 'systemName',
    width: TABLE_WIDTH_NAME
  },
  {
    title: i18nt('machineAlarm'),
    key: 'isEqpAlarm',
    width: TABLE_WIDTH_NAME,
    render: rowData => useRenderTableSwitch(!!rowData.isEqpAlarm)
  },
  { title: i18nt('creator'), key: 'creator', width: TABLE_WIDTH_NAME },
  {
    title: i18nt('createTime'),
    key: 'createTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('modifier'), key: 'editor', width: TABLE_WIDTH_NAME },
  {
    title: i18nt('modifyTime'),
    key: 'editTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  }
];
</script>

<script setup lang="ts">
// 获取设备编号列表
const {
  isLoading: isLoadingEquipmentNumberList,
  data: equipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);

// 获取系统名称列表
const {
  isLoading: isLoadingSystemNameList,
  data: systemNameList,
  execute: executeGetSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);

tryOnMounted(() => {
  executeGetEquipmentNumberList();
  executeGetSystemNameList();
});

// 模板引用
const curdRef = ref<CurdRefType<QueryInfoType, AlarmCodeInfo, AlarmCodeListType>>();

const curdRefPagination = computed(() => curdRef.value?.pagination);

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas(
  equipmentNumberList,
  isLoadingEquipmentNumberList,
  systemNameList,
  isLoadingSystemNameList
);

// 新增
const queryFormParams: Nullable<QueryInfoType> = { eqpId: null, alarmId: null, systemName: null };

const formSchemas = computed<FormSchemaType>(() =>
  initFormSchemas(
    equipmentNumberList.value,
    isLoadingEquipmentNumberList.value,
    systemNameEapList.value,
    systemNameNoEapList.value,
    isLoadingSystemNameList.value,
    curdRef.value
  )
);
const formParams: Nullable<EditType> = {
  eqpId: null,
  alarmID: null,
  isEqpAlarm: OpenState.close,
  alarmDesc: null,
  // systemName: systemNameList.value ? systemNameList.value[0].id : null
  systemName: null,
  isNeedClose: OpenState.close
};

const tableColumns = createColumns(curdRef, curdRefPagination);

const systemNameEapList = ref<OptionsType[]>([]);
const systemNameNoEapList = ref<OptionsType[]>();
// 新增事件
const openModal = () => {
  executeGetEquipmentNumberList();
  executeGetSystemNameList();
  if (!curdRef.value) return;
  if (!curdRef.value.formData) return;
  if (!systemNameList.value) return;
  systemNameEapList.value = systemNameList.value.filter(
    ele => ele.id.toUpperCase() === 'EAP' || ele.id.toUpperCase() === 'AMS'
  );
  systemNameNoEapList.value = systemNameList.value.filter(
    ele => ele.id.toUpperCase() !== 'EAP' && ele.id.toUpperCase() !== 'AMS'
  );
  curdRef.value.formData.systemName = systemNameNoEapList.value.length !== 0 ? systemNameNoEapList.value[0].id : null;
};
</script>

<template>
  <div id="alarm-code-maintain">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :create-api="AlarmCodeMaintainApis.createCodeMaintainApi"
      :export-api="AlarmCodeMaintainApis.getCodeMaintainListApi"
      :delete-api="AlarmCodeMaintainApis.deleteCodeMaintainApi"
      :import-api="AlarmCodeMaintainApis.importCodeMaintainApi"
      :edit-detail-api="AlarmCodeMaintainApis.getCodeMaintainDetailApi"
      :download-api="AlarmCodeMaintainApis.downloadCodeMaintainApi"
      :update-api="AlarmCodeMaintainApis.updateCodeMaintainApi"
      :read-api="AlarmCodeMaintainApis.getCodeMaintainListApi"
      modal-title="alarmCodeMaintain"
      @before-open-add-modal="openModal"
    />
  </div>
</template>
