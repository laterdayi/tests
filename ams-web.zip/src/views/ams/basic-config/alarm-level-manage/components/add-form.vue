<script setup lang="tsx">
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import { AlarmLevelManageApis } from '@/service/apis/ams/basic-config/alarm-level-manage';
import type { AlarmLevelListType, AlarmLevelType } from '@/service/apis/ams/basic-config/alarm-level-manage';
import { formatAlarmList } from '@/views/ams/constants';
import type { AlarmActionProps } from '@/views/ams/constants';

const emit = defineEmits<{
  'reset-table': [];
}>();

const {
  data: actionList,
  isLoading: isLoadingAction,
  execute: executeActionList
} = useAxiosGet<AlarmActionProps[]>(AlarmSystemSettingApis.getActionListApi);

// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
// 弹窗title
const modalTitle = ref<string>('');
// 接口设置
const modalUrl = ref<string>('');
// 是否是详情页
const viewDetailIsShow = ref<boolean>(false);
// 获取表单详情
const { execute: executeGetDetails } = useAxiosGet<AlarmLevelListType>(AlarmLevelManageApis.getInfoApi);
const editIsShow = ref<boolean>(false);
//  打开弹窗
const handleOpenModal = async (id: string, isShow: boolean) => {
  resetField();
  viewDetailIsShow.value = !isShow;
  try {
    await executeActionList();
    if (id) {
      modalTitle.value = isShow ? i18nt('edit') + i18nt('alarmLevel') : i18nt('viewDetail');
      modalUrl.value = AlarmLevelManageApis.updateUserApi;
      const { data } = await executeGetDetails({
        params: { id }
      });
      if (!data.value) return;
      formData.value = data.value;
      editIsShow.value = true;
    } else {
      modalTitle.value = i18nt('add') + i18nt('alarmLevel');
      modalUrl.value = AlarmLevelManageApis.createUserApi;
      editIsShow.value = false;
    }
    openModal();
  } catch (error) {
    console.log(error);
  }
};

// 表单配置
const { formData, resetField, validate, formRef } = useForm<Nullable<AlarmLevelType>>({
  alarmLevel: null,
  alarmAction: [],
  description: null
});

const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'alarmLevel',
    formItemProps: {
      label: i18nt('alarmLevel'),
      rule: [useRuleStringLength(), useRules('input', i18nt('alarmLevel'))]
    }
  },
  {
    type: 'select',
    model: 'alarmAction',
    formItemProps: {
      label: i18nt('executeAction')
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: formatAlarmList(actionList.value || []),
      loading: isLoadingAction.value,
      multiple: true,
      renderLabel: (option: { id: string; name: string }) => h('span', {}, i18nt(option.name))

    }
  },
  useRenderFormTextarea({ model: 'description', formItemClass: 'col-span-2!' })
]);
// 提交
const { isLoading: isLoadingChangeExecutor, execute: executeChangeExecutor } = useAxiosPost('');
const handleSubmitChangeExecutor = async () => {
  try {
    await validate();
    await executeChangeExecutor(modalUrl.value, {
      data: {
        ...formData.value
      }
    });

    emit('reset-table');
    closeModal();
  } catch (error) {
    console.log(error);
  }
};

defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :loading="isLoadingChangeExecutor"
    :show="showModal"
    :title="modalTitle"
    :positive-text="viewDetailIsShow ? '' : i18nt('confirm')"
    :inside-scroll="false"
    @close="closeModal"
    @negative-click="closeModal"
    @positive-click="handleSubmitChangeExecutor"
    @after-leave="resetField"
  >
    <base-form ref="formRef" v-model="formData" :disabled="viewDetailIsShow" layout="dialog" :schemas="formSchemas" />
  </base-modal>
</template>
