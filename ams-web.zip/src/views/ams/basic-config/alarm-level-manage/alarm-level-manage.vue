<script setup lang="ts">
import addForm from './components/add-form.vue';
import { alarmActionType } from '@/views/ams/constants';
import { AlarmLevelManageApis } from '@/service/apis/ams/basic-config/alarm-level-manage';
import type { AlarmLevelListType, AlarmLevelType } from '@/service/apis/ams/basic-config/alarm-level-manage';

const { hasEditPermission } = useRoutes();
// 模板引用
const curdRef = ref<CurdRefType<undefined, AlarmLevelType, AlarmLevelListType>>();
const addFormRef = ref();
const curdRefPagination = computed(() => curdRef.value?.pagination);

const tableColumns: DataTableColumns<AlarmLevelListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination.value),
  {
    title: i18nt('alarmLevel'),
    key: 'alarmLevel',
    sorter: true,
    width: TABLE_WIDTH_DATETIME,
    render: rowData =>
      useRenderTableTitleEdit(rowData.alarmLevel, () =>
        addFormRef.value.handleOpenModal(rowData.id, hasEditPermission.value))
  },
  { title: i18nt('description'), key: 'description' },
  {
    title: i18nt('executeAction'),
    key: 'actions',
    ...useRenderTableMultiTag((rowData: AlarmLevelListType) =>
      rowData?.actions?.map((item: number) => (alarmActionType[item] ? i18nt(alarmActionType[item]) : ''))
    )
  },
  { title: i18nt('creator'), key: 'creator', width: TABLE_WIDTH_NAME },
  {
    title: i18nt('createTime'),
    key: 'createTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('modifier'), key: 'editor', width: TABLE_WIDTH_NAME },
  { title: i18nt('modifyTime'), key: 'editTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];
// 刷新页面
const resetTable = () => {
  curdRef?.value?.handleSearch();
};
// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    add: () => addFormRef.value.handleOpenModal(__, true),
    edit: () => addFormRef.value.handleOpenModal(curdRef?.value?.tableRef?.selectedKeys[0], hasEditPermission.value)
  };
  columnsList[permission as string]?.();
};
</script>

<template>
  <div id="alarm-level">
    <base-curd
      ref="curdRef"
      :columns="tableColumns"
      :read-api="AlarmLevelManageApis.getUserListApi"
      :delete-api="AlarmLevelManageApis.deleteUserApi"
      @handle="handlePermission"
    />
    <addForm ref="addFormRef" @reset-table="resetTable" />
  </div>
</template>
