export const collectAlarms: { id: number; name: string }[] = [
  { id: 1, name: i18nt('yes') },
  { id: 0, name: i18nt('no') }
];
