<script lang="tsx">
import { h, ref } from 'vue';
import { NTag } from 'naive-ui';
import { AlarmStatisticsConfigApis } from '@/service/apis/ams/basic-config/alarm-statistics-config';
import { CommonApis } from '@/service/apis/common/common';
import BaseRadioGroup from '@/components/base-ui/base-radio/base-radio-group.vue';
import BaseRadio from '@/components/base-ui/base-radio/base-radio.vue';
import BaseSwitch from '@/components/base-ui/base-switch/base-switch.vue';

interface QueryInfoType {
  eqpType: string
  alarmId: string
  eqpName: string[]
}

interface SummaryConfig {
  eqpType: string | string[]
  alarmId: string[]
  alarmIdList: string[]
  createTime: string
  creator: string
  editTime: string
  editor: string
  eqpNames: string
  category: string
  id: number
  intervalSetting: number
  isDeleted: number
  projectCode: string
  remark: string
  systemName: string
  isCount: number
  countType: number
}

type SummaryListType = SummaryConfig & QueryInfoType;

const ALL = 'All';

// 初始化查询表单
const initQueryFormSchemas = (
  executeGetEquipmentNumberList: ({ params }: { params: { layoutId: string; check: string } }) => void,
  updataEqpNameValue: (updataValue: { key: keyof Pick<QueryInfoType, 'eqpName'>; value: string[] }) => void,
  productLineList: Ref<OptionsType[] | undefined>,
  eqpNameList?: OptionsType[],
  isLoadingEqpName?: boolean
): FormSchemaType => {
  return [
    {
      type: 'tree-select',
      model: 'eqpType',
      formItemProps: { label: i18nt('productionLineLevel') },
      componentProps: {
        keyField: 'id',
        labelField: 'name',
        options: productLineList.value,
        onUpdateValue: (value: string) => {
          executeGetEquipmentNumberList({ params: { layoutId: value, check: '1' } });
          updataEqpNameValue({ key: 'eqpName', value: [] });
        }
      }
    },
    {
      type: 'select',
      model: 'eqpName',
      formItemProps: {
        label: i18nt('eqpName')
      },
      componentProps: {
        options: eqpNameList,
        loading: isLoadingEqpName,
        valueField: 'name',
        labelField: 'name',
        multiple: true
      }
    },
    {
      type: 'input',
      model: 'alarmId',
      formItemProps: {
        label: i18nt('alarmCode')
      }
    }
  ];
};

const initFormSchemas = (
  allFlag: Ref<boolean>,
  setAlarmCodeList: (eqpType?: string | string[], systemName?: string) => void,
  equipmentNumberList: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberList: Ref<boolean>,
  eqpTypeList?: OptionsType[],
  isLoadingeqpType?: boolean,
  alarmIdList?: OptionsType[],
  curdRef?: CurdRefType<QueryInfoType, SummaryConfig, SummaryListType>,
  systemNameList?: Ref<OptionsType[] | undefined>
): FormSchemaType => [
  {
    type: 'custom-form-item',
    model: 'category',
    formItemProps: { label: i18nt('category') },
    render() {
      return h(
        BaseRadioGroup,
        {
          size: 'large',
          name: 'category',
          value: curdRef?.formData?.category,
          onUpdateValue: (value: string) => {
            curdRef?.formRef?.baseFormRef?.restoreValidation();
            if (curdRef?.formData) {
              curdRef.formData.category = value;
              curdRef.formData.eqpType = null;
              curdRef.formData.alarmId = [];
              curdRef.formData.intervalSetting = null;
              curdRef.formData.remark = null;

              if (!systemNameList?.value) return;
              curdRef.formData.systemName = systemNameList.value.length === 0 ? null : systemNameList.value[0].id;
              curdRef.formData.isCount = 1;
              curdRef.formData.countType = 2;
              setAlarmCodeList('');
            }
          }
        },
        {
          default: () => [
            h(BaseRadio, { disabled: curdRef?.isEditMode, label: i18nt('byEqp'), value: '2' }),
            h(BaseRadio, { disabled: curdRef?.isEditMode, label: i18nt('byEqpType'), value: '1' })
          ]
        }
      );
    }
  },
  curdRef?.formData && curdRef.formData.category === '2'
    ? {
        type: 'select',
        model: 'eqpType',
        formItemProps: {
          label: i18nt('eqpId'),
          rule: [{ ...useRules('change', i18nt('eqpId')) }]
        },
        componentProps: {
          options: equipmentNumberList.value,
          loading: isLoadingEquipmentNumberList.value,
          valueField: 'name',
          labelField: 'name',
          onUpdateValue: (value: string[]) => {
            setAlarmCodeList(value, (curdRef?.formData && curdRef.formData.systemName) || undefined);
            curdRef?.formData && (curdRef.formData.alarmId = []);
            curdRef?.formData && (curdRef.formData.eqpType = null);
          }
        },
        formItemClass: 'col-span-2!'
      }
    : {
        type: 'tree-select',
        model: 'eqpType',
        formItemProps: {
          label: i18nt('eqpType'),
          rule: [{ ...useRules('change', i18nt('eqpType')) }]
        },
        componentProps: {
          keyField: 'id',
          labelField: 'name',
          loading: isLoadingeqpType,
          options: eqpTypeList,
          'onUpdate:value': (value: string) => {
            setAlarmCodeList(value, (curdRef?.formData && curdRef.formData.systemName) || undefined);
            curdRef?.formData && (curdRef.formData.alarmId = []);
          }
        },
        formItemClass: 'col-span-2!'
      },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: {
      label: i18nt('systemName'),
      rule: [useRules('change', i18nt('systemName'))]
    },
    formItemClass: 'col-span-2!',
    componentProps: {
      options: systemNameList?.value,
      labelField: 'name',
      valueField: 'id',
      clearable: false,
      onUpdateValue: value => {
        if (curdRef?.formData) {
          curdRef.formData.alarmId = [];
          setAlarmCodeList(curdRef.formData.eqpType || undefined, value);
        }
      }
    }
  },

  {
    type: 'select',
    model: 'alarmId',
    formItemProps: {
      label: i18nt('alarmCode'),
      rule: { type: 'array', ...useRules('change', i18nt('alarmCode')) }
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: alarmIdList,
      multiple: true,
      renderTag: ({ option, handleClose }) => {
        return h(
          NTag,
          {
            closable: true,
            onMousedown: (e: FocusEvent) => {
              e.preventDefault();
            },
            onClose: (e: MouseEvent) => {
              e.stopPropagation();
              handleClose();
              if (option.id === ALL) {
                allFlag.value = false;
                curdRef?.formData && (curdRef.formData.alarmId = []);
              } else if (curdRef?.formData?.alarmId?.includes(ALL)) {
                allFlag.value = false;
                curdRef.formData.alarmId = curdRef.formData.alarmId?.filter(id => id !== ALL);
              }
            }
          },
          { default: () => option.name }
        );
      },
      nodeProps: option => {
        return {
          onClick() {
            if (option.id === ALL) {
              allFlag.value = !allFlag.value;
              if (!curdRef?.formData?.alarmId) return;
              curdRef.formData.alarmId = [ALL];
            } else {
              allFlag.value = false;
              if ((curdRef?.formData?.alarmId?.length ?? 0) <= (alarmIdList || []).length && curdRef?.formData) {
                curdRef.formData.alarmId = curdRef?.formData?.alarmId?.filter(id => id !== ALL) ?? [];
              }
            }
          }
        };
      }
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'switch',
    model: 'isCount',
    formItemProps: { label: i18nt('statisticsOrNot') },
    componentProps: {
      checkedValue: 1,
      uncheckedValue: 0,
      onUpdateValue: () => {
        if (curdRef?.formData) {
          curdRef.formData.countType = 2;
          curdRef.formData.intervalSetting = null;
        }
      }
    },
    formItemClass: 'w-min!'
  },
  curdRef?.formData && curdRef.formData.isCount === 1
    ? {
        type: 'custom-form-item',
        model: 'countType',
        formItemClass: 'col-span-2!',
        formItemProps: { label: i18nt('statisticalMethods') },
        render() {
          return h(
            BaseRadioGroup,
            {
              size: 'large',
              name: 'countType',
              value: curdRef?.formData?.countType,
              onUpdateValue: (value: number) => {
                if (curdRef?.formData) {
                  curdRef.formData.intervalSetting = null;
                  curdRef.formData.countType = value;
                }
              }
            },
            {
              default: () => [
                h(BaseRadio, { label: i18nt('alarmTimeInterval'), value: 2 }),
                h(BaseRadio, { label: i18nt('totalAlarmTime'), value: 1 })
              ]
            }
          );
        }
      }
    : __,
  curdRef?.formData && curdRef.formData.isCount === 1 && curdRef.formData.countType === 1
    ? {
        type: 'input-number',
        model: 'intervalSetting',
        formItemProps: {
          label: i18nt('totalAlarmTime'),
          rule: [
            useRules('input-number', 'onlyPositiveIntZeroRule', {
              required: true,
              message: i18nt('totalAlarmTime')
            }),
            useRuleNumberLength(0, 4)
          ]
        },
        componentProps: {
          min: 0
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  curdRef?.formData && curdRef.formData.isCount === 1 && curdRef.formData.countType === 2
    ? {
        type: 'input-number',
        model: 'intervalSetting',
        formItemProps: {
          label: i18nt('alarmTimeInterval'),
          rule: [
            useRules('input-number', 'onlyPositiveIntZeroRule', {
              required: true,
              message: i18nt('alarmTimeInterval')
            }),
            useRuleNumberLength(0, 4)
          ]
        },
        componentProps: {
          min: 0
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  useRenderFormTextarea({ model: 'remark', label: i18nt('remark'), formItemClass: 'col-span-2!' }),
  {
    type: 'switch',
    model: 'isDeleted',
    formItemProps: { label: i18nt('valid') },
    componentProps: {
      checkedValue: 0,
      uncheckedValue: 1
    },
    formItemClass: 'w-min!'
  }
];
const createColumns = (
  curdRef: Ref<CurdRefType<QueryInfoType, SummaryConfig, SummaryListType> | undefined>,
  pagination: ComputedRef<PaginationProps | undefined>
): DataTableColumns<SummaryListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('nodeLevel'),
    width: TABLE_WIDTH_STATE * 2,
    key: 'eqpNames',
    render: rowData =>
      useRenderTableTitleEdit(rowData.category.toString() === '2' ? '' : rowData.eqpNames, () => {
        curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title);
      })
  },
  {
    title: i18nt('eqpName'),
    key: 'alarmId',
    width: TABLE_WIDTH_MODULE,
    render: rowData =>
      useRenderTableTitleEdit(rowData.category.toString() !== '2' ? '' : rowData.eqpNames, () => {
        curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title);
      })
  },
  {
    title: i18nt('alarmCode'),
    key: 'alarmIdList',
    ...useRenderTableMultiTag('alarmIdList', { ellipsis: true })
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_STATE },
  {
    title: i18nt('statisticsOrNot'),
    key: 'isCount',
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return h(BaseSwitch, {
        size: 'small',
        value: rowData.isCount,
        disabled: true,
        checkedValue: 1,
        uncheckedValue: 0
      });
    }
  },
  {
    title: i18nt('statisticalMethods'),
    key: 'countType',
    width: TABLE_WIDTH_DATETIME,
    render: rowData => {
      return rowData.countType === 0
        ? ''
        : rowData.countType === 1
          ? i18nt('totalAlarmTime')
          : i18nt('alarmTimeInterval');
    }
  },
  { title: i18nt('timeInterval'), key: 'intervalSetting', width: TABLE_WIDTH_NAME },
  {
    title: i18nt('valid'),
    key: 'isDeleted',
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return h(BaseSwitch, {
        size: 'small',
        value: rowData.isDeleted,
        disabled: true,
        checkedValue: 0,
        uncheckedValue: 1
      });
    }
  },
  { title: i18nt('creator'), key: 'creator', width: TABLE_WIDTH_NAME },
  {
    title: i18nt('createTime'),
    key: 'createTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  { title: i18nt('modifier'), key: 'editor', width: TABLE_WIDTH_NAME },
  { title: i18nt('modifyTime'), key: 'editTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];
</script>

<script setup lang="tsx">
const allFlag = ref(false);
const appStore = useAppStore();
const { local } = storeToRefs(appStore);
// 模板引用
const curdRef = ref<CurdRefType<QueryInfoType, SummaryConfig, SummaryListType>>();

const curdRefPagination = computed(() => curdRef.value?.pagination);

// 查询表单模型
const queryFormSchemas = computed<FormSchemaType>(() =>
  initQueryFormSchemas(
    executeGetEquipmentNumberList,
    updataEqpNameValue,
    treeIdList,
    equipmentNumberList.value,
    isLoadingEquipmentNumberList.value
  )
);
const updataEqpNameValue = (updataValue: { key: keyof Pick<QueryInfoType, 'eqpName'>; value: string[] }) => {
  curdRef.value?.queryFormData && (curdRef.value.queryFormData[updataValue.key] = updataValue.value);
};
tryOnMounted(() => {
  executeGetEquipmentNumberList();
  getSystemNameList();
});
const refactorFormQueryParams = (data: QueryInfoType) => ({
  ...data,
  language: local.value === 'zh-CN' ? 0 : 1
});

// 系统名称
const { data: systemNameList, execute: getSystemNameList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi
);
// 查询
const queryFormParams: Nullable<QueryInfoType> = { eqpName: null, eqpType: null, alarmId: null };

const formParams = {
  intervalSetting: null,
  isDeleted: 0,
  remark: null,
  alarmId: null,
  eqpType: null,
  category: '2',
  systemName: null,
  isCount: 1,
  countType: 2
};

const { data: treeIdList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelQueryApi,
  __,
  undefined,
  { immediate: true }
);

const {
  data: levelList,
  isLoading: isLoadingLevelList,
  execute: executeGetLevelList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);

const alarmCodeList = ref<OptionsType[]>([]);

const { execute: executeGetAlarmCodeList } = useAxiosGet<OptionsType[]>(AlarmStatisticsConfigApis.getAlarmCodeListApi);

// 获取设备编号列表
const {
  data: equipmentNumberList,
  isLoading: isLoadingEquipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);

const formSchemas = computed<FormSchemaType>(() =>
  initFormSchemas(
    allFlag,
    setAlarmCodeList,
    equipmentNumberList,
    isLoadingEquipmentNumberList,
    levelList.value,
    isLoadingLevelList.value,
    alarmCodeList.value,
    curdRef.value,
    systemNameList
  )
);
const tableColumns = createColumns(curdRef, curdRefPagination);

// 报警代码
const setAlarmCodeList = async (eqpType?: string | string[], systemName?: string) => {
  if (eqpType) {
    alarmCodeList.value = [];
    try {
      const res = await executeGetAlarmCodeList({
        params: {
          category: curdRef?.value?.formData?.category,
          eqpModel: eqpType,
          systemName,
          language: local.value === 'zh-CN' ? 0 : 1
        },
        paramsSerializer: typeof eqpType === 'string' ? undefined : useParamsSerializer()
      });
      alarmCodeList.value = res.data.value as OptionsType[];
    } catch (error) {
      alarmCodeList.value = [];
      console.log(error);
    }
  } else {
    alarmCodeList.value = [];
  }
};
// 新增弹窗打开
const queryAllSelectList = () => {
  alarmCodeList.value = [];
  executeGetLevelList();
  executeGetEquipmentNumberList();
  if (!curdRef.value) return;
  if (!curdRef.value.formData) return;
  if (!systemNameList.value) return;
  curdRef.value.formData.systemName = systemNameList.value.length === 0 ? null : systemNameList.value[0].id;
};

const handleAlarmCodeList = () => {
  setAlarmCodeList(curdRef?.value?.formData?.eqpType as string, curdRef?.value?.formData?.systemName as string);
};

const refactorFormSubmitParams = (data: SummaryConfig) => {
  const alarmIds = data.alarmId.includes(ALL) ? [ALL] : data.alarmId;
  return { ...data, alarmId: alarmIds };
};

const refactorFormEditParams = (data: SummaryConfig) => {
  return {
    ...data,
    alarmId: (data.alarmId as unknown as string).split(',')
  };
};
const handlePermission = (permission: PermissionType) => {
  if (permission === 'reset') {
    executeGetEquipmentNumberList();
  }
};
</script>

<template>
  <div id="alarm-statistics-config">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      params-serializer-query
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL }"
      :form-props="{
        labelWidth: 150
      }"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :create-api="AlarmStatisticsConfigApis.addSummaryConfigApi"
      :delete-api="AlarmStatisticsConfigApis.deleteSummaryConfigApi"
      :edit-detail-api="AlarmStatisticsConfigApis.getInfoApi"
      :update-api="AlarmStatisticsConfigApis.updateSummaryConfigApi"
      :read-api="AlarmStatisticsConfigApis.getListApi"
      modal-title="alarmStatistics"
      :refactor-form-submit-params="refactorFormSubmitParams"
      :refactor-form-edit-params="refactorFormEditParams"
      :refactor-form-query-params="refactorFormQueryParams"
      @modal-closed="allFlag = false"
      @before-open-add-modal="queryAllSelectList"
      @before-open-edit-modal="queryAllSelectList"
      @after-open-edit-modal="handleAlarmCodeList"
      @handle="handlePermission"
    />
  </div>
</template>
