<script setup lang="tsx">
import { CommonApis } from '@/service/apis/common/common';
import { WeChatGroupBindingApis } from '@/service/apis/ams/basic-config/we-chat-group-binding';
import type {
  EditType,
  EquipmentType,
  QueryType,
  TableListType
} from '@/service/apis/ams/basic-config/we-chat-group-binding';

// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<EquipmentType[]>(CommonApis.getProductionLineLevelApi);

// 获取系统名称
const systemNameData = ref<OptionsType[]>();
const { isLoading: isLoadingSystemName, execute: executeSystemNameList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi
);

tryOnMounted(async () => {
  try {
    executeGetProductLineList();
    const { data } = await executeSystemNameList();
    systemNameData.value = data.value || [];
  } catch (error) {
    console.log(error);
  }
});
// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();

// 查询表单
const queryFormParams: Nullable<QueryType> = { systemName: null, webhookKey: null };
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'systemName',
    formItemProps: {
      label: i18nt('systemName')
    },
    componentProps: {
      loading: isLoadingSystemName.value,
      options: systemNameData.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'input',
    model: 'webhookKey',
    formItemProps: {
      label: 'Webhook'
    }
  }
]);
const refactorFormQueryParams = (data: QueryType) => ({ ...data, layoutId: currentSelectNodeId.value });
// 编辑表单
const formParams: Nullable<EditType> = {
  layoutId: null,
  systemName: null,
  webhookKey: null
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'systemName',
    formItemProps: {
      label: i18nt('systemName'),
      rule: [{ ...useRules('change', i18nt('systemName')) }]
    },
    componentProps: {
      loading: isLoadingSystemName.value,
      options: systemNameData.value,
      disabled: curdRef.value?.isEditMode,
      valueField: 'id',
      labelField: 'name'
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: 'Webhook' },
    render() {
      if (!curdRef.value) return;
      if (!curdRef.value.formData) return;
      return (
        <div class="w-100%!">
          <base-input
            autosize={{
              minRows: 9,
              maxRows: 9
            }}
            class="w-100%!"
            onInput={(val: string) => {
              if (!curdRef.value) return;
              if (!curdRef.value.formData) return;
              curdRef.value.formData.webhookKey = val.replace(/[ \t\n\r]+/g, '');
            }}
            placeholder={`${i18nt('baseForm.pleaseInput')}Webhook,${i18nt('spcUserGroupBindingTips')}`}
            type="textarea"
            v-model:value={curdRef.value.formData.webhookKey}
          />
        </div>
      );
    }
  }
]);

const refactorFormSubmitParams = (data: EditType) =>
  curdRef.value?.isEditMode ? data : { ...data, layoutId: currentSelectNodeId.value };

// 表格
const pagination = computed(() => curdRef.value?.pagination);
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('systemName'),
    key: 'systemName',
    sorter: true,
    width: TABLE_WIDTH_INFO,
    render: rowData =>
      useRenderTableTitleEdit(rowData.systemName, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  {
    title: i18nt('equipmentLevel'),
    key: 'layoutNameLists',
    render(rowData) {
      return (
        <div class=" flex">
          {rowData.layoutNameLists.map((ele, index) => {
            return (
              <div>
                <base-tag>{ele}</base-tag>
                {index === rowData.layoutNameLists.length - 1 ? '' : <span class="mx">{'->'}</span>}
              </div>
            );
          })}
        </div>
      );
    }
  },
  {
    title: 'Webhook',
    key: 'webhookList',
    ...useRenderTableMultiTag('webhookList', { ellipsis: true })
  },
  { title: i18nt('creator'), key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];

// 节点操作
const currentSelectNodeId = ref<string>();
const nodeProps = ({ option }: { option: TreeOption<EquipmentType> }) => ({
  onClick: () => {
    try {
      currentSelectNodeId.value = option.id;
      if (!curdRef.value) return;
      curdRef.value?.handleSearch();
      if (!curdRef.value.formData) return;
      curdRef.value.formData.layoutId = option.id;
    } catch (error) {
      console.log('getMenuNodeDetail：异常', error);
    }
  }
});

const formDisableCondition = computed(() => ({
  add: !currentSelectNodeId.value
}));
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    reset: () => {
      curdRef.value?.tableRef?.clearSelected()
    }
  };
  if (permissionAction[permission]) permissionAction[permission]();
};
</script>

<template>
  <div id="equipment-info-manage" class="flex layout-content-page-vh">
    <base-card class="mr" :content-style="{ height: '100%' }" :class="[`w-${TREE_WIDTH_CONTAINER}px!`]">
      <base-tree
        wrapper-class="h-full"
        class="h-full"
        :data="productLineList"
        :loading="isLoadingProductLineList"
        label-field="name"
        key-field="id"
        :checkable="false"
        :node-props="nodeProps"
        :cascade="false"
      />
    </base-card>
    <base-curd
      ref="curdRef"
      class="flex-1 overflow-auto"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :read-api="WeChatGroupBindingApis.getListApi"
      :create-api="WeChatGroupBindingApis.addApi"
      :edit-detail-api="WeChatGroupBindingApis.getDetailApi"
      :update-api="WeChatGroupBindingApis.updateApi"
      :delete-api="WeChatGroupBindingApis.deleteApi"
      :refactor-form-query-params="refactorFormQueryParams"
      :refactor-form-submit-params="refactorFormSubmitParams"
      modal-title="weChatGroupBinding"
      :form-permission-disable="formDisableCondition"
      @handle="handlePermission"
    />
  </div>
</template>
