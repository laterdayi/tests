import type {
  UserListType
} from '@/service/apis/ams/basic-config/alarm-rules-setting';

export const lotTypeList = [
  { name: i18nt('completeMachine'), id: 1 },
  { name: 'port', id: 2 },
  { name: 'chamber', id: 3 }
];

export const MESEqpStates: Record<number, string> = {
  2: 'AMS_LotPort',
  3: 'AMS_LotChamber'
};

 // 处理通知用户树数据
 export const userListEmptyHandle = (list: UserListType[]): UserListType[] => {
  if (!list?.length) return [];
  return list.map(ele => {
    const { children, ...obj } = ele;
    return {
      ...obj,
      ...(children && children.length === 0 ? {} : { children: userListEmptyHandle(children || []) })
    };
  });
};
export const collectAlarms: { id: number; name: string }[] = [
  { id: 1, name: i18nt('yes') },
  { id: 0, name: i18nt('no') }
];
