<script lang="tsx" setup>
import type { VNode } from 'vue';
import { MESEqpStates, lotTypeList, userListEmptyHandle } from '../constants';
import BaseButton from '@/components/base-ui/base-button/base-button.vue';
import { AlarmLevelManageApis } from '@/service/apis/ams/basic-config/alarm-level-manage';
import { AlarmLevelRulesSettingApis } from '@/service/apis/ams/basic-config/alarm-rules-setting';
import type {
  AddTableType,
  AlarmLevelListProps,
  UserListType
} from '@/service/apis/ams/basic-config/alarm-rules-setting';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'render-data': [];
}>();
const userStore = useUserStore();
const { systemPermissions } = storeToRefs(userStore);
// 报警级别
const {
  data: alarmLevelList,
  isLoading: isLoadingAlarmLevel,
  execute: executeAlarmLevel
} = useAxiosGet<AlarmLevelListProps[]>(AlarmLevelManageApis.getAllLevelApi);
// 获取holdCode列表
const {
  data: hodeCodeList,
  isLoading: isLoadingHodeCode,
  execute: executeGetHodeCodeList
} = useAxiosGet<OptionsType[]>(AlarmLevelRulesSettingApis.getHodeCodeListApi);
// 获取机台状态列表
const {
  data: holdEqpStateList,
  isLoading: isLoadingHoldEqpState,
  execute: executeGetHoldEqpStateList
} = useAxiosGet<OptionsType[]>(CommonApis.getSelectItemListApi);
// 获取通知用户(层级设备)
const userList = ref<UserListType[]>([]);
const { isLoading: isLoadingUsers, execute: executeGetNotifyUsers } = useAxiosGet<UserListType[]>(
  AlarmLevelRulesSettingApis.getNotifyUsersApi
);
// 系统名称
const {
  isLoading: isLoadingsystemName,
  data: systemNameList,
  execute: getSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);
// 按系统报警级别判定
const { execute: executeHoldInfoSelectType } = useAxiosGet<{
  selectType: number;
}>(AlarmLevelRulesSettingApis.getHoldInfoSelectTypeApi);
// 获取holdDepartment列表
const {
  data: departmentList,
  isLoading: isLoadingDepartment,
  execute: executeGetDepartmentList
} = useAxiosGet<OptionsType[]>(AlarmLevelRulesSettingApis.getHoldDepartmentListApi);

// 锁机类型
const selectItemListObj = reactive<{ [key: number]: SelectOption[] }>({});
const { execute: executeGetSelectItemList } = useAxiosGet<SelectOption[]>(CommonApis.getSelectItemListApi);

const eqpModel = ref<string>('');
const category = ref<number>(1);

// 打开弹窗
const { showModal, openModal, closeModal } = useModal();
const handleOpenModal = async (values: { eqpModel: string; category: number }) => {
  tableData.value = [];
  eqpModel.value = values.eqpModel;
  category.value = values.category;
  // 通知用户处理
  const { data: userListData } = await executeGetNotifyUsers({
    params: {
      category: values.category,
      eqpModel: values.eqpModel,
      systemName: values.category === 3 ? values.eqpModel : null
    }
  });
  if (!userListData.value) return;
  userList.value = userListEmptyHandle(userListData.value);
  executeGetHodeCodeList();
  executeGetHoldEqpStateList({
    params: {
      type: AttributeType.holdEqpState
    }
  });
  executeAlarmLevel();
  await getSystemNameList();
  tableData.value.push(initRowForm());
  openModal();
};

// 表格配置
const tableData = ref<Nullable<AddTableType>[]>([]);
const scrollX = ref<string | number>();
// 默认表格
const tableColumns = computed(() => {
  // return tableHandle(category.value, lotChamberPortConfigData.value?.chamberPortConfig);
  // 锁机类型根据登录获取来显隐chamberPortConfig 1展示 chamberPortConfig true展示port或者chmber值
  return tableHandle(
    category.value,
    systemPermissions.value?.chamberPortConfigOpen,
    systemPermissions.value?.isShowChamberPortList,
    systemPermissions.value?.isHiddenHoldInfo,
    systemPermissions.value?.isHiddenRemoveDuplicate,
    systemPermissions.value?.isHiddenIgnoreEqpStatusSwitch
  );
});
const tableHandle = (
  category: number,
  chamberPortConfigOpen?: number,
  isShowChamberPortList?: boolean,
  isHiddenHoldInfo?: boolean,
  isHiddenRemoveDuplicate?: boolean,
  isHiddenIgnoreEqpStatusSwitch?: boolean
) => {
  scrollX.value = category !== 3 && chamberPortConfigOpen ? TABLE_WIDTH_SCROLL_SMALL + 150 : '';
  return (
    [
      // 收集报警
      category !== 3
        ? {
            title: i18nt('collectAlarms'),
            key: 'isSave',
            width: TABLE_WIDTH_STATE,
            render(row) {
              return (
                <base-switch
                  checked-value={1}
                  on-updateValue={() => {
                    row.isIgnoreEqpStatus = 0;
                  }}
                  unchecked-value={0}
                  v-model:value={row.isSave}
                />
              );
            }
          }
        : __,
      // 收集过滤报警
      category !== 3
        ? isHiddenIgnoreEqpStatusSwitch
          ? __
          : {
              title: i18nt('collectAndFilterAlarms'),
              key: 'isIgnoreEqpStatus',
              width: TABLE_WIDTH_DATE,
              render(row) {
                return (
                  <base-switch
                    checked-value={1}
                    disabled={!row.isSave}
                    unchecked-value={0}
                    v-model:value={row.isIgnoreEqpStatus}
                  />
                );
              }
            }
        : __,
      // 报警代码
      {
        title: () => {
          return requiredHandle(i18nt('alarmCode'));
        },
        key: 'alarmId',
        width: TABLE_WIDTH_DATETIME,
        render(row) {
          return (
            <base-input
              clearable
              maxlength="30"
              placeholder={`${i18nt('baseForm.pleaseInput')}${i18nt('alarmCode')}`}
              showCount
              type="text"
              v-model:value={row.alarmId}
            />
          );
        }
      },
      // 报警级别
      {
        title: i18nt('alarmLevel'),
        key: 'alarmLevel',
        width: TABLE_WIDTH_DATETIME,
        ellipsis: false,
        render(row) {
          return (
            <base-select
              class="w-100%!"
              clearable
              filterable
              label-field="name"
              loading={isLoadingAlarmLevel.value}
              onUpdateValue={async (value: string) => {
                try {
                  // 按系统报警级别判定
                  const { data } = await executeHoldInfoSelectType({ params: { id: value } });
                  if (!data.value) return;
                  row.alarmLevel = value;
                  row.holdInfoSelectType = data.value.selectType;
                  row.holdCode = null;
                  row.holdDepartment = null;
                  row.holdEqpState = null;

                  row.lotType = null;
                  row.lotPortListInfo = [];
                  row.lotChamberListInfo = [];
                } catch (error) {
                  console.log(error);
                }
              }}
              options={alarmLevelList.value}
              placeholder={`${i18nt('baseForm.pleaseSelect')}${i18nt('alarmLevel')}`}
              value={row.alarmLevel}
              value-field="id"
            />
          );
        }
      },
      // Hold相关信息
      !isHiddenHoldInfo
        ? {
            title: i18nt('relevantInformation'),
            key: 'lotType',
            width: QRCODE_SIZE * 2,
            render(row) {
              return (
                <div class="flex w-100%!">
                  {row.holdInfoSelectType === 1 || row.holdInfoSelectType === 3 ? (
                    <div class="flex w-66%!">
                      <base-select
                        label-field="name"
                        loading={isLoadingHodeCode.value}
                        on-updateValue={async (value: string) => {
                          row.holdDepartment = null;
                          row.holdCode = value;
                          await executeGetDepartmentList({ params: { holdCode: value } });
                        }}
                        options={hodeCodeList.value}
                        placeholder={`${i18nt('baseForm.pleaseSelect')}Hold Code`}
                        value={row.holdCode}
                        value-field="id"
                      />
                      {row.holdCode ? (
                        <base-select
                          class="ml "
                          label-field="name"
                          loading={isLoadingDepartment.value}
                          options={departmentList.value}
                          placeholder={`${i18nt('baseForm.pleaseSelect')}Hold Department`}
                          v-model:value={row.holdDepartment}
                          value-field="id"
                        />
                      ) : (
                        ''
                      )}
                    </div>
                  ) : (
                    ''
                  )}
                  {row.holdInfoSelectType === 2 || row.holdInfoSelectType === 3 ? (
                    <base-select
                      class="w-33% ml"
                      label-field="name"
                      loading={isLoadingHoldEqpState.value}
                      options={holdEqpStateList.value}
                      placeholder={i18nt('baseForm.pleaseSelect') + i18nt('machineState')}
                      v-model:value={row.holdEqpState}
                      value-field="id"
                    />
                  ) : (
                    ''
                  )}
                </div>
              );
            }
          }
        : __,
      // 锁机类型
      chamberPortConfigOpen === 1
        ? {
            title: i18nt('lockType'),
            key: 'lotType',
            ellipsis: false,
            width: TABLE_WIDTH_INFO * 2,
            render(row, index) {
              const defaultDisabled = (alarmLevelList.value || []).find(
                opt => opt.id === row.alarmLevel
              )?.isShowLotConfig;
              return (
                <div class="w-100%! flex items-center content-center">
                  <base-select
                    clearable
                    disabled={!defaultDisabled}
                    filterable
                    label-field="name"
                    onUpdateValue={async (value: number) => {
                      tableData.value[index].lotType = value;
                      tableData.value[index].lotPortListInfo = [];
                      tableData.value[index].lotChamberListInfo = [];
                      // 整机不需要
                      if (value !== 1 && !selectItemListObj[value]) {
                        const res = await executeGetSelectItemList({ params: { type: MESEqpStates[value] } });
                        selectItemListObj[value] = res.data.value || [];
                      }
                    }}
                    options={lotTypeList}
                    placeholder={`${i18nt('baseForm.pleaseSelect')}${i18nt('lockType')}`}
                    value={row.lotType}
                    value-field="id"
                  />
                  {isShowChamberPortList &&
                    row.lotType &&
                    lockTypeComponents[row.lotType](selectItemListObj[row.lotType], row)}
                </div>
              );
            }
          }
        : __,
      // 通知用户
      {
        title: i18nt('notifiedUsers'),
        key: 'notifiedUserIds',
        ellipsis: false,
        width: TREE_WIDTH,
        render(row) {
          return (
            <base-tree-select
              cascade
              checkable
              class="w-100%!"
              key-field="id"
              label-field="name"
              loading={isLoadingUsers.value}
              multiple
              onUpdateValue={(value: string[], item: UserListType[]) => {
                row.notifiedUsers = item.filter(ele => ele && !ele.children).map(ele => ele.id);
              }}
              options={userList.value}
              placeholder={i18nt('baseForm.pleaseSelect') + i18nt('notifiedUsers')}
              value={row.notifiedUsers}
            />
          );
        }
      },
      // 系统名称
      category !== 3
        ? {
            title: () => {
              return requiredHandle(i18nt('systemName'));
            },
            key: 'systemName',
            width: TABLE_WIDTH_MODULE,
            ellipsis: false,
            render(row) {
              return (
                <base-select
                  class="w-100%!"
                  clearable
                  label-field="name"
                  loading={isLoadingsystemName.value}
                  onUpdateValue={() => {
                    row.repeatCount = 1;
                    row.effectiveTime = null;
                    row.removeDuplicateInterval = null;
                  }}
                  options={systemNameList.value}
                  placeholder={`${i18nt('please')}${i18nt('systemName')}`}
                  v-model:value={row.systemName}
                  value-field="id"
                />
              );
            }
          }
        : __,
      // 报警触发次数
      category !== 3
        ? {
            title: i18nt('repeatCount'),
            key: 'repeatCount',
            width: TABLE_WIDTH_DATE,
            render(row) {
              return (
                <base-input-number
                  class="w-100%!"
                  clearable={false}
                  disabled={systemNameHandle(row.systemName)}
                  max={999}
                  min={1}
                  precision={0}
                  showButton={false}
                  v-model:value={row.repeatCount}
                />
              );
            }
          }
        : __,
      // 有效时间
      category !== 3
        ? {
            title: i18nt('effectiveTime', { val: `(${i18nt('second')})` }),
            key: 'effectiveTime',
            width: TABLE_WIDTH_DATE,
            render(row) {
              return (
                <base-input-number
                  class="w-100%!"
                  clearable={false}
                  disabled={systemNameHandle(row.systemName)}
                  max={9999}
                  min={0}
                  precision={0}
                  showButton={false}
                  v-model:value={row.effectiveTime}
                />
              );
            }
          }
        : __,
      // 去重间隔
      category !== 3
        ? isHiddenRemoveDuplicate
          ? __
          : {
              title: `${i18nt('deDuplicationInterval')}(${i18nt('minute')})`,
              key: 'removeDuplicateInterval',
              width: TABLE_WIDTH_DATE,
              render(row) {
                return (
                  <base-input-number
                    class="w-100%!"
                    clearable={false}
                    disabled={systemNameHandle(row.systemName)}
                    max={9999}
                    min={0}
                    precision={0}
                    showButton={false}
                    v-model:value={row.removeDuplicateInterval}
                  />
                );
              }
            }
        : __,
      // 上报时间
      category !== 3
        ? {
            title: i18nt('reportInterval', { val: `(${i18nt('minute')})` }),
            key: 'upInterval',
            width: TABLE_WIDTH_DATE,
            render(row) {
              return (
                <base-input-number
                  class="w-100%!"
                  clearable={false}
                  min={0}
                  precision={0}
                  showButton={false}
                  v-model:value={row.upInterval}
                />
              );
            }
          }
        : __,
      // 报警描述
      {
        title: i18nt('alarmDescription'),
        key: 'description',
        render(row) {
          return (
            <base-input
              class="w-100%!"
              clearable
              maxlength="200"
              placeholder={`${i18nt('baseForm.pleaseInput')}${i18nt('alarmDescription')}`}
              showCount
              type="text"
              v-model:value={row.description}
            />
          );
        }
      },
      // 操作
      {
        title: i18nt('action'),
        key: '',
        width: '80px',
        fixed: 'right',
        render(row, index) {
          return (
            <base-button
              disabled={tableData.value.length <= 1}
              onClick={() => {
                tableData.value.splice(index, 1);
              }}
              text
              type="primary"
            >
              {i18nt('delete')}
            </base-button>
          );
        }
      }
    ] as DataTableColumns<Nullable<AddTableType>>
  ).filter(item => item);
};
// 系统名称选中处理
const systemNameHandle = (item: string | null) => {
  return !(item?.toUpperCase() === 'EAP' || item?.toUpperCase() === 'AMS');
};
// 必填项
const requiredHandle = (title: string) => {
  return (
    <div>
      {title}
      <span style={{ color: '#f56c6c', marginLeft: '2px' }}>*</span>
    </div>
  );
};
const lockTypeComponents: Record<
  number,
  (options: SelectOption[] | undefined, row: Nullable<AddTableType>) => VNode | null
> = {
  1: () => null,
  2: (options: SelectOption[] | undefined, row: Nullable<AddTableType>) => {
    return (
      <base-select
        class="m-l w-100%!"
        clearable
        filterable
        label-field="name"
        maxTagCount="responsive"
        multiple
        onUpdateValue={(value: string[]) => {
          row.lotPortListInfo = value;
        }}
        options={options}
        placeholder=""
        value={row.lotPortListInfo}
        value-field="id"
      />
    );
  },
  3: (options: SelectOption[] | undefined, row: Nullable<AddTableType>) => (
    <base-select
      class="m-l w-100%!"
      clearable
      filterable
      label-field="name"
      maxTagCount="responsive"
      multiple
      onUpdateValue={(value: string[]) => {
        row.lotChamberListInfo = value;
      }}
      options={options}
      placeholder=""
      value={row.lotChamberListInfo}
      value-field="id"
    />
  )
};
// 初始化行
const initRowForm = (): Nullable<AddTableType> => {
  return {
    isSave: 1,
    isIgnoreEqpStatus: 0,
    alarmId: null,
    alarmLevel: null,
    notifiedUsers: [],
    description: null,
    repeatCount: 1,
    effectiveTime: null,
    upInterval: null,
    lotType: null,
    lotPortListInfo: [],
    lotChamberListInfo: [],
    systemName:
      category.value === 3
        ? eqpModel.value
        : systemNameList.value && systemNameList.value.length !== 0
          ? systemNameList.value[0].id
          : null,
    holdCode: null,
    holdDepartment: null,
    holdEqpState: null,
    holdInfoSelectType: 0,
    removeDuplicateInterval: null
  };
};
// 新增行
const addRow = () => {
  tableData.value.push(initRowForm());
};
// 保存
const { isLoading: isLoadingHandleAdd, execute: executeHandleAdd } = useAxiosPost(
  AlarmLevelRulesSettingApis.handleAddApi
);
const handleSave = async () => {
  try {
    // 报警代码验证
    const alarmIdsIsShow = tableData.value.every(item => item.alarmId);
    if (!alarmIdsIsShow) {
      $message.error(i18nt(30011));
      return;
    }
    // 系统名称验证
    const systemNameIsShow = tableData.value.every(item => item.systemName);
    if (!systemNameIsShow) {
      $message.error(i18nt(10229));
      return;
    }
    // 上报时间验证
    const upIntervalIsShow = tableData.value.every(
      item => !item.upInterval || (item.upInterval >= 5 && item.upInterval <= 720)
    );
    if (!upIntervalIsShow) {
      $message.error(i18nt('reportInterval') + i18nt('rules.lengthRule', { min: 5, max: 720 }));
      return;
    }
    if (systemPermissions.value?.chamberPortConfigOpen === 1) {
      const checkedAlarmTyps = tableData.value.filter(item => item.alarmLevel && !item.lotType);
      if (checkedAlarmTyps.length) {
        $message.error(i18nt('lockTypeEmpty'));
        return;
      }
      if (systemPermissions.value.isShowChamberPortList) {
        const checkLotType = tableData.value.filter(
          item =>
            item.lotType && item.lotType !== 1 && !(item.lotChamberListInfo?.length || item.lotPortListInfo?.length)
        );
        if (checkLotType.length) {
          $message.error(i18nt('completeLockTypeTip'));
          return;
        }
      }
    }
    await executeHandleAdd({
      data: {
        eqpModel: eqpModel.value,
        category: category.value,
        systemName: category.value === 3 ? eqpModel.value : null,
        settings: tableData.value.map(item => ({ ...item, notifiedUsers: item.notifiedUsers?.toString() }))
      }
    });
    emit('render-data');
    closeModal();
  } catch (error) {
    console.log(error);
  }
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-1850px!"
    :show="showModal"
    :title="`${i18nt('add')}${i18nt('alarmCode')}`"
    @close="closeModal"
    @negative-click="closeModal"
  >
    <base-table :columns="tableColumns" :data="tableData" :scroll-x="scrollX" />
    <template #action>
      <div class="flex items-center justify-between w-full">
        <base-button type="primary" button-name="add" size="small" @click="addRow">
          <template #default> {{ i18nt('addRow') }} </template>
        </base-button>
        <base-space>
          <base-button button-name="cancel" size="small" @click="closeModal">
            <template #default> {{ i18nt('cancel') }} </template>
          </base-button>
          <base-button type="primary" button-name="save" size="small" :loading="isLoadingHandleAdd" @click="handleSave">
            <template #default> {{ i18nt('confirm') }} </template>
          </base-button>
        </base-space>
      </div>
    </template>
  </base-modal>
</template>

<style scoped lang="less">
:deep(.n-data-table-td) {
  .n-ellipsis {
    width: 100%;
  }
}
</style>
