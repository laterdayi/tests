<script setup lang="tsx">
import { AlarmLevelRulesSettingApis } from '@/service/apis/ams/basic-config/alarm-rules-setting';
import type { FormDataType, TableListType } from '@/service/apis/ams/basic-config/alarm-rules-setting';

const formData = ref<FormDataType>({
  keyId: '',
  tableName: 'AlarmSettingEntity',
  operateType: 'Update',
  language: 0
});

const appStore = useAppStore();
const { local } = storeToRefs(appStore);
//  打开弹窗
const handleOpenModal = (keyId: string) => {
  try {
    formData.value.keyId = keyId;
    formData.value.language = local.value === 'zh-CN' ? 0 : 1;
    getList();
    openModal();
  } catch (error) {
    closeModal();
  }
};
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  tableData,
  tableRef,
  handleResetPagination,
  executeQueryList: getList
} = useTable<TableListType[]>(AlarmLevelRulesSettingApis.getPageListApi, {
  queryFormParams: formData
});

const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(pagination),
  {
    title: i18nt('modifyContent'),
    key: 'new'
  },
  {
    title: i18nt('modifier'),
    key: 'creator',
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('modifyTime'),
    key: 'createTime',
    width: TABLE_WIDTH_DATETIME
  }
];

const { showModal, openModal, closeModal } = useModal();

defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-60%!"
    :show="showModal"
    :title="i18nt('modifyRecord')"
    positive-text=""
    @close="closeModal"
    @after-leave="handleResetPagination"
    @negative-click="closeModal"
  >
    <!-- 表格 -->
    <base-table
      ref="tableRef"
      remote
      :columns="tableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery"
      :pagination="pagination"
      @update:sorter="handleSorterChange"
    />
  </base-modal>
</template>
