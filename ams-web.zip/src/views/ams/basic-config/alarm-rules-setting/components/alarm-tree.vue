<script setup lang="ts">
import { CommonApis } from '@/service/apis/common/common';
import type { LevelNodeProps } from '@/service/apis/ams/basic-config/alarm-rules-setting';

const props = defineProps<{
  // 类型
  treeType: number;
}>();

const emit = defineEmits<{
  'on-checked': [node: OptionsType | LevelNodeProps | TreeOption<LevelNodeProps>];
}>();
tryOnMounted(() => {
  const type = props.treeType;
  if (type === 1) {
    byHierarchyListHandle();
  } else if (type === 2) {
    byEqpListHandle();
  } else if (type === 3) {
    bySystemHandle();
  }
});

// 按层级------------->
const byHierarchyList = ref<LevelNodeProps[]>([]);
const { isLoading: isLoadingByHierarchy, execute: executeByHierarchy } = useAxiosGet<LevelNodeProps[]>(
  CommonApis.getProductionLineLevelQueryApi
);
// 按层级获取数据
const byHierarchyListHandle = async () => {
  try {
    const { data } = await executeByHierarchy();
    byHierarchyList.value = setTreeDataLevel<LevelNodeProps>(data.value as LevelNodeProps[]) || [];
  } catch (e) {
    byHierarchyList.value = [];
  }
};
// 处理按层级数据
function setTreeDataLevel<T extends { children?: T[] }>(root: T[], level = 1): (T & { level: number })[] | undefined {
  if (!root?.length) return undefined;
  return (root || []).map((node: T) => ({
    ...node,
    level,
    isLeaf: undefined,
    children: setTreeDataLevel(node.children || [], level + 1)
  }));
}
// 处理按层级label
const byHierarchyLabel = ({ option }: { option: TreeOption }) =>
  useRenderEllipsisLabel({
    option,
    key: 'name',
    contentProps: {
      style: {
        color: option.hasDefaultLevel ? '' : option.level > 2 ? '#f56c6c' : ''
      }
    }
  });
// 按设备------------->
const byEqpList = ref<OptionsType[]>([]);
const { isLoading: isLoadingbyEqp, execute: executeByEqp } = useAxiosGet<OptionsType[]>(
  CommonApis.getEquipmentNumberListApi
);
// 按设备获取数据
const byEqpListHandle = async () => {
  try {
    const { data } = await executeByEqp();
    byEqpList.value = data.value || [];
  } catch (e) {
    byHierarchyList.value = [];
  }
};
// 处理按设备label
const byEqpLabel = ({ option }: { option: TreeOption }) => {
  option.eqpLabel = `${option.eqpType}-${option.name}`;
  return useRenderEllipsisLabel({
    option,
    key: 'eqpLabel',
    contentProps: {
      style: { color: option.hasDefaultLevel ? '' : '#f56c6c' }
    }
  });
};
// 按系统------------->
const bySystemList = ref<OptionsType[]>([]);
const bySystemSelected = ref<string[]>([]);
const { execute: executeBySystem, isLoading: isLoadingBySystem } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi
);
// 按系统获取数据
const bySystemHandle = async () => {
  try {
    const { data } = await executeBySystem();
    if (data.value) {
      bySystemList.value = data.value.filter(
        item => item.name.toLowerCase() !== 'eap' && item.name.toLowerCase() !== 'ams'
      );
      if (bySystemList.value.length === 0) return;
      bySystemSelected.value = [bySystemList.value[0].id];
      emit('on-checked', bySystemList.value[0]);
    } else {
      bySystemList.value = [];
    }
  } catch (e) {
    bySystemList.value = [];
  }
};

// 点击事件
const nodeProps = ({ option }: { option: TreeOption<LevelNodeProps> }) => {
  return {
    onClick() {
      emit('on-checked', option);
    }
  };
};
</script>

<template>
  <!-- 按层级 -->
  <base-tree
    v-if="props.treeType === 1"
    wrapper-class="h-full"
    class="h-full"
    :loading="isLoadingByHierarchy"
    :data="byHierarchyList"
    default-expand-all
    key-field="id"
    label-field="name"
    :checkable="false"
    :node-props="nodeProps"
    :render-label="byHierarchyLabel"
  />
  <!-- 按设备 -->
  <base-tree
    v-if="props.treeType === 2"
    wrapper-class="h-full"
    class="h-full"
    :loading="isLoadingbyEqp"
    :data="byEqpList"
    block-line
    key-field="id"
    label-field="name"
    :render-label="byEqpLabel"
    :node-props="nodeProps"
    :checkable="false"
    cascade
  />
  <!-- 按系统 -->
  <base-tree
    v-if="props.treeType === 3"
    wrapper-class="h-full"
    class="h-full"
    :default-selected-keys="bySystemSelected"
    :watch-props="['defaultSelectedKeys']"
    :loading="isLoadingBySystem"
    :data="bySystemList"
    block-line
    key-field="id"
    label-field="name"
    :node-props="nodeProps"
    :checkable="false"
    cascade
  />
</template>
