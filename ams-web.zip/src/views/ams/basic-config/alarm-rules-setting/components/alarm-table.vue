<script setup lang="tsx">
import { NTooltip } from 'naive-ui';
import { MESEqpStates, lotTypeList } from '../constants';
import AlarmCodeModal from './add-code-modal.vue';
import modifyRecordModel from './modify-record-model.vue';
import BaseButton from '@/components/base-ui/base-button/base-button.vue';
import { AlarmLevelRulesSettingApis } from '@/service/apis/ams/basic-config/alarm-rules-setting';
import type {
  AlarmLevelListProps,
  QueryFormType,
  SaveFormDataType,
  TableDataType,
  UserListType
} from '@/service/apis/ams/basic-config/alarm-rules-setting';
import { CommonApis } from '@/service/apis/common/common';

const props = withDefaults(
  defineProps<{
    // 查询数据
    queryForm: Nullable<QueryFormType>;
    // 是否为设备层级
    isEqpType: boolean;
    // 报警级别
    alarmLevelList: AlarmLevelListProps[];
    // 用户列表
    userList: UserListType[];
    // 系统名称
    systemNameList: OptionsType[];
  }>(),
  {
    userList: () => [],
    systemNameList: () => [],
    levelList: () => []
  }
);

const emit = defineEmits<{
  'on-search': [value: boolean];
}>();
// 不收集报警的设备状态
const { data: notGetAlarmEqpStateList, isLoading: isLoadingNotGetAlarmEqpState } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.noCollectEquipmentAlarmState
  },
  undefined,
  { immediate: true }
);
// 获取保存表单默认配置
const { execute: executeQueryDefaultConfig } = useAxiosGet<SaveFormDataType>(
  AlarmLevelRulesSettingApis.queryDefaultConfigApi
);
// 获取holdDepartment列表
const {
  data: departmentList,
  isLoading: isLoadingDepartment,
  execute: executeGetDepartmentList
} = useAxiosGet<OptionsType[]>(AlarmLevelRulesSettingApis.getHoldDepartmentListApi);
// 获取holdDepartment列表处理
const holdCodeUpdate = async (value: string) => {
  await executeGetDepartmentList({ params: { holdCode: value } });
};
// 获取holdCode列表
const {
  data: hodeCodeList,
  isLoading: isLoadingHodeCode,
  execute: executeGetHodeCodeList
} = useAxiosGet<OptionsType[]>(AlarmLevelRulesSettingApis.getHodeCodeListApi);
// 获取机台状态列表
const {
  data: holdEqpStateList,
  isLoading: isLoadingHoldEqpState,
  execute: executeGetHoldEqpStateList
} = useAxiosGet<OptionsType[]>(CommonApis.getSelectItemListApi);

// 按系统报警级别判定
const { execute: executeHoldInfoSelectType } = useAxiosGet<{
  selectType: number;
}>(AlarmLevelRulesSettingApis.getHoldInfoSelectTypeApi);
// 锁机类型
const selectItemListObj = reactive<{ [key: number]: SelectOption[] }>({});
const { execute: executeGetSelectItemList } = useAxiosGet<SelectOption[]>(CommonApis.getSelectItemListApi);

const { hasAddPermission, hasEditPermission } = useRoutes();
const userStore = useUserStore();
const { systemPermissions } = storeToRefs(userStore);
const eqpModel = computed<string>(() => props.queryForm.eqpModel || '');
const category = computed<number>(() => props.queryForm.category || 1);
watch(
  () => props.queryForm,
  () => {
    // console.log(props.queryForm, '-----');
    if (!props.queryForm.eqpModel) return;
    renderData();
    executeGetHodeCodeList();
    executeGetHoldEqpStateList({
      params: {
        type: AttributeType.holdEqpState
      }
    });
    if (props.queryForm.category === 3) return;
    getStructureInfo({
      category: props.queryForm.category || 1,
      eqpModel: props.queryForm.eqpModel
    });
  },
  { immediate: true }
);

// Eqp类型验证并获取保存表单默认配置
const getStructureInfo = async ({ eqpModel, category }: { eqpModel: string; category: number }) => {
  const { data } = await executeQueryDefaultConfig({ params: { eqpModel, category } });
  resetField();
  updateField(data.value);
};
// 保存表单------------------------>
const {
  formData,
  updateField,
  resetField,
  validate,
  formRef: saveFormRefs
} = useForm<Nullable<SaveFormDataType>>({
  defaultLevel: null,
  effectiveTime: null,
  noAlarmEqpStates: [],
  repeatCount: null,
  upInterval: null,
  removeDuplicateInterval: null
});
const saveFormSchemas = computed<FormSchemaType>(() => [
  // 默认级别
  {
    type: 'select',
    model: 'defaultLevel',
    formItemProps: {
      label: i18nt('defaultLevel')
    },
    componentClass: 'w-180px!',
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: props.alarmLevelList,
      renderOption: ({ node, option }: { node: VNode; option: SelectOption }) =>
        h(NTooltip, null, {
          trigger: () => node,
          default: () => option.name
        })
    }
  },
  // 报警触发次数
  {
    type: 'input-number',
    model: 'repeatCount',
    formItemProps: {
      label: i18nt('repeatCount')
    },
    componentClass: 'w-180px!',
    componentProps: {
      precision: 0,
      min: 1,
      max: 999
    }
  },
  // 有效时间秒
  {
    type: 'input-number',
    model: 'effectiveTime',
    formItemProps: {
      label: i18nt('effectiveTime', { val: `(${i18nt('second')})` })
    },
    componentClass: 'w-180px!',
    componentProps: {
      precision: 0,
      min: 0,
      max: 9999
    }
  },
  // 去重间隔
  {
    type: 'input-number',
    model: 'removeDuplicateInterval',
    formItemProps: {
      showFeedback: true,
      labelWidth: 120,
      label: `${i18nt('deDuplicationInterval')}(${i18nt('minute')})`,
      rule: useRuleNumberSize(0, 9999)
    },
    componentClass: 'w-180px!',
    componentProps: { min: 0, max: 9999, precision: 0 }
  },
  // 上报时间
  {
    type: 'input-number',
    model: 'upInterval',
    formItemProps: {
      showFeedback: true,
      labelWidth: 120,
      label: i18nt('reportInterval', { val: `(${i18nt('minute')})` }),
      rule: useRuleNumberSize(5, 720)
    },
    componentClass: 'w-180px!',
    componentProps: { min: 0, precision: 0 }
  },
  // 不收集报警的设备状态
  {
    type: 'select',
    model: 'noAlarmEqpStates',
    formItemProps: {
      label: i18nt('notGetAlarmEqpState'),
      labelWidth: 160
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: notGetAlarmEqpStateList.value,
      loading: isLoadingNotGetAlarmEqpState.value,
      multiple: true
    }
  }
]);
// 顶部表单保存按钮
const handleSaveDefaultConfig = async () => {
  try {
    await validate();
    if (tableData.value?.length) {
      updateField({
        repeatCount: formData.value.repeatCount || 1,
        effectiveTime: formData.value.effectiveTime || null
      });
      const dialog = $dialog.warning({
        title: i18nt('tips'),
        content: i18nt('overwriteExistingSettings'),
        negativeText: i18nt('no'),
        positiveText: i18nt('yes'),
        onPositiveClick: () => {
          try {
            dialog.loading = true;
            onSaveDefaultConfig(1);
          } catch (error) {
            console.log('base-curd handleDialogDelete：异常', error);
            return false;
          } finally {
            dialog.loading = false;
          }
        },
        onNegativeClick: () => {
          try {
            dialog.loading = true;
            onSaveDefaultConfig(0);
          } catch (error) {
            console.log('base-curd handleDialogDelete：异常', error);
            return false;
          }
        }
      });
    } else {
      onSaveDefaultConfig(undefined);
    }
  } catch (error) {
    console.log(error);
  }
};
// 保存默认配置接口处理
const { execute: executeSaveDefaultConfig } = useAxiosPost(AlarmLevelRulesSettingApis.saveDefaultConfigApi);
const onSaveDefaultConfig = async (isBatchUpdate: number | undefined) => {
  try {
    await executeSaveDefaultConfig({
      data: {
        ...formData.value,
        eqpModel: eqpModel.value,
        category: category.value,
        isBatchUpdate
      }
    });
    renderData();
  } catch (error) {
    console.log(error);
  }
};
// 右侧表格------------------------>
// 右侧表格传参
const queryForm = computed(() => {
  return {
    ...props.queryForm,
    eqpModel: category.value === 3 ? null : props.queryForm.eqpModel,
    systemName: category.value === 3 ? props.queryForm.eqpModel : props.queryForm.systemName
  };
});
// 获取表格数据
const { handleSorterChange, pagination, isLoadingQuery, tableData, executeQueryList, tableRef } = useTable<
  TableDataType[]
>(AlarmLevelRulesSettingApis.getListApi, {
  queryFormParams: queryForm
});
watch(
  isLoadingQuery,
  newValue => {
    emit('on-search', newValue);
  },
  { immediate: true }
);
const scrollX = ref<string | number>();
// 右侧表格公共内容
const tableColumns = computed(() => {
  // 锁机类型根据登录获取来显隐chamberPortConfig 1展示 chamberPortConfig true展示port或者chmber值
  return tableHandle(
    category.value,
    systemPermissions.value?.chamberPortConfigOpen,
    systemPermissions.value?.isShowChamberPortList,
    systemPermissions.value?.isHiddenHoldInfo,
    systemPermissions.value?.isHiddenRemoveDuplicate,
    systemPermissions.value?.isHiddenIgnoreEqpStatusSwitch
  );
});
const tableHandle = (
  category: number,
  chamberPortConfigOpen?: number,
  isShowChamberPortList?: boolean,
  isHiddenHoldInfo?: boolean,
  isHiddenRemoveDuplicate?: boolean,
  isHiddenIgnoreEqpStatusSwitch?: boolean
) => {
  scrollX.value =
    category === 3
      ? TABLE_WIDTH_SCROLL_SMALL
      : chamberPortConfigOpen === 1
        ? TABLE_WIDTH_SCROLL_MIDDLE
        : TABLE_WIDTH_SCROLL_SMALL + 350;
  return (
    [
      { type: 'selection' },
      useRenderTableIndex(pagination),
      // 收集报警
      category !== 3
        ? {
            title: i18nt('collectAlarms'),
            key: 'isSave',
            sorter: true,
            width: TABLE_WIDTH_STATE,
            render(row) {
              return isIsShowEdit(row) ? (
                <base-switch
                  checked-value={1}
                  on-updateValue={() => {
                    rowForm.value.isIgnoreEqpStatus = 0;
                  }}
                  unchecked-value={0}
                  v-model:value={rowForm.value.isSave}
                />
              ) : (
                <base-switch checked-value={1} disabled={true} unchecked-value={0} v-model:value={row.isSave} />
              );
            }
          }
        : __,
      // 收集过滤报警
      category !== 3
        ? isHiddenIgnoreEqpStatusSwitch
          ? __
          : {
              title: i18nt('collectAndFilterAlarms'),
              key: 'isIgnoreEqpStatus',
              sorter: true,
              width: TABLE_WIDTH_DATE,
              render(row) {
                return isIsShowEdit(row) ? (
                  <base-switch
                    checked-value={1}
                    disabled={!rowForm.value.isSave}
                    unchecked-value={0}
                    v-model:value={rowForm.value.isIgnoreEqpStatus}
                  />
                ) : (
                  <base-switch
                    checked-value={1}
                    disabled={true}
                    unchecked-value={0}
                    v-model:value={row.isIgnoreEqpStatus}
                  />
                );
              }
            }
        : __,
      // 报警代码
      {
        title: i18nt('alarmCode'),
        key: 'alarmId',
        sorter: true,
        width: TABLE_WIDTH_DATETIME,
        render(row) {
          return isIsShowEdit(row) ? (
            <div class="inputItem">
              <base-input
                clearable
                maxlength="30"
                onInput={(value: string) => rowInput(1, value)}
                showCount
                type="text"
                v-model:value={rowForm.value.alarmId}
              />
              {rowRules(rowForm.value.alarmIdVerify || false, i18nt('baseForm.pleaseInput') + i18nt('alarmCode'))}
            </div>
          ) : (
            <span>{row.alarmId}</span>
          );
        }
      },
      // 报警级别
      {
        title: i18nt('alarmLevel'),
        key: 'alarmLevel',
        ellipsis: false,
        width: TABLE_WIDTH_DATETIME,
        render(row) {
          const level = props.alarmLevelList?.find(level => level.id === row.alarmLevel);
          return isIsShowEdit(row) ? (
            <div class="inputItem">
              <base-select
                class="w-100%!"
                clearable
                filterable
                label-field="name"
                onUpdateValue={async (value: string) => {
                  try {
                    const { data } = await executeHoldInfoSelectType({ params: { id: value } });
                    if (!data.value) return;
                    rowForm.value.alarmLevel = value;

                    rowForm.value.holdInfoSelectType = data.value.selectType;
                    rowForm.value.holdCode = null;
                    rowForm.value.holdDepartment = null;
                    rowForm.value.holdEqpState = null;

                    rowForm.value.lotType = null;
                    rowForm.value.lotPortListInfo = [];
                    rowForm.value.lotChamberListInfo = [];
                    rowForm.value.lotTypeVerify = false;
                    rowForm.value.lotPortListInfoVerify = false;
                    rowForm.value.lotChamberListInfoVerify = false;
                  } catch (error) {
                    console.log(error);
                  }
                }}
                options={props.alarmLevelList}
                placeholder={`${i18nt('baseForm.pleaseSelect')}${i18nt('alarmLevel')}`}
                value={rowForm.value.alarmLevel}
                value-field="id"
              />
            </div>
          ) : (
            <span>{level?.name}</span>
          );
        }
      },
      // Hold相关信息
      !isHiddenHoldInfo
        ? {
            title: i18nt('relevantInformation'),
            key: 'relevantInformation',
            width: QRCODE_SIZE * 2,
            render(row) {
              return isIsShowEdit(row) ? (
                <div class="flex w-100%!">
                  {rowForm.value.holdInfoSelectType === 1 || rowForm.value.holdInfoSelectType === 3 ? (
                    <div class="flex w-66%!">
                      <base-select
                        class="w-100%!"
                        label-field="name"
                        loading={isLoadingHodeCode.value}
                        onUpdateValue={(value: string) => {
                          rowForm.value.holdDepartment = null;
                          rowForm.value.holdCode = value;
                          holdCodeUpdate(value);
                        }}
                        options={hodeCodeList.value}
                        placeholder={`${i18nt('baseForm.pleaseSelect')}Hold Code`}
                        value={rowForm.value.holdCode}
                        value-field="id"
                      />
                      {rowForm.value.holdCode ? (
                        <base-select
                          class="w-100%! ml"
                          label-field="name"
                          loading={isLoadingDepartment.value}
                          options={departmentList.value}
                          placeholder={`${i18nt('baseForm.pleaseSelect')}Hold Department`}
                          v-model:value={rowForm.value.holdDepartment}
                          value-field="id"
                        />
                      ) : (
                        ''
                      )}
                    </div>
                  ) : (
                    ''
                  )}
                  {rowForm.value.holdInfoSelectType === 2 || rowForm.value.holdInfoSelectType === 3 ? (
                    <div class="w-33% ml">
                      <base-select
                        class="w-100%!"
                        label-field="name"
                        loading={isLoadingHoldEqpState.value}
                        options={holdEqpStateList.value}
                        placeholder={i18nt('baseForm.pleaseSelect') + i18nt('machineState')}
                        v-model:value={rowForm.value.holdEqpState}
                        value-field="id"
                      />
                    </div>
                  ) : (
                    ''
                  )}
                </div>
              ) : (
                <span>
                  {row.holdCode ? useRenderTableTag([row.holdCode]) : ''}
                  {row.holdDepartment ? useRenderTableTag([row.holdDepartment]) : ''}
                  {row.holdEqpState ? useRenderTableTag([row.holdEqpState]) : ''}
                </span>
              );
            }
          }
        : __,
      // 锁机类型
      chamberPortConfigOpen === 1
        ? {
            title: i18nt('lockType'),
            key: 'lotType',
            ellipsis: false,
            width: TABLE_WIDTH_INFO * 2,
            render(row) {
              const type: { id: number; name: string } | undefined = lotTypeList.find(type => type.id === row.lotType);
              const defaultDisabled = (props.alarmLevelList || []).find(
                opt => opt.id === rowForm.value.alarmLevel
              )?.isShowLotConfig;
              return isIsShowEdit(row) ? (
                <div class="inputItem">
                  <div class="inputItem1">
                    <base-select
                      class="w-120px! mr"
                      clearable
                      disabled={!defaultDisabled}
                      filterable
                      label-field="name"
                      onUpdateValue={async (value: number) => {
                        rowInput(4, value);
                        rowForm.value.lotType = value;
                        rowForm.value.lotPortListInfo = [];
                        rowForm.value.lotChamberListInfo = [];
                        if (isShowChamberPortList) {
                          rowForm.value.lotPortListInfoVerify = value === 2;
                          rowForm.value.lotChamberListInfoVerify = value === 3;
                        }

                        if (value !== 1 && !selectItemListObj[value]) {
                          const res = await executeGetSelectItemList({ params: { type: MESEqpStates[value] } });
                          selectItemListObj[value] = res.data.value || [];
                        }
                      }}
                      options={lotTypeList}
                      value={rowForm.value.lotType}
                      value-field="id"
                    />
                    {isShowChamberPortList &&
                      rowForm.value.lotType &&
                      lockTypeComponents[rowForm.value.lotType as number](
                        selectItemListObj[rowForm.value.lotType as number]
                      )}
                  </div>
                  {rowForm.value.alarmLevel
                    ? rowRules(rowForm.value.lotTypeVerify || false, i18nt('baseForm.pleaseSelect') + i18nt('lockType'))
                    : ''}
                </div>
              ) : (
                <div class="flex items-center">
                  <span>{type?.name}</span>
                  {useRenderTableTag(row.lotPortListInfo || [])}
                  {useRenderTableTag(row.lotChamberListInfo || [])}
                </div>
              );
            }
          }
        : __,
      // 通知用户
      {
        title: i18nt('notifiedUsers'),
        key: 'notifiedUsers',
        width: TABLE_WIDTH_DATE * 2,
        render(row) {
          return isIsShowEdit(row) ? (
            <base-tree-select
              cascade
              checkable
              class="w-100%!"
              key-field="id"
              label-field="name"
              multiple
              onUpdateValue={(value: string[], item: UserListType[]) => {
                rowForm.value.notifiedUsers = item.filter(ele => ele && !ele.children).map(ele => ele.id);
              }}
              options={props.userList}
              value={rowForm.value.notifiedUsers}
            />
          ) : (
            useRenderTableTag(row.notifiedUserNames)
          );
        }
      },
      // // 报警描述
      category !== 3
        ? {
            title: i18nt('alarmDescription'),
            key: 'description',
            sorter: true,
            width: QRCODE_SIZE,
            render(row) {
              return isIsShowEdit(row) ? (
                <div class="inputItem">
                  <base-input
                    clearable
                    maxlength="200"
                    showCount
                    type="text"
                    v-model:value={rowForm.value.description}
                  />
                </div>
              ) : (
                <span>{row.description}</span>
              );
            }
          }
        : __,
      // 系统名称
      category !== 3
        ? {
            title: i18nt('systemName'),
            key: 'systemName',
            ellipsis: false,
            width: TABLE_WIDTH_NAME,
            render(row) {
              return isIsShowEdit(row) ? (
                <div class="inputItem">
                  <base-select
                    class="w-100%!"
                    clearable
                    label-field="name"
                    onUpdateValue={(value: string) => {
                      rowForm.value.repeatCount = 1;
                      rowForm.value.effectiveTime = null;
                      rowForm.value.removeDuplicateInterval = null;
                      rowForm.value.systemName = value;
                      rowInput(2, value);
                    }}
                    options={props.systemNameList}
                    value={rowForm.value.systemName}
                    value-field="id"
                  />
                  {rowRules(
                    rowForm.value.systemNameVerify || false,
                    i18nt('baseForm.pleaseSelect') + i18nt('systemName')
                  )}
                </div>
              ) : (
                <span>{row.systemName}</span>
              );
            }
          }
        : __,
      // 报警触发次数
      category !== 3
        ? {
            title: i18nt('repeatCount'),
            key: 'repeatCount',
            sorter: true,
            width: TABLE_WIDTH_NAME,
            render(row) {
              return isIsShowEdit(row) ? (
                <div class="inputItem">
                  <base-input-number
                    class="w-100%!"
                    clearable
                    disabled={systemNameHandle(rowForm.value.systemName)}
                    max={999}
                    min={0}
                    precision={0}
                    showButton={false}
                    v-model:value={rowForm.value.repeatCount}
                  />
                </div>
              ) : (
                <span>{row.repeatCount}</span>
              );
            }
          }
        : __,
      // 有效时间
      category !== 3
        ? {
            title: i18nt('effectiveTime', { val: `(${i18nt('second')})` }),
            key: 'effectiveTime',
            sorter: true,
            width: TABLE_WIDTH_NAME,
            render(row) {
              return isIsShowEdit(row) ? (
                <div class="inputItem">
                  <base-input-number
                    class="w-100%!"
                    clearable
                    disabled={systemNameHandle(rowForm.value.systemName)}
                    max={9999}
                    min={0}
                    precision={0}
                    showButton={false}
                    v-model:value={rowForm.value.effectiveTime}
                  />
                </div>
              ) : (
                <span>{row.effectiveTime}</span>
              );
            }
          }
        : __,
      // 去重时间
      category !== 3
        ? isHiddenRemoveDuplicate
          ? __
          : {
              title: `${i18nt('deDuplicationInterval')}(${i18nt('minute')})`,
              key: 'removeDuplicateInterval',
              sorter: true,
              width: TABLE_WIDTH_INFO,
              render(row) {
                return isIsShowEdit(row) ? (
                  <div class="inputItem">
                    <base-input-number
                      class="w-100%!"
                      clearable
                      disabled={systemNameHandle(rowForm.value.systemName)}
                      max={9999}
                      min={0}
                      precision={0}
                      showButton={false}
                      v-model:value={rowForm.value.removeDuplicateInterval}
                    />
                  </div>
                ) : (
                  <span>{row.removeDuplicateInterval}</span>
                );
              }
            }
        : __,
      // 上报时间
      category !== 3
        ? {
            title: i18nt('reportInterval', { val: `(${i18nt('minute')})` }),
            key: 'upInterval',
            sorter: true,
            width: TABLE_WIDTH_NAME + 20,
            render(row) {
              const min = 5;
              const max = 720;
              return isIsShowEdit(row) ? (
                <div class="inputItem">
                  <base-input-number
                    class="w-100%!"
                    clearable
                    min={0}
                    onUpdateValue={(value: number) => {
                      rowInput(3, value);
                      rowForm.value.upInterval = value;
                    }}
                    precision={0}
                    showButton={false}
                    value={rowForm.value.upInterval}
                  />
                  {rowRules(rowForm.value.upIntervalVerify || false, i18nt('rules.sizeRule', { min, max }))}
                </div>
              ) : (
                <span>{row.upInterval ? row.upInterval : ''}</span>
              );
            }
          }
        : __,
      { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
      { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
      // 操作
      useRenderTableActionColumn({
        width: TABLE_WIDTH_DATE,
        render(row) {
          return (
            <div class="inputItem">
              {isIsShowEdit(row) ? (
                <div class="flex ">
                  <base-button class="mr" onClick={() => tableCancel()} text type="primary">
                    {i18nt('cancel')}
                  </base-button>
                  <base-button onClick={() => tableSave()} text type="primary">
                    {i18nt('save')}
                  </base-button>
                </div>
              ) : (
                <div class="flex ">
                  <base-button
                    class="mr"
                    disabled={!hasEditPermission.value || rowForm.value.id !== null}
                    onClick={() => tableEdit(row)}
                    text
                    type="primary"
                  >
                    {i18nt('edit')}
                  </base-button>
                  <base-button onClick={() => modifyRecordCLick(row)} text type="primary">
                    {i18nt('modifyRecord')}
                  </base-button>
                </div>
              )}
            </div>
          );
        }
      })
    ] as DataTableColumns<TableDataType>
  ).filter(item => item);
};
const lockTypeComponents: Record<number, (options: SelectOption[]) => VNode | null> = {
  1: () => null,
  2: (options: SelectOption[]) => {
    return (
      <div class="inputItem">
        <base-select
          class="w-100px!"
          clearable
          filterable
          label-field="name"
          multiple
          onUpdateValue={(value: string[]) => {
            rowForm.value.lotPortListInfo = value;
            rowInput(5, value);
          }}
          options={options}
          value={rowForm.value.lotPortListInfo}
          value-field="id"
        />
        {rowRules(rowForm.value.lotPortListInfoVerify || false, `${i18nt('baseForm.pleaseSelect')}port`)}
      </div>
    );
  },
  3: (options: SelectOption[]) => {
    return (
      <div class="inputItem">
        <base-select
          class="w-100px!"
          clearable
          filterable
          label-field="name"
          multiple
          onUpdateValue={(value: string[]) => {
            rowForm.value.lotChamberListInfo = value;
            rowInput(6, value);
          }}
          options={options}
          value={rowForm.value.lotChamberListInfo}
          value-field="id"
        />
        {rowRules(rowForm.value.lotChamberListInfoVerify || false, `${i18nt('baseForm.pleaseSelect')}chamber`)}
      </div>
    );
  }
};
// 系统名称选中处理
const systemNameHandle = (item: string | null) => {
  return !(item?.toUpperCase() === 'EAP' || item?.toUpperCase() === 'AMS');
};
// 初始化表格行表单
const initRowForm = (): Nullable<TableDataType> => {
  return {
    id: null,
    isSave: null,
    isIgnoreEqpStatus: null,
    alarmLevel: null,
    alarmId: null,
    systemName: null,
    upInterval: null,
    holdInfoSelectType: null,
    holdCode: null,
    holdDepartment: null,
    holdEqpState: null,
    lotType: null,
    lotPortListInfo: null,
    lotChamberListInfo: null,
    notifiedUserIds: null,
    notifiedUsers: null,
    notifiedUserNames: null,
    description: null,
    repeatCount: null,
    effectiveTime: null,
    removeDuplicateInterval: null,

    alarmIdVerify: null,
    systemNameVerify: null,
    upIntervalVerify: null,
    lotPortListInfoVerify: null,
    lotChamberListInfoVerify: null,
    lotTypeVerify: null
  };
};
const rowForm = ref<Nullable<TableDataType>>(initRowForm());
// 必填项
const rowRules = (isShow: boolean, item: string) => {
  return (
    <div
      class="slotError"
      style={{
        display: isShow ? 'block' : 'none'
      }}
    >
      {item}
    </div>
  );
};
// 表格输入框验证
const rowInput = (type: number, value: string | number | string[]) => {
  switch (type) {
    case 1:
      rowForm.value.alarmIdVerify = !value;
      break;
    case 2:
      rowForm.value.systemNameVerify = !value;
      break;
    case 3:
      rowForm.value.upIntervalVerify = value ? !!(Number(value) < 5 || Number(value) > 720) : false;
      break;
    case 4:
      rowForm.value.lotTypeVerify = rowForm.value.alarmLevel ? !value : false;
      break;
    case 5:
      if (!Array.isArray(value)) return;
      rowForm.value.lotPortListInfoVerify = rowForm.value.lotType === 2 ? value.length === 0 : false;
      break;
    case 6:
      if (!Array.isArray(value)) return;
      rowForm.value.lotChamberListInfoVerify = rowForm.value.lotType === 3 ? value.length === 0 : false;
      break;
    default:
      break;
  }
};
// 是否编辑状态
const isIsShowEdit = (row: TableDataType) => row.id === rowForm.value.id;
// 表格编辑
const tableEdit = async (row: TableDataType) => {
  const { data: holdInfoSelectTypeData } = await executeHoldInfoSelectType({ params: { id: row.alarmLevel } });
  if (!holdInfoSelectTypeData.value) return;
  row.holdInfoSelectType = holdInfoSelectTypeData.value.selectType;

  rowForm.value = {
    ...initRowForm(),
    ...cloneDeep(row)
  };
  rowForm.value = {
    ...rowForm.value,
    notifiedUsers: rowForm.value.notifiedUserIds
  };
  const res = await executeGetSelectItemList({ params: { type: MESEqpStates[row.lotType as number] } });
  selectItemListObj[row.lotType as number] = res.data.value || [];
  holdCodeUpdate(rowForm.value.holdCode || '');
};
// 修改历史记录
const modifyRecordModelRef = ref();
const modifyRecordCLick = ({ id }: { id: string }) => {
  modifyRecordModelRef?.value?.handleOpenModal(id);
};
// 表格取消
const tableCancel = () => {
  rowForm.value = { ...initRowForm() };
};
// 表格更新(保存)
const { execute: executeUpdate } = useAxiosPost(AlarmLevelRulesSettingApis.handleUpdateApi);
const tableSave = async () => {
  if (rowForm.value.alarmIdVerify || rowForm.value.systemNameVerify || rowForm.value.upIntervalVerify) return;
  if (systemPermissions.value?.chamberPortConfigOpen === 1) {
    if (rowForm.value.lotTypeVerify) return;
    if (systemPermissions.value.isShowChamberPortList) {
      if (rowForm.value.lotPortListInfoVerify || rowForm.value.lotChamberListInfoVerify) return;
    }
  }
  try {
    await executeUpdate({
      data: {
        ...rowForm.value
      }
    });
    rowForm.value = { ...initRowForm() };
    executeQueryList();
  } catch (error) {
    console.log(error);
  }
};
// 按钮点击
const handleButtons = (permission: PermissionType, resolve?: AsyncEmitResolveType) => {
  const permissionAction: PermissionActionType = {
    add: handleAddAlarmCode,
    delete: () => handleDelete(resolve),
    export: handleExport,
    download: handleDownload,
    import: () => {
      // 选择机台或设备才允许查询
      if (props.isEqpType) {
        renderData();
      }
    }
  };
  permissionAction[permission as PermissionType]?.();
};
// 新增报警代码
const alarmModalRef = ref();
const handleAddAlarmCode = () => {
  alarmModalRef.value.handleOpenModal({
    eqpModel: eqpModel.value,
    category: category.value
  });
};
// 表格删除
const { execute: executeDelete } = useAxiosPost(AlarmLevelRulesSettingApis.handleDeleteApi);
const handleDelete = async (resolve?: AsyncEmitResolveType) => {
  try {
    await executeDelete({ data: { ids: tableRef.value?.selectedKeys } });
    resolve?.(true);
    renderData();
  } catch (error) {
    console.log(error);
    resolve?.(false);
  }
};
// 下载
const handleDownload = () => {
  category.value === 3 ? executeSystemDownload() : executeDownload();
};
const { execute: executeDownload, isLoading: isLoadingDownload } = useDownloadFile(
  AlarmLevelRulesSettingApis.getTemplateApi
);
const { execute: executeSystemDownload, isLoading: isLoadingSystemDownload } = useDownloadFile(
  AlarmLevelRulesSettingApis.getSystemTemplateApi
);
// 导出
const { execute: executeExport, isLoading: isLoadingExport } = useDownloadFile(AlarmLevelRulesSettingApis.getListApi);
// 全部导出
const handleExport = () => {
  executeExport({
    ...queryForm.value
  });
};
// 导入按钮api
const importApiHandle = computed(() => {
  return category.value === 3
    ? AlarmLevelRulesSettingApis.importSystemMaterialCategoryApi
    : AlarmLevelRulesSettingApis.importMaterialCategoryApi;
});
provide('importApi', importApiHandle);

// 刷新
const renderData = async () => {
  rowForm.value = { ...initRowForm() };
  pagination.value.page = 1;
  await executeQueryList();
  tableRef?.value?.selectedKeys?.length && tableRef.value?.clearSelected();
};
// 重置表格组件一切
const alarmReset = () => {
  resetField();
  tableData.value = [];
};
defineExpose({
  alarmReset
});
</script>

<template>
  <div class="mt">
    <!-- 保存表单 -->
    <base-form
      v-if="category !== 3"
      ref="saveFormRefs"
      v-model="formData"
      :schemas="saveFormSchemas"
      layout="page"
      :row-limit-number="10"
      :label-width="100"
    >
      <template #header-action>
        <base-space v-if="props.isEqpType" :wrap-item="false">
          <base-button v-if="hasAddPermission" type="primary" button-name="save" @click="handleSaveDefaultConfig">
            <template #default> {{ $t('save') }} </template>
          </base-button>
        </base-space>
      </template>
    </base-form>
    <base-divider v-if="category !== 3" class="mb-0! mt!" />
    <!-- 保存表格 -->
    <base-table
      ref="tableRef"
      :columns="tableColumns"
      :data="tableData"
      :pagination="pagination"
      :loading="isLoadingQuery"
      remote
      :scroll-x="scrollX"
      @update:sorter="handleSorterChange"
    >
      <template #header>
        <div v-if="props.isEqpType" class="flex flex-col">
          <permission-button
            :loading-props="{
              searchLoading: false,
              exportLoading: isLoadingExport,
              downloadLoading: category === 3 ? isLoadingSystemDownload : isLoadingDownload
            }"
            :ignore-permission-list="['edit', 'search', 'reset']"
            :select-length="tableRef?.selectedKeys?.length"
            @import-success="handleButtons('import')"
            @handle="handleButtons"
          />
        </div>
      </template>
    </base-table>
    <!-- 修改记录 -->
    <modifyRecordModel ref="modifyRecordModelRef" />
    <!-- 新增 -->
    <alarm-code-modal ref="alarmModalRef" @render-data="renderData" />
  </div>
</template>

<style scoped lang="less">
:deep(.n-data-table-td) {
  .n-ellipsis {
    width: 100%;
  }
  .inputItem {
    display: flex;
    flex-direction: column;
    .slotError {
      color: #f56c6c;
      font-size: 12px;
      height: 15px;
      line-height: 15px;
      text-align: left;
      margin-top: 4px;
      margin-left: 2px;
    }
    button {
      height: 26px !important;
    }
  }
  .inputItem1 {
    display: flex;
    flex-direction: row;
  }
}
</style>
