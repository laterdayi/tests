<script setup lang="ts">
import { collectAlarms, userListEmptyHandle } from './constants';
import AlarmTree from './components/alarm-tree.vue';
import AlarmTable from './components/alarm-table.vue';
import { AlarmCountStatisticsApis } from '@/service/apis/ams/query-statistics/alarm-count-statistics';
import { AlarmLevelRulesSettingApis } from '@/service/apis/ams/basic-config/alarm-rules-setting';
import type {
  AlarmLevelListProps,
  LevelNodeProps,
  QueryFormType,
  UserListType
} from '@/service/apis/ams/basic-config/alarm-rules-setting';
import { CommonApis } from '@/service/apis/common/common';

// 获取报警级别
const { data: alarmLevelList, isLoading: isLoadingAlarmLevel } = useAxiosGet<AlarmLevelListProps[]>(
  AlarmCountStatisticsApis.getAlarmLevelListApi,
  undefined,
  undefined,
  { immediate: true }
);
// 获取通知用户(层级设备)
const userList = ref<UserListType[]>([]);
const { isLoading: isLoadingUsers, execute: executeGetNotifyUsers } = useAxiosGet<UserListType[]>(
  AlarmLevelRulesSettingApis.getNotifyUsersApi
);
// 获取系统名称
const {
  data: systemNameList,
  execute: executeSystemNameList,
  isLoading: isLoadingSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);
// 右侧表格
const alarmTableRef = ref();

tryOnMounted(() => {
  systemNameListHandle();
});

// 左侧切换点击
const categoryChange = (value: number) => {
  resetField();
  updateField({
    eqpModel: null,
    category: value
  });
  isEqpType.value = false;
  alarmTableRef.value?.alarmReset();
};
// 判断是否是设备
const { execute: executeIsEqpType } = useAxiosGet<boolean>(AlarmLevelRulesSettingApis.getIsEqpTypeApi);
const isEqpType = ref(false);
// 左侧组件点击
const onChecked = async (node: TreeOption<LevelNodeProps>) => {
  // console.log(node, '侧边点击');
  try {
    if (formData.value.category === 1) {
      const { data } = await executeIsEqpType({ params: { layoutId: node.id } });
      isEqpType.value = !!data.value;
    } else {
      isEqpType.value = true;
    }
    updateField({
      eqpModel: node.id,
      category: formData.value.category
    });
    userListHandle(node.id);
  } catch (error) {
    isEqpType.value = false;
    formData.value.eqpModel = null;
  }
};
// 通知用户(层级设备)获取
const userListHandle = async (id?: string) => {
  try {
    const { data } = await executeGetNotifyUsers({
      params: {
        category: formData.value.category,
        eqpModel: id,
        systemName: formData.value.category === 3 ? id : null
      }
    });
    if (!data.value) return;
    userList.value = userListEmptyHandle(data.value);
  } catch (error) {
    console.log(error);
  }
};
// 获取系统名称
const systemNameListHandle = async () => {
  try {
    const { data } = await executeSystemNameList();
    if (!data.value) return;
    systemNameList.value = data.value;
  } catch (error) {
    systemNameList.value = [];
  }
};

// 右侧查询loading
const searchLoading = ref(false);
// 查询表单
const {
  formData,
  resetField,
  updateField
} = useForm<Nullable<QueryFormType>>({
  isSave: null,
  alarmId: null,
  alarmLevel: null,
  user: null,
  alarmDesc: null,
  category: 1,
  systemName: null
  // eqpModel: null
});
const queryFormSchemas = computed<FormSchemaType>(() => [
  // 收集报警
  formData.value.category !== 3
    ? {
        type: 'select',
        model: 'isSave',
        formItemProps: {
          label: i18nt('collectAlarms')
        },
        componentProps: {
          valueField: 'id',
          labelField: 'name',
          options: collectAlarms
        }
      }
    : __,
  // 报警代码
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: {
      label: i18nt('alarmCode')
    },
    componentProps: {
      replaceSpace: false
    }
  },
  // 报警级别
  {
    type: 'select',
    model: 'alarmLevel',
    formItemProps: {
      label: i18nt('alarmLevel')
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingAlarmLevel.value,
      options: alarmLevelList.value
    }
  },
  // 通知用户
  formData.value.category !== 3
    ? {
        type: 'tree-select',
        model: 'user',
        formItemProps: { label: i18nt('notifiedUsers') },
        componentProps: {
          loading: isLoadingUsers.value,
          options: userList.value,
          labelField: 'name',
          keyField: 'id'
        }
      }
    : __,
  // 系统名称
  formData.value.category !== 3
    ? {
        type: 'select',
        model: 'systemName',
        formItemProps: {
          label: i18nt('systemName')
        },
        componentProps: {
          valueField: 'id',
          labelField: 'name',
          loading: isLoadingSystemNameList.value,
          options: systemNameList.value
        }
      }
    : __,
  // 报警描述
  {
    type: 'input',
    model: 'alarmDesc',
    formItemProps: {
      label: i18nt('alarmDescription')
    },
    componentProps: {
      replaceSpace: false
    }
  }
]);

// 右侧查询/重置 按钮点击
const handleButtons = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    search: () => {
      if (!isEqpType.value) {
        $message.error(`${i18nt('baseForm.pleaseSelect')}${i18nt('levelOrEquipment')}`);
        return;
      }
      updateField({ ...formData.value });
    },
    reset: () => {
      resetField();
    }
  };
  permissionAction[permission as PermissionType]?.();
};
const handleTableQuery = (loading: boolean) => {
  searchLoading.value = loading;
};
</script>

<template>
  <div id="alarm-rules-setting" class="flex layout-content-page-vh">
    <base-card class="mr" :class="[`w-${TREE_WIDTH_CONTAINER}px!`]" :content-style="{ height: '100%' }">
      <!-- 左侧树   -->
      <base-tabs
        class="h-full"
        pane-class="h-[calc(100%-var(--n-pane-padding-top))]"
        pane-wrapper-class="h-full"
        type="line"
        :value="formData.category || 1"
        @update:value="categoryChange"
      >
        <!-- 按层级 -->
        <n-tab-pane :name="1" :tab="i18nt('byHierarchy')">
          <alarm-tree :tree-type="1" @on-checked="onChecked" />
        </n-tab-pane>
        <!-- 按设备 -->
        <n-tab-pane :name="2" :tab="i18nt('byEqp')">
          <alarm-tree :tree-type="2" @on-checked="onChecked" />
        </n-tab-pane>
        <!-- 按系统 -->
        <n-tab-pane :name="3" :tab="i18nt('bySystem')">
          <alarm-tree :tree-type="3" @on-checked="onChecked" />
        </n-tab-pane>
        <template #suffix>
          <base-popover trigger="hover" placement="bottom">
            <template #trigger>
              <base-icon class="cursor-pointer" icon="i-carbon:help" />
            </template>
            <span>{{ $t('alarmRulesTip') }}</span>
          </base-popover>
        </template>
      </base-tabs>
    </base-card>
    <!-- 右侧内容 -->
    <base-card class="flex-1 overflow-hidden" :content-style="{ height: '100%', overflow: 'auto' }">
      <!-- 右侧表单 -->
      <base-form
        v-model="formData"
        :schemas="queryFormSchemas"
        :row-limit-number="formData.category === 3 ? 3 : 2"
      >
        <template #header-action>
          <permission-button
            :loading-props="{ searchLoading }"
            form
            :ignore-permission-list="['add', 'edit', 'delete']"
            @handle="handleButtons"
          />
        </template>
      </base-form>
      <base-divider class="mb-0! mt!" />
      <!-- 右侧列表 -->
      <alarm-table
        ref="alarmTableRef"
        :query-form="formData"
        :is-eqp-type="isEqpType"
        :user-list="userList"
        :system-name-list="systemNameList"
        :alarm-level-list="alarmLevelList || []"
        @on-search="handleTableQuery"
      />
    </base-card>
  </div>
</template>
