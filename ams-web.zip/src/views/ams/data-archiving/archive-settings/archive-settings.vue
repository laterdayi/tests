<script setup lang="tsx">
import { ArchiveSettingsApis } from '@/service/apis/ams/data-archiving/archive-settings';
import type { QueryType, RenderItemType } from '@/service/apis/ams/data-archiving/archive-settings';
import { ArchiveRecordsApis } from '@/service/apis/ams/data-archiving/archive-records';

const { isLoading: getArchieveSettingApiLoding, execute: getArchieveSetting } = useAxiosGet<RenderItemType & QueryType>(
  ArchiveSettingsApis.getArchiveSettingApi
);
// 表名
const { data: tableList } = useAxiosGet<OptionsType[]>(ArchiveRecordsApis.getTableListApi, {}, __, {
  immediate: true
});
tryOnMounted(async () => {
  try {
    const { data } = await getArchieveSetting();
    if (!data.value) return;
    formData.value = { ...data.value };
  } catch (error) {
    console.log(error);
  }
});
const { formRef, formData } = useForm<Nullable<RenderItemType & QueryType>>({
  isOpen: false,
  retainMonths: null,
  archiveDays: null,
  archiveHours: null
});
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('functionSwitch') },
    render() {
      return <base-switch checked-value={true} unchecked-value={false} v-model:value={formData.value.isOpen} />;
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: {
      label: i18nt('archiveSettingsTips1'),
      rule: {
        required: !!formData.value.isOpen,
        trigger: ['change', 'input'],
        validator() {
          return true;
        }
      }
    },
    render() {
      return <div></div>;
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: {},
    render() {
      return (
        <div class="flex ml-170px flex-wrap">
          {tableList.value?.map(ele => {
            return <base-tag class="ml pl pr"> {ele} </base-tag>;
          })}
        </div>
      );
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: {},
    render() {
      return (
        <div class="flex items-center ml-180px">
          <div class="mr-16px">{i18nt('every')}</div>
          <base-input-number max={31} min={1} precision={0} v-model:value={formData.value.archiveDays} />
          <div class="ml-16px mr-16px">{i18nt('day')}</div>
          <base-input-number max={23} min={0} precision={0} v-model:value={formData.value.archiveHours} />
          <div class="ml-16px">{i18nt('archiveSettingsTips3')}</div>
        </div>
      );
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: {
      label: i18nt('archiveSettingsTips2'),
      rule: {
        required: !!formData.value.isOpen,
        trigger: ['change', 'input'],
        validator() {
          return true;
        }
      }
    },
    render() {
      return (
        <div class="flex items-center">
          <base-input-number max={24} min={1} precision={0} v-model:value={formData.value.retainMonths} />
          <div class="ml-16px">{i18nt('EnumTimeUnit_Month')}</div>
        </div>
      );
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: '' },
    render() {
      return (
        <base-button buttonName="save" class="ml-180px" on-click={saveForm} type="info">
          {i18nt('save')}
        </base-button>
      );
    }
  }
]);
const verify = (index: number) => {
  if (index === 1) {
    return formData.value.isOpen ? !formData.value.archiveDays || !formData.value.archiveHours : false;
  } else if (index === 2) {
    return formData.value.isOpen ? !formData.value.retainMonths : false;
  } else if (index === 3) {
    return (
      !!(formData.value.archiveDays && formData.value.archiveHours?.toString() === undefined)
      || !!(!formData.value.archiveDays && formData.value.archiveHours?.toString() !== undefined)
    );
  }
};
// 保存表单
const { execute: addAlarmHistory } = useAxiosPost(ArchiveSettingsApis.addArchiveSettingApi);
const saveForm = async () => {
  if (formData.value.isOpen) {
    if (verify(1)) {
      $message.warning(i18nt('archiveSettingsTips6'));
      return;
    }
    if (verify(2)) {
      $message.warning(`${i18nt('archiveSettingsTips5')}`);
      return;
    }
  } else if (verify(3)) {
    $message.warning(i18nt('archiveSettingsTips7'));
    return;
  }

  try {
    await addAlarmHistory({
      data: {
        ...formData.value
      }
    });
    const { data } = await getArchieveSetting();
    if (!data.value) return;
    formData.value = { ...data.value };
  } catch (error) {
    console.log(error);
  }
};
</script>

<template>
  <div id="archive-settings">
    <n-grid :cols="1">
      <n-gi class="p-16px">
        <base-space>
          <base-spin :show="getArchieveSettingApiLoding">
            <base-form
              ref="formRef"
              v-model="formData"
              :label-width="180"
              type="query"
              :schemas="schemas"
              label-align="right"
              layout="base"
            />
          </base-spin>
        </base-space>
      </n-gi>
    </n-grid>
  </div>
</template>

<style scoped lang="less">
#archive-settings {
  background: #ffffff;
}
</style>
