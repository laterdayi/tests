<script setup lang="ts">
import { ArchiveRecordsApis } from '@/service/apis/ams/data-archiving/archive-records';
import type { QueryType, TableListType } from '@/service/apis/ams/data-archiving/archive-records';

// 模板引用
const curdRef = ref<CurdRefType<QueryType, TableListType>>();
// 表名
const { data: tableList, isLoading: isLoadingtableList } = useAxiosGet<OptionsType[]>(
  ArchiveRecordsApis.getTableListApi,
  {},
  __,
  {
    immediate: true
  }
);
// 查询表单配置
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'businessName',
    formItemProps: {
      label: i18nt('tableNameArchiving')
    },
    class: 'w-500px!',
    componentProps: {
      loading: isLoadingtableList.value,
      options: tableList.value
        ? tableList.value.map(ele => {
          return {
            label: ele,
            value: ele
          };
        })
        : []
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'daterange', clearable: false }
  }
]);
const queryFormParams: Nullable<QueryType> = {
  businessName: null,
  timestamp: useFormatDateRange(30, { format: 'YYYY-MM-DD' })
};
const curdRefPagination = computed(() => curdRef.value?.pagination);

// 表格数据配置
// 表格查询传值更改
const refactorFormQueryParams = (data: QueryType) => {
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),

  { title: i18nt('tableNameArchiving'), key: 'businessName' },
  { title: i18nt('filingDate'), key: 'archiveDate', sorter: true },
  { title: i18nt('numberOfLocalRecords'), key: 'sourceNums', sorter: true },
  { title: i18nt('numberOfArchivedRecords'), key: 'targetNums', sorter: true },
  { title: i18nt('startTime'), key: 'startTime', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: i18nt('endTime'), key: 'endTime', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: `${i18nt('executeTime')}(${i18nt('second')})`, key: 'duration', width: TABLE_WIDTH_DATETIME, sorter: true },
  { title: i18nt('remark'), key: 'remark' }
];
</script>

<template>
  <div id="archive-records">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :read-api="ArchiveRecordsApis.getAlarmHistoryListApi"
      modal-title="roleManage"
      :refactor-form-query-params="refactorFormQueryParams"
    />
  </div>
</template>

<style scss="less">
#archive-records {
  .n-form-item-blank {
    width: 260px !important;
    .n-select {
      width: 100% !important;
    }
  }
}
</style>
