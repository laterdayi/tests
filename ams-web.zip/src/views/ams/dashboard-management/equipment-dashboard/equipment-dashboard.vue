<script setup lang="tsx">
import autofit from 'autofit.js';
import Swiper from 'swiper';
import 'swiper/css';
import { register } from 'swiper/element/bundle';
import type { EChartsType } from 'echarts/types/dist/core.js';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { PtFormType } from '@/service/apis/ams/system-setting';
import { CallState, EquipmentDashboardApis } from '@/service/apis/ams/dashboard-management/equipment-dashboard';
import type {
  CallsType,
  DashboardType,
  EchartListType
} from '@/service/apis/ams/dashboard-management/equipment-dashboard';
import dashboardTop from '@/components/project/dashboard/dashboard-top.vue';
import dashboardAvailable from '@/components/project/dashboard/dashboard-available.vue';

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const route = useRoute();
const { params } = route;

// 获取通用设置
const { execute: executeCallCommonSetting } = useAxiosGet<PtFormType>(AlarmSystemSettingApis.getCallCommonSettingApi);

// 获取看板数据
const callData = ref<DashboardType>();
const { execute: executeGetEqpDashboardApi, data: tableDataRaw } = useAxiosGet<DashboardType>(
  EquipmentDashboardApis.getEqpDashboardApi
);
const eqpCallCarouselData = ref<CallsType[]>([]);
// 饼图
const echartList = ref<EchartListType[]>([]);
const echartDataTotal = ref<number>(0);

register();
const refreshLoading = ref<boolean>(false);
// 轮播刷新频率
const delayLength = ref<number>(3000);
tryOnMounted(async () => {
  try {
    const { data } = await executeCallCommonSetting();
    tabTiming.value = (data?.value?.refreshTime || 0) * 1000 || 10000;
    delayLength.value = (data?.value?.rollTime || 0) * 1000 || 3000;
    autofitHandle();
    eqpDashboardHandle(true, true);
  } catch (error) {
    console.log(error);
  }
});
// 处理页面适配
const autofitHandle = () => {
  autofit.init({
    dh: 1080,
    dw: 1920,
    el: '#equipment-dashboard',
    resize: true
  });
};
// 处理看板数据
const eqpDashboardHandle = async (isShow = false, swiperIsShow = false) => {
  try {
    if (isShow) {
      refreshLoading.value = true;
    }
    const { data } = await executeGetEqpDashboardApi({ params: { id: params.id } });
    if (!data.value) return;
    handleSendSpeak();
    callData.value = data.value;
    tableData.value = data.value?.calls ?? [];

    echartList.value = [
      {
        name: 'RepairOperateStateEnum_ToTakeOver',
        color: '#F56C6C',
        value: data.value.toTakeOverCount
      },
      {
        name: 'underRepair',
        color: '#F0AD4E',
        value: data.value.inRepairCount
      },
      {
        name: 'underInspection',
        color: '#8B4513',
        value: data.value.inAuditCount
      },
      {
        name: 'normal',
        color: '#5CB85C',
        value: data.value.normalCount
      }
    ];
    echartDataTotal.value = data.value.eqpCount;
    eqpCallCarouselData.value = data.value?.calls.filter(ele => ele.state === 1);

    if (swiperIsShow) {
      swiperTableHandle();
      swiperListHandle();
    }
    refreshLoading.value = false;
  } catch (error) {
    tableData.value = [];
    eqpCallCarouselData.value = [];
    refreshLoading.value = false;
    console.log('获取实时数据', error);
  }
};
// 定时刷新看板数据
const tabTiming = ref<number>(10000);
// resume
const { pause } = useIntervalFn(eqpDashboardHandle, tabTiming);
// 全屏 isFullscreen
const { toggle: toggleScreen } = useFullscreen();
// 当前状态对象
const currentStatusObj: {
  [key: number]: {
    color: string;
    title: string;
  };
} = {
  [CallState.toTakeOver]: {
    color: '#F56C6C',
    title: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  [CallState.underRepair]: {
    color: '#F0AD4E',
    title: i18nt('underRepair')
  },
  [CallState.underInspection]: {
    color: '#8B4513',
    title: i18nt('underInspection')
  },
  [CallState.finalizeTheOrder]: {
    color: '#5CB85C',
    title: i18nt('finalizeTheOrder')
  }
};

// 默认最大行
const tableLength = ref<number>(10);
// 表格
const tableData = ref<CallsType[]>([]);
const tableColumns = [
  {
    title: i18nt('index'),
    key: 'index',
    width: TABLE_WIDTH_INDEX
  },
  {
    title: i18nt('callNumber'),
    key: 'flowNo'
  },
  { title: i18nt('eqpName'), key: 'eqpId', width: TABLE_WIDTH_INFO },
  { title: i18nt('abnormalityType'), key: 'flowType', width: TABLE_WIDTH_STATE },
  {
    title: i18nt('currentState'),
    key: 'state',
    width: TABLE_WIDTH_STATE,
    render: ({ scope }: { scope: CallsType }) => {
      return (
        <base-tag
          color={{
            color: currentStatusObj[scope.state].color,
            textColor: '#FFFFFF',
            borderColor: currentStatusObj[scope.state].color
          }}
          size={componentSize.value}
        >
          {currentStatusObj[scope.state].title}
        </base-tag>
      );
    }
  },
  { title: i18nt('currentUserGroup'), key: 'currentNoticeUserGroupName' },
  { title: i18nt('currentAssignee'), key: 'currentHandler', width: TABLE_WIDTH_NAME },
  { title: i18nt('caller'), key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('callTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME_MILLISECOND + 30 },
  { title: i18nt('downtimeDuration'), key: 'totalTime', width: TABLE_WIDTH_DATETIME_MILLISECOND }
];
// 表格轮播处理
const swiperTable = ref();
const swiperTableHandle = () => {
  swiperTable.value = new Swiper('.tableSwiper', {
    direction: 'vertical',
    slidesPerView: 10,
    slidesPerGroup: 5,
    autoplay: {
      delay: delayLength.value,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    mousewheel: true,
    observer: true
  });
};
watch(echartList, newValue => {
  if (!newValue) return;
  if (echartList.value.length !== 0) {
    handlePie();
  }
});
// 饼图
const echartRef = ref<ChartRefType | null>(null);
const handlePie = () => {
  nextTick(() => {
    if (echartRef.value) {
      echartRef.value?.setOption(
        {
          tooltip: {
            show: false
          },
          color: echartList.value.map(ele => ele.color),
          series: [
            {
              name: '数量',
              type: 'pie',
              radius: ['50%', '70%'],
              center: ['50%', '45%'],
              data: echartList.value,
              avoidLabelOverlap: false,
              label: {
                show: false,
                position: 'center',
                formatter: item => {
                  const data = item.data as { name: string; value: number };
                  return `{text|${i18nt(data.name)} }\n{rate|${toPercent(
                    data.value / echartDataTotal.value
                  )}}\n{value|${data.value}}`;
                },
                rich: {
                  text: {
                    align: 'center',
                    color: '#9BD0FF',
                    verticalAlign: 'middle',
                    fontSize: 14,
                    padding: 4
                  },
                  rate: {
                    align: 'center',
                    verticalAlign: 'middle',
                    color: '#FFFFFF',
                    padding: 8,
                    fontSize: 24
                  },
                  value: {
                    align: 'center',
                    verticalAlign: 'middle',
                    color: '#3BE3B5',
                    fontSize: 24
                  }
                }
              },
              emphasis: {
                label: {
                  show: true,
                  fontSize: '12',
                  fontWeight: 'bold'
                }
              },
              labelLine: {
                show: true
              }
            }
          ]
        },
        true
      );
      echartRef.value?.resize();
      const echartDemo = echartRef.value?.getInstance();
      bulgeTimer(echartList.value, echartDemo);
    }
  });
};
// 饼图高亮
const swiperTime = 5000;
let changePieInterval: NodeJS.Timeout | null;
const bulgeTimer = (echartList: EchartListType[], myChart: EChartsType | null) => {
  if (!myChart) {
    return;
  }
  let currentIndex = -1;
  const selectPie = () => {
    currentIndex = (currentIndex + 1) % echartList.length;
    highlightPie();
  };
  if (!changePieInterval) {
    changePieInterval = setInterval(selectPie, swiperTime);
  }
  // 取消所有高亮并高亮当前图形
  const highlightPie = () => {
    for (const index in echartList) {
      myChart?.dispatchAction({
        type: 'downplay',
        seriesIndex: 0,
        dataIndex: index
      });
    }
    // 高亮当前图形
    myChart?.dispatchAction({
      type: 'highlight',
      seriesIndex: 0,
      dataIndex: currentIndex
    });
  };
  // 鼠标进入
  myChart.on('mouseover', (params: { componentType: string; dataIndex: number }) => {
    if (changePieInterval) {
      clearInterval(changePieInterval);
    }

    changePieInterval = null;
    if (params.componentType === 'graphic') {
      return;
    }
    currentIndex = params.dataIndex;
    highlightPie();
  });
  //  鼠标离开
  myChart.on('mouseout', () => {
    if (changePieInterval) {
      clearInterval(changePieInterval);
    }
    changePieInterval = null;
    changePieInterval = setInterval(selectPie, swiperTime);
  });
};
// 小数转换百分比
const toPercent = (point: number) => {
  if (isNaN(point)) {
    return '0%';
  }

  const percent = (point * 100).toFixed(2);
  return `${parseFloat(percent)}%`;
};
// 底部轮播处理
const swiperList = ref();
const swiperListHandle = () => {
  swiperList.value = new Swiper('.swiperList', {
    slidesPerView: 4,
    slidesPerGroup: 5,
    spaceBetween: 25,
    autoplay: {
      delay: delayLength.value,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    mousewheel: true,
    observer: true
  });
};

// 播放声音
const synth = window.speechSynthesis;
const handleSendSpeak = () => {
  const diffCallResult = tableDataRaw.value?.calls?.filter(itemB => {
    const itemA = tableData.value?.find(item => item.flowNo === itemB.flowNo);
    return (!itemA || new Date(itemB.systemTime).getTime() > new Date(itemA.systemTime).getTime()) && itemB.state === 1;
  });
  const diffUserGroupResult = tableData.value.length
    ? tableDataRaw.value?.calls.filter(itemB => {
        const itemA = tableData.value.find(itemA => itemA.flowNo === itemB.flowNo);
        return itemA && itemA.currentNoticeUserGroupName !== itemB.currentNoticeUserGroupName && itemB.state === 1;
      })
    : [];
  if (diffCallResult?.length) handleStartSpeak(diffCallResult, '机台', '正在呼叫');
  if (diffUserGroupResult?.length) handleStartSpeak(diffUserGroupResult, '机台', '已向上反馈');
};
const handleStartSpeak = (result: CallsType[], prefix: string, suffix: string) => {
  if (result?.length) {
    for (let i = 0; i < result.length; i++) {
      for (let j = 0; j < 3; j++) {
        const msg = new SpeechSynthesisUtterance();
        const text = result[i].eqpId
          .replace(/[^a-z0-9\u4e00-\u9fa5]/gi, '')
          .split('')
          .join(' ');
        msg.text = `${prefix}${text}${suffix}`;
        synth.speak(msg);
      }
    }
  }
};

tryOnUnmounted(() => {
  if (tableData?.value.length !== 0 && swiperTable.value) {
    swiperTable.value.destroy(true, false);
    swiperTable.value = null;
  }
  if (eqpCallCarouselData?.value.length !== 0 && swiperList.value) {
    swiperList.value.destroy(true, false);
    swiperList.value = null;
  }
  pause();
  autofit.off();
  synth.cancel();
  if (changePieInterval) {
    clearInterval(changePieInterval);
  }
  changePieInterval = null;
  echartRef.value = null;
});
</script>

<template>
  <div
    id="equipment-dashboard"
    :style="{
      backgroundColor: callData?.backgroundColor || '#030c32'
    }"
  >
    <base-spin size="large" :show="refreshLoading">
      <div class="dashboard">
        <div class="dashboard-content">
          <dashboard-top
            :select-name="callData?.areaName || ''"
            :dashboard-name="callData?.name || ''"
            :dashboard-title="i18nt('equipmentDashboard')"
            refresh-is-show
            @toggle-screen="toggleScreen"
          />
          <!-- 中间 -->
          <div class="dashboard-middle">
            <!-- 表格 -->
            <div class="dashboard-type11">
              <div class="type11-content">
                <div class="left-title">{{ i18nt('equipmentDashboardTips3') }}</div>
                <div v-show="tableData.length !== 0" class="table">
                  <!-- 标题 -->
                  <div class="table-ul table-ul-title">
                    <div
                      v-for="(item, index) in tableColumns"
                      :key="item.key"
                      class="table-li"
                      :style="{
                        textAlign: index === 0 ? 'center' : 'start',
                        maxWidth: item.width ? `${item?.width - 12}px` : `none`,
                        minWidth: `50px`
                      }"
                    >
                      <span> {{ item.title }}</span>
                    </div>
                  </div>
                  <!-- 内容 -->
                  <div class="tableSwiper">
                    <div class="swiper-wrapper">
                      <div
                        v-for="(item, index) in tableData"
                        :key="item.eqpId"
                        class="swiper-slide table-ul"
                        :class="
                          item.state === 1
                            ? 'table-ul-state table-ul'
                            : callData?.calls.length === tableLength && index === tableLength - 1
                              ? 'table-ul-border table-ul'
                              : 'table-ul'
                        "
                      >
                        <div
                          v-for="(columnItem, columnIndex) in tableColumns"
                          :key="columnItem.key"
                          class="table-li"
                          :style="{
                            textAlign: columnIndex === 0 ? 'center' : 'start',
                            maxWidth: columnItem.width ? `${columnItem?.width - 12}px` : `none`,
                            minWidth: `50px`
                          }"
                        >
                          <span v-if="columnIndex === 0">{{ index + 1 }}</span>
                          <div v-else>
                            <div v-if="columnItem.render">
                              <component :is="columnItem.render" :scope="item" />
                            </div>
                            <div v-else>{{ item[columnItem.key] }}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <dashboard-available v-show="tableData.length === 0" />
              </div>
            </div>
            <div class="middle-statistics">
              <!-- 统计 -->
              <div class="dashboard-type7">
                <div class="type7-content">
                  <div class="left-title">{{ i18nt('dataStatistics') }}</div>
                  <div class="statistics-ul">
                    <div class="statistics-li">
                      <div class="li-title">{{ i18nt('RepairOperateStateEnum_ToTakeOver') }}</div>
                      <div class="li-text">{{ callData?.toTakeOverCount }}</div>
                    </div>
                    <div class="li-middle" />
                    <div class="statistics-li">
                      <div class="li-title">{{ i18nt('underRepair') }}</div>
                      <div class="li-text">{{ callData?.inRepairCount }}</div>
                    </div>
                  </div>
                  <div class="statistics-ul statistics-ul1">
                    <div class="statistics-li statistics-li1">
                      <div class="li-title li-title1">{{ i18nt('totalNumberOfEquipment') }}</div>
                      <div class="li-text1">{{ callData?.eqpCount }}</div>
                    </div>
                    <div class="statistics-li statistics-li1">
                      <div class="li-title li-title1">{{ i18nt('underInspection') }}</div>
                      <div class="li-text1">{{ callData?.inAuditCount }}</div>
                    </div>
                    <div class="statistics-li statistics-li1">
                      <div class="li-title li-title1">{{ i18nt('normal') }}</div>
                      <div class="li-text1">{{ callData?.normalCount }}</div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- 状态分布 -->
              <div class="dashboard-type7 echart">
                <div class="type7-content">
                  <div class="left-title">{{ i18nt('equipmentDashboardTips4') }}</div>
                  <div v-show="echartList.length !== 0" class="echart-buttom">
                    <base-chart ref="echartRef" class="echartRef" />
                    <div class="echartRef-right">
                      <div v-for="item in echartList" :key="item.name" class="echartRef-li">
                        <div
                          class="li-color"
                          :style="{
                            backgroundColor: item.color
                          }"
                        />
                        <div class="li-text">{{ i18nt(item.name) }}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 底部 轮播展示 -->
          <div v-show="eqpCallCarouselData.length !== 0" class="bottom swiperList">
            <div class="swiper-wrapper">
              <div v-for="item in eqpCallCarouselData" :key="item.eqpId" class="dashboard-type7 swiper-slide">
                <div class="type7-content">
                  <div class="left-title">{{ i18nt('equipmentDashboardTips5') }}</div>
                  <div class="swiper-ul">
                    <div class="swiper-li-left">
                      <div class="li-title">{{ i18nt('callNumber') }}</div>
                      <div class="li-text">{{ item.flowNo }}</div>
                    </div>
                    <div class="swiper-interval" />
                    <div class="swiper-li-left swiper-li-right">
                      <div class="li-title">{{ i18nt('eqpName') }}</div>
                      <div class="li-text">{{ item.eqpId }}</div>
                    </div>
                  </div>
                  <div class="swiper-ul">
                    <div class="swiper-li-left">
                      <div class="li-title">{{ i18nt('abnormalityType') }}</div>
                      <div class="li-text">{{ item.flowType }}</div>
                    </div>
                    <div class="swiper-interval" />
                    <div class="swiper-li-left swiper-li-right">
                      <div class="li-title">{{ i18nt('currentUserGroup') }}</div>
                      <div class="li-text">{{ item.currentNoticeUserGroupName }}</div>
                    </div>
                  </div>
                  <div class="swiper-ul">
                    <div class="swiper-li-left">
                      <div class="li-title">{{ i18nt('caller') }}</div>
                      <div class="li-text">{{ item.creator }}</div>
                    </div>
                    <div class="swiper-interval" />
                    <div class="swiper-li-left swiper-li-right">
                      <div class="li-title">{{ i18nt('callTime') }}</div>
                      <div class="li-text">{{ item.createTime }}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div v-show="eqpCallCarouselData.length === 0" class="bottom-available">
            <dashboard-available />
          </div>
        </div>
      </div>
    </base-spin>
  </div>
</template>

<style lang="less" scoped>
@import '@/components/project/dashboard/dashboard.less';
#equipment-dashboard {
  @dashboard();
  // 中间
  .dashboard-middle {
    margin: 17px auto;
    height: 606px;
    display: flex;
    justify-content: space-between;
    @imageType11();
    @tableType();
    .table {
      width: 100%;
      margin-top: 20px;
      border-radius: 10px;
      font-size: 14px;
      border: 1px solid #374d81;
      .tableUlType(#00cfff,44px);
      .table-ul-title {
        font-size: 16px;
        font-weight: bold;
      }
      .tableSwiper {
        height: 450px;
        overflow: hidden;
        .tableUlType(#9bd0ff,44px);
      }
    }
    // 右侧
    .middle-statistics {
      width: 456px;
      @imageType7();
      .dashboard-type7 {
        padding-top: 1px;
        height: 295px;
      }
      .statisticsType(@background,@width,@height) {
        .statistics-li {
          background: @background;
          width: @width;
          height: @height;
          border-radius: 10px;
          text-align: center;
          .li-title {
            height: 19px;
            font-size: 14px;
            color: #9bd0ff;
            line-height: 19px;
          }
          .li-text {
            margin-top: 12px;
            height: 52px;
            font-size: 40px;
            font-weight: bold;
            color: #00cfff;
            line-height: 52px;
            background: linear-gradient(180deg, #fad961 0%, #f78f1c 100%);
            background-clip: text;
            -webkit-text-fill-color: transparent;
          }
          .li-title1 {
            margin-top: 16px;
          }
          .li-text1 {
            font-size: 30px;
            font-weight: bold;
            color: #3be3b5;
            line-height: 40px;
            margin-top: 13px;
          }
        }
      }

      .statistics-ul {
        margin-top: 15px;
        display: flex;
        justify-content: space-around;
        align-items: center;
        .statisticsType(none,122px,85pxpx);
      }
      .statistics-ul1 {
        .statisticsType(#0f2762,128px,112px);
      }
      .li-middle {
        width: 1px;
        height: 60px;
        background: #374d81;
      }
      // 状态分布
      .echart {
        margin-top: 14px;
        .echart-buttom {
          height: 240px;
          margin: 0 auto;
          display: flex;
          justify-content: space-between;
          .echartRef {
            width: 214px;
            margin-top: 25px;
            height: 202px;
          }
          .echartRef-right {
            margin-top: 25px;
            height: 202px;
            width: 50%;
            width: 176px;
            .echartRef-li {
              width: 100%;
              cursor: pointer;
              height: 32px;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 12px;
              color: #ffffff;
              line-height: 32px;
              .li-color {
                width: 12px;
                height: 12px;
                border-radius: 2px;
              }

              .li-text {
                width: 56px;
                margin-left: 12px;
              }
            }
          }
        }
      }
    }
  }
  // 底部
  .bottom {
    height: 296px;
    display: flex;
    justify-content: space-between;
    overflow: hidden;
    @imageType7();
    .swiper-ul {
      margin-top: 8px;
      height: 72px;
      background: #0f2762;
      border-radius: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .swiper-li-left {
        width: 170px;
        margin-left: 24px;
        text-align: center;

        .li-title {
          height: 21px;
          line-height: 21px;
          font-weight: bold;
          color: #00cfff;
          font-size: 16px;
          .colorType();
        }
        .li-text {
          height: 19px;
          line-height: 19px;
          margin-top: 8px;
          color: #9bd0ff;
          font-size: 14px;
        }
      }
      .swiper-interval {
        width: 1px;
        height: 30px;
        background-color: #374d81;
      }
      .swiper-li-right {
        margin-right: 24px;
      }
    }
    .bottom-available {
      width: 100%;
      height: 296px;
    }
  }
}
</style>
