<script setup lang="tsx">
import Swiper from 'swiper';
import 'swiper/css';
import type { BarSeriesOption, CustomSeriesOption } from 'echarts/charts';
import { register } from 'swiper/element/bundle';
import autofit from 'autofit.js';
import { actionCategoryObj, alarmActionType } from '@/views/ams/constants';
import type { AlarmStatisticsDataType } from '@/views/ams/constants';
import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';
import type {
  AlarmActionInfosProps,
  AlarmCodesType,
  AlarmDashboardProps,
  EchartDataProps
} from '@/service/apis/ams/dashboard-management/alarm-statistics-dashboard';
import { AlarmDashboardApis } from '@/service/apis/ams/dashboard-management/alarm-statistics-dashboard';
import { AMSCommonApis } from '@/service/apis/ams/common';
import dashboardTop from '@/components/project/dashboard/dashboard-top.vue';
import dashboardAvailable from '@/components/project/dashboard/dashboard-available.vue';

const appStore = useAppStore();
const route = useRoute();
const { params } = route;
// 获取统计信息
const { data: alrmStatisticsDataData, execute: executeGetAlarmStatisticsData } = useAxiosGet<AlarmStatisticsDataType>(
  AMSCommonApis.getAlarmStatisticsDataApi
);
// 获取当前设备报警/系统执行动作
const alarmStatisticsData = ref<AlarmDashboardProps>();
const { execute: executeGetAlarmStatistics } = useAxiosGet<AlarmDashboardProps>(
  AlarmDashboardApis.getAlarmStatisticsApi
);
// 历史报警信息统计
const { data: alarmHistoricalData, execute: executeGetAlarmHistorical } = useAxiosGet<EchartDataProps>(
  AlarmDashboardApis.getAlarmHistoricalApi
);
register();
// 全屏
const { toggle: toggleScreen } = useFullscreen();
// 刷新页面
const refreshLoading = ref<boolean>(false);
const refresh = () => {
  pause();
  refreshLoading.value = true;
  detailHandle(true);
  resume();
};
const detailHandle = async (isShow = false) => {
  try {
    await executeGetAlarmStatisticsData({
      params: { id: params.id }
    });
    const { data } = await executeGetAlarmStatistics({
      params: { id: params.id, language: appStore.local === LOCAL_DEFAULT ? 0 : 1 }
    });
    alarmStatisticsData.value = data.value;
    swiperTableHandle();
    swiperActionHandle();
    await executeGetAlarmHistorical({
      params: { id: params.id }
    });
    if (isShow) {
      delayLength.value = (data?.value?.interval || 1) * 1000 || 60000;
      refreshLoading.value = false;
    }
  } catch (error) {
    console.log(error);
  }
};
// 定时刷新时间
const delayLength = ref<number>(60000);
// 定时
const { pause, resume } = useIntervalFn(detailHandle, delayLength);
tryOnMounted(() => {
  refreshLoading.value = true;
  detailHandle(true);
  autofitHandle();
});

// 处理页面适配
const autofitHandle = () => {
  autofit.init({
    dh: 1080,
    dw: 1920,
    el: '#alarm-statistics-dashboard',
    resize: true
  });
};

// 当前设备报警
const alarmHistoryColumns = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX
  },
  { title: i18nt('eqpId'), key: 'eqpId' },
  { title: i18nt('alarmCode'), key: 'alarmId' },
  { title: i18nt('alarmDescription'), key: 'alarmDesc' },
  { title: i18nt('alarmTime'), key: 'alarmStartTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('duration'), key: 'duration' }
];
const swiperAlarmHistory = ref();
const swiperTableHandle = () => {
  swiperAlarmHistory.value = new Swiper('.swiperAlarmHistory', {
    direction: 'vertical',
    slidesPerView: 5,
    slidesPerGroup: 5,
    autoplay: {
      delay: 30000,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    mousewheel: true,
    observer: true
  });
};

// 系统执行动作
const actionColumns = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX
  },
  { title: i18nt('eqpId'), key: 'eqpId' },
  { title: i18nt('alarmCode'), key: 'alarmId' },
  {
    title: i18nt('executeAction'),
    key: 'alarmAction',
    render: ({ scope }: { scope: AlarmActionInfosProps }) => {
      return alarmActionType[scope.alarmAction] ? i18nt(alarmActionType[scope.alarmAction]) : '';
    }
  },
  {
    title: i18nt('actionCategory'),
    key: 'alarmActionCategory',
    render({ scope }: { scope: AlarmActionInfosProps }) {
      return actionCategoryObj[scope.alarmActionCategory] || '';
    }
  },
  { title: i18nt('executeTime'), key: 'systemTime', width: TABLE_WIDTH_DATETIME }
];
const swiperAction = ref();
const swiperActionHandle = () => {
  swiperAction.value = new Swiper('.swiperAction', {
    direction: 'vertical',
    slidesPerView: 5,
    slidesPerGroup: 5,
    autoplay: {
      // delay: delayLength.value,
      delay: 30000,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    mousewheel: true,
    observer: true
  });
};
// 图表配置
watch(alarmHistoricalData, newValue => {
  if (!newValue) return;
  if (alarmHistoricalData.value?.dailyAlarms.length !== 0) {
    dayTendencyHandle();
  }
  if (alarmHistoricalData.value?.alarmActionLists.length !== 0) {
    dayActionTendencyHandle();
  }
  if (alarmHistoricalData.value?.alarmEqps.length !== 0) {
    dayEquTopRefHandle(alarmHistoricalData.value?.alarmEqps || [], 1);
  }
  if (alarmHistoricalData.value?.alarmCodes.length !== 0) {
    dayEquTopRefHandle(alarmHistoricalData.value?.alarmCodes || [], 2);
  }
});
const dayTendencyRef = ref<ChartRefType | null>(null);
// 近10天报警趋势
const dayTendencyHandle = () => {
  nextTick(() => {
    if (dayTendencyRef.value) {
      const xAxisData = alarmHistoricalData.value?.dailyAlarms.map(ele => ele.monthDay) || [];
      dayTendencyRef.value?.setOption(
        {
          ...BAR_OPTION,
          grid: {
            top: '15px',
            left: '10px',
            right: '10px',
            bottom: '0px',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: xAxisData,
            axisTick: { alignWithLabel: true },
            axisLabel: {
              color: '#9BD0FF',
              interval: 0
            }
          },
          yAxis: {
            type: 'value',
            minInterval: 1,
            axisLabel: {
              color: '#9BD0FF'
            },
            axisLine: {
              lineStyle: {
                color: '#9BD0FF'
              }
            }
          },
          series: [
            {
              data: alarmHistoricalData.value?.dailyAlarms.map(ele => ele.totalAlarmCount),
              barWidth: BAR_WIDTH_HORIZONTAL,
              label: {
                show: true,
                position: 'top',
                width: 50,
                overflow: 'truncate',
                color: '#9BD0FF'
              },
              type: 'bar'
            }
          ]
        },
        true
      );
      dayTendencyRef.value?.resize();
    }
  });
};
// 近10天执行动作趋势
const resultObj: {
  [key: number]: string;
} = {
  0: '#e6a23c',
  1: '#67c23a',
  2: '#f56c6c'
};
const dayActionTendencyRef = ref<ChartRefType | null>(null);
const dayActionTendencyHandle = () => {
  nextTick(() => {
    if (dayActionTendencyRef.value) {
      const data = alarmHistoricalData.value?.alarmActionLists || [];
      const names: string[] = [];
      const xAxis: string[] = [];
      const series: BarSeriesOption[] = [];

      for (let i = 0; i < data.length; i++) {
        const item = data[i];
        xAxis.push(item.monthDay);
        for (let x = 0; x < item.alarmActions.length; x++) {
          const subItem = item.alarmActions[x];
          if (!names.includes(subItem.alarmActionId)) {
            names.push(subItem.alarmActionId);
          }
        }
      }

      for (let i = 0; i < names.length; i++) {
        const item = names[i];
        const findName = alarmActionType[Number(item)] ? i18nt(alarmActionType[Number(item)]) : '';
        const list = [];
        for (let x = 0; x < data.length; x++) {
          const subItem = data[x];
          const dataItem = subItem.alarmActions.find(val => val.alarmActionId === item);
          list.push(item ? dataItem?.count : 0);
        }
        series.push({
          ...(BAR_OPTION.series as CustomSeriesOption[])[0],
          stack: 'total',
          type: 'bar',
          label: {
            show: false
          },
          emphasis: {
            focus: 'series'
          },
          name: findName,
          data: list
        } as BarSeriesOption);
      }
      dayActionTendencyRef.value?.setOption(
        {
          ...BAR_OPTION,
          grid: {
            top: '30%',
            left: '10px',
            right: '10px',
            bottom: '0px',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: xAxis,
            axisLabel: {
              color: '#9BD0FF'
            }
          },
          yAxis: {
            type: 'value',
            axisLabel: {
              color: '#9BD0FF'
            }
          },
          legend: {
            textStyle: {
              color: '#9BD0FF'
            }
          },
          series
        },
        true
      );
      dayActionTendencyRef.value?.resize();
    }
  });
};

// 30天报警设备Top10 | 30天报警代码Top10
const dayEquTopRef = ref<ChartRefType | null>(null);
const dayCodeTopRef = ref<ChartRefType | null>(null);
const dayEquTopRefHandle = (data: AlarmCodesType[], type: number) => {
  nextTick(() => {
    const echartRef = type === 1 ? dayEquTopRef.value : dayCodeTopRef.value;
    if (echartRef) {
      const yAxisData: string[] = [];
      const seriesData = [];
      for (let i = 0; i < data.length; i++) {
        const item = data[i];
        yAxisData.unshift(item?.alarmType);
        seriesData.unshift(item?.count);
      }

      echartRef?.setOption(
        {
          ...BAR_OPTION,
          grid: {
            left: '10px',
            top: '0px',
            bottom: '0px',
            right: '10px',
            containLabel: true
          },
          xAxis: { show: false },
          yAxis: {
            type: 'category',
            axisLine: { show: false },
            axisTick: { show: false },
            data: yAxisData,
            axisLabel: {
              color: '#9BD0FF',
              formatter(value: string) {
                return value.length > 30 ? `${value.substring(0, 30)}...` : value;
              }
            }
          },
          series: [
            {
              barWidth: 40,
              label: {
                show: true,
                position: 'right',
                width: 50,
                overflow: 'truncate',
                color: '#9BD0FF'
              },
              type: 'bar',
              data: seriesData
            }
          ]
        },
        true
      );
      echartRef?.resize();
    }
  });
};

tryOnUnmounted(() => {
  if (alarmStatisticsData.value?.alarmHistoryInfos.length !== 0 && swiperAlarmHistory.value) {
    swiperAlarmHistory.value.destroy(true, false);
    swiperAlarmHistory.value = null;
  }
  if (alarmStatisticsData.value?.alarmActionInfos?.length !== 0 && swiperAction.value) {
    swiperAction.value.destroy(true, false);
    swiperAction.value = null;
  }
  pause();

  dayTendencyRef.value = null;
  dayActionTendencyRef.value = null;
  dayEquTopRef.value = null;
  dayCodeTopRef.value = null;
  autofit.off();
});
</script>

<template>
  <div
    id="alarm-statistics-dashboard"
    :style="{
      backgroundColor: alarmStatisticsData?.backgroundColor || '#030c32'
    }"
  >
    <base-spin size="large" :show="refreshLoading">
      <div class="dashboard">
        <div class="dashboard-content">
          <!-- 顶部 -->
          <dashboard-top
            :select-name="alarmStatisticsData?.areaName || ''"
            :dashboard-name="alarmStatisticsData?.name || ''"
            :dashboard-title="i18nt('alarmStatisticsDashboard')"
            @refresh="refresh"
            @toggle-screen="toggleScreen"
          />
          <!-- 中间 -->
          <div class="dashboard-middle">
            <!-- 近10天报警趋势 -->
            <div class="dashboard-type7">
              <div class="type7-content">
                <div class="left-title">{{ i18nt('day10Tendency') }}</div>
                <base-chart
                  v-if="alarmHistoricalData?.dailyAlarms.length !== 0"
                  ref="dayTendencyRef"
                  class="h-202px! m-t-22px w-100%"
                />
                <dashboard-available v-else />
              </div>
            </div>
            <!-- 设备统计 -->
            <div class="dashboard-type8">
              <div class="type8-content">
                <div class="left-title">{{ i18nt('deviceStatistics') }}</div>
                <div class="statistics-ul">
                  <!-- 今日报警次数 -->
                  <div class="statistics-li">
                    <div class="title">{{ $t('todayAlarmCount') }}</div>
                    <div class="text">{{ alrmStatisticsDataData?.totalAlarmCount || 0 }}</div>
                  </div>
                  <!-- 进行中 -->
                  <div class="statistics-li">
                    <div class="title">{{ $t('onGoingCount') }}</div>
                    <div class="text">{{ alrmStatisticsDataData?.onGoingCount || 0 }}</div>
                  </div>
                  <!-- 已关闭 -->
                  <div class="statistics-li">
                    <div class="title">{{ $t('closeAlarmCount') }}</div>
                    <div class="text">{{ alrmStatisticsDataData?.closeAlarmCount || 0 }}</div>
                  </div>
                  <!-- 报警中设备占比 -->
                  <div class="statistics-li">
                    <div class="title">{{ $t('alarmEqpPercent') }}</div>
                    <div class="text">
                      {{ `${((alrmStatisticsDataData?.alarmEqpPercent ?? 0) * 100).toFixed(1)}%` }}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- 近10天执行动作趋势 -->
            <div class="dashboard-type7">
              <div class="type7-content">
                <div class="left-title">{{ i18nt('day10ActionTendency') }}</div>
                <base-chart
                  v-if="alarmHistoricalData?.alarmActionLists.length !== 0"
                  ref="dayActionTendencyRef"
                  class="h-202px! m-t-22px w-100%"
                />
                <dashboard-available v-else />
              </div>
            </div>
          </div>
          <!-- 底部 -->
          <div class="bottom">
            <!-- 30天报警设备Top10 -->
            <div class="dashboard-type9">
              <div class="type9-content">
                <div class="left-title">{{ i18nt('day30EquTop10') }}</div>
                <base-chart
                  v-if="alarmHistoricalData?.alarmEqps.length !== 0"
                  ref="dayEquTopRef"
                  class="h-526px! m-t-22px w-100%"
                />
                <dashboard-available v-else />
              </div>
            </div>
            <!-- 设备/系统表格 -->
            <div class="bpttpm-table">
              <!-- 当前设备报警 -->
              <div class="dashboard-type8">
                <div class="type8-content">
                  <div class="left-title">{{ i18nt('currentDeviceAlarm') }}</div>
                  <div v-show="alarmStatisticsData?.alarmHistoryInfos.length !== 0" class="table">
                    <!-- 标题 -->
                    <div class="table-ul table-ul-title">
                      <div
                        v-for="(item, index) in alarmHistoryColumns"
                        :key="item.key"
                        class="table-li"
                        :style="{
                          textAlign: index === 0 ? 'center' : 'start',
                          maxWidth: item.width ? `${item?.width - 12}px` : `none`,
                          minWidth: `50px`
                        }"
                      >
                        <span> {{ item.title }}</span>
                      </div>
                    </div>
                    <!-- 内容 -->
                    <div class="swiperAlarmHistory tableSwiper">
                      <div class="swiper-wrapper">
                        <div
                          v-for="(item, index) in alarmStatisticsData?.alarmHistoryInfos"
                          :key="item.eqpId"
                          class="swiper-slide table-ul"
                          :style="{
                            color: item.alarmEndTime ? '#67c23a' : '#f56c6c'
                          }"
                          :class="
                            alarmStatisticsData?.alarmHistoryInfos.length === 10 && index === 9
                              ? 'table-ul-border table-ul'
                              : 'table-ul'
                          "
                        >
                          <div
                            v-for="(columnItem, columnIndex) in alarmHistoryColumns"
                            :key="columnItem.key"
                            class="table-li"
                            :style="{
                              textAlign: columnIndex === 0 ? 'center' : 'start',
                              maxWidth: columnItem.width ? `${columnItem?.width - 12}px` : `none`,
                              minWidth: `50px`
                            }"
                          >
                            <span v-if="columnIndex === 0">{{ index + 1 }}</span>
                            <div v-else>
                              <div>{{ item[columnItem.key] }}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <dashboard-available v-show="alarmStatisticsData?.alarmHistoryInfos.length === 0" />
                </div>
              </div>
              <!-- 系统执行动作 -->
              <div class="dashboard-type8">
                <div class="type8-content">
                  <div class="left-title">{{ i18nt('systemExecutionAction') }}</div>
                  <div v-show="alarmStatisticsData?.alarmActionInfos.length !== 0" class="table">
                    <!-- 标题 -->
                    <div class="table-ul table-ul-title">
                      <div
                        v-for="(item, index) in actionColumns"
                        :key="item.key"
                        class="table-li"
                        :style="{
                          textAlign: index === 0 ? 'center' : 'start',
                          maxWidth: item.width ? `${item?.width - 12}px` : `none`,
                          minWidth: `50px`
                        }"
                      >
                        <span> {{ item.title }}</span>
                      </div>
                    </div>
                    <!-- 内容 -->
                    <div class="swiperAction tableSwiper">
                      <div class="swiper-wrapper">
                        <div
                          v-for="(item, index) in alarmStatisticsData?.alarmActionInfos"
                          :key="item.eqpId"
                          class="swiper-slide table-ul"
                          :style="{
                            color: resultObj[item.result]
                          }"
                          :class="
                            alarmStatisticsData?.alarmActionInfos.length === 10 && index === 9
                              ? 'table-ul-border table-ul'
                              : 'table-ul'
                          "
                        >
                          <div
                            v-for="(columnItem, columnIndex) in actionColumns"
                            :key="columnItem.key"
                            class="table-li"
                            :style="{
                              textAlign: columnIndex === 0 ? 'center' : 'start',
                              maxWidth: columnItem.width ? `${columnItem?.width - 12}px` : `none`,
                              minWidth: `50px`
                            }"
                          >
                            <span v-if="columnIndex === 0">{{ index + 1 }}</span>
                            <div v-else>
                              <div v-if="columnItem.render">
                                <component :is="columnItem.render" :scope="item" />
                              </div>
                              <div v-else>{{ item[columnItem.key] }}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <dashboard-available v-show="alarmStatisticsData?.alarmActionInfos.length === 0" />
                </div>
              </div>
            </div>
            <!-- 30天报警代码Top10 -->
            <div class="dashboard-type9">
              <div class="type9-content">
                <div class="left-title">{{ i18nt('day30CodeTop10') }}</div>
                <base-chart
                  v-if="alarmHistoricalData?.alarmCodes.length !== 0"
                  ref="dayCodeTopRef"
                  class="h-526px! m-t-22px w-100%"
                />
                <dashboard-available v-else />
              </div>
            </div>
          </div>
        </div>
      </div>
    </base-spin>
  </div>
</template>

<style lang="less" scoped>
@import '@/components/project/dashboard/dashboard.less';
#alarm-statistics-dashboard {
  @dashboard();

  // 中间
  .dashboard-middle {
    margin: 17px auto;
    height: 296px;
    display: flex;
    justify-content: space-between;
    @imageType7();
    @imageType8();
    // 设备统计
    .statistics-ul {
      width: 100%;
      margin-top: 20px;
      height: 202px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .statistics-li {
        width: 186px;
        height: 144px;
        padding: 10px;
        background: #0f2762;
        border-radius: 10px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        text-align: center;

        .title {
          font-size: 20px;
          color: #9bd0ff;
          line-height: 30px;
        }
        .text {
          font-size: 35px;
          font-weight: bold;
          color: #3be3b5;
          line-height: 40px;
          margin-top: 20px;
          width: 100%;

          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
    }
  }
  // 底部
  .bottom {
    height: 606px;
    display: flex;
    justify-content: space-between;
    @imageType9();
    .bpttpm-table {
      width: 928px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      @imageType8();
      @tableType();
      .dashboard-type8 {
        padding-top: 1px;
        height: 295px;
      }
      // 服务列表
      .table {
        width: 100%;
        margin-top: 20px;
        border-radius: 10px;
        font-size: 14px;
        border: 1px solid #374d81;
        .tableUlType(#00cfff,35px);
        .table-ul-title {
          font-size: 16px;
          font-weight: bold;
        }
        .tableSwiper {
          height: 174px;
          overflow: hidden;
          .tableUlType(#9bd0ff,35px);
        }
      }
    }
  }
}
</style>
