<script setup lang="tsx">
import Swiper from 'swiper';
import 'swiper/css';
import * as echarts from 'echarts';
import 'echarts-liquidfill';
import { register } from 'swiper/element/bundle';
import autofit from 'autofit.js';
import { alarmActionType } from '@/views/ams/constants';
import type { AlarmStatisticsDataType } from '@/views/ams/constants';
import { AMSCommonApis } from '@/service/apis/ams/common';
import { AlarmRealtimeDashboardApis } from '@/service/apis/ams/dashboard-management/alarm-realtime-dashboard';
import type {
  AlarmDataObjType,
  AlarmDataType,
  TableListType
} from '@/service/apis/ams/dashboard-management/alarm-realtime-dashboard';
import dashboardTop from '@/components/project/dashboard/dashboard-top.vue';
import dashboardAvailable from '@/components/project/dashboard/dashboard-available.vue';

const appStore = useAppStore();
const route = useRoute();
const { params } = route;

// 获取统计信息
const { data: alrmStatisticsDataData, execute: executeGetAlarmStatisticsData } = useAxiosGet<AlarmStatisticsDataType>(
  AMSCommonApis.getAlarmStatisticsDataApi
);

// 获取实时统计数据
const alarmRealtimeList = ref<TableListType[]>();
const alarmRealtimeObj = ref<Nullable<AlarmDataObjType>>();
const { execute: executeGetAlarmRealtimeList } = useAxiosGet<AlarmDataType>(
  AlarmRealtimeDashboardApis.getAlarmRealtimeListApi
);
// 全屏
const { toggle: toggleScreen } = useFullscreen();
// 刷新页面
const refreshLoading = ref<boolean>(false);
const refresh = () => {
  pause();
  refreshLoading.value = true;
  detailHandle(true);
  resume();
};
const detailHandle = async (isShow = false) => {
  try {
    await executeGetAlarmStatisticsData({ params: { id: params.id } });
    const { data } = await executeGetAlarmRealtimeList({
      params: { id: params.id, language: appStore.local === LOCAL_DEFAULT ? 0 : 1 }
    });
    alarmRealtimeList.value = data.value?.data || [];
    alarmRealtimeObj.value = {
      name: data.value?.name || null,
      backgroundColor: data.value?.backgroundColor || null,
      areaName: data.value?.areaName || null
    };
    swiperAlarmRealtimeHandle();
    if (isShow) {
      delayLength.value = (data?.value?.interval || 1) * 1000 || 60000;
      refreshLoading.value = false;
    }
  } catch (error) {
    console.log(error);
  }
};
// 定时刷新时间
const delayLength = ref<number>(60000);
// 定时
const { pause, resume } = useIntervalFn(detailHandle, delayLength);
tryOnMounted(() => {
  refreshLoading.value = true;
  detailHandle(true);
  autofitHandle();
});

// 处理页面适配
const autofitHandle = () => {
  autofit.init({
    dh: 1080,
    dw: 1920,
    el: '#alarm-realtime-dashboard',
    resize: true
  });
};

// 当前设备报警
const alarmRealtimeColumns = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX
  },
  { title: i18nt('equipmentNumber'), key: 'eqpID', width: TABLE_WIDTH_NAME },
  { title: i18nt('alarmCode'), key: 'alarmID', width: TABLE_WIDTH_STATE },
  { title: i18nt('alarmDescription'), key: 'alarmDesc' },
  { title: i18nt('alarmTime'), key: 'alarmStartTime', width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('endTime'), key: 'alarmEndTime', width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('duration'), key: 'duration', width: TABLE_WIDTH_DATETIME_MILLISECOND },
  {
    title: i18nt('executeAction'),
    key: 'actions',
    render: ({ scope }: { scope: TableListType }) => {
      return scope.actions?.map((item: number) =>
        h('span', { class: 'mr-6px' }, alarmActionType[item] ? i18nt(alarmActionType[item]) : '')
      );
      return 1;
    }
  }
];
register();
const swiperAlarmRealtime = ref();
const swiperAlarmRealtimeHandle = () => {
  swiperAlarmRealtime.value = new Swiper('.swiperAlarmRealtime', {
    direction: 'vertical',
    slidesPerView: 20,
    slidesPerGroup: 10,
    autoplay: {
      delay: 30000,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    mousewheel: true,
    observer: true
  });
};

// 图表配置
watch(alrmStatisticsDataData, newValue => {
  if (!newValue) return;
  if (chart.value) {
    chart.value?.dispose();
  }

  equipmentHandle();
});
const equipmentRef = ref(null);

const chart = ref<echarts.ECharts>();
// 报警中设备占比
const equipmentHandle = () => {
  nextTick(() => {
    if (equipmentRef.value) {
      chart.value = echarts.init(equipmentRef.value);
      const value = alrmStatisticsDataData.value?.alarmEqpPercent || 0;
      chart.value?.setOption(
        {
          series: [
            {
              type: 'liquidFill',
              radius: '100%',
              center: ['50%', '50%'],
              color: ['#3be3b5'],
              // data个数代表波浪数
              data: [value],
              // 背景色
              backgroundStyle: {
                borderWidth: 1,
                color: '#0f2762'
              },
              label: {
                formatter: `${(value * 100).toFixed(2)}%`,
                fontSize: 30,
                color: '#3be3b5'
              },
              outline: {
                show: false
              }
            }
          ]
        },
        true
      );
      chart.value?.resize();
    }
  });
};

tryOnUnmounted(() => {
  if (alarmRealtimeList.value?.length !== 0 && swiperAlarmRealtime.value) {
    swiperAlarmRealtime.value.destroy(true, false);
    swiperAlarmRealtime.value = null;
  }
  equipmentRef.value = null;
  autofit.off();
  pause();
});
</script>

<template>
  <div
    id="alarm-realtime-dashboard"
    :style="{
      backgroundColor: alarmRealtimeObj?.backgroundColor || '#030c32'
    }"
  >
    <base-spin size="large" :show="refreshLoading">
      <div class="dashboard">
        <div class="dashboard-content">
          <!-- 顶部 -->
          <dashboard-top
            :select-name="alarmRealtimeObj?.areaName || ''"
            :dashboard-name="alarmRealtimeObj?.name || ''"
            :dashboard-title="i18nt('alarmRealtimeDashboard')"
            @refresh="refresh"
            @toggle-screen="toggleScreen"
          />
          <!-- 中间 -->
          <div class="dashboard-middle">
            <!-- 报警统计 -->
            <div class="dashboard-type10">
              <div class="type10-content">
                <div class="left-title">{{ i18nt('alarmStatistics') }}</div>
                <div v-show="alarmRealtimeList?.length !== 0" class="table">
                  <!-- 标题 -->
                  <div class="table-ul table-ul-title">
                    <div
                      v-for="(item, index) in alarmRealtimeColumns"
                      :key="item.key"
                      class="table-li"
                      :style="{
                        textAlign: index === 0 ? 'center' : 'start',
                        maxWidth: item.width ? `${item?.width - 12}px` : `none`,
                        minWidth: `50px`
                      }"
                    >
                      <span> {{ item.title }}</span>
                    </div>
                  </div>
                  <!-- 内容 -->
                  <div class="swiperAlarmRealtime tableSwiper">
                    <div class="swiper-wrapper">
                      <div
                        v-for="(item, index) in alarmRealtimeList"
                        :key="(item.eqpId as string)"
                        class="swiper-slide table-ul"
                        :style="{
                          color: item.alarmEndTime ? '#67c23a' : '#f56c6c'
                        }"
                        :class="
                          alarmRealtimeList?.length === 10 && index === 9 ? 'table-ul-border table-ul' : 'table-ul'
                        "
                      >
                        <div
                          v-for="(columnItem, columnIndex) in alarmRealtimeColumns"
                          :key="columnItem.key"
                          class="table-li"
                          :style="{
                            textAlign: columnIndex === 0 ? 'center' : 'start',
                            maxWidth: columnItem.width ? `${columnItem?.width - 12}px` : `none`,
                            minWidth: `50px`
                          }"
                        >
                          <span v-if="columnIndex === 0">{{ index + 1 }}</span>
                          <div v-else>
                            <div v-if="columnItem.render">
                              <component :is="columnItem.render" :scope="item" />
                            </div>
                            <div v-else>{{ item[columnItem.key] }}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <dashboard-available v-show="alarmRealtimeList?.length === 0" />
              </div>
            </div>
            <!-- 右侧状态 -->
            <div class="middle-type">
              <!-- 报警中设备占比 -->
              <div class="dashboard-type7">
                <div class="type7-content">
                  <div class="left-title">{{ i18nt('alarmEqpPercent') }}</div>
                  <div ref="equipmentRef" class="h-202px! m-t-22px w-100%" />
                </div>
              </div>
              <!-- 设备统计 -->
              <div class="dashboard-type9">
                <div class="type9-content">
                  <div class="left-title">{{ i18nt('deviceStatistics') }}</div>
                  <div class="statistics-ul">
                    <!-- 今日报警次数 -->
                    <div class="statistics-li">
                      <div class="title">{{ $t('todayAlarmCount') }}</div>
                      <div class="text">{{ alrmStatisticsDataData?.totalAlarmCount || 0 }}</div>
                    </div>
                    <!-- 进行中 -->
                    <div class="statistics-li">
                      <div class="title">{{ $t('onGoingCount') }}</div>
                      <div class="text">{{ alrmStatisticsDataData?.onGoingCount || 0 }}</div>
                    </div>
                    <!-- 已关闭 -->
                    <div class="statistics-li">
                      <div class="title">{{ $t('closeAlarmCount') }}</div>
                      <div class="text">{{ alrmStatisticsDataData?.closeAlarmCount || 0 }}</div>
                    </div>
                    <!-- 报警中设备占比 -->
                    <!--
                      <div class="statistics-li">
                      <div class="title">{{ $t('alarmEqpPercent') }}</div>
                      <div class="text">
                      {{ `${((alrmStatisticsDataData?.alarmEqpPercent ?? 0) * 100).toFixed(1)}%` }}
                      </div>
                      </div>
                    -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </base-spin>
  </div>
</template>

<style lang="less" scoped>
@import '@/components/project/dashboard/dashboard.less';

#alarm-realtime-dashboard {
  @dashboard();

  // 中间
  .dashboard-middle {
    margin: 17px auto;
    height: 918px;
    display: flex;
    justify-content: space-between;
    @imageType10();
    // 报警统计
    @tableType();

    .dashboard-type10 {
      width: 1400px;
      height: 918px;

      .type10-content {
        width: 1352px;
        height: 878px;

        .table {
          width: 100%;
          margin-top: 20px;
          border-radius: 10px;
          font-size: 14px;
          border: 1px solid #374d81;
          .tableUlType(#00cfff, 40px);

          .table-ul-title {
            font-size: 16px;
            font-weight: bold;
          }

          .tableSwiper {
            height: 772px;
            overflow: hidden;
            .tableUlType(#9bd0ff, 40px);
          }
        }
      }
    }

    // 右侧状态
    .middle-type {
      width: 456px;
      height: 918px;
      // 报警中设备占比
      @imageType7();

      .dashboard-type7 {
        padding-top: 1px;
        height: 295px;
      }

      // 设备统计
      @imageType9();

      .dashboard-type9 {
        padding-top: 1px;
        margin-top: 16px;
        height: 605px;

        .statistics-ul {
          width: 100%;
          margin-top: 20px;
          height: 526px;

          .statistics-li {
            height: 160px;
            padding: 0 20px;
            margin-bottom: 20px;
            background: #0f2762;
            border-radius: 10px;
            display: flex;
            align-items: center;

            .title {
              width: 190px;
              font-size: 28px;
              color: #9bd0ff;
            }

            .text {
              width: 178px;
              font-size: 35px;
              font-weight: bold;
              color: #3be3b5;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }
          }
        }
      }
    }
  }
}
</style>
