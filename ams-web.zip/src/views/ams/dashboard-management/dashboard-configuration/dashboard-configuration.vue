<script setup lang="tsx">
import addForm from './components/add-form.vue';
import { DashboardConfigurationApis } from '@/service/apis/ams/dashboard-management/dashboard-configuration';
import type {
  EditType,
  QueryType,
  TableListType
} from '@/service/apis/ams/dashboard-management/dashboard-configuration';
import { CommonApis } from '@/service/apis/common/common';

const { hasEditPermission } = useRoutes();
const appStore = useAppStore();
const userStore = useUserStore();
const { systemPermissions } = storeToRefs(userStore);

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
const addFormRef = ref();

// 获取设备编号列表

const { isLoading: isLoadingEquipmentNumberList, data: equipmentNumberList } = useAxiosGet<OptionsType[]>(
  CommonApis.getEquipmentNumberIdListApi,
  __,
  __,
  {
    immediate: true
  }
);

// 查询表单配置
const queryFormParams: Nullable<QueryType> = {
  name: null,
  area: null,
  category: null,
  eqpId: null,
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'name',
    formItemProps: {
      label: i18nt('dashboardName'),
      rule: [useRuleStringLength(0, 50)]
    }
  },
  {
    type: 'input',
    model: 'area',
    formItemProps: {
      label: i18nt('region')
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'select',
    model: 'category',
    formItemProps: { label: i18nt('category') },
    componentProps: {
      options: categoryList.value,
      loading: false
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('eqpName') },
    componentProps: {
      options: equipmentNumberList.value,
      loading: isLoadingEquipmentNumberList.value,
      valueField: 'id',
      labelField: 'name'
    },
    formItemClass: 'col-span-2!'
  }
]);

// 类别列表
const categoryList = computed<SelectOption[]>(() => {
  const list = [
    {
      label: i18nt('productionDashboard'),
      value: '1'
    },
    {
      label: i18nt('equipmentDashboard'),
      value: '2'
    },
    {
      label: i18nt('alarmRealtimeDashboard'),
      value: '3'
    },
    {
      label: i18nt('alarmStatisticsDashboard'),
      value: '4'
    }
  ];
  return systemPermissions.value?.callOpen === 1 ? list : list.splice(2, 4);
});
const categoryObj: {
  [key: number]: {
    name: string;
    routerHandle: (id: string) => void;
  };
} = {
  1: {
    name: i18nt('productionDashboard'),
    routerHandle: (id: string) => {
      router.push(`/ams/dashboard-management/production-dashboard/${id}`);
    }
  },
  2: {
    name: i18nt('equipmentDashboard'),
    routerHandle: (id: string) => {
      router.push(`/ams/dashboard-management/equipment-dashboard/${id}`);
    }
  },
  3: {
    name: i18nt('alarmRealtimeDashboard'),
    routerHandle: (id: string) => {
      router.push(`/ams/dashboard-management/alarm-realtime-dashboard/${id}`);
    }
  },
  4: {
    name: i18nt('alarmStatisticsDashboard'),
    routerHandle: (id: string) => {
      router.push(`/ams/dashboard-management/alarm-statistics-dashboard/${id}`);
    }
  }
};

// 表格数据配置
const curdRefPagination = computed(() => curdRef.value?.pagination);
const router = useRouter();
const tableColumns = computed<DataTableColumns<TableListType>>(() => {
  const list = tableAlarmColumns;
  if (systemPermissions.value?.callOpen === 1) {
    list.splice(7, 0, ...tableCategoryColumns);
  }
  return list;
});
const tableAlarmColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    key: 'name',
    title: i18nt('dashboardName'),
    sorter: true,
    width: TABLE_WIDTH_INFO,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.name, () => {
        addFormRef.value.handleOpenModal(
          rowData.id,
          hasEditPermission.value,
          categoryList.value,
          systemPermissions.value?.callOpen
        );
      })
  },
  {
    key: 'backgroundColor',
    title: i18nt('billboardBackground'),
    width: TABLE_WIDTH_STATE,
    render: (rowData: TableListType) => (
      <div
        class="w-100%!"
        style={{
          padding: '8px',
          backgroundColor: rowData.backgroundColor
        }}
      />
    )
  },
  { title: i18nt('region'), key: 'areaName', sorter: true, width: TABLE_WIDTH_INFO },
  {
    title: i18nt('category'),
    key: 'category',
    sorter: true,
    width: TABLE_WIDTH_INFO,
    render: (rowData: TableListType) => (rowData.category ? categoryObj[rowData.category].name : '')
  },
  { title: i18nt('eqpName'), key: 'eqpNames', ...useRenderTableMultiTag('eqpNames') },
  { title: i18nt('creator'), key: 'creator', width: TABLE_WIDTH_NAME },
  {
    title: i18nt('createTime'),
    key: 'createTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  useRenderTableActionColumn({
    width: TABLE_WIDTH_ACTION,
    render: rowData => {
      return useRenderTableFixedButton('play', {
        onClick: () => {
          categoryObj[rowData.category].routerHandle(rowData.id);
        }
      });
    }
  })
];
const tableCategoryColumns: DataTableColumns<TableListType> = [
  {
    title: i18nt('abnormalityType'),
    key: 'flowTypes',
    ...useRenderTableMultiTag('flowTypes')
  }
];
// 刷新页面
const resetTable = () => {
  curdRef?.value?.handleSearch();
};
// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    add: () => addFormRef.value.handleOpenModal(__, true, categoryList.value, systemPermissions.value?.callOpen),
    edit: () =>
      addFormRef.value.handleOpenModal(
        curdRef?.value?.tableRef?.selectedKeys[0],
        hasEditPermission.value,
        categoryList.value,
        systemPermissions.value?.callOpen
      )
  };
  columnsList[permission as string]?.();
};
</script>

<template>
  <div id="call-dashboard">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :read-api="DashboardConfigurationApis.getPageListApi"
      :delete-api="DashboardConfigurationApis.deleteApi"
      modal-title="callDashboard"
      @handle="handlePermission"
    />
    <addForm ref="addFormRef" @reset-table="resetTable" />
  </div>
</template>

<style scoped lang="less">
#call-dashboard {
  :deep(.n-data-table-td) {
    .n-ellipsis {
      width: 100%;
    }
  }
}
</style>
