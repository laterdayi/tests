<script setup lang="tsx">
import { NTag } from 'naive-ui';
import { DashboardConfigurationApis } from '@/service/apis/ams/dashboard-management/dashboard-configuration';
import type { EditType, EquipmentType } from '@/service/apis/ams/dashboard-management/dashboard-configuration';
import { CallEquipmentOverviewApis } from '@/service/apis/ams/equipment-call/call-equipment-overview';
import type { FlowTypesListType } from '@/service/apis/ams/equipment-call/call-equipment-overview';

const emit = defineEmits<{
  'reset-table': [];
}>();

// 获取树数据
const {
  data: equipmentList,
  execute: executeGetEquipmentList,
  isLoading: isLoadingEquipmentList
} = useAxiosGet<EquipmentType[]>(DashboardConfigurationApis.getEquipmentListApi);

// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
// 弹窗title
const modalTitle = ref<string>('');
// 接口设置
const modalUrl = ref<string>('');
// 是否是详情页
const viewDetailIsShow = ref<boolean>(false);
// 获取表单详情
const { execute: executeGetDetails } = useAxiosGet<EditType>(DashboardConfigurationApis.getDetailApi);
// 异常类型
const flowTypesList = ref<FlowTypesListType[]>();
const { execute: executeGetFlowType, isLoading: isLoadingFlowType } = useAxiosGet<FlowTypesListType[]>(
  CallEquipmentOverviewApis.getFlowTypeApi
);
// 类别列表
const categoryNewList = ref<SelectOption[]>();
const callOpenType = ref<number>(0);
//  打开弹窗
const handleOpenModal = async (id: string, isShow: boolean, categoryList: SelectOption[], callOpen: number) => {
  resetField();
  clearSelectedList();
  viewDetailIsShow.value = !isShow;
  categoryNewList.value = categoryList;
  callOpenType.value = callOpen;
  try {
    const { data: flowTypesData } = await executeGetFlowType();
    flowTypesList.value = flowTypesData.value
      ? [
          {
            id: 'All',
            disabled: false,
            name: i18nt('All')
          },
          ...flowTypesData.value
        ]
      : [];
    await executeGetEquipmentList();
    defaultExpandedKeys.value = removeInnerLevel(equipmentList.value || []);
    if (id) {
      modalTitle.value = isShow ? i18nt('edit') + i18nt('callDashboard') : i18nt('viewDetail');
      modalUrl.value = DashboardConfigurationApis.updateApi;
      const { data } = await executeGetDetails({
        params: { id }
      });
      if (!data.value) return;
      formData.value = data.value;
      updatecheckAllKeys(data.value.eqpIds);
    } else {
      modalTitle.value = i18nt('add') + i18nt('callDashboard');
      modalUrl.value = DashboardConfigurationApis.addApi;
    }
    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 左侧树
const { handleIndeterminate, handleCheck, checkAllKeys, clearSelectedList, updatecheckAllKeys } = useTree();
// 树默认展开的数组
const defaultExpandedKeys = ref<string[]>([]);
// 树展开处理
const removeInnerLevel = (tree: EquipmentType[], level = 0, list: string[] = []): string[] => {
  for (let i = 0; i < tree.length; i++) {
    if (level <= 0) {
      list.push(tree[i].id);
    }
    if (tree[i].children) {
      removeInnerLevel(tree[i].children ?? [], level + 1, list);
    }
  }
  return list;
};
// 表单配置
const { formData, resetField, restoreValidation, validate, formRef } = useForm<Nullable<EditType>>({
  name: null,
  areaName: null,
  eqpIds: [],
  description: null,
  category: null,
  backgroundColor: '#1400a8',
  flowTypes: []
});

const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'name',
    formItemProps: {
      label: i18nt('dashboardName'),
      rule: [useRules('input', i18nt('dashboardName')), useRuleStringLength(0, 50)]
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'color-picker',
    model: 'backgroundColor',
    formItemProps: {
      label: i18nt('billboardBackground')
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'areaName',
    formItemProps: {
      label: i18nt('region'),
      rule: [useRules('input', i18nt('region')), useRuleStringLength(0, 50)]
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'select',
    model: 'category',
    formItemProps: { label: i18nt('category'), rule: useRules('change', i18nt('category')) },
    componentProps: {
      options: categoryNewList.value,
      loading: false,
      onUpdateValue: () => {
        formData.value.flowTypes = null;
        restoreValidation();
      }
    },
    formItemClass: 'col-span-2!'
  },
  callOpenType.value === 1 && (formData.value.category === '1' || formData.value.category === '2')
    ? {
        type: 'select',
        model: 'flowTypes',
        formItemProps: {
          label: i18nt('abnormalityType'),
          rule: { type: 'array', ...useRules('change', i18nt('abnormalityType')) }
        },
        componentProps: {
          valueField: 'id',
          labelField: 'name',
          options: flowTypesList.value,
          loading: isLoadingFlowType.value,
          multiple: true,
          renderTag: ({ option, handleClose }) => {
            return h(
              NTag,
              {
                closable: true,
                onMousedown: (e: FocusEvent) => {
                  e.preventDefault();
                },
                onClose: (e: MouseEvent) => {
                  e.stopPropagation();
                  handleClose();
                  if (option.id === 'All') {
                    formData.value.flowTypes = [];
                  } else if (formData.value.flowTypes?.includes('All')) {
                    formData.value.flowTypes = formData.value.flowTypes?.filter(id => id !== 'All');
                  }
                }
              },
              { default: () => option.name }
            );
          },
          nodeProps: option => {
            return {
              onClick() {
                if (option.id === 'All') {
                  if (!formData.value.flowTypes) return;
                  formData.value.flowTypes = ['All'];
                } else {
                  if ((formData.value.flowTypes?.length ?? 0) <= (flowTypesList.value || []).length) {
                    formData.value.flowTypes = formData.value.flowTypes?.filter(id => id !== 'All') ?? [];
                  }
                }
              }
            };
          }
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  useRenderFormTextarea({
    model: 'description',
    label: i18nt('description'),
    formItemClass: 'col-span-2!'
  })
]);
// 提交
const { isLoading: isLoadingChangeExecutor, execute: executeChangeExecutor } = useAxiosPost('');
const handleSubmitChangeExecutor = async () => {
  try {
    if (checkAllKeys.value.length === 0) {
      $message.warning(i18nt('baseForm.pleaseSelect', { val: i18nt('equipment') }));
      return;
    }
    await validate();
    await executeChangeExecutor(modalUrl.value, {
      data: {
        ...formData.value,
        eqpIds: checkAllKeys.value
      }
    });
    emit('reset-table');
    closeModal();
  } catch (error) {
    console.log(error);
  }
};

defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :loading="isLoadingChangeExecutor"
    :show="showModal"
    :title="modalTitle"
    :positive-text="viewDetailIsShow ? '' : i18nt('confirm')"
    :inside-scroll="false"
    @close="closeModal"
    @negative-click="closeModal"
    @positive-click="handleSubmitChangeExecutor"
    @after-leave="resetField()"
  >
    <div class="flex">
      <base-tree
        class="modal-content-height"
        layout="dialog"
        check-on-click
        :disabled="viewDetailIsShow"
        :default-checked-keys="checkAllKeys"
        :default-expanded-keys="defaultExpandedKeys"
        :loading="isLoadingEquipmentList"
        :data="equipmentList ?? []"
        :default-expand-all="false"
        key-field="id"
        label-field="name"
        @update:checked-keys="handleCheck"
        @update:indeterminate-keys="handleIndeterminate"
      />
      <div class="w-100%">
        <base-form
          ref="formRef"
          v-model="formData"
          :disabled="viewDetailIsShow"
          layout="dialog"
          :schemas="formSchemas"
        />
      </div>
    </div>
  </base-modal>
</template>
