<script setup lang="tsx">
import type { BarSeriesOption } from 'echarts/charts';
import Swiper from 'swiper';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import { register } from 'swiper/element/bundle';
import autofit from 'autofit.js';
import { CallState, ProductionDashboardApis } from '@/service/apis/ams/dashboard-management/production-dashboard';
import type {
  CallEqpInfosType,
  CallsType,
  EqpStatusListDataType,
  FaultStatisticsType,
  ProduceDashboardType,
  StatusDashboardType
} from '@/service/apis/ams/dashboard-management/production-dashboard';

import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { PtFormType } from '@/service/apis/ams/system-setting';
import dashboardTop from '@/components/project/dashboard/dashboard-top.vue';
import dashboardAvailable from '@/components/project/dashboard/dashboard-available.vue';

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);

// 获取通用设置
const { execute: executeCallCommonSetting } = useAxiosGet<PtFormType>(AlarmSystemSettingApis.getCallCommonSettingApi);

// 获取设备状态数据
const statusDashboardData = ref<StatusDashboardType>();
// const { data: statusDashboardData, execute: executeGetStatusDashboard } = useAxiosGet<StatusDashboardType>(
//   CallDashboardApis.getEqpStatusDashboardApi
// );

// 获取看板全部数据
const { data: produceDashboardData, execute: executeGetProduceDashboardApi } = useAxiosGet<ProduceDashboardType>(
  ProductionDashboardApis.getProduceDashboardApi
);
// 获取看板顶部状态数据
const eqpStatusListData = ref<EqpStatusListDataType[]>([]);
const { execute: executeGetEqpStatusListApi } = useAxiosGet<OptionsType[]>(ProductionDashboardApis.getEqpStatusListApi);

const route = useRoute();
const { params } = route;
register();

tryOnMounted(async () => {
  refreshLoading.value = true;
  await callCommonSettingHandle();
  autofitHandle();
  listDetail(undefined, true);
  tableDetail(true);
});
// 轮播刷新频率
const delayLength = ref<number>(3000);
const callCommonSettingHandle = async () => {
  try {
    const { data } = await executeCallCommonSetting();
    listTiming.value = (data?.value?.productTopRefreshTime || 0) * 60000 || 3000000;
    tabTiming.value = (data?.value?.refreshTime || 0) * 1000 || 10000;
    delayLength.value = (data?.value?.rollTime || 0) * 1000 || 3000;
  } catch (error) {
    console.log(error);
  }
};

// 处理页面适配
const autofitHandle = () => {
  autofit.init({
    dh: 1080,
    dw: 1920,
    el: '#production-dashboard',
    resize: true
  });
};
// 全屏
const { toggle: toggleScreen } = useFullscreen();
// 刷新页面
const refreshLoading = ref<boolean>(false);
const refresh = async () => {
  refreshLoading.value = true;
  listPause();
  tablePause();

  clearSwiper();
  activeName.value = '';
  await callCommonSettingHandle();

  listDetail(undefined, true, true);
  listResume();
  tableDetail(true);
  tableResume();
};

// 顶部列表定时刷新
const listTiming = ref<number>(3000000);
const listDetail = async (status?: string, swiperIsShow = false, update = false) => {
  try {
    // 获取设备状态数据
    // await executeGetStatusDashboard({ params: { id: params.id, status: activeName.value } });
    statusDashboardData.value = {
      'callEqpStatusDtos': [
        {
          'eqpType': 'H5620',
          'callEqpInfos': [
            {
              'eqpId': 'H56101-1',
              'statues': 'Running',
              'downTime': '85天10时3分52秒'
            },
            {
              'eqpId': 'H56101-2',
              'statues': 'Running',
              'downTime': '85天9时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'GSD1430N-AA',
          'callEqpInfos': [
            {
              'eqpId': 'NDB001',
              'statues': 'Idle',
              'downTime': '86天9时56分52秒'
            },
            {
              'eqpId': 'NDB002',
              'statues': 'Running',
              'downTime': '87天9时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'SLD-1101A��FVI��',
          'callEqpInfos': [
            {
              'eqpId': 'IFFVI001',
              'statues': 'Running',
              'downTime': '87天16时56分52秒'
            },
            {
              'eqpId': 'IFFVI002',
              'statues': 'Down',
              'downTime': '87天15时56分52秒'
            },
            {
              'eqpId': 'IFFVI003',
              'statues': 'Lending',
              'downTime': '87天14时56分52秒'
            },
            {
              'eqpId': 'IFFVI004',
              'statues': 'Stop',
              'downTime': '87天15时56分52秒'
            },
            {
              'eqpId': 'IFFVI006',
              'statues': 'Idle',
              'downTime': '87天7时56分52秒'
            },
            {
              'eqpId': 'IFFVI007',
              'statues': 'PM',
              'downTime': '87天8时56分52秒'
            },
            {
              'eqpId': 'IFFVI008',
              'statues': 'PM',
              'downTime': '86天9时56分52秒'
            },
            {
              'eqpId': 'IFFVI009',
              'statues': 'B/I pretest',
              'downTime': '88天9时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'March',
          'callEqpInfos': [
            {
              'eqpId': 'WBP6003',
              'statues': 'Setup',
              'downTime': '88天2时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'Mol-2DW',
          'callEqpInfos': [
            {
              'eqpId': 'OVN6152',
              'statues': 'Setup',
              'downTime': '88天2时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'SBT PB C-SUN (MOL-2DSA)',
          'callEqpInfos': [
            {
              'eqpId': 'OVN6001',
              'statues': 'Setup',
              'downTime': '88天2时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'TN100B',
          'callEqpInfos': [
            {
              'eqpId': 'LD6001',
              'statues': 'Setup',
              'downTime': '88天2时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'UA3000II',
          'callEqpInfos': [
            {
              'eqpId': 'UV6001',
              'statues': 'Setup',
              'downTime': '88天2时56分52秒'
            }
          ]
        },
        {
          'eqpType': 'LAB--HTS-01',
          'callEqpInfos': [
            {
              'eqpId': 'LAB-HTS-01',
              'statues': 'Setup',
              'downTime': '88天2时56分52秒'
            }
          ]
        }
      ],
      'eqpStatusNumStatistics': [
        {
          'status': 'Running',
          'num': 4
        },
        {
          'status': 'Idle',
          'num': 2
        },
        {
          'status': 'Down',
          'num': 1
        },
        {
          'status': 'Lending',
          'num': 1
        },
        {
          'status': 'Stop',
          'num': 1
        },
        {
          'status': 'PM',
          'num': 2
        },
        {
          'status': 'B/I pretest',
          'num': 1
        },
        {
          'status': 'Setup',
          'num': 6
        }
      ]
    };
    // 处理顶部轮播
    const { data: eqpStatusData } = await executeGetEqpStatusListApi();
    if (!eqpStatusData.value) return;
    eqpStatusListData.value = eqpStatusData.value.map(ele => {
      const item = statusDashboardData.value?.eqpStatusNumStatistics.find(
        (ele1: { status: string }) => ele1.status === ele.name
      );
      return {
        id: ele.id,
        name: ele.name,
        num: item ? item.num : 0,
        activeIsShow: false
      };
    });
    const index = eqpStatusListData.value.findIndex(ele => ele.name === activeName.value);
    if (index !== -1) {
      eqpStatusListData.value[index].activeIsShow = true;
    }
    if (swiperIsShow) {
      if (statusDashboardData?.value?.callEqpStatusDtos.length === 0 && !swiperList.value) return;
      swiperListHandle();
      if (!update) return;
      swiperList.value.update();
    }
  } catch (error) {
    console.log('获取实时数据', error);
  }
};

const { pause: listPause, resume: listResume } = useIntervalFn(listDetail, listTiming);

// 中间轮播处理
const swiperList = ref();
const swiperUlList = ref();
const swiperListHandle = () => {
  swiperList.value = new Swiper('.swiperList', {
    slidesPerView: 4,
    slidesPerGroup: 4,
    spaceBetween: 12,
    mousewheel: true,
    observer: true
  });
  swiperUlList.value = new Swiper('.swiperUlList', {
    direction: 'vertical',
    slidesPerView: 4,
    slidesPerGroup: 4,
    spaceBetween: 0,
    autoplay: {
      delay: delayLength.value,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    observer: true,
    observeSlideChildren: true
  });
};
const tableTopColumns = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX
  },
  { title: i18nt('eqpName'), key: 'eqpId' },
  {
    title: i18nt('state'),
    key: 'statues',
    width: TABLE_WIDTH_INDEX,
    render: ({ scope }: { scope: CallEqpInfosType }) => {
      return (
        <div
          class="statues h-70%"
          style={{
            backgroundColor: eqpStatusListObj[scope.statues]
          }}
        />
      );
    }
  },
  {
    title: i18nt('duration'),
    key: 'downTime',
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  }
];
// 设备状态对象
const eqpStatusListObj: {
  [key: string]: string;
} = {
  Running: '#73d376',
  Retest: '#d6f601',
  Idle: '#dededc',
  'Lot Change': '#ff92c3',
  Setup: '#00d7d6',
  PM: '#deb892',
  Down: '#fe4448',
  Lending: '#847fc0',
  Stop: '#d06b24',
  'B/I pretest': '#aee4f7'
};
const activeName = ref<string>('');
// 设备状态点击
const activeClick = (item: EqpStatusListDataType, index: number) => {
  listPause();
  if (item.activeIsShow) {
    eqpStatusListData.value[index].activeIsShow = false;
    activeName.value = '';
  } else {
    eqpStatusListData.value[index].activeIsShow = true;
    activeName.value = item.name;
  }
  // statusDashboardData.value = {
  //   callEqpStatusDtos: [],
  //   eqpStatusNumStatistics: []
  // };
  clearSwiper(false);
  listDetail(activeName.value, true, true);
  listResume();
};

// 底部表格定时刷新
const tabTiming = ref<number>(10000);
const tableDetail = async (swiperIsShow = false) => {
  try {
    await executeGetProduceDashboardApi({ params: { id: params.id } });
    if (swiperIsShow) {
      swiperTableHandle();
      refreshLoading.value = false;
    }
  } catch (error) {
    console.log('获取实时数据', error);
  }
};
const { pause: tablePause, resume: tableResume } = useIntervalFn(tableDetail, tabTiming);

// 当前状态对象
const currentStatusObj: {
  [key: number]: {
    color: string;
    title: string;
  };
} = {
  [CallState.toTakeOver]: {
    color: '#F56C6C',
    title: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  [CallState.underRepair]: {
    color: '#F0AD4E',
    title: i18nt('underRepair')
  },
  [CallState.underInspection]: {
    color: '#8B4513',
    title: i18nt('underInspection')
  },
  [CallState.finalizeTheOrder]: {
    color: '#5CB85C',
    title: i18nt('finalizeTheOrder')
  }
};
// 催单
const { isLoading: isLoadingRemind, execute: executeRemindApi } = useAxiosPost(ProductionDashboardApis.remindApi);
const tableColumns = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX
  },
  {
    title: i18nt('eqpName'),
    key: 'eqpId',
    width: TABLE_WIDTH_DATE - 10
  },
  {
    title: i18nt('abnormalityType'),
    key: 'flowType',
    width: TABLE_WIDTH_ACTION
  },
  {
    title: i18nt('callType'),
    key: 'callType',
    width: TABLE_WIDTH_ACTION
  },
  {
    title: i18nt('currentState'),
    key: 'state',
    width: TABLE_WIDTH_ACTION,
    render: ({ scope }: { scope: CallsType }) => {
      return (
        <base-tag
          color={{
            color: currentStatusObj[scope.state].color,
            textColor: '#FFFFFF',
            borderColor: currentStatusObj[scope.state].color
          }}
          size={componentSize.value}
        >
          {currentStatusObj[scope.state].title}
        </base-tag>
      );
    }
  },
  { title: i18nt('currentAssignee'), key: 'currentHandler', width: TABLE_WIDTH_DATE - 20 },
  { title: i18nt('callTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME_MILLISECOND + 50 },
  { title: i18nt('downtimeDuration'), key: 'downTime', width: TABLE_WIDTH_INFO },
  {
    title: i18nt('operate'),
    key: '',
    width: TABLE_WIDTH_INDEX,
    render: ({ scope }: { scope: CallsType }) => {
      return scope.state === 1 ? (
        <div class="w-100%! cursor-pointer" onClick={() => remindHandle(scope.id)}>
          {i18nt('reminder')}
        </div>
      ) : null;
    }
  }
];
// 催单
const remindHandle = async (id: string) => {
  try {
    await executeRemindApi({ data: { id } });
  } catch (error) {
    console.log(error);
  }
};
// 底部表格轮播处理
const swiperTable = ref();
const swiperTableHandle = () => {
  swiperTable.value = new Swiper('.swiperTable', {
    direction: 'vertical',
    slidesPerView: 10,
    slidesPerGroup: 5,
    autoplay: {
      delay: delayLength.value,
      stopOnLastSlide: false,
      pauseOnMouseEnter: true
    },
    mousewheel: true,
    observer: true
  });
};

// 图表配置
const chartBarRef = ref<ChartRefType | null>(null);
const chartPieRef = ref<ChartRefType | null>(null);
// 柱状图
const handleBarSearch = () => {
  nextTick(() => {
    if (chartBarRef.value) {
      const xAxisData = produceDashboardData.value?.eqpStatistics.map(ele => ele.name) || [];
      chartBarRef.value?.setOption(
        {
          ...BAR_OPTION,
          grid: {
            left: '10px',
            right: '10px',
            containLabel: true
          },
          toolbox: {
            show: false
          },
          legend: {
            data: [i18nt('downtimeDuration'), i18nt('callsNumber')],
            textStyle: {
              color: '#9BD0FF'
            }
          },
          color: ['#FF7070', '#FFDC60'],
          xAxis: {
            type: 'category',
            data: xAxisData,
            axisTick: {
              alignWithLabel: true
            },
            axisLabel: {
              color: '#9BD0FF',
              rotate: 40
            },
            axisLine: {
              lineStyle: {
                color: '#9BD0FF'
              }
            },
            splitLine: {
              lineStyle: {
                color: '#9BD0FF'
              }
            }
          },
          yAxis: [
            {
              type: 'value',
              name: i18nt('minute'),
              minInterval: 1,
              axisLabel: {
                color: '#9BD0FF'
              },
              axisLine: {
                show: true,
                lineStyle: {
                  color: '#9BD0FF'
                }
              },
              splitLine: {
                lineStyle: {
                  color: '#374d81'
                }
              }
            },
            {
              type: 'value',
              name: i18nt('freq'),
              minInterval: 1,
              splitLine: {
                show: false
              },
              axisLine: {
                lineStyle: {
                  color: '#9BD0FF'
                }
              }
            }
          ],
          series: [
            {
              ...(BAR_OPTION.series as BarSeriesOption[])[0],
              type: 'bar',
              name: i18nt('downtimeDuration'),
              large: true,
              data: produceDashboardData.value?.eqpStatistics.map(ele => ele.downtime),
              label: {
                show: true,
                color: '#FFFFFF'
              }
            },
            {
              type: 'line',
              name: i18nt('callsNumber'),
              yAxisIndex: 1,
              data: produceDashboardData.value?.eqpStatistics.map(ele => ele.num),
              label: {
                show: true,
                color: '#FFFFFF'
              }
            }
          ]
        },
        true
      );
      chartBarRef.value?.resize();
    }
  });
};
// 饼图
const handlePieSearch = () => {
  nextTick(() => {
    if (chartPieRef.value) {
      const faultStatisticsLIst: FaultStatisticsType[] =
        produceDashboardData.value?.faultStatistics.map(ele => {
          return {
            value: ele.downtime,
            name: ele.name,
            num: ele.num
          };
        }) || [];
      chartPieRef.value?.setOption(
        {
          tooltip: {
            show: true,
            trigger: 'item',
            formatter(params) {
              if (!Array.isArray(params)) {
                const data = params.data as { name: string; value: number; num: number };
                return `${data.name}:<br/>
                &nbsp&nbsp${i18nt('downtimeDuration')}: ${data.value}<br/>
                &nbsp&nbsp${i18nt('callsNumber')}: ${data.num} `;
              }
              return '';
            }
          },
          series: [
            {
              name: '数量',
              type: 'pie',
              radius: ['30%', '50%'],
              center: ['50%', '40%'],
              data: faultStatisticsLIst,
              // avoidLabelOverlap: false,
              label: {
                formatter: ['{c|{c}}', '{b|{b}}'].join('\n'),
                rich: {
                  c: {
                    color: '#9BD0FF',
                    fontSize: 18,
                    fontWeight: 'bold'
                  },
                  b: {
                    color: '#9BD0FF',
                    fontSize: 15,
                    height: 40
                  }
                }
              }
            }
          ]
        },
        true
      );
      chartPieRef.value?.resize();
      chartPieRef.value?.resize();
    }
  });
};

watch(produceDashboardData, newValue => {
  if (!newValue) return;
  if (produceDashboardData.value?.eqpStatistics.length !== 0) {
    handleBarSearch();
  }
  if (produceDashboardData.value?.faultStatistics.length !== 0) {
    handlePieSearch();
  }
});

// 清除页面轮播
const clearSwiper = (tableIsShow = true) => {
  if (statusDashboardData?.value?.callEqpStatusDtos.length !== 0 && swiperList.value) {
    swiperList.value.destroy(true, true);
    swiperList.value = null;
  }
  if (swiperUlList.value) {
    if (Array.isArray(swiperUlList.value)) {
      swiperUlList.value.forEach((ele: { destroy: (arg0: boolean, arg1: boolean) => void }) => {
        ele.destroy(true, true);
      });
    } else {
      if (swiperUlList.value.destroyed) {
        swiperUlList.value.destroy(true, true);
      }
    }
    swiperUlList.value = null;
  }
  if (!tableIsShow) return;
  if (produceDashboardData?.value?.calls.length !== 0 && swiperTable.value) {
    swiperTable.value.destroy(true, true);
    swiperTable.value = null;
  }
};

onBeforeUnmount(() => {
  clearSwiper();

  autofit.off();
  listPause();
  tablePause();
});
</script>

<template>
  <div
    id="production-dashboard"
    :style="{
      backgroundColor: produceDashboardData?.backgroundColor || '#030c32'
    }"
  >
    <base-spin size="large" :show="refreshLoading || isLoadingRemind">
      <div class="dashboard">
        <div class="dashboard-content">
          <!-- 顶部 -->
          <dashboard-top
            :select-name="produceDashboardData?.areaName || ''"
            :dashboard-name="produceDashboardData?.name || ''"
            :dashboard-title="i18nt('productionDashboard')"
            @refresh="refresh"
            @toggle-screen="toggleScreen"
          />
          <!-- 中间 轮播展示 -->
          <div v-if="statusDashboardData?.callEqpStatusDtos.length !== 0" class="dashboard-middle swiperList">
            <div class="swiper-wrapper">
              <div
                v-for="topItem in statusDashboardData?.callEqpStatusDtos"
                :key="topItem.eqpType"
                class="dashboard-type7 swiper-slide"
              >
                <div class="swiper-content type7-content">
                  <div class="left-title">{{ topItem.eqpType }}</div>
                  <!-- 嵌套表格 -->
                  <div v-if="topItem.callEqpInfos.length !== 0" class="table">
                    <div class="table-ul table-ul-title">
                      <div
                        v-for="(item, index) in tableTopColumns"
                        :key="item.key"
                        class="table-li"
                        :style="{
                          textAlign: index === 0 ? 'center' : 'start',
                          maxWidth: item.width ? `${item?.width - 12}px` : `none`,
                          minWidth: `38px`
                        }"
                      >
                        <span> {{ item.title }}</span>
                      </div>
                    </div>
                    <!-- 内容 -->
                    <div class="swiperUlList">
                      <div class="swiper-wrapper">
                        <div
                          v-for="(item, index) in topItem.callEqpInfos"
                          :key="item.eqpId"
                          class="swiper-slide table-ul"
                          :class="
                            item.state === 1
                              ? 'table-ul-state table-ul'
                              : topItem.callEqpInfos.length === 10 && index === 9
                                ? 'table-ul-border table-ul'
                                : 'table-ul'
                          "
                        >
                          <div
                            v-for="(columnItem, columnIndex) in tableTopColumns"
                            :key="columnItem.key"
                            class="table-li"
                            :style="{
                              textAlign: columnIndex === 0 ? 'center' : 'start',
                              maxWidth: columnItem.width ? `${columnItem?.width - 12}px` : `none`,
                              minWidth: `38px`
                            }"
                          >
                            <span v-if="columnIndex === 0">{{ index + 1 }}</span>
                            <div v-else class="table-li-div">
                              <div v-if="columnItem.render">
                                <component :is="columnItem.render" :scope="item" />
                              </div>
                              <div v-else>
                                {{ item[columnItem.key] }}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <dashboard-available v-else />
                </div>
              </div>
            </div>
          </div>
          <div v-show="statusDashboardData?.callEqpStatusDtos.length === 0" class="middle-available">
            <dashboard-available />
          </div>
          <!-- 底部 -->
          <div class="bottom">
            <!-- 待处理列表 -->
            <div class="dashboard-type10">
              <div class="type10-content">
                <div class="left-title">{{ i18nt('pendingTaskList') }}</div>
                <div v-show="produceDashboardData?.calls.length !== 0" class="table">
                  <!-- 标题 -->
                  <div class="table-ul table-ul-title">
                    <div
                      v-for="(item, index) in tableColumns"
                      :key="item.key"
                      class="table-li"
                      :style="{
                        textAlign: index === 0 ? 'center' : 'start',
                        maxWidth: item.width ? `${item?.width - 12}px` : `none`,
                        minWidth: `50px`
                      }"
                    >
                      <span> {{ item.title }}</span>
                    </div>
                  </div>
                  <!-- 内容 -->
                  <div class="swiperTable">
                    <div class="swiper-wrapper">
                      <div
                        v-for="(item, index) in produceDashboardData?.calls"
                        :key="item.eqpId"
                        class="swiper-slide table-ul"
                        :class="
                          item.state === 1
                            ? 'table-ul-state table-ul'
                            : produceDashboardData?.calls.length === 10 && index === 9
                              ? 'table-ul-border table-ul'
                              : 'table-ul'
                        "
                      >
                        <div
                          v-for="(columnItem, columnIndex) in tableColumns"
                          :key="columnItem.key"
                          class="table-li"
                          :style="{
                            textAlign: columnIndex === 0 ? 'center' : 'start',
                            maxWidth: columnItem.width ? `${columnItem?.width - 12}px` : `none`,
                            minWidth: `50px`
                          }"
                        >
                          <span v-if="columnIndex === 0">{{ index + 1 }}</span>
                          <div v-else>
                            <div v-if="columnItem.render">
                              <component :is="columnItem.render" :scope="item" />
                            </div>
                            <div v-else>{{ item[columnItem.key] }}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <dashboard-available v-show="produceDashboardData?.calls.length === 0" />
              </div>
            </div>
            <!-- 左侧 -->
            <div class="statistics">
              <div class="statistics-top">
                <!-- 故障类型统计 -->
                <div class="dashboard-type7">
                  <div class="type7-content">
                    <div class="left-title">{{ i18nt('faultTypeStatistics') }}</div>
                    <base-chart
                      v-if="produceDashboardData?.faultStatistics.length !== 0"
                      ref="chartPieRef"
                      class="w-100%"
                    />
                    <dashboard-available v-else />
                  </div>
                </div>
                <!-- 设备状态 -->
                <div class="dashboard-type7">
                  <div class="type7-content">
                    <div class="left-title">{{ i18nt('equipmentStatus') }}</div>
                    <div class="type-ul">
                      <div
                        v-for="(item, index) in eqpStatusListData"
                        :key="item.id"
                        class="type-li-left"
                        :style="{
                          color: eqpStatusListObj[item.name]
                        }"
                        @click="activeClick(item, index)"
                      >
                        <div class="li-title">{{ item.name }}</div>
                        <div class="li-text">{{ item.num }}</div>
                        <base-icon
                          v-if="item.activeIsShow && activeName === item.name"
                          class="text-icon"
                          icon="i-carbon:touch-1"
                          :size="15"
                          :color="eqpStatusListObj[item.name]"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- 宕机统计 -->
              <div class="dashboard-type8">
                <div class="type8-content">
                  <div class="left-title">{{ i18nt('downtimeStatistics') }}</div>
                  <base-chart
                    v-if="produceDashboardData?.eqpStatistics.length !== 0"
                    ref="chartBarRef"
                    class="w-100%"
                  />
                  <dashboard-available v-else />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </base-spin>
  </div>
</template>

<style lang="less" scoped>
@import '@/components/project/dashboard/dashboard.less';
#production-dashboard {
  @dashboard();
  @tableType();
  // 中间
  .dashboard-middle {
    margin: 17px auto;
    height: 296px;
    display: flex;
    justify-content: space-between;
    overflow: hidden;
    @imageType7();
    // 表格
    .table {
      width: 100%;
      margin-top: 20px;
      border-radius: 10px;
      font-size: 14px;
      border: 1px solid #374d81;
      .tableUlType(#00cfff,39px);
      .table-ul-title {
        font-size: 16px;
        font-weight: bold;
      }
      .swiperUlList {
        height: 160px;
        overflow: hidden;
        .tableUlType(#9bd0ff,39px);
      }
    }
    .middle-available {
      width: 100%;
      height: 296px;
    }
  }
  // 底部
  .bottom {
    height: 606px;
    display: flex;
    justify-content: space-between;
    @imageType10();
    // 待处理列表
    .table {
      width: 100%;
      margin-top: 20px;
      border-radius: 10px;
      font-size: 14px;
      border: 1px solid #374d81;
      .tableUlType(#00cfff,44px);
      .table-ul-title {
        font-size: 16px;
        font-weight: bold;
      }
      .swiperTable {
        height: 450px;
        overflow: hidden;
        .tableUlType(#9bd0ff,44px);
      }
    }
    .statistics {
      width: 928px;
      height: 606px;
      .statistics-top {
        display: flex;
        justify-content: space-between;
        margin-bottom: 14px;
        @imageType7();
        .dashboard-type7 {
          height: 296px;
        }
        // 设备状态
        .type-ul {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;

          .type-li-left {
            width: 200px;
            display: flex;
            align-items: center;
            cursor: pointer;
            margin-top: 8px;
            height: 40px;
            background: #0f2762;
            border-radius: 10px;
            position: relative;

            .li-title {
              margin-left: 20px;
              width: 110px;
              height: 21px;
              line-height: 21px;
              font-weight: bold;
              font-size: 16px;
            }
            .li-text {
              width: 50px;
              height: 19px;
              line-height: 19px;
              margin-top: 8px;
              color: #9bd0ff;
              font-size: 14px;
            }
            .text-icon {
              position: absolute;
              right: 10px;
              bottom: 10px;
            }
          }
          .active {
            color: #ffffff !important;
          }
        }
      }
      @imageType8();
      .dashboard-type8 {
        height: 295px;
        padding-top: 1px;
      }
    }
  }
}
</style>
