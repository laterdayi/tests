<script setup lang="tsx">
import detailsForm from './components/details-form.vue';
import { CallEquipmentOverviewApis } from '@/service/apis/ams/equipment-call/call-equipment-overview';
import type {
  CallStateType,
  CallStateTypeDatasType,
  CallStateTypeListType,
  FormType,
  TypeDemoType,
  TypeObjType
} from '@/service/apis/ams/equipment-call/call-equipment-overview';
import { CommonApis } from '@/service/apis/common/common';

//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelQueryApi,
  __,
  __,
  {
    immediate: true
  }
);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);

//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });

// 按钮事件
const handleButton = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      activeIndex.value = null;
      handleQueryEquipmentList();
      resetField();
      getEqpStateListtDetail();
    },
    search: () => {
      getEqpStateListtDetail();
    },
    initiateCall: () => {
      detailsFormRef.value.handleOpenModal(null, false);
    }
  };
  columnsList[permission]();
};

const { formRef, formData, resetField } = useForm<Nullable<FormType>>({
  treeIds: [],
  eqpIds: []
});
// 表单查询
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: '' },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      placeholder: i18nt('baseForm.pleaseSelect') + i18nt('productionLineLevel'),
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        if (formData.value) formData.value.eqpIds = [];
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
            params: { layoutIds: value }
          })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpIds',
    formItemProps: { label: '' },
    componentProps: {
      placeholder: i18nt('baseForm.pleaseSelect') + i18nt('equipmentNumber'),
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'name',
      multiple: true
    }
  }
]);

const detailsFormRef = ref();
// 顶部列表
const typeList = [
  { id: 9, type: 'normalNumber', name: i18nt('normal'), color: 'rgb(92,184,92)', background: 'rgba(92,184,92,0.1)' },
  {
    id: 1,
    type: 'inCallNumber',
    name: i18nt('inCall'),
    color: 'rgb(245,108,108)',
    background: 'rgba(240,173,78,0.1)'
  },
  {
    id: 2,
    type: 'inRepairNumber',
    name: i18nt('underRepair'),
    color: 'rgb(240,173,78)',
    background: 'rgba(245,108,108,0.1)'
  },
  {
    id: 3,
    type: 'toAuditNumber',
    name: i18nt('ConversionOperateStateEnum_NotVerify'),
    color: 'rgb(139,69,19)',
    background: 'rgba(139,69,19,0.1)'
  }
];
// 获取全部数据
const callStateList = ref<CallStateType>();
// data: callStateList,
const { isLoading: isLoadingCallState, execute: getCallState } = useAxiosGet<CallStateType>(
  CallEquipmentOverviewApis.getCallStateApi,
  {},
  { paramsSerializer: useParamsSerializer() }
);
// 选中状态
const activeIndex = ref<number | null>(null);
tryOnMounted(() => {
  try {
    handleQueryEquipmentList();
    getEqpStateListtDetail();
  } catch (error) {
    console.log(error);
  }
});
// 标题点击
const titleClick = (item: CallStateTypeListType) => {
  item.listIsShow = !item.listIsShow;
};
// 顶部点击
const topClick = (type: number) => {
  activeIndex.value = activeIndex.value === type ? null : type;
  getEqpStateListtDetail();
};
// 底部状态
const typeObj: { [key: number]: TypeObjType } = {
  1: {
    name: i18nt('inCall'),
    color: 'rgb(245,108,108)',
    background: 'rgba(240,173,78,0.1)'
  },
  2: {
    name: i18nt('underRepair'),

    color: 'rgb(240,173,78)',
    background: 'rgba(245,108,108,0.1)'
  },
  3: {
    name: i18nt('underInspection'),
    color: 'rgb(139,69,19)',
    background: 'rgba(139,69,19,0.1)'
  },
  9: {
    name: i18nt('normal'),
    color: 'rgb(92,184,92)',
    background: 'rgba(92,184,92,0.1)'
  }
};

// 底部点击
const bottomClick = (itemDatas: CallStateTypeDatasType) => {
  if (itemDatas.state !== 9) return;
  detailsFormRef.value.handleOpenModal(itemDatas);
};

// 公共demo
const typeDemo = (props: TypeDemoType) => {
  return (
    <div
      class={props.class}
      style={{
        border:
          props.type === 0 && activeIndex.value === props.state
            ? `2px solid ${props.color}`
            : `1px solid ${props.color}`,
        backgroundColor: `${props.background}`,
        cursor: props.type === 1 ? (props.state === 9 ? 'pointer' : 'default') : 'pointer'
      }}
    >
      <div class="list-title">
        <div class="trapezoid" style={{ borderTop: `30px solid ${props.color}` }} />
        <div class="title-right">{typeObj[props.state].name}</div>
      </div>
      {props.type === 0
        ? (
          <div class="list-text">
            <div class="text-left">{props.total}</div>
            <div class="text-right">台</div>
            {activeIndex.value === props.state
            ? (
              <base-icon class="text-icon" color={props.color} icon="i-carbon:touch-1" size={20} />
              )
            : (
                ''
              )}
          </div>
          )
        : (
          <div class={props.title && props.title?.length > 10 ? 'time-top-content1' : 'time-top-content'}>
            <div class="time-title"> {props.title}</div>
            <div class="list-time">
              <base-icon class="time-left" color="#c2c2c6" icon="i-carbon:screen" />
              <div class="time-top">
                <div class={props.statetime && props.statetime.length > 13 ? 'time-top-text' : ''}>{props.statetime}</div>
              </div>
            </div>
          </div>
          )}
    </div>
  );
};

// 重置
const resetList = () => {
  // await getCallState({ params: { state: activeIndex.value } });
  getEqpStateListtDetail();
};

// 获取全部
const getEqpStateListtDetail = async () => {
  try {
    const { data } = await getCallState({
      params: {
        ...formData.value,
        state: activeIndex.value
      }
    });
    if (!data.value) return;
    callStateList.value = data.value;

    if (callStateList.value.list && callStateList.value.list.length !== 0) {
      callStateList.value.list[0].listIsShow = true;
    }
  } catch (error) {}
};
</script>

<template>
  <div id="call-equipment-overview">
    <!-- 顶部选择 -->
    <div class="type-top">
      <div class="flex">
        <typeDemo
          v-for="item in typeList"
          :key="item.id"
          class="type-list type-list1"
          :type="0"
          :total="callStateList && callStateList[item.type as keyof CallStateType]"
          :color="item.color"
          :background="item.background"
          :state="item.id"
          @click="topClick(item.id)"
        />
      </div>
      <!-- 搜索 -->
      <base-form ref="formRef" v-model="formData" type="query" :schemas="formSchemas" label-align="right" layout="page">
        <template #header-action>
          <permission-button form :loading-props="{ searchLoading: isLoadingCallState }" @handle="handleButton" />
          <permission-button :loading-props="{ searchLoading: isLoadingCallState }" @handle="handleButton" />
        </template>
      </base-form>
    </div>
    <!-- 底部列表 -->

    <base-spin :show="isLoadingCallState" class="type-bottom">
      <div v-for="item in callStateList && callStateList.list" :key="item.id" class="type-content">
        <div class="type-ul-title" @click="titleClick(item)">{{ item.levelName }} ({{ item.levelCount }})</div>
        <div v-if="item.listIsShow" class="type-ul">
          <div v-for="itemDatas in item.datas" :key="itemDatas.eqpId">
            <typeDemo
              :key="itemDatas.eqpId"
              class="type-list"
              :type="1"
              :title="itemDatas.eqpId"
              :color="typeObj[itemDatas.state].color"
              :background="typeObj[itemDatas.state].background"
              :state="itemDatas.state"
              :statetime="itemDatas.statetime"
              @click="bottomClick(itemDatas)"
            />
          </div>
        </div>
      </div>
      <base-empty v-if="callStateList && callStateList.list.length === 0" />
    </base-spin>
    <detailsForm ref="detailsFormRef" @reset-list="resetList" />
  </div>
</template>

<style lang="less">
#call-equipment-overview {
  .type-list {
    padding-left: 10px;
    width: 168px;
    height: 68px;
    margin: 0 16px 16px 0;
    border-radius: 5px;
    cursor: pointer;

    .list-title {
      height: 30px;
      line-height: 30px;
      position: relative;
      display: flex;
      align-items: center;

      .title-left {
        color: #000000;
        width: 60px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 14px;
        font-weight: 500;
      }

      .title-right {
        position: absolute;
        right: 0px;
        top: 0px;
        color: #ffffff;
        width: 60px;
        line-height: 30px;
        text-align: center;
      }

      .trapezoid {
        position: absolute;
        right: 0px;
        top: 0px;
        border-left: 30px solid transparent;
        border-right: 0px solid transparent;
        height: 0;
        width: 60px;
      }
    }

    .list-text {
      margin-top: 25px;
      height: 35px;
      line-height: 35px;
      display: flex;
      align-items: center;
      position: relative;
      color: #c2c2c6;

      .text-left {
        margin-right: 8px;
        font-size: 20px;
        color: #5f636f;
      }

      .text-right {
        color: #8d8d96;
      }

      .text-icon {
        position: absolute;
        top: 8px;
        right: 5px;
      }
    }
    .contentType() {
      .time-title {
        font-size: 12px;
        font-weight: bold;
        line-height: 18px;
        word-wrap: break-word;
        word-break: normal;
        width: 79px;
      }

      .list-time {
        display: flex;
        align-items: center;
        margin-top: 5px;
        .time-top {
          margin-left: 10px;
          font-size: 14px;
          font-weight: bold;
          height: 35px;
          line-height: 35px;
          overflow: hidden;

          .time-top-text {
            display: inline-block;
            white-space: nowrap;
            animation: 10s wordsLoop linear infinite normal;
          }

          @keyframes wordsLoop {
            0% {
              transform: translateX(-100%);
              -webkit-transform: translateX(-100%);
            }

            100% {
              transform: translateX(140px);
              -webkit-transform: translateX(140px);
            }
          }

          @-webkit-keyframes wordsLoop {
            0% {
              transform: translateX(-100%);
              -webkit-transform: translateX(-100%);
            }

            100% {
              transform: translateX(140px);
              -webkit-transform: translateX(140px);
            }
          }

          //划过暂停
          .time-top-text:hover {
            display: inline-block;
            white-space: nowrap;
            animation: 10s wordsLoop linear infinite normal paused;
          }
        }
      }
    }
    .time-top-content {
      margin-top: -20px;
      .contentType();
    }
    .time-top-content1 {
      margin-top: -30px;
      .contentType();
      .list-time {
        margin-top: 0px;
      }
    }
  }
  .type-list1 {
    height: 30px;
    margin: 0 16px 0 0;
    .list-text {
      margin-top: -30px;
      height: 30px;
      line-height: 30px;
      .text-icon {
        position: absolute;
        top: 8px;
        right: 75px;
      }
    }
  }

  .time-list {
    width: 168px;

    .list-title {
      .title-left {
        width: 80px;
      }
    }
  }
}
</style>

<style lang="less" scoped>
.type-top {
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 24px;
  background-color: #ffffff;
}

.type-bottom {
  width: 100%;
  max-height: calc(100vh - 208px);
  overflow-y: scroll;
  margin-top: 12px;

  .type-content {
    background-color: #ffffff;
    margin-bottom: 11px;
    padding: 0px 24px;
    border-radius: 12px;

    .type-ul-title {
      line-height: 50px;
      cursor: pointer;
      font-size: 20px;
      font-weight: bold;
    }

    .type-ul {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
    }
  }
}
</style>
