<script setup lang="tsx">
import { CallEquipmentOverviewApis } from '@/service/apis/ams/equipment-call/call-equipment-overview';
import type {
  AMSFlowType,
  AbnormalityTypeList,
  CallStateTypeDatasType,
  FormDataType
} from '@/service/apis/ams/equipment-call/call-equipment-overview';

const emit = defineEmits<{
  'reset-list': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);

// 呼叫异常类型设备列表
const { execute: executeGetFlowType } = useAxiosGet<OptionsType[]>(CallEquipmentOverviewApis.getFlowTypeApi);

// 呼叫类型列表
const AMSFlowTypeData = ref<AMSFlowType[]>([]);
const { execute: executeGetAMSFlowType } = useAxiosGet<AMSFlowType[]>(CallEquipmentOverviewApis.getAMSFlowTypeApi);

// 弹窗开启
const { showModal, openModal, closeModal } = useModal();

// 设备呼叫效验
const { execute: getCheckCallEqp } = useAxiosGet<string[]>(CallEquipmentOverviewApis.getCheckCallEqpApi);
const checkCallEqpList = ref<string[]>([]);
const eqpNameisShow = ref<boolean>(true);
//  打开弹窗
const handleOpenModal = (item: CallStateTypeDatasType, isShow = true) => {
  eqpNameisShow.value = isShow;
  AMSFlowTypeData.value = [];
  checkCallEqpList.value = [];
  abnormalityTypeList.value = [];
  if (isShow) {
    checkCallEqpHandle(item.eqpId);
  }
  updateField({
    eqpName: isShow ? item.eqpId : null
  });
  openModal();
};
// 设备呼叫效验
const checkCallEqpHandle = async (eqpId: string) => {
  try {
    const { data } = await getCheckCallEqp({ params: { eqpName: eqpId } });
    if (!data.value) return;
    checkCallEqpList.value = data.value;
    const { data: flowTypeList } = await executeGetFlowType({ params: { eqpName: eqpId } });
    if (!flowTypeList.value) return;
    abnormalityTypeList.value = flowTypeList.value?.map(ele => {
      return {
        ...ele,
        clickIsShow: false,
        disabled: !data.value?.some(item => item === ele.name)
      };
    });
  } catch (error) {
    abnormalityTypeList.value = [];
    checkCallEqpList.value = [];
    console.log(error);
  }
};

// 表单配置
const { formRef, formData, resetField, updateField } = useForm<Nullable<FormDataType>>({
  eqpName: null,
  flowType: null,
  userId: null,
  callType: null
});
// 设备状态列表展示
const abnormalityTypeList = ref<AbnormalityTypeList[]>([]);
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    model: 'eqpName',
    formItemProps: {
      label: ''
    },
    render() {
      return (
        <div class="userId">
          <base-input
            class="userId-input"
            disabled={eqpNameisShow.value}
            on-blur={() => {
              if (!formData.value) return;
              if (!formData.value.eqpName) return;
              formData.value.flowType = null;
              formData.value.callType = null;
              checkCallEqpHandle(formData.value.eqpName);
            }}
            onKeydown={(e: KeyboardEvent) => {
              if (e.key === 'Enter') {
                if (!formData.value) return;
                if (!formData.value.eqpName) return;
                formData.value.flowType = null;
                formData.value.callType = null;
                checkCallEqpHandle(formData.value.eqpName);
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('eqpName')}
            v-model:value={formData.value.eqpName}
          />
        </div>
      );
    }
  },
  // 人员编号
  {
    type: 'custom-form-item',
    model: 'userId',
    formItemProps: {
      label: ''
    },
    render() {
      return (
        <div class="userId">
          {/* maxlength="8" */}
          {/* minlength="6" */}
          <base-input
            class="userId-input"
            on-blur={() => userIdBlur()}
            onKeydown={(e: KeyboardEvent) => {
              if (e.key === 'Enter') {
                userIdBlur();
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('employeeID')}
            v-model:value={formData.value.userId}
          />
        </div>
      );
    },
    componentProps: {
      disabled: true
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: {
      label: ''
    },
    model: 'flowType',
    render() {
      return (
        <div class="abnormalityType">
          {abnormalityTypeList.value.map(ele => {
            return (
              <div
                class={
                  ele.disabled
                    ? 'abnormalityType-demo disabled'
                    : ele.clickIsShow
                      ? 'abnormalityType-demo active'
                      : 'abnormalityType-demo'
                }
                onClick={async () => {
                  try {
                    if (ele.disabled) return;
                    AMSFlowTypeData.value = [];
                    if (ele.clickIsShow) {
                      ele.clickIsShow = false;
                      formData.value.flowType = null;
                    } else {
                      abnormalityTypeList.value?.forEach(ele => (ele.clickIsShow = false));
                      ele.clickIsShow = true;
                      formData.value.flowType = ele.name;
                      if (!formData.value.flowType) return;
                      const { data } = await executeGetAMSFlowType({ params: { value: formData.value.flowType } });
                      if (!data.value) return;
                      AMSFlowTypeData.value = data.value.map(ele => {
                        return {
                          ...ele,
                          clickIsShow: false
                        };
                      });
                      formData.value.callType = null;
                    }
                  } catch (error) {
                    AMSFlowTypeData.value = [];
                    formData.value.callType = null;
                    console.log(error);
                  }
                }}
              >
                {ele.name}
                {ele.disabled ? (
                  ''
                ) : ele.clickIsShow ? (
                  <base-icon class="text-icon" color="rgb(245, 108, 108)" icon="i-carbon:touch-1" size={20} />
                ) : (
                  ''
                )}
              </div>
            );
          })}
        </div>
      );
    },
    formItemClass: 'col-span-2!'
  },
  formData.value.flowType && AMSFlowTypeData.value.length !== 0
    ? {
        type: 'custom-form-item',
        formItemProps: {
          label: ''
        },
        model: 'callType',
        render() {
          return (
            <div class="abnormalityType callType">
              {(AMSFlowTypeData.value || []).map(ele => {
                return (
                  <div
                    class={ele.clickIsShow ? 'abnormalityType-demo active' : 'abnormalityType-demo'}
                    onClick={() => {
                      if (ele.clickIsShow) {
                        ele.clickIsShow = false;
                        formData.value.callType = null;
                      } else {
                        AMSFlowTypeData.value?.forEach(ele => (ele.clickIsShow = false));
                        ele.clickIsShow = true;
                        formData.value.callType = ele.name;
                      }
                    }}
                  >
                    {ele.name}
                    {ele.clickIsShow ? (
                      <base-icon class="text-icon" color="rgb(245, 108, 108)" icon="i-carbon:touch-1" size={20} />
                    ) : (
                      ''
                    )}
                  </div>
                );
              })}
            </div>
          );
        },
        formItemClass: 'col-span-2!'
      }
    : __
]);
// 员工工号验证
// const { execute: executeCheckUserApi } = useAxiosGet<OptionsType[]>(CallEquipmentOverviewApis.checkUserApi);
const userIdBlur = () => {
  if (formData.value.userId) return;
  $message.warning(i18nt('baseForm.pleaseInput') + i18nt('employeeID'));
  // if (formData.value.userId) {
  //   if (formData.value.userId.length < 6) {
  //     $message.warning(i18nt('initiateCallTips1'));
  //     formData.value.userId = null;
  //     // return
  //   }
  //   // try {
  //   //   await executeCheckUserApi({
  //   //     params: { userId: formData.value.userId }
  //   //   });
  //   // } catch (error) {
  //   //   formData.value.userId = null;
  //   //   console.log(error);
  //   // }
  // } else {
  //   $message.warning(i18nt('baseForm.pleaseInput') + i18nt('employeeID'));
  // }
};
const { isLoading: isLoadingCall, execute: executeCallApi } = useAxiosPost(CallEquipmentOverviewApis.getCallApi);
// 保存表单
const saveForm = async () => {
  try {
    await executeCallApi({
      data: {
        ...formData.value
      }
    });
    emit('reset-list');
    closeModal();
  } catch (error) {
    console.log(error);
  }
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-50%!"
    :show="showModal"
    :title="$t('initiateCall')"
    @close="closeModal"
    @after-leave="resetField()"
    @negative-click="closeModal"
    @positive-click="saveForm"
  >
    <base-form
      id="abnormalityTypeFormType"
      ref="formRef"
      v-model="formData"
      class="form"
      layout="dialog"
      :schemas="formSchemas"
    />
    <template #action>
      <base-button :size="componentSize" class="mr" button-name="cancel" @click="closeModal">
        {{ $t('cancel') }}
      </base-button>
      <base-button
        v-if="checkCallEqpList.length !== 0"
        :disabled="!formData.eqpName || !formData.flowType || !formData.userId"
        :loading="isLoadingCall"
        :size="componentSize"
        button-name="initiateCall"
        type="primary"
        @click="saveForm"
      >
        {{ $t('initiateCall') }}
      </base-button>
    </template>
  </base-modal>
</template>

<style lang="less">
#abnormalityTypeFormType {
  .eqpName {
    width: 100%;
    background-color: rgb(250, 250, 252);
    border: 1px solid rgb(239, 239, 245);
    border-radius: 6px;
    color: #000000;
    font-size: 50px;
    font-weight: bold;
    text-align: center;
    line-height: 78px;
    height: 78px;
  }
  .userId {
    width: 100%;
    height: 78px;
    .userId-input {
      width: 100% !important;
      height: 100%;
      .n-input-wrapper {
        .n-input__input-el {
          width: 100% !important;
          height: 100%;
          font-size: 50px;
          font-weight: bold;
          text-align: center;
        }
        .n-input__placeholder {
          text-align: center;
          font-size: 30px;
          font-weight: bold;
        }
      }
    }
  }
  .abnormalityType {
    width: 100%;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    .abnormalityType-demo {
      position: relative;
      width: 158px;
      height: 78px;
      margin: 0 16px 16px 0;
      border-radius: 6px;
      cursor: pointer;
      border: 1px solid rgb(92, 184, 92);
      background-color: rgba(92, 184, 92, 0.1);
      color: rgb(92, 184, 92);
      line-height: 78px;
      text-align: center;
      font-size: 35px;
      font-weight: bold;
    }
    .disabled {
      cursor: default;
      color: rgba(194, 194, 194, 1);
      background-color: rgb(250, 250, 252);
      border: 1px solid rgb(239, 239, 245);
    }
    .text-icon {
      position: absolute;
      bottom: 6px;
      right: 6px;
    }
    .active {
      color: rgb(245, 108, 108);
      background-color: rgba(245, 108, 108, 0.1);
      border: 1px solid rgb(245, 108, 108);
    }
  }
  .callType {
    padding-top: 22px;
    border-top: 1px solid rgba(194, 194, 194, 1);
    .abnormalityType-demo {
      width: 128px;
      height: 48px;
      line-height: 48px;
      font-size: 30px;
    }
  }
}
</style>
