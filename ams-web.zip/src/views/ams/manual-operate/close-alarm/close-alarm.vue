<script lang="ts">
import { renderSpan } from '../../query-statistics/common';
import { CloseAlarmApis } from '@/service/apis/ams/manual-operate/close-alarm';
import { CommonApis } from '@/service/apis/common/common';
import { formatAlarmList, resultOptions } from '@/views/ams/constants';
import type { AlarmActionProps } from '@/views/ams/constants';
import { AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';

interface QueryType {
  eqpName: string[]
  treeIds: string[]
  alarmId: string
  description: string
  language: number
  systemName: string
  timestamp?: string[]
}

interface TableListType {
  id: string
  eqpID: string
  alarmID: string
  alarmStartTime: string
  alarmEndTime: string
  systemName: string
  duration: string
  createTime: string
  treeIds: string
  isEqpAlarm: string
  alarmDesc: string
  elapsedSeconds: number
  alarmConsuming: number
  alarmStatus: number
  closeReason: string
  closedBy: string
  txId: string
}
interface DetailDataType {
  actionInfo: ExecuteActionType[]
  alarmDesc: string
  alarmEndTime: string
  alarmID: string
  alarmStartTime: string
  eqpID: string
  duration: string
  alarmConsuming: string
  treeId: string
  createTime: string
  isEqpAlarm: number
  lotInfo: BatchInfoType[]
  systemName: string
  closedBy?: string
  txId?: string
  closeReason?: string
  isManualClose?: 0 | 1
}

interface BatchInfoType {
  id: number
  historyId: number
  lotId: string
  recipeName: string
  lotPortId: string
  chamberId: string
  productId: string
  carrierId: string
  batchId: string
  reserved: string
  step: string
  state: string
  createTime: string
  alarmConsuming: string
}

interface ExecuteActionType {
  id: number
  alarmAction: string
  alarmActionId: string
  alarmID: string
  eqpID: string
  relatedPersons: string
  remark: string
  result: number
  systemTime: string
}

enum ActionStatus {
  warning,
  success,
  error
}

interface CloseAlarmType {
  reason: string
}

// 初始化查询表单
const initQueryFormSchemas = (
  productLineList: Ref<OptionsType[] | undefined>,
  isLoadingProductLineList: Ref<boolean>,
  equipmentNumberChildList: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberChildList: Ref<boolean>,
  systemNameList: Ref<OptionsType[] | undefined>,
  isLoadingSystemNameList: Ref<boolean>,
  onUpdateProductLineValue: (value: (string | number | null)[]) => void
): BaseForm.Schema.Item[] => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: computed(() => ({
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      labelField: 'name',
      keyField: 'id',
      multiple: true,
      checkable: true,
      cascade: true,
      onUpdateValue: (value: (string | number | null)[]) => onUpdateProductLineValue(value)
    }))
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      multiple: true,
      options: equipmentNumberChildList?.value,
      loading: isLoadingEquipmentNumberChildList?.value,
      labelField: 'name',
      valueField: 'name'
    }))
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      loading: isLoadingSystemNameList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  { type: 'input', model: 'alarmId', formItemProps: { label: i18nt('alarmCode') } },
  {
    type: 'input',
    model: 'description',
    formItemProps: { label: i18nt('alarmDescription') },
    componentProps: { replaceSpace: false }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
];

const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  handleOpenCloseAlarmModal: (rowData: TableListType) => void,
  handleOpenAlarmDetailModal: (id: string) => Promise<void>,
  hasCustomPermission: (name: PermissionCustomType) => boolean | undefined
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    key: 'txId',
    title: i18nt('alarmID'),
    width: TABLE_WIDTH_DATETIME + 20,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.txId, () => handleOpenAlarmDetailModal(rowData.id))
  },
  {
    title: i18nt('equipmentNumber'),
    key: 'eqpID'
  },
  { key: 'alarmID', title: i18nt('alarmCode') },
  { title: i18nt('alarmDescription'), key: 'alarmDesc' },
  { title: i18nt('alarmStartTime'), key: 'alarmStartTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  {
    title: i18nt('alarmState'),
    key: 'alarmStatus',
    width: TABLE_WIDTH_STATE,
    sorter: true,
    render(rowData) {
      return useRenderTableSingleTag(
        rowData.alarmStatus ? TagState.default : TagState.warning,
        rowData.alarmStatus ? i18nt('closed') : i18nt('alarming')
      );
    }
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_NAME },
  { title: i18nt('duration'), key: 'duration', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('manualCloseTime'), key: 'alarmEndTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('closePerson'), key: 'closedBy', width: TABLE_WIDTH_NAME },
  { title: i18nt('closeReason'), key: 'closeReason' },
  useRenderTableActionColumn({
    width: TABLE_WIDTH_STATE,
    render: rowData =>
      useRenderTableFixedButton('closeAlarm', {
        disabled: !hasCustomPermission('closeAlarm') || !!rowData.alarmStatus,
        onClick: () => handleOpenCloseAlarmModal(rowData)
      })
  })
];

// 查看详情
const initDetailFormSchemas = (formData: DetailDataType): FormSchemaType => [
  {
    type: 'custom-form-item',
    model: 'eqpID',
    formItemProps: { label: i18nt('equipmentNumber') },
    render() {
      return renderSpan(formData.eqpID);
    }
  },
  {
    type: 'custom-form-item',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    render() {
      return renderSpan(formData.systemName);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmID',
    formItemProps: { label: i18nt('alarmCode') },
    render() {
      return renderSpan(formData.alarmID);
    }
  },
  {
    type: 'custom-form-item',
    model: 'txId',
    formItemProps: { label: i18nt('alarmID') },
    render() {
      return renderSpan(formData.txId);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmStartTime',
    formItemProps: { label: i18nt('alarmStartTime') },
    render() {
      return renderSpan(formData.alarmStartTime);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmEndTime',
    formItemProps: { label: i18nt('alarmEndTime') },
    render() {
      return renderSpan(formData.alarmEndTime);
    }
  },
  {
    type: 'switch',
    model: 'isEqpAlarm',
    formItemProps: { label: i18nt('machineSelfAlarm') },
    componentProps: { checkedValue: 1, uncheckedValue: 0 },
    formItemClass: 'w-min!'
  },
  {
    type: 'custom-form-item',
    model: 'alarmStatus',
    formItemProps: { label: i18nt('alarmState') },
    render() {
      return useRenderTableSingleTag(
        formData.alarmEndTime ? TagState.default : TagState.warning,
        formData.alarmEndTime ? i18nt('closed') : i18nt('alarming')
      );
    }
  },
  {
    type: 'custom-form-item',
    model: 'duration',
    formItemProps: { label: i18nt('duration') },
    render() {
      return renderSpan(formData.duration);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmConsuming',
    formItemProps: { label: i18nt('consuming') },
    render() {
      return renderSpan(formData.alarmConsuming);
    }
  },
  {
    type: 'custom-form-item',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.treeId);
    }
  },

  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('createTime') },
    render() {
      return renderSpan(formData.createTime);
    }
  },
  formData.isManualClose
    ? {
        type: 'custom-form-item',
        model: 'alarmDesc',
        formItemProps: { label: i18nt('closePerson') },
        render() {
          return renderSpan(formData.closedBy);
        }
      }
    : __,
  formData.isManualClose
    ? {
        type: 'custom-form-item',
        model: 'alarmDesc',
        formItemProps: { label: i18nt('closeReason') },
        render() {
          return renderSpan(formData.closeReason);
        }
      }
    : __,
  {
    type: 'custom-form-item',
    model: 'alarmDesc',
    formItemProps: { label: i18nt('alarmDescription') },
    formItemClass: 'col-span-2!',
    render() {
      return renderSpan(formData.alarmDesc);
    }
  }
];
const createColumnsBatch = (): DataTableColumns<BatchInfoType> => [
  { key: 'lotId', title: i18nt('lotNumebr') },
  { key: 'lotPortId', title: 'Port' },
  { key: 'chamberId', title: 'Chamber' },
  { key: 'productId', title: 'Product' },
  { key: 'carrierId', title: 'Carrier ID' },
  { key: 'batchId', title: 'Batch ID' },
  { key: 'reserved', title: 'Reserved' },
  { key: 'state', title: 'State' }
];
const createColumnsExecuteAction = (): DataTableColumns<ExecuteActionType> => [
  { key: 'eqpID', title: i18nt('equipmentNumber') },
  { key: 'alarmID', title: i18nt('alarmCode') },
  { key: 'systemTime', title: i18nt('occurredTime'), width: TABLE_WIDTH_DATETIME },
  { key: 'alarmAction', title: i18nt('executeAction') },
  {
    key: 'result',
    title: i18nt('executeResult'),
    render(rowData) {
      const find = resultOptions.find(c => c.id === rowData.result);
      return useRenderTableSingleTag(ActionStatus[find?.id || 0] as TagStateType, find?.name || '');
    }
  },
  { key: 'alarmActionConsuming', title: i18nt('consuming') },
  { key: 'relatedPersons', title: i18nt('relatedInformation') },
  { key: 'remark', title: i18nt('remark') }
];
</script>

<script setup lang="ts">
const appStore = useAppStore();
const { hasCustomPermission } = useRoutes();
// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);
const handleQuery = () => executeGetProductLineList(__);

// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};

// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(CommonApis.getEqpsByLayoutIdsApi, undefined, {
  paramsSerializer: useParamsSerializer()
});

// 获取系统名称列表
const {
  isLoading: isLoadingSystemNameList,
  data: systemNameList,
  execute: executeGetSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);

// 模板引用
const curdRef = ref<CurdRefType<QueryType, unknown, TableListType>>();

const onUpdateProductLineValue = (value: (string | number | null)[]) => {
  if (curdRef.value?.queryFormData) curdRef.value.queryFormData.eqpName = [];
  value?.length
    ? executeGetEquipmentNumberChildList(__, {
      params: { layoutIds: value }
    })
    : handleQueryEquipmentNumberList();
};

tryOnMounted(() => (handleQuery(), handleQueryEquipmentNumberList(), executeGetSystemNameList()));

// 查询表单参数
const queryFormParams: Nullable<QueryType> = {
  eqpName: null,
  treeIds: null,
  alarmId: null,
  systemName: null,
  description: null,
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1,
  timestamp: useFormatDateRange(30)
};
const curdRefPagination = computed(() => curdRef.value?.pagination);

const refactorFormQueryParams = (data: QueryType) => ({ ...data, ...useFormatDateTimeParams(data.timestamp) });

// -------------------------------------------------------------------------------------------- > 关闭报警
const { showModal: showModalCloseAlarm, openModal: openModalCloseAlarm, closeModal: closeModalCloseAlarm } = useModal();

const currentHandleData = ref<TableListType>();
const handleOpenCloseAlarmModal = (rowData: TableListType) => {
  openModalCloseAlarm();
  currentHandleData.value = rowData;
};

const { formData, resetField, validate, formRef } = useForm<Nullable<CloseAlarmType>>({
  reason: null
});

const initFormSchemas = (): FormSchemaType => [
  {
    type: 'input',
    model: 'reason',
    formItemProps: { label: i18nt('closeReason'), rule: useRules('input', i18nt('closeReason')) },
    componentProps: { type: 'textarea', maxlength: MAX_LENGTH_DESCRIPTION, showCount: true }
  }
];

const { isLoading: isLoadingCloseAlarm, execute } = useAxiosPost(CloseAlarmApis.closeAlarmApi);

const handleSubmit = async () => {
  try {
    await validate();
    const ids = currentHandleData.value ? [currentHandleData.value?.id] : curdRef.value?.tableRef?.selectedKeys;
    await execute(__, { data: { ...formData.value, ids } });
    closeModalCloseAlarm();
    currentHandleData.value = __;
    curdRef.value?.handleSearch();
  } catch (error) {
    console.log('关闭报警异常：', error);
  }
};

// -------------------------------------------------------------------------------------------- > 查看详情
// -------------------------------------------------------------------------------------------- > Modal
const { showModal, openModal, closeModal } = useModal();

const {
  data: historyRecordData,
  isLoading: isLoadingHistoryRecordData,
  execute: executeHistoryRecordData
} = useAxiosGet<DetailDataType>(AlarmHistoryRecordApis.getAlarmHistoryDetailApi);

const { execute: executeActionList } = useAxiosGet<AlarmActionProps[]>(AlarmSystemSettingApis.getActionListApi);

function defaultValues(): Nullable<Omit<DetailDataType, 'actionInfo' | 'lotInfo' | 'systemName'>> {
  return {
    eqpID: null,
    alarmID: null,
    alarmDesc: null,
    alarmStartTime: null,
    alarmEndTime: null,
    isEqpAlarm: null,
    duration: null,
    alarmConsuming: null,
    treeId: null,
    createTime: null
  };
}

const infoForm = ref<Nullable<Omit<DetailDataType, 'actionInfo' | 'lotInfo' | 'systemName'>>>(defaultValues());

const handleOpenModal = async (id: string) => {
  openModal();

  const { data } = await executeHistoryRecordData({
    params: { id, language: appStore.local === LOCAL_DEFAULT ? 0 : 1 }
  });
  const { data: actionList } = await executeActionList();

  const { actionInfo, lotInfo, ...params } = data.value as DetailDataType;

  const actions = (actionInfo || []).map(item => {
    const action = formatAlarmList(actionList.value || []).find(act => act.id === item.alarmAction);
    return {
      ...item,
      alarmAction: i18nt(action?.name || '')
    };
  });

  historyRecordData.value && (historyRecordData.value.actionInfo = actions as unknown as ExecuteActionType[]);
  infoForm.value = params;
};

const handleCloseModal = () => {
  closeModal();
  infoForm.value = defaultValues();
};

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas(
  productLineList,
  isLoadingProductLineList,
  equipmentNumberChildList,
  isLoadingEquipmentNumberChildList,
  systemNameList,
  isLoadingSystemNameList,
  onUpdateProductLineValue
);

// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  console.log(permission);
  const permissionAction: PermissionActionType = {
    closeAlarm: openModalCloseAlarm,
    reset: handleQueryEquipmentNumberList
  };
  permissionAction[permission]?.();
};

const tableColumns = createColumns(curdRefPagination, handleOpenCloseAlarmModal, handleOpenModal, hasCustomPermission);

const tableColumnsBatch = createColumnsBatch();
const tableColumnsExecuteAction = createColumnsExecuteAction();
const detailFormSchemas = computed(() => initDetailFormSchemas(infoForm.value as DetailDataType));
const disableCloseAlarm = computed(() => {
  const selectedRows = curdRef.value?.tableRef?.selectedRows;
  return !!selectedRows?.length && selectedRows?.every(selected => !selected.alarmStatus);
});
</script>

<template>
  <div id="close-alarm">
    <base-curd
      ref="curdRef"
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL }"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :form-permission-disable="{ closeAlarm: !disableCloseAlarm }"
      :read-api="CloseAlarmApis.getCloseListApi"
      :export-api="CloseAlarmApis.getCloseListApi"
      @handle="handlePermission"
    />
    <!-- -------------------------------------------------------------------------------------------- > 关闭报警 -->
    <base-modal
      class="w-35%!"
      :loading="isLoadingCloseAlarm"
      :show="showModalCloseAlarm"
      :title="$t('closeAlarm')"
      @close="closeModalCloseAlarm"
      @negative-click="closeModalCloseAlarm"
      @positive-click="handleSubmit"
      @after-leave="resetField(), (currentHandleData = __)"
    >
      <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="initFormSchemas()" />
    </base-modal>

    <!-- -------------------------------------------------------------------------------------------- > 查看详情 -->
    <base-modal
      :show="showModal"
      :title="i18nt('viewDetail')"
      :positive-text="__"
      @close="handleCloseModal"
      @negative-click="handleCloseModal"
    >
      <base-form v-model="infoForm" :schemas="detailFormSchemas" layout="dialog" disabled />
      <div class="card-title">{{ $t('batchDetail') }}</div>
      <base-table
        :max-height="isLoadingHistoryRecordData ? 60 : 400"
        :loading="isLoadingHistoryRecordData"
        :columns="tableColumnsBatch"
        :data="historyRecordData?.lotInfo"
      />
      <div class="card-title mt">{{ $t('executeActionDetail') }}</div>
      <base-table
        :max-height="isLoadingHistoryRecordData ? 60 : 400"
        :loading="isLoadingHistoryRecordData"
        :columns="tableColumnsExecuteAction"
        :data="historyRecordData?.actionInfo"
      />
    </base-modal>
  </div>
</template>
