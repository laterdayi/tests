<script setup lang="ts">
import type { TableListType, TurnOrderFormType } from '@/service/apis/ams/manual-operate/alarm-transfer-record';
import { AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';

const emit = defineEmits<{
  'reset-table': [];
}>();
// 获取接收人
const {
  isLoading: isLoadingrecipientQuery,
  data: recipientQueryList,
  execute: executegetAlarmTansferees
} = useAxiosGet<OptionsType[]>(AlarmHistoryRecordApis.getAlarmTansfereesApi);

// 打开详情
const { showModal, openModal, closeModal } = useModal();
const handleOpenModal = (item: TableListType) => {
  try {
    formData.value.historyId = item.id;
    executegetAlarmTansferees(__, {
      params: {
        eqpName: item.eqpID,
        historyId: item.id
      }
    });
    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 表单配置
const { formRef, formData, validate, resetField } = useForm<Nullable<TurnOrderFormType>>({
  transfereeList: [],
  historyId: null
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'transfereeList',
    formItemProps: {
      label: i18nt('recipientQuery'),
      rule: { type: 'array', ...useRules('change', i18nt('recipientQuery')) }
    },
    componentProps: {
      options: recipientQueryList?.value,
      loading: isLoadingrecipientQuery?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }
  }
]);

// 保存表单
const { isLoading: isLoadingAlarmTansfer, execute: executeAlarmTansfer } = useAxiosPost(
  AlarmHistoryRecordApis.alarmTansferApi
);
const saveForm = async () => {
  try {
    await validate();
    await executeAlarmTansfer(__, {
      data: { ...formData.value }
    });
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  closeModal();
  resetField();
  emit('reset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <!-- 操作  -->
  <base-modal
    :show="showModal"
    :loading="isLoadingAlarmTansfer"
    :title="i18nt('operate')"
    @positive-click="saveForm"
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" :schemas="formSchemas" layout="dialog" />
  </base-modal>
</template>
