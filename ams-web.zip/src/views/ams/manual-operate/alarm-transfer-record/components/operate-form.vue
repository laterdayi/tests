<script setup lang="ts">
import type { OperateFormType, OperateTableListType } from '@/service/apis/ams/manual-operate/alarm-transfer-record';
import { AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';

// 操作详情
const {
  data: tableData,
  isLoading: isLoadingAlarmDisposeTableList,
  execute: executeGetAlarmDisposeTableList
} = useAxiosGet<Record<string, unknown>[]>(AlarmHistoryRecordApis.getAlarmDisposeTableListApi);
// 打开详情
const { showModal, openModal, closeModal } = useModal();
const handleOpenModal = (id: string) => {
  try {
    formData.value.historyId = id;
    executeGetAlarmDisposeTableList(__, { params: { historyId: id } });
    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 表单配置
const { formRef, formData, validate, resetField } = useForm<Nullable<OperateFormType>>({
  alarmDispose: null,
  alarmReason: null,
  historyId: null
});
const formSchemas = computed<FormSchemaType>(() => [
  useRenderFormTextarea({
    model: 'alarmReason',
    label: i18nt('alarmReason'),
    formItemProps: {
      rule: useRules('input', i18nt('alarmReason'))
    }
  }),
  useRenderFormTextarea({
    model: 'alarmDispose',
    label: i18nt('alarmProcessMethod'),
    formItemProps: {
      rule: useRules('input', i18nt('alarmProcessMethod'))
    }
  })
]);
// 表格配置
const tableColumns: DataTableColumns<OperateTableListType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  { title: i18nt('alarmReason'), key: 'alarmReason' },
  { title: i18nt('alarmProcessMethod'), key: 'alarmDispose' },
  { title: i18nt('operator'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('operateTime'), key: 'operateTime', width: TABLE_WIDTH_DATETIME },
  useRenderTableActionColumn({
    render: rowData =>
      useRenderTableFixedButton('delete', {
        disabled: !rowData.isHasDeletePower,
        onClick: () => handleDeleteAlarmDispose(rowData)
      })
  })
];
// 表格删除
const handleDeleteAlarmDispose = (rowData: OperateTableListType) => {
  const dialog = $dialog.warning({
    title: i18nt('tips'),
    content: i18nt('permission-button.confirmTooltip', { val: i18nt('delete') }),
    onPositiveClick: async () => {
      try {
        dialog.loading = true;
        await useAxiosPost(AlarmHistoryRecordApis.deleteAlarmDisposeApi, { id: rowData.id }, __, { immediate: true });
        executeGetAlarmDisposeTableList(__, { params: { historyId: formData.value.historyId } });
      } catch (error) {
        console.log(error);
        return false;
      } finally {
        dialog.loading = false;
      }
    }
  });
};
// 保存表单
const { isLoading: changeEqpStateLoding, execute: executeAlarmDispose } = useAxiosPost(
  AlarmHistoryRecordApis.alarmDisposeApi
);
const saveForm = async () => {
  try {
    await validate();
    await executeAlarmDispose({
      data: {
        ...formData.value
      }
    });
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  closeModal();
  resetField();
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <!-- 操作  -->
  <base-modal
    :show="showModal"
    :loading="changeEqpStateLoding"
    :title="i18nt('operate')"
    @positive-click="saveForm"
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" :schemas="formSchemas" layout="dialog" />
    <base-table :loading="isLoadingAlarmDisposeTableList" :columns="tableColumns" :data="tableData" />
  </base-modal>
</template>
