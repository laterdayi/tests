<script setup lang="ts">
import { StatusSwitchApis } from '@/service/apis/ams/manual-operate/status-switch';
import type { StatusSwitchType } from '@/service/apis/ams/manual-operate/status-switch';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'reset-table': [];
}>();
// 获取状态切换列表
const {
  data: machineStateList,
  isLoading: isLoadingMachineStateList,
  execute: executeGetMachineStateList
} = useAxiosGet<OptionsType[]>(CommonApis.getSelectItemListApi);
// 打开详情
const { showModal, openModal, closeModal } = useModal();
const handleOpenModal = (id: string[]) => {
  executeGetMachineStateList({
    params: {
      type: AttributeType.machineState
    }
  });
  formData.value.historyIds = id;
  openModal();
};

// 表单配置
const { formRef, formData, validate, resetField } = useForm<Nullable<StatusSwitchType>>({
  alarmState: null,
  reason: null,
  remark: null,
  historyIds: []
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'alarmState',
    formItemProps: { label: i18nt('alarmState'), rule: [useRules('change', i18nt('alarmState'))] },
    componentProps: {
      options: machineStateList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingMachineStateList.value
    }
  },
  {
    type: 'input',
    model: 'reason',
    formItemProps: {
      label: i18nt('switchingReason'),
      rule: [useRules('input', i18nt('switchingReason'))]
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    }
  },
  {
    type: 'input',
    model: 'remark',
    formItemProps: {
      label: i18nt('remark')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    }
  }
]);
// 保存表单
const { isLoading: changeEqpStateLoding, execute: addChangeEqpState } = useAxiosPost(
  StatusSwitchApis.getChangeEqpStateApi
);
const saveForm = async () => {
  try {
    await validate();
    await addChangeEqpState({
      data: {
        ...formData.value
      }
    });
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  closeModal();
  resetField();
  emit('reset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <!-- 查看详情  -->
  <base-modal
    :show="showModal"
    :loading="changeEqpStateLoding"
    :title="i18nt('statusSwitch')"
    @positive-click="saveForm"
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-form ref="formRef" v-model="formData" :schemas="formSchemas" layout="dialog" />
  </base-modal>
</template>
