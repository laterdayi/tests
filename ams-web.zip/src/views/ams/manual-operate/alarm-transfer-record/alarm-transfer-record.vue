<script setup lang="tsx">
import { alarmStatusType } from '../../constants';
import detailForm from './components/detail-form.vue';
import statusSwitchForm from './components/status-switch-form.vue';
import operateForm from './components/operate-form.vue';
import turnOrderForm from './components/turn-order-form.vue';
import { AlarmTransferRecordApis } from '@/service/apis/ams/manual-operate/alarm-transfer-record';
import type { QueryType, TableListType } from '@/service/apis/ams/manual-operate/alarm-transfer-record';
import { CommonApis } from '@/service/apis/common/common';

const appStore = useAppStore();
const { hasCustomPermission } = useRoutes();
const detailFormRef = ref();
const statusSwitchFormRef = ref();
const operateFormRef = ref();
const turnOrderFormRef = ref();
const curdRef = ref<CurdRefType<QueryType, unknown, TableListType>>();
// 获取报警状态列表
const { isLoading: isLoadingMachineStateList, data: machineStateList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.machineState
  },
  __,
  {
    immediate: true
  }
);

// 查询表单
const queryFormParams: Nullable<QueryType> = {
  alarmId: null,
  alarmState: null,
  description: null,
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1,
  timestamp: useFormatDateRange(30)
};
const queryFormSchemas: FormSchemaType = [
  { type: 'input', model: 'alarmId', formItemProps: { label: i18nt('alarmCode') } },
  {
    type: 'input',
    model: 'description',
    formItemProps: { label: i18nt('alarmDescription') },
    componentProps: { replaceSpace: false }
  },

  {
    type: 'select',
    model: 'alarmState',
    formItemProps: { label: i18nt('alarmState') },
    componentProps: computed(() => ({
      options: machineStateList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingMachineStateList.value
    }))
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
];
// 重构查询
const refactorFormQueryParams = (data: QueryType) => ({ ...data, ...useFormatDateTimeParams(data.timestamp) });
// 表格
const curdRefPagination = computed(() => curdRef.value?.pagination);

const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    key: 'txId',
    title: i18nt('alarmID'),
    width: TABLE_WIDTH_DATETIME + 20,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.txId, () => {
        detailFormRef.value.handleOpenModal(rowData.id);
      })
  },
  {
    title: i18nt('equipmentNumber'),
    key: 'eqpID'
  },
  { key: 'alarmID', title: i18nt('alarmCode') },
  { title: i18nt('alarmDescription'), key: 'alarmDesc' },
  { title: i18nt('alarmStartTime'), key: 'alarmStartTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('alarmEndTime'), key: 'alarmEndTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('transferrer'), key: 'transferor', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('transferTime'), key: 'transferTime', width: TABLE_WIDTH_DATETIME_MILLISECOND },
  {
    title: i18nt('alarmState'),
    key: 'alarmState',
    width: TABLE_WIDTH_DATE,
    sorter: true,
    render(rowData) {
      return useRenderTableSingleTag(alarmStatusType[rowData.alarmState], rowData.alarmState);
    }
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_NAME },
  useRenderTableActionColumn({
    render: rowData => {
      return (
        <div class="flex">
          {useRenderTableFixedButton('action', {
            disabled: !hasCustomPermission('operate'),
            onClick: () => operateFormRef.value.handleOpenModal(rowData.id)
          })}
          <div class="ml-4px"></div>
          {useRenderTableFixedButton('turnOrder', {
            disabled: !hasCustomPermission('turnOrder') || rowData.alarmState === 'Close',
            onClick: () => turnOrderFormRef.value.handleOpenModal(rowData)
          })}
        </div>
      );
    }
  })
];
// 按钮点击
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    statusSwitch: () => {
      statusSwitchFormRef.value.handleOpenModal(curdRef.value?.tableRef?.selectedKeys);
    }
  };
  permissionAction[permission]?.();
};
// 状态切换权限
const disableCloseAlarm = computed(() => {
  const selectedRows = curdRef.value?.tableRef?.selectedRows;
  return selectedRows?.length ? !selectedRows?.some(selected => selected.alarmState === 'Close') : false;
});
// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleResetPageSize();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="close-alarm">
    <base-curd
      ref="curdRef"
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL }"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :form-permission-disable="{ statusSwitch: !disableCloseAlarm }"
      :read-api="AlarmTransferRecordApis.getCloseListApi"
      :ignore-form-permission-list="['turnOrder', 'operate']"
      @handle="handlePermission"
    />
    <!-- 状态切换 -->
    <statusSwitchForm ref="statusSwitchFormRef" @reset-table="resetTable" />
    <!-- 操作 -->
    <operateForm ref="operateFormRef" />
    <!-- 转单 -->
    <turnOrderForm ref="turnOrderFormRef" @reset-table="resetTable" />
    <!-- 查看详情  -->
    <detailForm ref="detailFormRef" />
  </div>
</template>
