<script lang="ts">
import { CommonApis } from '@/service/apis/common/common';
import { AlarmUnlockApis } from '@/service/apis/ams/manual-operate/alarm-unlock';

interface QueryType {
  eqpId: string[]
  alarmId: string
  timestamp: string[]
  unLockTime: string
  state: string
  systemName: string
}

interface TableListType {
  id: string
  eqpID: string
  alarmID: string
  alarmDesc: string
  alarmTime: string
  unLockId: string
  unLockTime: string
  state: number
  createTime: string
  editTime: string
  remark: string
  projectCode: string
}
interface FormType {
  userName: string
  userPwd: string | number
  remark: string
}
type CustomType = {
  id: number
  name: string
  status: keyof typeof TagState
};

const currentStateList: CustomType[] = [
  { id: 0, name: i18nt('unlocking'), status: 'warning' },
  { id: 1, name: i18nt('unlockSucceeded'), status: 'success' },
  { id: 2, name: i18nt('unlockFaild'), status: 'error' }
];

const statusObj = currentStateList.reduce(
  (previousValue: { [prospName: number | string]: { name: string; status: string } }, currentValue: CustomType) => {
    const { id, ...obj } = currentValue;
    previousValue[id] = obj;
    return previousValue;
  },
  {}
);

// 初始化查询表单
const initQueryFormSchemas = (
  currentStateList: CustomType[],
  equipmentNumberList?: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberList?: Ref<boolean>,
  systemNameList?: Ref<OptionsType[] | undefined>,
  isLoadingsystemName?: Ref<boolean | undefined>
): FormSchemaType => [
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      multiple: true,
      options: equipmentNumberList?.value,
      loading: isLoadingEquipmentNumberList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: { label: i18nt('alarmCode') }
  },
  {
    type: 'date-picker',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('alarmDate') },
    model: 'timestamp',
    componentProps: { type: 'datetimerange', clearable: false }
  },
  {
    type: 'date-picker',
    model: 'unLockTime',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('unlockDate') }
  },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: currentStateList
    }
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: {
      label: i18nt('systemName')
    },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingsystemName?.value
    }))
  }
];

// 初始化表单(操作表单参数)
const initFormSchemas = (): FormSchemaType => [
  {
    type: 'input',
    model: '',
    formItemProps: {
      label: i18nt('action')
    }
  }
];

const createColumns = (
  curdRef: Ref<CurdRefType<QueryType, FormType, TableListType> | undefined>,
  pagination: ComputedRef<PaginationProps | undefined>,
  openModal: (title: string) => void,
  handeleCurrentOperateId: (id: string, key: string) => string,
  hasCustomPermission: (name: PermissionCustomType) => boolean | undefined
): DataTableColumns<TableListType> => [
  useRenderTableIndex(pagination),
  {
    title: i18nt('eqpName'),
    key: 'eqpID',
    sorter: true,
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('alarmCode'),
    key: 'alarmID',
    sorter: true
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_STATE },
  {
    title: i18nt('alarmDescription'),
    key: 'alarmDesc'
  },
  {
    title: i18nt('alarmDate'),
    key: 'alarmTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  {
    title: i18nt('unlockDate'),
    key: 'unLockTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('currentState'),
    key: 'state',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData: TableListType) {
      const current = statusObj[rowData.state];
      return useRenderTableSingleTag(current.status as TagStateType, current.name);
    }
  },
  {
    title: i18nt('createTime'),
    key: 'createTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: i18nt('unlockPeople'),
    key: 'unLockId',
    sorter: true,
    width: TABLE_WIDTH_NAME
  },
  {
    title: i18nt('remark'),
    key: 'remark'
  },
  useRenderTableActionColumn({
    render: (rowData: TableListType) => {
      return useRenderTableFixedButton('unlock', {
        disabled: !hasCustomPermission('unlock') || rowData.state === 1,
        onClick: () => {
          openModal('unlock');
          handeleCurrentOperateId(rowData.id, rowData.remark);
        }
      });
    }
  })
];
</script>

<script setup lang="ts">
const { hasCustomPermission } = useRoutes();

// 获取设备编号列表
const {
  isLoading: isLoadingEquipmentNumberList,
  data: equipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
// 系统名称
const {
  data: systemNameList,
  isLoading: isLoadingsystemName,
  execute: getSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);

tryOnMounted(() => {
  executeGetEquipmentNumberList();
  getSystemNameList();
});

// 模板引用
const curdRef = ref<CurdRefType<QueryType, FormType, TableListType>>();

const { formRef, validate, formData, resetField } = useForm<Nullable<FormType>>({
  userName: null,
  userPwd: null,
  remark: null
});

// 当前id
const currentOperateId = ref('');
// 当前remark
const currentReamrk = ref('');
const isCheck = ref(false);
const handeleCurrentOperateId = (id: string, key: string) => (
  (currentOperateId.value = id), (currentReamrk.value = key)
);

// 表单配置
const modalSchemas = computed<FormSchemaType>(() => [
  !isCheck.value
    ? {
        type: 'input',
        model: 'userName',
        formItemProps: {
          label: i18nt('accounts'),
          rule: [useRules('input', i18nt('accounts')), useRuleStringLength(0, 100)]
        }
      }
    : __,
  !isCheck.value
    ? {
        type: 'input',
        model: 'userPwd',
        formItemProps: {
          label: i18nt('password'),
          rule: [useRules('input', i18nt('password')), useRuleStringLength(0, 100)]
        },
        componentProps: {
          type: 'password',
          showPasswordOn: 'mousedown'
        }
      }
    : __,
  isCheck.value ? useRenderFormTextarea({ model: 'remark', label: i18nt('remark'), formItemClass: 'col-span-2!' }) : __
]);

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas(
  currentStateList,
  equipmentNumberList,
  isLoadingEquipmentNumberList,
  systemNameList,
  isLoadingsystemName
);
// 查询表单参数
const queryFormParams: Nullable<QueryType> = {
  eqpId: null,
  alarmId: null,
  timestamp: useFormatDateRange(30),
  unLockTime: null,
  state: null,
  systemName: null
};
// 查询表单数据 -> 响应式
const curdRefPagination = computed(() => curdRef.value?.pagination);

// 表单模型
const formSchemas = initFormSchemas();
// 表单参数
const formParams = {};

const { showModal, openModal, closeModal } = useModal();

// 验证解锁权限
const { isLoading: isLoadingCheckPermission, execute: executeCheckPermission } = useAxiosPost(
  AlarmUnlockApis.checkUnLockApi
);

// 解锁
const { isLoading: isLoadingUnlock, execute: executeUnlock } = useAxiosPost(AlarmUnlockApis.unLockApi);
const saveForm = async () => {
  try {
    await validate();
    const { remark, ...otherParams } = formData.value;
    if (!isCheck.value) {
      await executeCheckPermission(__, {
        data: { ...otherParams }
      });
      isCheck.value = true;
    } else {
      await executeUnlock(__, {
        data: { id: currentOperateId.value, remark, userId: otherParams.userName }
      });
      handleClose();
      curdRef.value?.handleSearch();
    }
  } catch (error) {
    console.log('解锁异常：', error);
  }
};
const tableColumns = createColumns(curdRef, curdRefPagination, openModal, handeleCurrentOperateId, hasCustomPermission);

const refactorFormQueryParams = (data: QueryType) => {
  return {
    ...data,
    eqpId: data.eqpId
      ? data.eqpId.map(ele => {
        const eqpIdObj = equipmentNumberList?.value?.find(item => item.id === ele);
        return eqpIdObj ? eqpIdObj.name : null;
      }) || []
      : null,
    ...useFormatDateTimeParams(data.timestamp, 'timestamp', 'alarmStartTime', 'alarmEndTime')
  };
};

const handleClose = () => {
  closeModal();
  resetField();
  isCheck.value = false;
};
</script>

<template>
  <div id="alarm-unlock">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :ignore-form-permission-list="['unlock']"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :read-api="AlarmUnlockApis.getAlarmListApi"
      :refactor-form-query-params="refactorFormQueryParams"
    />
    <base-modal
      class="w-35%!"
      :loading="isLoadingCheckPermission || isLoadingUnlock"
      :show="showModal"
      :title="$t('unlock')"
      @close="handleClose"
      @negative-click="handleClose"
      @positive-click="saveForm"
    >
      <base-form ref="formRef" v-model="formData" type="query" layout="dialog" :schemas="modalSchemas" />
    </base-modal>
  </div>
</template>
