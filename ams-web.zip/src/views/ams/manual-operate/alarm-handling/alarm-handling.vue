<script setup lang="tsx">
import { CommonApis } from '@/service/apis/common/common';
import { AlarmHandlingApis } from '@/service/apis/ams/manual-operate/alarm-handling';
import type { DetailType, FormDataType, UserListType } from '@/service/apis/ams/manual-operate/alarm-handling';

const appStore = useAppStore();
const { componentSize, local } = storeToRefs(appStore);
const { currentRoutePowers } = useRoutes();
// 获取设备编号列表
const { data: equipmentNumberList, isLoading: isLoadingEquipmentNumber } = useAxiosGet<OptionsType[]>(
  CommonApis.getEquipmentNumberListApi,
  undefined,
  undefined,
  { immediate: true }
);
// 获取系统名称列表
const systemNameList = ref<OptionsType[]>([]);
const { isLoading: isLoadingSystemNameList, execute: executeGetSystemNameList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi
);

tryOnMounted(() => {
  systemNameListHandle(0);
});
// 处理系统名称
const systemNameListHandle = async (type: number) => {
  try {
    const { data } = await executeGetSystemNameList();
    if (!data.value) return;
    systemNameList.value =
      type === 0
        ? data.value.filter(ele => ele.id.toUpperCase() !== 'EAP')
        : data.value.filter(ele => ele.id.toUpperCase() === 'EAP');
  } catch (error) {
    console.log(error);
  }
};
// 获取报警代码
const alarmCodeList = ref<OptionsType[]>([]);
const { isLoading: isLoadingAlarmCodeList, execute: executeGetAllAlarmCodeList } = useAxiosGet<OptionsType[]>(
  AlarmHandlingApis.getAllAlarmCodeListApi
);
// 报警代码带出详情
const { execute: executeGetDetail } = useAxiosGet<DetailType>(AlarmHandlingApis.getDetailApi);
// 获取通知用户
const notifyUsersList = ref<UserListType[]>([]);
const { isLoading: isLoadingNotifyUsers, execute: executeGetNotifyUsers } = useAxiosGet<UserListType[]>(
  AlarmHandlingApis.getNotifyUsersApi
);

// 获取报警级别
const {
  data: alarmLevelList,
  isLoading: isLoadingAlarmLevel,
  execute: executeGetAlarmLevelList
} = useAxiosGet<OptionsType[]>(AlarmHandlingApis.getAlarmLevelListApi);

// 表单配置
const { formData, resetField, restoreValidation, validate, formRef } = useForm<Nullable<FormDataType>>({
  isEqpAlarm: 0,
  category: 0,
  eqpName: null,
  systemName: null,
  alarmID: null,
  notifyUsers: [],
  alarmLevel: null,
  alarmDesc: null,
  // startTime: useDateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss').value,
  startTime: null,
  endTime: null
});

const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('jobCategory') },
    model: 'category',
    render() {
      return (
        <base-radio-group
          disabled={formDisabled.value}
          onUpdateValue={(value: number) => {
            formData.value.category = value;
            clearClick();
          }}
          v-model:value={formData.value.category}
        >
          <base-radio label={i18nt('retroactiveEntry')} value={0} />
          <base-radio label={i18nt('manualSend')} value={1} />
        </base-radio-group>
      );
    },
    formItemClass: 'col-span-2!'
  },

  useRenderFormSwitch({
    key: 'isEqpAlarm',
    label: i18nt('machineAlarm'),
    formItemClass: 'col-span-2!',
    componentProps: {
      onUpdateValue: (value: number) => {
        formData.value.systemName = null;
        formData.value.alarmID = null;
        formData.value.alarmDesc = null;
        restoreValidation();
        systemNameListHandle(value === 1 ? 1 : formData.value.eqpName ? 1 : 0);

        alarmCodeHandle(formData.value.eqpName, formData.value.systemName);
      }
    }
  }),
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: {
      label: i18nt('eqpName'),
      rule: formData.value.isEqpAlarm === 0 ? [] : [{ ...useRules('change', i18nt('eqpName')) }]
    },
    componentProps: {
      options: equipmentNumberList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingEquipmentNumber.value,
      onUpdateValue: (value: string) => {
        formData.value.systemName = null;
        alarmCodeHandle(value, formData.value.systemName);
        systemNameListHandle(formData.value.isEqpAlarm === 1 ? 1 : value ? 1 : 0);
      }
    }
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: {
      label: i18nt('systemName'),
      rule: [useRules('change', i18nt('systemName'))]
    },
    componentProps: {
      options: systemNameList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingSystemNameList.value,
      onUpdateValue: (value: string) => {
        alarmCodeHandle(formData.value.eqpName, value);
      }
    }
  },
  {
    type: 'select',
    model: 'alarmID',
    formItemProps: {
      label: i18nt('alarmCode'),
      rule: [{ ...useRules('change', i18nt('alarmCode')) }]
    },
    componentProps: {
      options: alarmCodeList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingAlarmCodeList.value,
      onUpdateValue: (value: string) => {
        detailHandle(value);
      }
    }
  },

  formData.value.category === 1
    ? {
        type: 'select',
        model: 'alarmLevel',
        formItemProps: { label: i18nt('alarmLevel'), rule: [useRules('change', i18nt('alarmLevel'))] },
        componentProps: {
          options: alarmLevelList.value,
          labelField: 'name',
          valueField: 'id',
          loading: isLoadingAlarmLevel.value
        }
      }
    : __,
  formData.value.category === 1
    ? {
        type: 'custom-form-item',
        formItemProps: {
          label: i18nt('notifiedUsers'),
          rule: { ...useRules('change', i18nt('notifiedUsers')), type: 'array' }
        },
        model: 'notifyUsers',
        render() {
          return (
            <base-tree-select
              cascade
              checkable
              class="w-100%!"
              disabled={formDisabled.value}
              key-field="id"
              label-field="name"
              loading={isLoadingNotifyUsers.value}
              multiple
              onUpdateValue={(value: string[], item: UserListType[]) => {
                formData.value.notifyUsers = item.filter(ele => !ele.children).map(ele => ele.id);
              }}
              options={notifyUsersList.value}
              placeholder={i18nt('baseForm.pleaseSelect') + i18nt('notifiedUsers')}
              value={formData.value.notifyUsers}
            />
          );
        }
      }
    : __,
  {
    type: 'date-picker',
    model: 'startTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('startTime'),
      rule: useRules('change', i18nt('startTime'))
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss',
      onUpdateShow: (show: boolean) => {
        if (show) return;
        if (!formData.value.endTime) return;
        if (!formData.value.startTime) return;
        if (Date.parse(formData.value.startTime) > Date.parse(formData.value.endTime)) {
          formData.value.startTime = null;
        }
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'date-picker',
    model: 'endTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('endTime'),
      rule: formData.value.category === 1 ? [] : [{ ...useRules('change', i18nt('endTime')) }]
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss',
      onUpdateShow: (show: boolean) => {
        if (show) return;
        if (!formData.value.endTime) return;
        if (!formData.value.startTime) return;
        if (Date.parse(formData.value.endTime) < Date.parse(formData.value.startTime)) {
          formData.value.endTime = null;
        }
      }
    },
    class: 'w-95%!'
  },

  useRenderFormTextarea({
    model: 'alarmDesc',
    formItemProps: { label: i18nt('detailedAlarmContent'), rule: [useRules('input', i18nt('alarmDescription'))] }
    // componentProps: { maxlength: 60 }
  }),
  formData.value.categoryList && formData.value.categoryList.length !== 0
    ? {
        type: 'custom-form-item',
        formItemProps: { label: '' },
        model: '',
        render() {
          return (
            <div class="m-l-120px w-100%!">
              <n-alert title={i18nt('sendingResult')} type="success">
                {formData.value.categoryList?.map(ele => {
                  return <div class="mb">{ele}</div>;
                })}
              </n-alert>
            </div>
          );
        },
        formItemClass: 'col-span-2!'
      }
    : __
]);
// 报警代码相关处理
const alarmCodeHandle = async (eqpName: string | null, systemName: string | null) => {
  try {
    restoreValidation();
    formData.value.alarmID = null;
    formData.value.alarmDesc = null;

    const { data } = await executeGetAllAlarmCodeList({
      params: { systemName, eqpName }
    });
    if (!data.value) return;
    alarmCodeList.value = data.value;

    if (formData.value.category === 0) return;
    formData.value.notifyUsers = [];
    formData.value.alarmLevel = null;
    formData.value.notifyUsers = null;
    if (eqpName) {
      getNotifyUsersHandle(eqpName, systemName);
    } else {
      if (!systemName) return;
      getNotifyUsersHandle(eqpName, systemName);
    }
  } catch (error) {
    console.log(error);
  }
};

const getNotifyUsersHandle = async (eqpName: string | null, systemName: string | null) => {
  const { data: notifyUsersData } = await executeGetNotifyUsers({
    params: { category: eqpName ? 2 : 3, eqpModel: eqpName, systemName }
  });
  if (!notifyUsersData.value) return;
  notifyUsersList.value = userListHandle(notifyUsersData.value);
};

// 处理通知用户树数据
const userListHandle = (list: UserListType[]): UserListType[] => {
  if (!list?.length) return [];
  return list.map(ele => {
    const { children, ...obj } = ele;
    return {
      ...obj,
      ...(children && children.length === 0 ? {} : { children: userListHandle(children || []) })
    };
  });
};
// 报警代码带出详情处理
const detailHandle = async (id: string) => {
  try {
    restoreValidation();
    formData.value.alarmDesc = null;

    const { data } = await executeGetDetail({
      params: { id }
    });
    if (!data.value) return;
    formData.value.alarmDesc = data.value.description;
    if (formData.value.category === 0) return;
    formData.value.alarmLevel = data.value.alarmLevel;
    formData.value.notifyUsers = data.value.notifiedUserIds;
  } catch (error) {
    console.log(error);
  }
};
// 发送
const { isLoading: isLoadingAddAlarm, execute: executeAddAlarm } = useAxiosPost<string[]>(
  AlarmHandlingApis.addAlarmApi
);
const sendClick = async () => {
  try {
    await validate();
    const { data } = await executeAddAlarm(__, {
      data: {
        ...formData.value,
        language: local.value === 'zh-CN' ? 0 : 1,
        alarmID: formData.value.alarmID
          ? alarmCodeList.value.find(ele => ele.id === formData.value.alarmID)?.name
          : null,
        notifyUsers: formData.value.notifyUsers ? formData.value.notifyUsers.toString() : ''
      }
    });
    if (!data.value) return;
    if (formData.value.category === 1) {
      formData.value.categoryList = data.value;
    } else {
      clearClick();
    }
  } catch (error) {
    console.log(error);
  }
};
// 清空
const clearClick = (index?: number | null) => {
  if (formData.value.category === 1) {
    executeGetAlarmLevelList();
    notifyUsersList.value = [];
  }
  systemNameListHandle(0);
  formData.value.categoryList = null;
  alarmCodeList.value = [];
  resetField();
  if (!index) return;
  formData.value.category = index;
};
// 手动发送是否置灰
const formDisabled = computed<boolean>(
  () => !!(formData.value.category === 1 && formData.value.categoryList && formData.value.categoryList.length !== 0)
);
// 验证是否拥有按钮权限
const verifyButton = (text: string) => {
  if (!currentRoutePowers.value) return;
  return currentRoutePowers.value.findIndex(ele => ele === text) !== -1;
};
</script>

<template>
  <div id="alarm-handling">
    <base-spin :show="isLoadingAddAlarm">
      <base-card>
        <div class="mb title">
          {{ $t('alarmHandling') }}
        </div>
        <base-form ref="formRef" v-model="formData" :disabled="formDisabled" layout="dialog" :schemas="formSchemas" />
        <div class="flex justify-end">
          <base-button
            v-if="verifyButton('send')"
            :disabled="formDisabled"
            class="mr"
            :size="componentSize"
            button-name="send"
            type="info"
            @click="sendClick"
          >
            <base-icon icon="i-carbon:send-alt" color="#FFFFFF" />
            {{ $t('send') }}
          </base-button>
          <base-button
            v-if="verifyButton('clear')"
            :size="componentSize"
            button-name="clear"
            type="error"
            @click="clearClick(formData.category)"
          >
            <base-icon icon="i-carbon:trash-can" color="#FFFFFF" />
            {{ $t('clear') }}
          </base-button>
        </div>
      </base-card>
    </base-spin>
  </div>
</template>

<style lang="less" scoped>
.title {
  font-size: 18px;
  font-weight: 500;
}
</style>
