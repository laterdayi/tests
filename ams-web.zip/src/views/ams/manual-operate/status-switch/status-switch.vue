<script setup lang="ts">
import { alarmStatusType } from '../../constants';
import detailForm from './components/detail-form.vue';
import statusSwitchForm from './components/status-switch-form.vue';
import { StatusSwitchApis } from '@/service/apis/ams/manual-operate/status-switch';
import type { QueryType, TableListType } from '@/service/apis/ams/manual-operate/status-switch';
import { CommonApis } from '@/service/apis/common/common';

const appStore = useAppStore();
const detailFormRef = ref();
const statusSwitchFormRef = ref();
// 模板引用
const curdRef = ref<CurdRefType<QueryType, unknown, TableListType>>();
// 获取报警状态列表
const { isLoading: isLoadingMachineStateList, data: machineStateList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.machineState
  },
  __,
  {
    immediate: true
  }
);
// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);
const handleQuery = () => executeGetProductLineList(__);

// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};

// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(CommonApis.getEqpsByLayoutIdsApi, undefined, {
  paramsSerializer: useParamsSerializer()
});

// 获取系统名称列表
const {
  isLoading: isLoadingSystemNameList,
  data: systemNameList,
  execute: executeGetSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);

tryOnMounted(() => (handleQuery(), handleQueryEquipmentNumberList(), executeGetSystemNameList()));
// 查询表单
const queryFormParams: Nullable<QueryType> = {
  eqpName: null,
  treeIds: null,
  alarmId: null,
  systemName: null,
  description: null,
  alarmState: null,
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1,
  timestamp: useFormatDateRange(30)
};
const queryFormSchemas: FormSchemaType = [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: computed(() => ({
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      checkable: true,
      cascade: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: (value: (string | number | null)[]) => {
        if (curdRef.value?.queryFormData) curdRef.value.queryFormData.eqpName = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
              params: { layoutIds: value }
            })
          : handleQueryEquipmentNumberList();
      }
    }))
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      multiple: true,
      options: equipmentNumberChildList?.value,
      loading: isLoadingEquipmentNumberChildList?.value,
      labelField: 'name',
      valueField: 'name'
    }))
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      loading: isLoadingSystemNameList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  { type: 'input', model: 'alarmId', formItemProps: { label: i18nt('alarmCode') } },
  {
    type: 'input',
    model: 'description',
    formItemProps: { label: i18nt('alarmDescription') },
    componentProps: { replaceSpace: false }
  },
  {
    type: 'select',
    model: 'alarmState',
    formItemProps: { label: i18nt('alarmState') },
    componentProps: computed(() => ({
      options: machineStateList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingMachineStateList.value
    }))
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
];
// 重构查询
const refactorFormQueryParams = (data: QueryType) => ({ ...data, ...useFormatDateTimeParams(data.timestamp) });
// 表格
const curdRefPagination = computed(() => curdRef.value?.pagination);

const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    key: 'txId',
    title: i18nt('alarmID'),
    width: TABLE_WIDTH_DATETIME + 20,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.txId, () => {
        detailFormRef.value.handleOpenModal(rowData.id);
      })
  },
  {
    title: i18nt('equipmentNumber'),
    key: 'eqpID'
  },
  { key: 'alarmID', title: i18nt('alarmCode') },
  { title: i18nt('alarmDescription'), key: 'alarmDesc' },
  { title: i18nt('alarmStartTime'), key: 'alarmStartTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  {
    title: i18nt('alarmState'),
    key: 'alarmState',
    width: TABLE_WIDTH_DATE,
    sorter: true,
    render(rowData) {
      return useRenderTableSingleTag(alarmStatusType[rowData.alarmState], rowData.alarmState);
    }
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_NAME },
  { title: i18nt('duration'), key: 'duration', sorter: true, width: TABLE_WIDTH_DATETIME },

  { title: i18nt('switchingTime'), key: 'changeStateTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('switchingPersonnel'), key: 'closedBy', width: TABLE_WIDTH_NAME },
  { title: i18nt('switchingReason'), key: 'closeReason' }
];
// 按钮点击
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    statusSwitch: () => {
      statusSwitchFormRef.value.handleOpenModal(curdRef.value?.tableRef?.selectedKeys);
    },
    reset: handleQueryEquipmentNumberList
  };
  permissionAction[permission]?.();
};
// 状态切换权限
const disableCloseAlarm = computed(() => {
  const selectedRows = curdRef.value?.tableRef?.selectedRows;
  return selectedRows?.length ? !selectedRows?.some(selected => selected.alarmState === 'Close') : false;
});
// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleResetPageSize();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="close-alarm">
    <base-curd
      ref="curdRef"
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL }"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :form-permission-disable="{ statusSwitch: !disableCloseAlarm }"
      :read-api="StatusSwitchApis.getCloseListApi"
      :export-api="StatusSwitchApis.getCloseListApi"
      @handle="handlePermission"
    />
    <!-- 关闭报警 -->
    <statusSwitchForm ref="statusSwitchFormRef" @reset-table="resetTable" />
    <!-- 查看详情  -->
    <detailForm ref="detailFormRef" />
  </div>
</template>
