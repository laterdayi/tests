<script setup lang="tsx">
import { renderSpan } from '../../../query-statistics/common';
import { actionCategoryObj, alarmStatusType, formatAlarmList, resultOptions } from '@/views/ams/constants';
import { ActionStatus } from '@/service/apis/ams/manual-operate/status-switch';
import type {
  ActionType,
  AdditionalInfoType,
  ChangeStateInfoType,
  DetailFormType,
  InfoType
} from '@/service/apis/ams/manual-operate/status-switch';

import type { AlarmActionProps } from '@/views/ams/constants';
import { AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';

// 打开详情
const appStore = useAppStore();
const { showModal, openModal, closeModal } = useModal();
const { isLoading: isLoadingHistoryRecordData, execute: executeHistoryRecordData } = useAxiosGet<DetailFormType>(
  AlarmHistoryRecordApis.getAlarmHistoryDetailApi
);
const { execute: executeActionList } = useAxiosGet<AlarmActionProps[]>(AlarmSystemSettingApis.getActionListApi);
const handleOpenModal = async (id: string) => {
  const { data } = await executeHistoryRecordData({
    params: { id, language: appStore.local === LOCAL_DEFAULT ? 0 : 1 }
  });
  if (!data.value) return;
  formData.value = data.value;
  const { data: actionList } = await executeActionList();
  formData.value.actionInfo = formData.value.actionInfo?.map(ele => {
    const action = formatAlarmList(actionList.value || []).find(act => act.id === ele.alarmAction);
    return {
      ...ele,
      alarmAction: i18nt(action?.name || '')
    };
  });
  openModal();
};

// 详情表单
const { formRef, formData, resetField } = useForm<Nullable<DetailFormType>>({
  eqpID: null,
  systemName: null,
  alarmID: null,
  txId: null,
  alarmStartTime: null,
  alarmEndTime: null,
  isEqpAlarm: null,
  alarmStatus: null,
  duration: null,
  alarmConsuming: null,
  treeId: null,
  createTime: null,
  isManualClose: null,
  closedBy: null,
  closeReason: null,
  alarmDesc: null
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    model: 'eqpID',
    formItemProps: { label: i18nt('equipmentNumber') },
    render() {
      return renderSpan(formData.value.eqpID || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    render() {
      return renderSpan(formData.value.systemName || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmID',
    formItemProps: { label: i18nt('alarmCode') },
    render() {
      return renderSpan(formData.value.alarmID || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'txId',
    formItemProps: { label: i18nt('alarmID') },
    render() {
      return renderSpan(formData.value.txId || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmStartTime',
    formItemProps: { label: i18nt('alarmStartTime') },
    render() {
      return renderSpan(formData.value.alarmStartTime || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmEndTime',
    formItemProps: { label: i18nt('alarmEndTime') },
    render() {
      return renderSpan(formData.value.alarmEndTime || '');
    }
  },
  {
    type: 'switch',
    model: 'isEqpAlarm',
    formItemProps: { label: i18nt('machineSelfAlarm') },
    componentProps: { checkedValue: 1, uncheckedValue: 0 },
    formItemClass: 'w-min!'
  },
  {
    type: 'custom-form-item',
    model: 'alarmStatus',
    formItemProps: { label: i18nt('alarmState') },
    render() {
      return useRenderTableSingleTag(
        alarmStatusType[formData.value.alarmStatus || ''],
        formData.value.alarmStatus || ''
      );
    }
  },
  {
    type: 'custom-form-item',
    model: 'duration',
    formItemProps: { label: i18nt('duration') },
    render() {
      return renderSpan(formData.value.duration || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmConsuming',
    formItemProps: { label: i18nt('consuming') },
    render() {
      return renderSpan(formData.value.alarmConsuming || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.value.treeId || '');
    }
  },

  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('createTime') },
    render() {
      return renderSpan(formData.value.createTime || '');
    }
  },
  // formData.value.isManualClose
  //   ? {
  //       type: 'custom-form-item',
  //       model: 'alarmDesc',
  //       formItemProps: { label: i18nt('switchingPersonnel') },
  //       render() {
  //         return renderSpan(formData.value.closedBy || '');
  //       }
  //     }
  //   : __,
  // formData.value.isManualClose
  //   ? {
  //       type: 'custom-form-item',
  //       model: 'alarmDesc',
  //       formItemProps: { label: i18nt('switchingReason') },
  //       render() {
  //         return renderSpan(formData.value.closeReason || '');
  //       }
  //     }
  //   : __,
  {
    type: 'custom-form-item',
    model: 'alarmDesc',
    formItemProps: { label: i18nt('alarmDescription') },
    formItemClass: 'col-span-2!',
    render() {
      return renderSpan(formData.value.alarmDesc || '');
    }
  }
]);
// 批次明细
const tableColumnsInfo: DataTableColumns<InfoType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  { key: 'lotId', title: i18nt('lotNumebr') },
  { key: 'lotPortId', title: 'Port' },
  { key: 'chamberId', title: 'Chamber' },
  { key: 'productId', title: 'Product' },
  { key: 'carrierId', title: 'Carrier ID' },
  { key: 'batchId', title: 'Batch ID' },
  { key: 'reserved', title: 'Reserved' },
  { key: 'state', title: 'State' }
];
// 执行动作明细
const tableColumnsAction: DataTableColumns<ActionType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  { key: 'eqpID', title: i18nt('equipmentNumber') },
  { key: 'alarmID', title: i18nt('alarmCode') },
  { key: 'systemTime', title: i18nt('occurredTime'), width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { key: 'alarmAction', title: i18nt('executeAction') },
  {
    title: i18nt('actionCategory'),
    key: 'alarmActionCategory',
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      return actionCategoryObj[rowData.alarmActionCategory] || '';
    }
  },
  {
    key: 'result',
    title: i18nt('executeResult'),
    render(rowData) {
      const find = resultOptions.find(c => c.id === rowData.result);
      return useRenderTableSingleTag(ActionStatus[find?.id || 0] as TagStateType, find?.name || '');
    }
  },
  { key: 'alarmActionConsuming', title: i18nt('consuming') },
  { key: 'relatedPersons', title: i18nt('relatedInformation') },
  { key: 'remark', title: i18nt('remark') }
];
// 切换状态
const tableColumnsChangeStateInfo: DataTableColumns<ChangeStateInfoType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  {
    title: i18nt('switchingStatus'),
    key: 'alarmDispose'
  },
  { title: i18nt('switchingTime'), key: 'operateTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  { title: i18nt('switchingPersonnel'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('switchingReason'), key: 'reason' },
  { key: 'remark', title: i18nt('remark') }
];
//  操作记录
const tableColumnsAdditionalInfo: DataTableColumns<AdditionalInfoType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  {
    title: i18nt('alarmReason'),
    key: 'alarmReason'
  },
  {
    title: i18nt('alarmProcessMethod'),
    key: 'alarmDispose'
  },
  {
    title: i18nt('operator'),
    key: 'operator'
  },
  {
    title: i18nt('operateTime'),
    key: 'alarmDispose'
  }
];
// 关闭弹窗
const handleCloseModal = () => {
  resetField();
  closeModal();
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <!-- 查看详情  -->
  <base-modal
    class="w-70%!"
    :show="showModal"
    :title="i18nt('viewDetail')"
    :positive-text="__"
    @close="handleCloseModal"
    @negative-click="handleCloseModal"
  >
    <base-form ref="formRef" v-model="formData" :schemas="formSchemas" layout="dialog" disabled />
    <div class="card-title">{{ $t('batchDetail') }}</div>
    <base-table
      :max-height="isLoadingHistoryRecordData ? 60 : 400"
      :loading="isLoadingHistoryRecordData"
      :columns="tableColumnsInfo"
      :data="formData?.lotInfo ?? []"
    />
    <div class="card-title mt">{{ $t('executeActionDetail') }}</div>
    <base-table
      :max-height="isLoadingHistoryRecordData ? 60 : 400"
      :loading="isLoadingHistoryRecordData"
      :columns="tableColumnsAction"
      :data="formData?.actionInfo ?? []"
    />
    <div class="card-title mt">{{ $t('switchingRecord') }}</div>
    <base-table
      :max-height="isLoadingHistoryRecordData ? 60 : 400"
      :loading="isLoadingHistoryRecordData"
      :columns="tableColumnsChangeStateInfo"
      :data="formData?.changeStateInfo ?? []"
    />
    <div class="card-title mt">{{ $t('operateRecord') }}</div>
    <base-table
      :max-height="isLoadingHistoryRecordData ? 60 : 400"
      :loading="isLoadingHistoryRecordData"
      :columns="tableColumnsAdditionalInfo"
      :data="formData?.additionalInfo ?? []"
    />
  </base-modal>
</template>
