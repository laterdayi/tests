<script setup lang="tsx">
import { SystemLogApis } from '@/service/apis/ams/system-operate-record/system-log';
import type {
  ListType,
  SystemLogListType,
  SystemLogQueryType
} from '@/service/apis/ams/system-operate-record/system-log';

// 弹窗标题
const baseModalTitle = ref<string>('');
// 模块列表
const { data: moduleList } = useAxiosGet<ListType[]>(
  SystemLogApis.getEnumListApi,
  { enumName: 'BussinessModule', showType: 0 },
  undefined,
  { immediate: true }
);
// 日志级别
const { data: levelList } = useAxiosGet<ListType[]>(
  SystemLogApis.getEnumListApi,
  {
    enumName: 'LogLevel',
    showType: 0
  },
  undefined,
  { immediate: true }
);
// 系统日志
const systemLogCurdRef = ref<CurdRefType<SystemLogQueryType, SystemLogListType>>();
const systemLogFormParams: Nullable<SystemLogQueryType> = {
  level: null,
  message: null,
  module: null,
  timestamp: useFormatDateRange(30)
};
const refactorFormQueryParams = (data: SystemLogQueryType) => {
  if (!data.timestamp) return;
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
const systemLogFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'module',
    formItemProps: { label: i18nt('modular') },
    componentProps: {
      options: moduleList.value,
      valueField: 'name',
      labelField: 'name'
    },
    class: 'w-40!'
  },
  {
    type: 'select',
    model: 'level',
    formItemProps: { label: i18nt('logLevel') },
    componentProps: {
      options: levelList.value,
      valueField: 'name',
      labelField: 'name'
    },
    class: 'w-40!'
  },
  {
    type: 'input',
    model: 'message',
    formItemProps: { label: i18nt('content') },
    class: 'w-130!'
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('occurredTime') },
    componentProps: { type: 'datetimerange' }
  }
]);

const curdRefPagination = computed(() => systemLogCurdRef.value?.pagination);

const systemLogColumns: DataTableColumns<SystemLogListType> = [
  useRenderTableIndex(curdRefPagination),
  { title: i18nt('modular'), key: 'module', sorter: true, width: TABLE_WIDTH_MODULE },
  { title: i18nt('logLevel'), key: 'level', sorter: true, width: 100 },
  { title: i18nt('occurredTime'), key: 'logTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  {
    title() {
      return <div class="systemLogTitle">{i18nt('content')}</div>;
    },
    key: 'message',
    align: 'left'
  },
  useRenderTableActionColumn({
    title: i18nt('viewDetail'),
    render: rowData =>
      useRenderTableTitleEdit(i18nt('viewDetail'), () => {
        baseModalTitle.value = i18nt('contentDetails');
        handleViewDetail(rowData.message);
      })
  })
];

// 查看内容
const { showModal, openModal, closeModal } = useModal();
const currentEmailContent = ref('');
const handleViewDetail = (content: string) => (openModal(), (currentEmailContent.value = content));
</script>

<template>
  <div id="system-log">
    <base-curd
      ref="systemLogCurdRef"
      :query-form-params="systemLogFormParams"
      :query-form-schemas="systemLogFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="systemLogColumns"
      :read-api="SystemLogApis.getSystemLogApi"
    />
    <base-modal
      :title="baseModalTitle"
      :show="showModal"
      :negative-text="$t('cancel')"
      :positive-text="__"
      @close="closeModal()"
      @negative-click="closeModal()"
    >
      <div id="email-content-area" v-html="currentEmailContent" />
    </base-modal>
  </div>
</template>

<style lang="less">
#email-content-area {
  table {
    width: 100%;
    td {
      text-align: center;
    }
  }
}
</style>

<style scoped lang="less">
:deep(.n-data-table-th__title) {
  .n-ellipsis {
    width: 100%;
    .systemLogTitle {
      text-align: center;
    }
  }
}
</style>
