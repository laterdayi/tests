<script setup lang="tsx">
import { CommonApis } from '@/service/apis/common/common';
import { CreateMaintenanceRequestApis } from '@/service/apis/ams/maintenance-manage/create-maintenance-request';
import type { FormDataType } from '@/service/apis/ams/maintenance-manage/create-maintenance-request';

// 获取设备编号列表
const { data: eqpmentNumberList, isLoading: isLoadingEqpmentNumberList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelApi,
  { check: 1, addEqp: 1 },
  { paramsSerializer: useParamsSerializer() },
  {
    immediate: true
  }
);
// 获取类型
const { data: alarmTypeDataList, isLoading: isLoadingAlarmTypeData } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.alarmType
  },
  __,
  {
    immediate: true
  }
);
// 获取处理方式
const { data: handleMeasuresDataList, isLoading: isLoadingHandleMeasuresData } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.handleMeasures
  },
  __,
  {
    immediate: true
  }
);
// 获取设备详情
const { isLoading: isLoadingRepairConfigDetail, execute: getRepairConfigDetail } = useAxiosPost<FormDataType>(
  CreateMaintenanceRequestApis.repairConfigDetailApi
);
//  是否拥有保修单
const { isLoading: isLoadingRepairInfo, execute: getRepairInfo } = useAxiosGet<FormDataType>(
  CreateMaintenanceRequestApis.getRepairInfoApi
);

const formDisabledIsShow = ref<boolean>(true);
// 左侧树
const eqpName = ref<string | null>();
// 树点击
const nodeProps = ({ option }: { option: TreeOption & { name: string } }) => {
  return {
    onClick: async () => {
      eqpName.value = option.name;
      if (option.children?.length !== 0) {
        eqpName.value = null;
        return;
      }
      try {
        restoreValidation();
        const { data: repairInfoData } = await getRepairInfo(__, {
          params: {
            eqpName: eqpName.value
          },
          showTooltip: false
        });
        // 已拥有保修单
        if (repairInfoData.value) {
          formDisabledIsShow.value = repairInfoData.value.currentStatus !== 1;
          updateField({
            ...repairInfoData.value,
            alarmID: null,
            eqpName: option.name,
            category: 0
          });
        } else {
          formDisabledIsShow.value = false;
          const { data } = await getRepairConfigDetail(__, {
            data: {
              eqpName: eqpName.value
            },
            showTooltip: false
          });
          if (!data.value) return;
          updateField({
            toolingType: data.value.toolingType || null,
            eqpName: option.name || null,
            alarmID: data.value.alarmID || null,
            alarmType: data.value.alarmType || null,
            createTime: useDateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss').value,
            productName: data.value.productName || null,
            alarmDesc: data.value.alarmDesc || null,
            reason: data.value.reason || null,
            improveMeasures: data.value.improveMeasures || null,
            category: 0,
            handleMeasures: data.value.handleMeasures || null,
            alarmIDList: data.value.alarmIDList || [],
            currentStatus: null
          });
        }
      } catch (error) {
        resetField();
        formData.value.eqpName = option.name;
        eqpName.value = null;
        formDisabledIsShow.value = true;
      }
    }
  };
};
// 右侧表单
const { formRef, formData, validate, resetField, restoreValidation, updateField } = useForm<Nullable<FormDataType>>({
  toolingType: null,
  eqpName: null,
  alarmID: null,
  alarmType: null,
  createTime: useDateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss').value,
  productName: null,
  alarmDesc: null,
  reason: null,
  improveMeasures: null,
  category: 0,
  alarmIDList: [],
  handleMeasures: null
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    model: 'toolingType',
    formItemProps: { label: i18nt('basicFaultInformation') },
    render() {
      return '';
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('category') },
    model: 'category',
    render() {
      return (
        <base-radio-group
          disabled={!eqpName.value}
          onUpdateValue={async (value: number) => {
            if (value === 1) {
              updateField({
                toolingType: null,
                alarmID: null,
                alarmType: null,
                createTime: useDateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss').value,
                productName: null,
                alarmDesc: null,
                reason: null,
                improveMeasures: null,
                category: 1,
                handleMeasures: null
              });
            } else {
              try {
                restoreValidation();
                const { data: repairInfoData } = await getRepairInfo(__, {
                  params: {
                    eqpName: eqpName.value
                  },
                  showTooltip: false
                });
                // 已拥有保修单
                if (repairInfoData.value) {
                  formDisabledIsShow.value = repairInfoData.value.currentStatus !== 1;
                  updateField({
                    ...repairInfoData.value,
                    alarmID: null,
                    eqpName: eqpName.value,
                    category: 0,

                  });
                } else {
                  formDisabledIsShow.value = false;
                  const { data } = await getRepairConfigDetail(__, {
                    data: {
                      eqpName: eqpName.value
                    },
                    showTooltip: false
                  });
                  if (!data.value) return;
                  updateField({
                    toolingType: data.value.toolingType || null,
                    eqpName: eqpName.value || null,
                    alarmID: data.value.alarmID || null,
                    alarmType: data.value.alarmType || null,
                    createTime: useDateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss').value,
                    productName: data.value.productName || null,
                    alarmDesc: data.value.alarmDesc || null,
                    reason: data.value.reason || null,
                    improveMeasures: data.value.improveMeasures || null,
                    category: 0,
                    handleMeasures: data.value.handleMeasures || null,
                    alarmIDList: data.value.alarmIDList || [],
                    currentStatus: null
                  });
                }
              } catch (error) {
                resetField();
                formData.value.eqpName = eqpName.value || null;
                eqpName.value = null;
                formDisabledIsShow.value = true;
              }
            }
          }}
          v-model:value={formData.value.category}
        >
          <base-radio label={i18nt('equipment')} value={0} />
          <base-radio label={i18nt('alarmCode')} value={1} />
        </base-radio-group>
      );
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'eqpName',
    formItemProps: {
      label: i18nt('affectedEquipment')
    },
    componentProps: {
      disabled: true
    }
  },
  formData.value.category === 1
    ? {
        type: 'select',
        model: 'alarmID',
        formItemProps: {
          label: i18nt('alarmCode'),
          rule: useRules('change', i18nt('alarmCode'))
        },
        componentProps: {
          valueField: 'name',
          labelField: 'name',
          clearable: false,
          loading: isLoadingRepairConfigDetail.value,
          options: formData.value.alarmIDList || [],
          disabled: !eqpName.value,
          onUpdateValue: async (value: string) => {
            try {
              restoreValidation();
              const { data: repairInfoData } = await getRepairInfo(__, {
                params: {
                  eqpName: eqpName.value,
                  alarmID: value
                },
                showTooltip: false
              });
              // 已拥有保修单
              if (repairInfoData.value) {
                formDisabledIsShow.value = repairInfoData.value.currentStatus !== 1;
                updateField({
                  ...repairInfoData.value,
                  alarmID: value,
                  eqpName: eqpName.value,
                  category: 1
                });
              } else {
                formDisabledIsShow.value = false;
                const { data } = await getRepairConfigDetail(__, {
                  data: {
                    eqpName: eqpName.value,
                    alarmID: value
                  },
                  showTooltip: false
                });
                if (!data.value) return;
                updateField({
                  toolingType: data.value.toolingType || null,
                  eqpName: eqpName.value || null,
                  alarmID: value,
                  alarmType: data.value.alarmType || null,
                  createTime: useDateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss').value,
                  productName: data.value.productName || null,
                  alarmDesc: data.value.alarmDesc || null,
                  reason: data.value.reason || null,
                  improveMeasures: data.value.improveMeasures || null,
                  category: 1,
                  handleMeasures: data.value.handleMeasures || null,
                  alarmIDList: data.value.alarmIDList || [],
                  currentStatus: null
                });
              }
            } catch (error) {
              formData.value.eqpName = eqpName.value || '';
              formData.value.alarmID = value;
              formDisabledIsShow.value = true;
            }
          }
        }
      }
    : __,
  {
    type: 'select',
    model: 'alarmType',
    formItemProps: {
      label: i18nt('typeOfMalfunction'),
      rule: useRules('change', i18nt('typeOfMalfunction'))
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingAlarmTypeData.value,
      options: alarmTypeDataList.value
    }
  },
  {
    type: 'select',
    model: 'handleMeasures',
    formItemProps: {
      label: i18nt('handlingMethods'),
      rule: useRules('change', i18nt('handlingMethods'))
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingHandleMeasuresData.value,
      options: handleMeasuresDataList.value
    }
  },
  {
    type: 'date-picker',
    model: 'createTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('occurredTime')
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss',
      clearable: false
    }
  },
  {
    type: 'input',
    model: 'productName',
    formItemProps: {
      label: i18nt('productType')
    }
  },
  {
    type: 'input',
    model: 'alarmDesc',
    formItemProps: {
      label: i18nt('faultDescription'),
      rule: [useRules('input', i18nt('faultDescription'))]
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'reason',
    formItemProps: {
      label: i18nt('primaryCause')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'improveMeasures',
    formItemProps: {
      label: i18nt('improvementMeasures')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    formItemClass: 'col-span-2!'
  }
]);
// 保存表单
const { isLoading: isLoadingAdd, execute: saveFormAdd } = useAxiosPost('');

const saveForm = async () => {
  try {
    await validate();
    await saveFormAdd(
      formData.value.currentStatus ? CreateMaintenanceRequestApis.updateApi : CreateMaintenanceRequestApis.addApi,
      {
        data: {
          ...formData.value
        }
      }
    );
  } catch (error) {
    console.log(error);
  }
};
</script>

<template>
  <div id="create-maintenance-request" class="flex layout-content-page-vh">
    <base-card
      class="mr"
      :class="[`w-${TREE_WIDTH_CONTAINER}px!`]"
      :content-style="{ height: '100%', overflow: 'hidden' }"
    >
      <base-tree
        wrapper-class="h-full"
        class="h-full"
        :watch-props="['defaultSelectedKeys']"
        :loading="isLoadingEqpmentNumberList"
        block-line
        :data="eqpmentNumberList"
        key-field="id"
        label-field="name"
        :node-props="nodeProps"
        :checkable="false"
        cascade
      />
    </base-card>
    <base-card>
      <base-spin :show="isLoadingRepairConfigDetail || isLoadingRepairInfo || isLoadingAdd">
        <div class="flex">
          <div class="form-title">{{ i18nt('equipmentMaintenanceReport') }}</div>
          <base-button :disabled="formDisabledIsShow" type="primary" class="mr" button-name="save" @click="saveForm">
            {{ $t('submit') }}
          </base-button>
        </div>
        <base-form
          ref="formRef"
          v-model="formData"
          :disabled="!eqpName || formDisabledIsShow"
          class="form"
          layout="dialog"
          :schemas="formSchemas"
        />
      </base-spin>
    </base-card>
  </div>
</template>

<style scoped lang="less">
.form-title {
  width: 100%;
  text-align: center;
  font-size: 18px;
  font-weight: bold;
}
</style>
