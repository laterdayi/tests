<script setup lang="tsx">
import { AlarmMaintenanceConfigurationApis } from '@/service/apis/ams/maintenance-manage/alarm-maintenance-configuration';
import type {
  EQPAlarmCodeType,
  EditType,
  QueryType,
  TableListType
} from '@/service/apis/ams/maintenance-manage/alarm-maintenance-configuration';
import { CommonApis } from '@/service/apis/common/common';

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
// 获取报警类型
const { data: alarmTypeDataList, isLoading: isLoadingAlarmTypeData } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.alarmType
  },
  __,
  {
    immediate: true
  }
);
// 获取处理方式
const { data: handleMeasuresDataList, isLoading: isLoadingHandleMeasuresData } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.handleMeasures
  },
  __,
  {
    immediate: true
  }
);
// 获取设备编号列表
const { data: equipmentNumberList, isLoading: isLoadingEquipmentNumberList } = useAxiosGet<OptionsType[]>(
  CommonApis.getEquipmentNumberIdListApi,
  {},
  { paramsSerializer: useParamsSerializer() },
  {
    immediate: true
  }
);
// 获取报警代码
const eQPAlarmCodeList = ref<EQPAlarmCodeType[]>([]);
const { isLoading: isLoadingEQPAlarmCodeList, execute: executeGetEQPAlarmCode } = useAxiosGet<EQPAlarmCodeType[]>(
  AlarmMaintenanceConfigurationApis.getEQPAlarmCodeListApi
);
// 查询表单配置
const queryFormParams: Nullable<QueryType> = {
  eqpID: null,
  alarmID: null,
  alarmType: null,
  handleMeasures: null,
  isRepair: null
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'eqpID',
    formItemProps: {
      label: i18nt('eqpName')
    },
    componentProps: {
      valueField: 'name',
      labelField: 'name',
      loading: isLoadingEquipmentNumberList.value,
      options: equipmentNumberList.value
    }
  },
  {
    type: 'input',
    model: 'alarmID',
    formItemProps: {
      label: i18nt('alarmCode'),
      rule: [useRuleStringLength(0, 50)]
    }
  },
  {
    type: 'select',
    model: 'alarmType',
    formItemProps: {
      label: i18nt('typeOfMalfunction')
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingAlarmTypeData.value,
      options: alarmTypeDataList.value
    }
  },

  {
    type: 'select',
    model: 'handleMeasures',
    formItemProps: {
      label: i18nt('handlingMethods')
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingHandleMeasuresData.value,
      options: handleMeasuresDataList.value
    }
  },
  {
    type: 'select',
    model: 'isRepair',
    formItemProps: {
      label: i18nt('needsRepair')
    },
    componentProps: {
      options: [
        {
          label: i18nt('yes'),
          value: 1
        },
        {
          label: i18nt('no'),
          value: 0
        }
      ]
    }
  }
]);

// 新增/编辑配置
const formParams: Nullable<EditType> = {
  eqpID: null,
  alarmID: null,
  alarmType: null,
  handleMeasures: null,
  isRepair: 1,
  category: 0,
  sop: null,
  sopName: null,
  alarmDesc: null,
  remark: null
};
// SOP上传格式
const ASTRICT_SOP_RULE = {
  rule: [
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/pdf',
    'video/*'
  ],
  error: i18nt('uploadFileTips.astrictSOPHint')
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('category') },
    model: 'category',
    render() {
      if (!curdRef.value) return;
      if (!curdRef.value.formData) return;
      return (
        <base-radio-group
          disabled={curdRef?.value?.isEditMode}
          onClick={() => {
            if (!curdRef.value) return;
            if (!curdRef.value.formData) return;
            curdRef.value.resetField();
            curdRef.value.formData.eqpID = null;
            curdRef.value.formData.alarmID = null;
          }}
          v-model:value={curdRef.value.formData.category}
        >
          <base-radio label={i18nt('equipment')} value={0} />
          <base-radio label={i18nt('alarmCode')} value={1} />
        </base-radio-group>
      );
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'select',
    model: 'eqpID',
    formItemProps: {
      label: i18nt('eqpName'),
      rule: useRules('change', i18nt('eqpName'))
    },
    componentProps: {
      valueField: 'name',
      labelField: 'name',
      loading: isLoadingEquipmentNumberList.value,
      options: equipmentNumberList.value,
      disabled: curdRef?.value?.isEditMode,
      onUpdateValue: async (value: string) => {
        try {
          if (!curdRef.value) return;
          if (!curdRef.value.formData) return;
          if (curdRef.value.formData.category === 1) {
            curdRef.value.formData.alarmID = null;
            curdRef.value.formData.alarmDesc = null;
            const { data } = await executeGetEQPAlarmCode({
              params: {
                eqpName: value
              }
            });

            if (!data.value) return;
            eQPAlarmCodeList.value = data.value;
          }
        } catch (error) {
          console.log(error);
          eQPAlarmCodeList.value = [];
        }
      }
    }
  },
  curdRef.value && curdRef.value.formData && curdRef.value.formData.category === 1
    ? {
        type: 'select',
        model: 'alarmID',
        formItemProps: {
          label: i18nt('alarmCode'),
          rule: useRules('change', i18nt('alarmCode'))
        },
        componentProps: {
          valueField: 'alarmId',
          labelField: 'alarmId',
          loading: isLoadingEQPAlarmCodeList.value,
          options: eQPAlarmCodeList.value,
          disabled: curdRef?.value?.isEditMode,
          onUpdateValue: (value: string) => {
            const item = eQPAlarmCodeList.value.find(ele => ele.alarmId === value);
            if (!curdRef.value) return;
            if (!curdRef.value.formData) return;
            curdRef.value.formData.alarmDesc = item?.description || '';
          }
        }
      }
    : __,
  {
    type: 'select',
    model: 'alarmType',
    formItemProps: {
      label: i18nt('typeOfMalfunction'),
      rule: useRules('change', i18nt('typeOfMalfunction'))
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingAlarmTypeData.value,
      options: alarmTypeDataList.value
    }
  },

  {
    type: 'select',
    model: 'handleMeasures',
    formItemProps: {
      label: i18nt('handlingMethods'),
      rule: useRules('change', i18nt('handlingMethods'))
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingHandleMeasuresData.value,
      options: handleMeasuresDataList.value
    }
  },
  useRenderFormSwitch({
    key: 'isRepair',
    label: i18nt('needsRepair'),
    formItemClass: 'col-span-2!'
  }),
  useRenderFormUpload({
    model: 'sop',
    label: 'SOP',
    rule: {
      rule: [...ASTRICT_SOP_RULE.rule],
      error: ASTRICT_SOP_RULE.error
    },
    astrictFileSize: 10,
    onFinished({ data, file }) {
      if (!curdRef.value) return;
      if (!curdRef.value.formData) return;
      curdRef.value.formData.sopName = file.name;
      curdRef.value.formData.sop = data;
    },
    onRemoved() {
      if (!curdRef.value) return;
      if (!curdRef.value.formData) return;
      curdRef.value.formData.sopName = null;
      curdRef.value.formData.sop = null;
    },
    componentProps: {
      action: CommonApis.uploadFileApi,
      listType: 'text',
      fileList:
        curdRef.value && curdRef.value.formData && curdRef.value.formData.sopName
          ? [
              {
                id:
                  curdRef.value && curdRef.value.formData && curdRef.value.formData.sopName
                    ? curdRef.value.formData.sopName
                    : '',
                name:
                  curdRef.value && curdRef.value.formData && curdRef.value.formData.sopName
                    ? curdRef.value.formData.sopName
                    : '',
                status: 'finished'
              }
            ]
          : []
    },
    formData: curdRef.value?.formData
  }),
  useRenderFormTextarea({
    model: 'alarmDesc',
    label: i18nt('faultDescription'),
    formItemClass: 'col-span-2!'
  }),

  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark'),
    componentProps: { maxlength: 1000 },
    formItemClass: 'col-span-2!'
  })
]);

// 表格数据配置
const curdRefPagination = computed(() => curdRef.value?.pagination);
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    key: 'eqpID',
    title: i18nt('eqpName'),
    sorter: true,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.eqpID, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  { title: i18nt('alarmCode'), key: 'alarmID', sorter: true, width: TABLE_WIDTH_INFO },
  { title: i18nt('typeOfMalfunction'), key: 'alarmType', sorter: true, width: TABLE_WIDTH_STATE },

  { title: i18nt('faultDescription'), key: 'alarmDesc' },
  { title: i18nt('handlingMethods'), key: 'handleMeasures', width: TABLE_WIDTH_STATE, sorter: true },
  {
    title: i18nt('needsRepair'),
    key: 'isRepair',
    width: TABLE_WIDTH_STATE,
    sorter: true,
    render: rowData => useRenderTableSwitch(!!rowData.isRepair)
  },
  {
    title: 'SOP',
    key: 'sop',
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.sopName, () => {
        window.open(`${window?.$CONFIG?.projectConfig?.ossUrl}${rowData.sop}`, '_blank');
      })
  },
  { title: i18nt('remark'), key: 'remark' },
  { title: i18nt('creator'), sorter: true, key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), sorter: true, key: 'createTime', width: TABLE_WIDTH_DATETIME }
];
// 新增事件
const openModal = async () => {
  try {
    if (!curdRef.value) return;
    if (!curdRef.value.formData) return;
    const { data } = await executeGetEQPAlarmCode({
      params: {
        eqpName: curdRef.value.formData.eqpID
      }
    });

    if (!data.value) return;
    eQPAlarmCodeList.value = data.value;
  } catch (error) {
    console.log(error);
    eQPAlarmCodeList.value = [];
  }
};
const modalClosed = () => {
  eQPAlarmCodeList.value = [];
};
</script>

<template>
  <div id="alarm-maintenance-configuration">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :read-api="AlarmMaintenanceConfigurationApis.getListApi"
      :create-api="AlarmMaintenanceConfigurationApis.addApi"
      :edit-detail-api="AlarmMaintenanceConfigurationApis.getDetailApi"
      :update-api="AlarmMaintenanceConfigurationApis.updateApi"
      :delete-api="AlarmMaintenanceConfigurationApis.deleteApi"
      :import-api="AlarmMaintenanceConfigurationApis.importApi"
      :export-api="AlarmMaintenanceConfigurationApis.getListApi"
      :download-api="AlarmMaintenanceConfigurationApis.downloadApi"
      modal-title="alarmMaintenanceConfiguration"
      @after-open-edit-modal="openModal"
      @modal-closed="modalClosed"
    />
  </div>
</template>
