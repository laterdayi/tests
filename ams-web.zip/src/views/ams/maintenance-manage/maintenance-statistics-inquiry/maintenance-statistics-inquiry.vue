<script setup lang="tsx">
import type { BarSeriesOption } from 'echarts/charts';
import { CommonApis } from '@/service/apis/common/common';
import { MaintenanceStatisticsInquiryApis } from '@/service/apis/ams/maintenance-manage/maintenance-statistics-inquiry';
import type { QueryType, TableListType } from '@/service/apis/ams/maintenance-manage/maintenance-statistics-inquiry';
import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';

// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);
const handleQueryProductLineList = () => executeGetProductLineList();
// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};
// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(
  CommonApis.getEqpsByLayoutIdsApi,
  {},
  { paramsSerializer: useParamsSerializer() }
);
// 查询表单

const {
  formRef,
  formData,
  resetField: resetQueryField
  // updateField
} = useForm<Nullable<QueryType>>({
  type: 2,
  layoutIds: [],
  eqpName: null,
  timestamp: useFormatDateRange(7)
});

// 横坐标
const abscissaList = [
  {
    label: i18nt('equipmentNumber'),
    value: 2
  },
  {
    label: i18nt('maintenancePersonnel'),
    value: 7
  }
];
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'type',
    formItemProps: { label: i18nt('abscissa') },
    componentProps: {
      options: abscissaList,
      clearable: false
    }
  },
  {
    type: 'tree-select',
    model: 'layoutIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: computed(() => ({
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      labelField: 'name',
      keyField: 'id',
      multiple: true,
      cascade: true,
      checkable: true,
      onUpdateValue: (value: (string | number | null)[]) => {
        if (formData.value) formData.value.eqpName = null;
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
            params: { layoutIds: value }
          })
          : handleQueryEquipmentNumberList();
      }
    }))
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      options: equipmentNumberChildList.value,
      loading: isLoadingEquipmentNumberChildList.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
]);
// 重构查询表单参数函数
const refactorFormQueryParams = (data: QueryType) => {
  if (!data.timestamp) return;
  return {
    ...data,
    ...useFormatDateTimeParams(data.timestamp)
  };
};

// 表格配置
const {
  handleSorterChange,
  pagination,
  handleResetPageSize,
  isLoadingQuery,
  tableData,
  executeQueryList: getSummary,
  tableRef
} = useTable<TableListType[]>(MaintenanceStatisticsInquiryApis.getSummaryApi, {
  queryFormParams: formData,
  paramsSerializerQuery: true,
  refactorFormQueryParams,
  remote: false
});

const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(pagination),
  {
    title: () => {
      return xName.value;
    },
    key: 'summaryType',
    sorter: true
  },
  { title: i18nt('maintenanceQuantity'), key: 'summaryCount', sorter: true }
];
// 图表配置
const chartRef = ref<ChartRefType | null>(null);
const xName = ref<string>('');

const charthandle = (list: TableListType[]) => {
  const xAxisData = list.map(ele => ele.summaryType) || [];
  nextTick(() => {
    if (chartRef.value) {
      chartRef.value?.setOption(
        {
          ...BAR_OPTION,
          legend: {
            data: [i18nt('maintenanceQuantity')]
          },
          yAxis: {
            name: i18nt('freq'),
            minInterval: 1
          },
          xAxis: {
            name: xName.value,
            type: 'category',
            data: xAxisData,

            axisTick: {
              alignWithLabel: true
            }
          },
          dataZoom: useChartDataZoomOption(xAxisData.length),
          series: [
            {
              ...(BAR_OPTION.series as BarSeriesOption[])[0],
              type: 'bar',
              name: i18nt('maintenanceQuantity'),
              large: true,
              data: list.map(ele => ele.summaryCount) || []
            }
          ]
        },
        true
      );
      chartRef.value?.resize();
    }
  });
};

tryOnMounted(async () => {
  handleQueryProductLineList();
  handleQueryEquipmentNumberList();
  await getSummary();
});
watch(tableData, newValue => {
  if (!newValue) return;
  const xObj = abscissaList.find(ele => ele.value === formData.value.type);
  xName.value = xObj?.label || '';
  if (tableData.value?.length === 0) {
    chartRef.value?.setEmptyOption();
  } else {
    charthandle(newValue);
  }
});
// 按钮事件
const handleButton = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      resetQueryField();
      handleResetPageSize();
      getSummary();
      handleQueryEquipmentNumberList();
    },
    search: () => {
      handleResetPageSize();
      getSummary();
    }
  };
  columnsList[permission as string]();
};
</script>

<template>
  <div id="maintain--completion-analysis">
    <base-card>
      <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
        <template #header-action>
          <permission-button form :loading-props="{ searchLoading: isLoadingQuery }" @handle="handleButton" />
        </template>
      </base-form>
      <!-- 默认 -->
      <base-table
        ref="tableRef"
        :columns="tableColumns"
        :data="tableData ?? []"
        :loading="isLoadingQuery"
        :pagination="{
          ...pagination,
          prefix: () => `${i18nt('baseTable.total')} ${tableData?.length} ${i18nt('baseTable.strip')}`
        }"
        @update:sorter="handleSorterChange"
      >
        <template #center>
          <div class="flex">
            <base-chart ref="chartRef" :loading="isLoadingQuery" />
          </div>
        </template>
      </base-table>
    </base-card>
  </div>
</template>
