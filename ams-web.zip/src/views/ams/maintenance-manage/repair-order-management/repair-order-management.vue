<script setup lang="tsx">
import detailForm from './components/detail-form.vue';
import { RepairHistoryApis, RepairState } from '@/service/apis/ams/maintenance-manage/repair-history';
import type { QueryType, TableListType } from '@/service/apis/ams/maintenance-manage/repair-history';
import { CommonApis } from '@/service/apis/common/common';

const { currentRoutePowers } = useRoutes();
const appStore = useAppStore();
// 模板引用
const curdRef = ref<CurdRefType<QueryType, TableListType>>();

// 详情弹窗
const detailFormRef = ref();
//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelQueryApi,
  __,
  __,
  {
    immediate: true
  }
);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
handleQueryEquipmentList();
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });
// 搜索栏
const queryFormParams: Nullable<QueryType> = {
  eqpName: null,
  treeIds: null,
  alarmDesc: null,
  state: null,
  alarmID: null,
  timestamp: useFormatDateRange(),
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1
};
// 重置搜索栏
const refactorFormQueryParams = (data: QueryType) => {
  return {
    ...data,
    ...useFormatDateTimeParams(data.timestamp)
  };
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        if (curdRef?.value?.queryFormData) curdRef.value.queryFormData.eqpName = null;
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
            params: { layoutIds: value }
          })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  { type: 'input', model: 'alarmID', formItemProps: { label: i18nt('alarmCode') } },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      options: [
        {
          id: 1,
          name: i18nt('RepairOperateStateEnum_ToTakeOver')
        },
        {
          id: 2,
          name: i18nt('RepairOperateStateEnum_AwaitingRepair')
        },
        // {
        //   id: 3,
        //   name: i18nt('RepairOperateStateEnum_MarjorDown')
        // },
        // {
        //   id: 4,
        //   name: i18nt('RepairOperateStateEnum_ToBeConfirmed')
        // },
        {
          id: 5,
          name: i18nt('RepairOperateStateEnum_EqpReceive')
        },
        // {
        //   id: 6,
        //   name: i18nt('RepairOperateStateEnum_PM')
        // },
        // {
        //   id: 7,
        //   name: i18nt('RepairOperateStateEnum_RepairMachine')
        // },
        {
          id: 8,
          name: i18nt('RepairOperateStateEnum_CompleteMaintenance')
        }
      ],
      labelField: 'name',
      valueField: 'id'
    }
  },
  { type: 'input', model: 'alarmDesc', formItemProps: { label: i18nt('faultDescription') } },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('repairTime') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
]);
// 当前状态
const currentStatusObj: {
  [key: number]: {
    type: 'default' | 'warning' | 'primary' | 'success' | 'error'
    title: string
  }
} = {
  [RepairState.toTakeOver]: {
    type: TagState.warning,
    title: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  [RepairState.awaitingRepair]: {
    type: TagState.primary,
    title: i18nt('RepairOperateStateEnum_AwaitingRepair')
  },
  // [RepairState.marjorDowarjorDow]: {
  //   type: TagState.primary,
  //   title: i18nt('RepairOperateStateEnum_MarjorDown')
  // },
  // [RepairState.toBeConfirmed]: {
  //   type: TagState.primary,
  //   title: i18nt('RepairOperateStateEnum_ToBeConfirmed')
  // },
  [RepairState.eapReceive]: {
    type: TagState.primary,
    title: i18nt('RepairOperateStateEnum_EqpReceive')
  },
  // [RepairState.PM]: {
  //   type: TagState.primary,
  //   title: i18nt('RepairOperateStateEnum_PM')
  // },
  // [RepairState.repairMachine]: {
  //   type: TagState.warning,
  //   title: i18nt('RepairOperateStateEnum_RepairMachine')
  // },
  [RepairState.completeMlaintenance]: {
    type: TagState.success,
    title: i18nt('RepairOperateStateEnum_CompleteMaintenance')
  }
};
// 列表
const curdRefPagination = computed(() => curdRef.value?.pagination);
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('workOrderNumber'),
    key: 'workOrder',
    sorter: true,
    render(rowData) {
      return rowData.currentStatus === RepairState.completeMlaintenance
        ? rowData.workOrder
        : useRenderTableTitleEdit(
          rowData.workOrder,
          () => detailFormRef.value?.handleOpenModal(rowData, true, currentRoutePowers.value)
        );
    }
  },
  {
    title: i18nt('currentState'),
    key: 'currentStatus',
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return useRenderTableSingleTag(
        currentStatusObj[rowData.currentStatus].type,
        currentStatusObj[rowData.currentStatus].title
      );
    }
  },
  {
    key: 'eqpID',
    title: i18nt('eqpName'),
    sorter: true
  },
  { title: i18nt('alarmCode'), key: 'alarmID', sorter: true },
  { title: i18nt('typeOfMalfunction'), key: 'alarmType', sorter: true, width: TABLE_WIDTH_STATE },
  { title: i18nt('currentResponsiblePerson'), key: 'currentHandler', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('handlingMethods'), key: 'handleMeasures', sorter: true, width: TABLE_WIDTH_STATE },
  { title: i18nt('faultDescription'), key: 'alarmDesc' },
  { title: i18nt('maintenanceDuration'), key: 'repairSeconds', width: TABLE_WIDTH_STATE },

  { title: i18nt('repairApplicant'), sorter: true, key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('repairTime'), sorter: true, key: 'createTime', width: TABLE_WIDTH_DATETIME },
  useRenderTableActionColumn({
    render: rowData =>
      useRenderTableFixedButton('viewDetail', {
        onClick: () => detailFormRef.value?.handleOpenModal(rowData, false, [])
      })
  })
];
// 按钮权限控制
const formDisableCondition = computed(() => {
  const selectedRows = curdRef?.value?.tableRef?.selectedRows;
  const { currentStatus } = selectedRows?.at(0) ?? {};
  return {
    delete: selectedRows?.length !== 1 || currentStatus !== RepairState.toTakeOver
  };
});

// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="repair-manage">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :form-permission-disable="formDisableCondition"
      :ignore-form-permission-list="[
        'takeOver',
        'changedHand',
        'maintenanceConfirmation',
        'qcConfirm',
        'equipmentReceive'
      ]"
      modal-title="repair"
      :read-api="RepairHistoryApis.getRepairListApi"
      :delete-api="RepairHistoryApis.deleteRepairApi"
      :export-api="RepairHistoryApis.getRepairListApi"
    />
    <!-- 查看详情 -->
    <detailForm ref="detailFormRef" @reset-table="resetTable" />
  </div>
</template>
