<script setup lang="tsx">
import formDesigner from '@/components/project/form-designer/form-designer.vue';
import type { WidgetType } from '@/components/project/form-designer/utils/designer-type';
import {
  FormItemMethodApis,
  handleTableTransformList,
  handleValidateChangeMachineForm,
  handleValidateFormIsMaxItemValue,
  handleValidateFormIsPass
} from '@/components/project/form-designer/utils/form-item-method';
import type { FormItemListType } from '@/components/project/form-designer/utils/form-item-type';
import { RepairHistoryApis } from '@/service/apis/ams/maintenance-manage/repair-history';
import type { QcConfirmFormType } from '@/service/apis/ams/maintenance-manage/repair-history';

const emit = defineEmits<{
  'reset-from': [];
}>();

// 获取QC表单信息
const { data: formInfoData, execute: executeGetQcConfirmForm } = useAxiosGet<QcConfirmFormType>(
  RepairHistoryApis.getFormInfoApi
);
// 获取QC表单列表信息
const { execute: executeGetFormItemList } = useAxiosPost<FormItemListType>(
  FormItemMethodApis.getFormItemListApi,
  __,
  __,
  { shallow: false }
);
// 表单数据
const formDesignerRef = ref();
const widgetList = ref<WidgetType[]>([]);
const qcFormId = ref<string>('');
//  打开弹窗
const showDrawer = ref<boolean>(false);
// 展示类型
const handleOpenModal = async (id: string) => {
  qcFormId.value = id;
  try {
    // 获取表单信息
    await executeGetQcConfirmForm(__, {
      params: {
        id,
        eFormType: 4
      }
    });
    if (formInfoData.value && formInfoData.value.eFormId) {
      // 获取表单列表信息
      const { data } = await executeGetFormItemList(__, {
        data: { formId: formInfoData.value.eFormId },
        showTooltip: false
      });
      if (!data.value) return;
      widgetList.value = data.value.table ? [data.value.table] : [];
    }
    showDrawer.value = true;
  } catch (error) {
    console.log(error);
  }
};

// 确认
const { execute: executeFormConfirm } = useAxiosPost<FormItemListType>(RepairHistoryApis.saveRepairHandlerFormApi);
const handleSubmitFormConfirm = async () => {
  const list = handleTableTransformList(formDesignerRef.value.designerHandle().widgetList[0]);
  // 表格为空验证
  if (!handleValidateChangeMachineForm(list)) return;
  // 表格长度验证
  if (handleValidateFormIsMaxItemValue(list)) return;
  // 表格效验验证
  if (!handleValidateFormIsPass(list)) return;
  if (!formInfoData.value) return;
  const { eFormId, prefix, repairHandleType } = formInfoData.value ?? {};
  await executeFormConfirm(__, {
    data: {
      id: qcFormId.value,
      repairHandleType,
      prefix,
      eFormId,
      table: formDesignerRef.value.designerHandle().widgetList[0],
      selectType: 0
    }
  });

  cancelDrawer();
};
// 关闭抽屉
const cancelDrawer = () => {
  showDrawer.value = false;
  widgetList.value = [];
  emit('reset-from');
};

defineExpose({
  handleOpenModal
});
</script>

<template>
  <!--  维修完成 -->
  <base-drawer v-model:show="showDrawer" width="85%" :title="i18nt('qcConfirm')" @mask-click="() => cancelDrawer">
    <formDesigner
      ref="formDesignerRef"
      :basic-fields="[]"
      :basic-fields-contro="[]"
      :basic-fields-shared="[]"
      :basic-fields-project="[]"
      :project-name="null"
      :form-height="120"
      :widget-list="widgetList"
      :preview-type="2"
      :preview-is-show="false"
      :table-item-component-is-show="false"
    />

    <template #footer>
      <base-button class="m-r" button-name="cancel" ghost @click="cancelDrawer">
        {{ $t('cancel') }}
      </base-button>
      <base-button button-name="confirm" type="primary" ghost @click="handleSubmitFormConfirm">
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-drawer>
</template>
