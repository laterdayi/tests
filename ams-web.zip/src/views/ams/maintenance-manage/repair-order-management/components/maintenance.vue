<script setup lang="tsx">
import maintenanceDrawer from './maintenance-drawer.vue';
import { RepairHistoryApis } from '@/service/apis/ams/maintenance-manage/repair-history';
import type {
  DetailFormType,
  FormItemListType,
  MaintenanceFormDataType,
  MaintenanceType
} from '@/service/apis/ams/maintenance-manage/repair-history';

const emit = defineEmits<{
  'reset-from': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 弹窗开启
const modalIsShow = ref(false);
// 存储数据
const modelForm = ref();
//  打开弹窗
const handleOpenModal = (row: DetailFormType) => {
  modelForm.value = row;
  stateChecked();
  formData.value.state = row.defaultSelection;
  modalIsShow.value = true;
};

// 表单
const { formData, resetField, formRef, validate } = useForm<Nilable<MaintenanceType>>({
  state: null,
  reason: null,
  improveMeasures: null,
  parameterModification: null,
  sparePartChange: null
});
// 维修确认列表
const maintenanceResultsList = [
  {
    id: 3,
    value: 'isBtnMajorDown',
    label: 'MajorDown'
  },
  {
    id: 6,
    value: 'isBtnPM',
    label: 'PM'
  },
  {
    id: 7,
    value: 'isBtnRepairMachine',
    label: i18nt('RepairActionEnum_RepairMachine')
  },
  {
    id: 8,
    value: 'isBtnRepairComplete',
    label: i18nt('RepairActionEnum_RepairComplete')
  }
];
// 维修确认点击
const stateChecked = () => {
  resetField();
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    formItemClass: 'col-span-2!',
    render() {
      return (
        <div
          style={{
            marginLeft: '50px'
          }}
        >
          <span class="mr">{i18nt('maintenanceResults')}</span>
          <n-radio-group name="radiogroup" onUpdateValue={stateChecked} v-model:value={formData.value.state}>
            <n-space>
              {maintenanceResultsList.map(ele => {
                return modelForm.value[ele.value as keyof DetailFormType] ? (
                  <n-radio value={ele.id}>{ele.label}</n-radio>
                ) : (
                  __
                );
              })}
            </n-space>
          </n-radio-group>
        </div>
      );
    }
  },
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'reason',
        formItemProps: {
          label: i18nt('primaryCause'),
          rule: useRules('input', i18nt('primaryCause'))
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'improveMeasures',
        formItemProps: {
          label: i18nt('repairsMeasure'),
          rule: useRules('input', i18nt('repairsMeasure'))
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'parameterModification',
        formItemProps: {
          label: i18nt('paramsModify')
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'input',
        model: 'sparePartChange',
        formItemProps: {
          label: i18nt('spareReplace')
        },
        componentProps: {
          type: 'textarea',
          minlength: 0,
          maxlength: MAX_LENGTH_DESCRIPTION,
          showCount: true
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  formData.value.state === 8
    ? {
        type: 'custom-form-item',
        render() {
          return (
            <div
              style={{
                marginLeft: '50px'
              }}
            >
              <span
                style={{
                  color: '#f56c6c',
                  marginRight: '5px'
                }}
              >
                *
              </span>
              <span class="mr">{i18nt('maintenanceConfirmation')}</span>
              <base-button
                buttonName={maintenanceFormData.value ? i18nt('confirmed') : i18nt('unconfirmed')}
                class="mr"
                onClick={maintenanceConfirmationClick}
                size={componentSize.value}
                type="primary"
              >
                {maintenanceFormData.value ? i18nt('confirmed') : i18nt('unconfirmed')}
              </base-button>
            </div>
          );
        }
      }
    : __
]);
const maintenanceDrawerRef = ref();
// 维修确认点击
const maintenanceConfirmationClick = () => {
  maintenanceDrawerRef.value?.handleOpenModal(modelForm.value.id, maintenanceFormData.value);
};
// 抽屉传值
const maintenanceFormData = ref<MaintenanceFormDataType>();
const drawerFrom = (item: MaintenanceFormDataType) => {
  maintenanceFormData.value = item;
};

const { execute: executeFormConfirm } = useAxiosPost<FormItemListType>(RepairHistoryApis.saveRepairHandlerFormApi);
const { execute: saveFormAdd } = useAxiosPost(RepairHistoryApis.submitFeedbackApi);
// 保存表单
const saveForm = async () => {
  try {
    await validate();
    if (formData.value.state === 8) {
      if (!maintenanceFormData.value) {
        return $message.warning(i18nt('notEmpty', { val: i18nt('maintenanceConfirmation') }));
      }
      const { eFormId, prefix, repairHandleType } = maintenanceFormData.value.formInfoData ?? {};
      await executeFormConfirm(__, {
        data: {
          ...formData.value,
          id: modelForm.value.id,
          eFormId,
          prefix,
          table: maintenanceFormData.value.table,
          repairHandleType,
          selectType: 1
        }
      });
    } else {
      await saveFormAdd({
        data: {
          state: formData.value.state,
          repairId: modelForm.value.id
        }
      });
    }
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  maintenanceFormData.value = undefined;
  // 重置表单并去除验证
  resetField();
  emit('reset-from');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="i18nt('maintenanceConfirmation')"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="formSchemas" />
    <!-- 维修确认抽屉 -->
    <maintenanceDrawer ref="maintenanceDrawerRef" @drawer-from="drawerFrom" />
  </base-modal>
</template>
