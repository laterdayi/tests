<script setup lang="tsx">
import { RepairHistoryApis } from '@/service/apis/ams/maintenance-manage/repair-history';
import type { TakeOverFormType } from '@/service/apis/ams/maintenance-manage/repair-history';

const emit = defineEmits<{
  'reset-from': []
}>();
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
//  打开弹窗
const handleOpenModal = (detailFormRow: TakeOverFormType) => {
  modalTitle.value = detailFormRow.isBtnTakeOver === 1 ? i18nt('takeOver') : i18nt('changedHand');
  formData.value = detailFormRow;
  updateField({
    ...formData.value,
    description: null
  });
  modalIsShow.value = true;
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  useRenderFormTextarea({
    label: i18nt('remark'),
    formItemProps: { rule: useRules('input', i18nt('remark')) },
    model: 'description',
    formItemClass: 'col-span-2!'
  })
]);
const { validate, formData, resetField, formRef, updateField } = useForm<Nullable<TakeOverFormType>>({
  id: null,
  eqpId: null,
  description: null,
  secondaryTakeover: 0,
  isBtnTakeOver: 1
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost(RepairHistoryApis.takeOverRepairApi);
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    await validate();
    saveFormLoading.value = true;
    const { id, description, isBtnTakeOver } = formData.value;
    await saveFormAdd({
      data: {
        id,
        description,
        operateType: isBtnTakeOver === 1 ? 1 : 2
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-from');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="modalTitle"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
    @positive-click="saveForm"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
  </base-modal>
</template>
