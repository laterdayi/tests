<script setup lang="tsx">
import takeOverForm from './take-over-form.vue';
import qcConfirmForm from './qc-confirm-form.vue';
import maintenanceConfirmationForm from './maintenance.vue';
import maintenanceDrawer from './maintenance-drawer.vue';

import { RepairHistoryApis } from '@/service/apis/ams/maintenance-manage/repair-history';
import type {
  DetailFormType,
  OperateRecordListType,
  TableListType
} from '@/service/apis/ams/maintenance-manage/repair-history';

import type { FormItemListType } from '@/components/project/form-designer/utils/form-item-type';

const emit = defineEmits<{
  'reset-table': [];
  'areset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const currentRoutePowers = ref<string[]>();
// 是否详情可编辑
const negativeIsShow = ref<boolean>(true);
// 弹窗备份
const detailFormRow = ref<TableListType>();
// 弹窗开启
const modalIsShow = ref(false);
// 获取详情
const { isLoading: isLoadingViewDetailData, execute: executeGetViewDetailData } = useAxiosGet<DetailFormType>(
  RepairHistoryApis.getRepairDetailApi
);
//  获取操作记录
const operateRecordList = ref<OperateRecordListType[]>();
const { isLoading: isLoadingOperateRecordList, execute: executeGetOperateRecordList } = useAxiosGet<
  OperateRecordListType[]
>(RepairHistoryApis.getRepairHistoryApi);
//  打开弹窗
const handleOpenModal = (row: TableListType, isShow: boolean, currentRoutePowersList: string[]) => {
  detailFormRow.value = row;
  negativeIsShow.value = isShow;
  currentRoutePowers.value = currentRoutePowersList;
  resetFrom();
  modalIsShow.value = true;
};
// 刷新表单
const resetFrom = async () => {
  const { data: detailData } = await executeGetViewDetailData({ params: { id: detailFormRow?.value?.id } });
  if (!detailData.value) return;
  formData.value = detailData.value;
  const { data: operateRecorData } = await executeGetOperateRecordList({
    params: { repairId: detailFormRow?.value?.id }
  });
  operateRecordList.value = operateRecorData.value;
};
// 表单
const { formData, resetField } = useForm<Nilable<DetailFormType>>({
  creator: null,
  createTime: null,
  layoutName: null,
  eqpName: null,
  productName: null,
  alarmInfo: null,
  alarmDesc: null,
  reason: null,
  improveMeasures: null,
  defaultSelection: null,
  parameterModification: null,
  sparePartChange: null
});
const renderSpan = (value?: string | number, style?: CSSProperties) => {
  return h('span', { style: { 'font-weight': 'bold', ...style } }, value);
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-node',
    render() {
      return h('div', { class: 'card-title col-span-2!' }, i18nt('repairInfo'));
    }
  },
  {
    type: 'custom-form-item',
    model: 'creator',
    formItemProps: { label: i18nt('repairApplicant') },
    render() {
      return renderSpan(formData.value.creator || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('repairTime') },
    render() {
      return renderSpan(formData.value.createTime || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'levelName',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.value.layoutName || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    render() {
      return renderSpan(formData.value.eqpName || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'productName',
    formItemProps: { label: i18nt('productType') },
    render() {
      return renderSpan(formData.value.productName || '');
    }
  },

  {
    type: 'custom-form-item',
    model: 'alarmDesc',
    formItemProps: { label: i18nt('faultDescription') },
    render() {
      return renderSpan(formData.value.alarmDesc || '');
    }
  },
  {
    type: 'custom-node',
    render() {
      return h('div', { class: 'card-title col-span-2!' }, i18nt('repairsInfo'));
    }
  },
  {
    type: 'custom-form-item',
    model: 'reason',
    formItemProps: { label: i18nt('primaryCause') },
    render() {
      return renderSpan(formData.value.reason || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'improveMeasures',
    formItemProps: { label: i18nt('repairsMeasure') },
    render() {
      return renderSpan(formData.value.improveMeasures || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'parameterModification',
    formItemProps: { label: i18nt('paramsModify') },
    render() {
      return renderSpan(formData.value.parameterModification || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'sparePartChange',
    formItemProps: { label: i18nt('spareReplace') },
    render() {
      return renderSpan(formData.value.sparePartChange || '');
    }
  }
]);

const operateTypeObj: { [key: number]: string } = {
  0: i18nt('RepairActionEnum_Submit'),
  1: i18nt('RepairActionEnum_TakeOver'),
  2: i18nt('RepairActionEnum_Transfer'),
  3: i18nt('RepairActionEnum_MajorDown'),
  4: i18nt('RepairActionEnum_InExecution'),
  5: i18nt('RepairActionEnum_Close'),
  6: i18nt('RepairActionEnum_PM'),
  7: i18nt('RepairActionEnum_RepairMachine'),
  8: i18nt('RepairActionEnum_RepairComplete')
};
// 操作记录
const tableColumns: DataTableColumns<OperateRecordListType> = [
  {
    title: i18nt('index'),
    key: 'index',
    titleColSpan: 2,
    colSpan: () => 2,
    ellipsis: {
      tooltip: true
    },
    width: TABLE_WIDTH_INDEX,
    render: (rowData, rowIndex) => <span>{rowIndex + 1}</span>
  },
  { title: i18nt('operator'), key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('operateTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('remark'), key: 'description', width: TABLE_WIDTH_DATETIME },
  {
    title: i18nt('action'),
    key: 'actionType',
    width: TABLE_WIDTH_INFO,
    render: rowData => {
      return (
        <div>
          <Base-Tag
            class={rowData.repairEFormId ? 'cursor-pointer' : 'default'}
            onClick={() => tableRowClick(rowData)}
            type={rowData.repairEFormId ? 'primary' : 'default'}
          >
            {operateTypeObj[rowData.operateType]}
          </Base-Tag>
        </div>
      );
    }
  }
];
// 操作记录按钮点击
const maintenanceDrawerRef = ref();
const { execute: executeGetEFormHistoryApiApi } = useAxiosGet<FormItemListType>(RepairHistoryApis.getEFormHistoryApi);
const tableRowClick = async (row: OperateRecordListType) => {
  if (!row.repairEFormId) return;
  const { data } = await executeGetEFormHistoryApiApi({ params: { repairEFormId: row.repairEFormId } });
  if (!data.value) return;
  maintenanceDrawerRef.value?.handleOpenModal(
    '',
    {
      table: data.value.table,
      fromResult: data.value.fromResult
    },
    1
  );
};
// 接手/转手
const takeOverFormRef = ref();
// QC确认
const qcConfirmFormRef = ref();
// 维修确认
const maintenanceConfirmationFormRef = ref();
// 设备接收
const { isLoading: isLoadingSaveEqpReceive, execute: executeSaveEqpReceiveForm } = useAxiosPost<DetailFormType>(
  RepairHistoryApis.saveEqpReceiveFormApi
);
// 按钮权限
const operateButtonPermissionList = [
  {
    key: 'isBtnTakeOver',
    text: 'takeOver',
    click: () => {
      takeOverFormRef.value?.handleOpenModal(formData.value);
    }
  },
  {
    key: 'isBtnHandOver',
    text: 'changedHand',
    click: () => {
      takeOverFormRef.value?.handleOpenModal(formData.value);
    }
  },
  {
    key: 'isBtnRepairConfirm',
    text: 'maintenanceConfirmation',
    click: () => {
      maintenanceConfirmationFormRef.value?.handleOpenModal(formData.value);
    }
  },
  {
    key: 'isBtnQCConfirm',
    text: 'qcConfirm',
    click: () => {
      qcConfirmFormRef.value?.handleOpenModal(formData.value.id);
    }
  },
  {
    key: 'isBtnEqpReceive',
    text: 'equipmentReceive',
    click: async () => {
      try {
        await executeSaveEqpReceiveForm({
          data: {
            id: detailFormRow.value?.id
          }
        });
        cancelModal();
      } catch (error) {
        console.log(error);
      }
    }
  }
];
// 验证是否拥有按钮权限
const verifyButton = (text: string) => {
  if (!currentRoutePowers.value) return;
  return currentRoutePowers.value.findIndex(ele => ele === text) !== -1;
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
  emit('areset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    :title="$t('viewDetail')"
    :positive-text="__"
    :negative-text="__"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
  >
    <div class="h-full overflow-auto">
      <base-spin :show="isLoadingViewDetailData">
        <base-form v-model="formData" disabled layout="dialog" :schemas="formSchemas" />
      </base-spin>
      <div class="card-title">{{ $t('operateRecord') }}</div>
      <base-table :loading="isLoadingOperateRecordList" :columns="tableColumns" :data="operateRecordList" />
    </div>

    <template #action>
      <div v-if="negativeIsShow" class="flex justify-between w-full">
        <div>
          <template v-for="item in operateButtonPermissionList" :key="item.key">
            <base-button
              v-if="formData?.[item.key as keyof DetailFormType] && verifyButton(item.text)"
              class="mr"
              :loading="isLoadingSaveEqpReceive"
              :size="componentSize"
              type="primary"
              :button-name="item.text"
              @click="item.click()"
            >
              {{ $t(item.text) }}
            </base-button>
          </template>
        </div>
      </div>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">
        {{ $t('cancel') }}
      </base-button>
    </template>
    <!-- 接手转手 -->
    <takeOverForm ref="takeOverFormRef" @reset-from="resetFrom" />
    <!-- QC确认 -->
    <qcConfirmForm ref="qcConfirmFormRef" @reset-from="resetFrom" />
    <!-- 维修确认 -->
    <maintenanceConfirmationForm ref="maintenanceConfirmationFormRef" @reset-from="resetFrom" />
    <!-- 操作记录详情 -->
    <maintenanceDrawer ref="maintenanceDrawerRef" />
  </base-modal>
</template>
