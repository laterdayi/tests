<script setup lang="tsx">
import type { BarSeriesOption } from 'echarts/charts';
import type { Arrayable } from '@vueuse/core';
import type { DataTableSortState } from 'naive-ui/es/data-table';
import { alarmActionType, resultOptions } from '@/views/ams/constants';
import { AlarmActionStatisticssApis } from '@/service/apis/ams/query-statistics/alarm-action-statistics';
import type {
  AlarmDetailListType,
  CustomType,
  QueryType,
  TableListType
} from '@/service/apis/ams/query-statistics/alarm-action-statistics';

import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';
import { AlarmCountStatisticsApis } from '@/service/apis/ams/query-statistics/alarm-count-statistics';
import { CommonApis } from '@/service/apis/common/common';
import type { ProductionLineLevelType } from '@/service/apis/common/type';
import type { ECOption } from '@/plugins/core/echarts';

import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { AlarmActionListType } from '@/service/apis/ams/system-setting';

const appStore = useAppStore();
// 横坐标
const abscissaList: CustomType[] = [
  { id: 1, name: i18nt('statisticsByDay') },
  { id: 2, name: i18nt('statisticsByWeek') },
  { id: 3, name: i18nt('statisticsByMonth') },
  { id: 4, name: i18nt('eqpName') }
];
const abscissaDetail: { [key in number]: string } = {
  1: i18nt('statisticsByDay'),
  2: i18nt('statisticsByWeek'),
  3: i18nt('statisticsByMonth'),
  4: i18nt('eqpName')
};
// 获取产线层级
const { data: productionLineLevelList, isLoading: isLoadingProductionLineLevel } = useAxiosGet<
  ProductionLineLevelType[]
>(CommonApis.getProductionLineLevelQueryApi, __, __, {
  immediate: true
});
// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};
// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(
  CommonApis.getEqpsByLayoutIdsApi,
  {},
  { paramsSerializer: useParamsSerializer() }
);
// 获取系统名称列表
const { isLoading: isLoadingSystemNameList, data: systemNameList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi,
  {},
  __,
  {
    immediate: true
  }
);
// 执行动作列表
const { execute: executegetAllActionsList } = useAxiosGet<AlarmActionListType[]>(
  AlarmSystemSettingApis.getAllActionsApi
);
const actionList = ref<AlarmActionListType[]>([]);
tryOnMounted(async () => {
  try {
    handleSearch();
    handleQueryEquipmentNumberList();
    const { data } = await executegetAllActionsList();
    actionList.value =
      data.value?.map(ele => {
        return {
          id: ele.id,
          name: alarmActionType[ele.id] ? i18nt(alarmActionType[ele.id]) : ''
        };
      }) || [];
  } catch (error) {
    actionList.value = [];
  }
});
// echarts配置
const chartRef = ref<ChartRefType | null>(null);
const xAxisData = ref<string[]>([]);
const seriesData = ref<{ value: number; alarmId: string | undefined }[]>([]);
// 查询数据
const { execute: executeGetNumberOfAlarmsData, isLoading: isLoadingAlarmData } = useAxiosGet<TableListType[]>(
  AlarmActionStatisticssApis.getAlarmActionSummaryApi
);
const handleSearch = async () => {
  try {
    expandedRowKeys.value = [];
    handleResetPageSize();
    const { data } = await executeGetNumberOfAlarmsData(__, {
      params: {
        ...useOmitNilRequestParams(formData.value),
        ...useFormatDateTimeParams(formData.value.timestamp),
        sortName: sortOrder.value.sortName,
        sort: sortOrder.value.sort
      },
      paramsSerializer: useParamsSerializer()
    });
    if (formData.value.type) {
      currentType.value = formData.value.type;
    }
    nextTick(() => {
      const actions: { [key in number]: () => void } = {
        1: () => (
          alarmDateRef.value?.setOption(alarmDateOptions(data.value ?? []), true),
          (tableData.value = data.value?.map(item => {
            return {
              ...item
            };
          }) as [])
        )
      };
      if (currentType.value) {
        actions[currentType.value] ? actions[currentType.value]() : filterData(data.value ?? []);
        const xAxisName = abscissaList.find(ele => ele.id === formData.value.type);
        chartRef.value?.setOption(
          {
            ...BAR_OPTION,
            yAxis: {
              name: i18nt('freq')
            },
            xAxis: {
              name: xAxisName ? xAxisName.name : '',
              type: 'category',
              data: xAxisData.value
            },
            dataZoom: useChartDataZoomOption(xAxisData.value.length),
            series: [
              {
                ...(BAR_OPTION.series as BarSeriesOption[])[0],
                type: 'bar',
                large: true,
                data: seriesData.value
              }
            ]
          },
          true
        );
        chartRef.value?.resize();
      }
    });
  } catch (error) {
    console.log(error);
  }
};
// 默认Options
const filterData = (data: TableListType[]) => {
  [tableData.value, xAxisData.value, seriesData.value] = [[], [], []];
  for (let i = 0; i < data.length; i++) {
    const item = data[i];
    tableData.value.push({
      alarmDesc: item.alarmDesc,
      count: item.count,
      alarmDetailList: item.alarmDetailList
    });
    xAxisData.value.push(item.alarmDesc);
    seriesData.value.push({ value: item.count, alarmId: item.alarmDesc });
  }
};
const alarmDateRef = ref<ChartRefType | null>(null);
// 按天统计 Options
const alarmDateOptions = (data: TableListType[]): ECOption => {
  const labels: number[] = [];
  const xAxis: string[] = [];
  const series: Arrayable<BarSeriesOption> = [];
  const color: string[] = [...CHART_COLOR_LIST];
  for (let i = 0; i < data.length; i++) {
    const item = data[i];
    xAxis.push(item.alarmDesc);
    for (let x = 0; x < item.alarmDetailList.length; x++) {
      const subItem = item.alarmDetailList[x];
      if (!labels.includes(subItem.alarmAction)) {
        labels.push(subItem.alarmAction);
      }
    }
  }
  // series处理
  for (let i = 0; i < labels.length; i++) {
    const item = alarmActionType[labels[i]] ? i18nt(alarmActionType[labels[i]]) : '';
    const list: (number | string)[] = [];
    for (let x = 0; x < data.length; x++) {
      const subItem = data[x];
      const dataItem = subItem.alarmDetailList.find(val => val.alarmAction === labels[i]);
      list.push((item ? dataItem?.actionCount : '-') ?? '-');
    }
    series.push({
      ...(BAR_OPTION.series as BarSeriesOption[])[0],
      stack: '总量',
      name: item,
      data: list
    });
  }
  // 颜色处理
  for (let i = 0; i < labels.length - CHART_COLOR_LIST.length; i++) {
    color.push(randomHex());
  }
  const xAxisName = abscissaList.find(ele => ele.id === formData.value.type);
  return {
    ...BAR_OPTION,
    dataZoom: useChartDataZoomOption(xAxis.length),
    tooltip: {
      ...BAR_OPTION.tooltip,
      ...useChartTooltipOverflow()
    },
    yAxis: {
      name: i18nt('freq'),
      minInterval: 1
    },
    color,
    xAxis: {
      type: 'category',
      data: xAxis,
      name: xAxisName ? xAxisName.name : ''
    },
    series
  };
};
// 表单配置
const { formData, formRef, resetField } = useForm<Nullable<QueryType>>({
  type: 1,
  treeIds: null,
  eqpName: null,
  alarmId: null,
  systemName: null,
  result: null,
  alarmAction: null,
  timestamp: useFormatDateRange()
});
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'type',
    formItemProps: { label: i18nt('abscissa') },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: abscissaList,
      clearable: false
    }
  },
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      multiple: true,
      checkable: true,
      cascade: true,
      keyField: 'id',
      labelField: 'name',
      options: productionLineLevelList.value,
      loading: isLoadingProductionLineLevel.value,
      onUpdateValue: (value: (string | number | null)[]) => {
        if (formData.value) formData.value.eqpName = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
              params: { layoutIds: value }
            })
          : handleQueryEquipmentNumberList();
      }
    }
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: equipmentNumberChildList.value,
      loading: isLoadingEquipmentNumberChildList.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: { label: i18nt('alarmCode') }
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      loading: isLoadingSystemNameList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'select',
    model: 'result',
    formItemProps: {
      label: i18nt('executeResult')
    },
    componentProps: {
      options: resultOptions,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'select',
    model: 'alarmAction',
    formItemProps: {
      label: i18nt('executeAction')
    },
    componentProps: {
      options: actionList.value,
      valueField: 'id',
      labelField: 'name'
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('occurredTime') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
]);

// 展开行
const expandedRowKeys = ref<string[]>([]);
const { pagination, sortOrder, handleResetPageSize, tableRef } = useTable<TableListType>(
  AlarmCountStatisticsApis.getAlarmListApi,
  {
    paramsSerializerQuery: true,
    refactorFormQueryParams: data => ({ ...data, ...useFormatDateTimeParams(data.timestamp) }),
    queryFormParams: formData,
    remote: false
  }
);
const handleSorterChange = (opt: DataTableSortState | null) => {
  if (opt) {
    pagination.value.page = 1;
    sortOrder.value.sortName = opt.order !== false ? opt.columnKey : __;
    sortOrder.value.sort = opt.order !== false ? opt.order : __;
    handleSearch();
  }
};
const handleExpand = (row: TableListType) => {
  row.expand = !row.expand;
  if (row.expand) {
    expandedRowKeys.value.push(row.alarmDesc);
  } else {
    const idx = expandedRowKeys.value.findIndex(item => item === row.alarmDesc);
    if (idx >= 0) {
      expandedRowKeys.value.splice(idx, 1);
    }
  }
};

// 表格配置
// 当前操作类型
const currentType = ref<number>();
const tableData = ref<TableListType[]>([]);
const createColumns = (currentType: Ref<number | undefined>): DataTableColumns<TableListType> => {
  const list: DataTableColumns<TableListType> = [
    useRenderTableIndex(pagination),
    {
      title: () => {
        return h('span', null, abscissaDetail[currentType.value ?? 1]);
      },
      key: 'alarmDesc',
      sorter: true
    },
    {
      title: i18nt('numberOfActions'),
      key: 'count',
      sorter: true,
      titleColSpan: 2,
      colSpan: () => 2,
      ellipsis: {
        tooltip: true
      },
      render: rowData => {
        return (
          <div style={{ cursor: 'pointer' }}>
            {rowData.alarmDetailList.length ? (
              <base-icon
                color={`${appStore.themePrimary}`}
                icon={rowData.expand ? 'i-carbon:chevron-down' : 'i-carbon:chevron-right'}
                onClick={() => handleExpand(rowData)}
              />
            ) : null}
            <span style={{ marginLeft: '10px' }}>{rowData.count}</span>
          </div>
        );
      }
    },
    {
      type: 'expand',
      expandable: () => true,
      renderExpand: rowData => {
        const columns = [
          {
            title: i18nt('executeAction'),
            key: 'alarmAction',
            render: (rowExpandaData: AlarmDetailListType) => {
              return alarmActionType[rowExpandaData.alarmAction]
                ? i18nt(alarmActionType[rowExpandaData.alarmAction])
                : '';
            }
          },
          { title: i18nt('numberOfActions'), key: 'actionCount' }
        ];
        return <base-table class="w-96%! ml-2%! mt mb" columns={columns} data={rowData.alarmDetailList || []} />;
      }
    }
  ];
  if (currentType.value === 1) {
    list.shift();
  }
  return list;
};
const tableColumns = computed(() => createColumns(currentType));

// 相关权限操作
const handleQueryPermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    search: handleSearch,
    reset: () => (
      (expandedRowKeys.value = []),
      handleResetPageSize(),
      resetField(),
      handleQueryEquipmentNumberList(),
      handleSearch()
    )
  };
  permissionAction[permission]?.();
};
// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = useDownloadFile(
  AlarmActionStatisticssApis.getAlarmActionSummaryApi
);
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    export: () => {
      executeExportData(
        {
          ...useOmitNilRequestParams({
            ...formData.value,
            sortName: sortOrder.value.sortName,
            sort: sortOrder.value.sort
          }),
          ...useFormatDateTimeParams(formData.value.timestamp)
        },
        { paramsSerializer: useParamsSerializer() }
      );
    }
  };
  permissionAction[permission]?.();
};
</script>

<template>
  <div id="alarm-count-statistics">
    <base-card>
      <base-form ref="formRef" v-model="formData" type="query" :schemas="queryFormSchemas">
        <template #header-action>
          <permission-button
            :loading-props="{ searchLoading: isLoadingAlarmData }"
            form
            @handle="handleQueryPermission"
          />
        </template>
      </base-form>
      <base-table
        ref="tableRef"
        v-model:expanded-row-keys="expandedRowKeys"
        class="ml-8%! w-86%!"
        :loading="isLoadingAlarmData"
        :columns="tableColumns"
        :data="tableData"
        :row-key="(rowData:TableListType) => rowData.alarmDesc"
        :render-expand-icon="() => null"
        :pagination="{
          ...pagination,
          prefix: () => `${i18nt('baseTable.total')} ${tableData.length} ${i18nt('baseTable.strip')}`
        }"
        @update:sorter="handleSorterChange"
      >
        <template #header>
          <permission-button :loading-props="{ exportLoading: isLoadingExportData }" @handle="handlePermission" />
        </template>
        <template #center>
          <div class="flex">
            <!-- 按天统计 -->
            <base-chart
              v-if="currentType === 1"
              ref="alarmDateRef"
              type="bar"
              :loading="isLoadingAlarmData"
              title="alarmActionStatistics"
            />
            <!-- 非按天统计 -->
            <base-chart v-else ref="chartRef" :loading="isLoadingAlarmData" title="alarmActionStatistics" type="bar" />
          </div>
        </template>
      </base-table>
    </base-card>
  </div>
</template>

<style lang="less" scoped>
:deep(.n-data-table-expand-trigger) {
  display: none;
}
</style>
