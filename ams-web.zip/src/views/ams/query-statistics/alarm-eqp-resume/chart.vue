<script setup lang="ts">
import type { CustomSeriesRenderItemAPI, CustomSeriesRenderItemReturn } from 'echarts/types/dist/shared.js';
import sliceInfoModal from './slice-info-modal.vue';
import type { SeriesDataType } from './alarm-eqp-resume.vue';
import echarts, { type ECOption } from '@/plugins/core/echarts';

interface PropsType {
  // 标题
  title?: string;
  // 标题位置
  xAxisData?: MixedArray;
  // 数据源
  seriesData: SeriesDataType[];
  // dataZoom
  dataZoom?: boolean;
  // 标题位置
  titleAlign?: 'left' | 'right' | 'center';
}

withDefaults(defineProps<PropsType>(), {
  title: undefined,
  seriesData: () => [],
  titleAlign: undefined,
  xAxisData: undefined
});

const renderItem = (params: CustomSeriesRenderItemParamsType, api: CustomSeriesRenderItemAPI) => {
  const categoryIndex = api.value(0);
  const start = api.coord([api.value(1), categoryIndex]);
  const end = api.coord([api.value(2), categoryIndex]);
  const height = (api?.size?.([0, 1]) as number[])[1] * 0.6;
  const rectShape = echarts.graphic.clipRectByRect(
    {
      x: start[0],
      y: start[1],
      width: end[0] - start[0],
      height
    },
    {
      x: params.coordSys.x as number,
      y: params.coordSys.y as number,
      width: params.coordSys.width as number,
      height: params.coordSys.height as number
    }
  );
  return (
    rectShape &&
    ({
      type: 'rect',
      transition: ['shape'],
      shape: rectShape,
      style: { ...api.style() }
    } as CustomSeriesRenderItemReturn)
  );
};

const initOptions: ECOption = {
  tooltip: {
    formatter: params => {
      if (!Array.isArray(params)) {
        const value = params.value as [number, number, number, { state: string; startTime: string; endTime: string }];
        const times = (value[2] - value[1]) / 1000;
        const day = Math.floor(times / (60 * 60 * 24));
        const hour = Math.floor(times / (60 * 60) - day * 24);
        const minutes = Math.floor(times / 60 - hour * 60 - day * 24 * 60);
        return `
        ${params?.marker} ${i18nt('equipmentState')}: ${value[3].state}<br/>
        ${i18nt('startTime')}: ${value[3].startTime}<br/>
        ${i18nt('endTime')}: ${value[3].endTime}<br/>
        ${i18nt('duration')}: ${day} ${i18nt('day')} ${hour} ${i18nt('hour')} ${minutes} ${i18nt('minute')}
      `;
      }
      return '';
    }
  },
  xAxis: {
    scale: true,
    min: data => data.min,
    max: data => data.max,
    axisLabel: {
      formatter: (val: number) => useFormatDate(val, 'MM-DD HH:mm:ss')
    },
    splitLine: { show: false }
  },
  grid: { height: 100, bottom: '40%' },
  yAxis: { show: false, data: [] },
  series: [
    {
      type: 'custom',
      renderItem,
      itemStyle: {
        opacity: 0.8
      },
      encode: { x: [1, 2], y: 0 },
      data: []
    }
  ]
};

const elRef = ref<ChartRefType | null>(null);

const showModal = ref<boolean>(false);

const openModal = () => {
  showModal.value = true;
};

const closeModal = () => {
  showModal.value = false;
};

onMounted(() => {
  const chart = elRef.value?.getInstance();
  chart?.on('click', params => {
    // 控制台打印数据
    console.log(params);
    openModal();
  });
});
</script>

<template>
  <div id="chart">
    <div v-if="title" :class="[`text-${titleAlign}`]" class="text-18px text-gray-500">{{ title }}</div>
    <base-chart ref="elRef" class="h-140px! w-full" :init-options="initOptions" :series-data="seriesData" />
    <sliceInfoModal :show-modal="showModal" @close-modal="closeModal" />
  </div>
</template>
