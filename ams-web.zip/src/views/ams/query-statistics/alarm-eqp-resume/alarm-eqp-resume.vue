<script lang="ts">
import Chart from './chart.vue';
import { CommonApis } from '@/service/apis/common/common';
import { EquipmentSliceViewApis } from '@/service/apis/report-manage/assembly-report/equipment-slice-view';

interface QueryType {
  eqpIds: string[];
  treeId: string[];
  timestamp: string[];
}

interface LegendListType {
  id?: string;
  color: string;
  name: string;
}

export interface SeriesDataType {
  name: string;
  value: (ValueClass | number | string)[];
  itemStyle: { normal: { color: string } };
}

export interface ValueClass {
  color: string;
  state: string;
  startTime: Date;
  endTime: Date;
  interval: string;
}

interface ChartListType {
  id?: string;
  eqP_ID: string;
  data: {
    id?: string;
    color: string;
    endTime: string;
    startTime: string;
    interval: string;
    state: string;
  }[];
  statisticsData: {
    id?: string;
    color: string;
    percent: number;
    state: string;
    totalInterval: string;
  }[];
  seriesData?: SeriesDataType[];
}

// 初始化查询表单
const initQueryFormSchemas = (
  executeGetEquipmentNumberChildList: ExecuteFunctionType<OptionsType[]>,
  handleQueryEquipmentNumberList: () => Promise<void>,
  formData: Ref<Nullable<QueryType>>,
  productLineList?: Ref<OptionsType[] | undefined>,
  isLoadingProductLineList?: Ref<boolean>,
  equipmentNumberChildList?: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberChildList?: Ref<boolean>
): FormSchemaType => [
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange' }
  },
  {
    type: 'tree-select',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: computed(() => ({
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      labelField: 'name',
      keyField: 'id',
      multiple: true,
      cascade: true,
      checkable: true,
      onUpdateValue: (value: (string | number | null)[]) => {
        if (formData.value) formData.value.eqpIds = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
              params: { layoutIds: value }
            })
          : handleQueryEquipmentNumberList();
      }
    }))
  },
  {
    type: 'select',
    model: 'eqpIds',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      multiple: true,
      options: equipmentNumberChildList?.value,
      loading: isLoadingEquipmentNumberChildList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  }
];
</script>

<script setup lang="ts">
// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelApi);
const handleQueryProductLineList = () => executeGetProductLineList(__, { params: { check: 2, isNormal: 1 } });

// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { error, data } = await executeGetEquipmentNumberList();
    !error.value && (equipmentNumberChildList.value = data.value);
  } catch (error) {
    console.log(error);
  }
};
// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(
  CommonApis.getEqpsByLayoutIdsApi,
  {},
  { paramsSerializer: useParamsSerializer() }
);

// 获取 legend 列表
const {
  data: legendList,
  isLoading: isLoadingLegendList,
  execute: executeGetLegendList
} = useAxiosGet<LegendListType[]>(EquipmentSliceViewApis.getLegendListApi);

// 表单参数
const { formData, formRef, resetField } = useForm<Nullable<QueryType>>({
  eqpIds: null,
  treeId: null,
  timestamp: useFormatDateRange()
});

const handleFilterData = (data: ChartListType[] | undefined) => {
  if (!data?.length) return;
  chartList.value = [];
  const result = data.map((item, index) => {
    item.seriesData = item.data.map(subItem => {
      return {
        name: item.eqP_ID,
        value: [
          index,
          new Date(subItem.startTime).getTime(),
          new Date(subItem.endTime).getTime(),
          subItem,
          item.eqP_ID
        ],
        itemStyle: {
          normal: {
            color: subItem.color
          }
        }
      };
    }) as SeriesDataType[];
    return item;
  });
  return result;
};

// 获取 chart 列表
const chartList = ref<ChartListType[]>();
const { isLoading: isLoadingChartList, execute: executeGetChartList } = useAxiosGet<ChartListType[]>(
  EquipmentSliceViewApis.getChartListApi
);

const handleQueryChart = async () => {
  try {
    const { data } = await executeGetChartList(__, {
      params: useOmitNilRequestParams({
        ...formData.value,
        ...useFormatDateTimeParams(formData.value.timestamp)
      }),
      paramsSerializer: useParamsSerializer()
    });
    chartList.value = handleFilterData(data.value);
  } catch (error) {
    console.log(error);
  }
};
const handleSearch = () => (executeGetLegendList(), handleQueryChart());

tryOnMounted(() => (handleQueryProductLineList(), handleQueryEquipmentNumberList(), handleSearch()));

// 查询表单模型
const queryFormSchemas = initQueryFormSchemas(
  executeGetEquipmentNumberChildList,
  handleQueryEquipmentNumberList,
  formData,
  productLineList,
  isLoadingProductLineList,
  equipmentNumberChildList,
  isLoadingEquipmentNumberChildList
);

// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    search: handleSearch,
    reset: () => (resetField(), handleSearch(), handleQueryEquipmentNumberList())
  };
  permissionAction[permission]?.();
};
</script>

<template>
  <div id="alarm-eqp-resume">
    <base-card>
      <base-form ref="formRef" v-model="formData" :schemas="queryFormSchemas">
        <template #header-action>
          <permission-button form @handle="handlePermission" />
        </template>
      </base-form>
    </base-card>
    <base-card class="my">
      <base-spin :show="isLoadingLegendList">
        <section class="flex flex-wrap">
          <div v-for="item in legendList" :key="item.id" class="flex-center my pr">
            <div class="h-10px mr rounded w-24px" :style="{ backgroundColor: item.color }" />
            <div class="text-12px">{{ item.name }}</div>
          </div>
        </section>
      </base-spin>
      <base-spin :show="isLoadingChartList" class="mt-20px">
        <div v-for="item in chartList" :key="item.id">
          <chart :title="item.eqP_ID" title-align="left" :series-data="toRaw(item.seriesData ?? [])" />
          <div class="flex-center">
            <div v-for="subItem in item.statisticsData" :key="subItem.id" class="flex-center ml text-14px">
              <div class="h-10px mr rounded w-24px" :style="{ backgroundColor: subItem.color }" />
              {{ subItem.state }},{{ $t('time') }}: {{ subItem.totalInterval }},{{ $t('percent') }}
              {{ subItem.percent }} %
            </div>
          </div>
        </div>
      </base-spin>
    </base-card>
  </div>
</template>
