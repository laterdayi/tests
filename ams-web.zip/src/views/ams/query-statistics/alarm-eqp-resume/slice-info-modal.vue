<script setup lang="ts">
import { renderSpan } from '../common';
import { AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';

interface BatchInfoType {
  id: number;
  historyId: number;
  lotId: string;
  recipeName: string;
  lotPortId: string;
  chamberId: string;
  productId: string;
  carrierId: string;
  batchId: string;
  reserved: string;
  step: string;
  state: string;
  createTime: string;
  alarmConsuming: string;
}

interface ExecuteActionType {
  id: number;
  alarmAction: number;
  alarmActionId: string;
  alarmID: string;
  eqpID: string;
  relatedPersons: string;
  remark: string;
  result: number;
  systemTime: string;
}

interface DetailDataType {
  actionInfo: ExecuteActionType[];
  alarmDesc: string;
  alarmEndTime: string;
  alarmID: string;
  alarmStartTime: string;
  eqpID: string;
  duration: string;
  alarmConsuming: string;
  treeId: string;
  createTime: string;
  isEqpAlarm: number;
  lotInfo: BatchInfoType[];
  systemName: string;
  closedBy?: string;
  txId?: string;
  closeReason?: string;
  isManualClose?: 0 | 1;
}

const props = defineProps({
  // 显示
  showModal: Boolean
});

const emit = defineEmits<{
  'close-modal': [];
}>();

function defaultValues(): Nullable<Omit<DetailDataType, 'actionInfo' | 'lotInfo' | 'systemName'>> {
  return {
    eqpID: null,
    alarmID: null,
    alarmDesc: null,
    alarmStartTime: null,
    alarmEndTime: null,
    isEqpAlarm: null,
    duration: null,
    alarmConsuming: null,
    treeId: null,
    createTime: null
  };
}

// 查看详情
const initDetailFormSchemas = (formData: DetailDataType): FormSchemaType => [
  {
    type: 'custom-form-item',
    model: 'eqpID',
    formItemProps: { label: i18nt('equipmentNumber') },
    render() {
      return renderSpan(formData.eqpID);
    }
  },
  {
    type: 'custom-form-item',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    render() {
      return renderSpan(formData.systemName);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmID',
    formItemProps: { label: i18nt('alarmCode') },
    render() {
      return renderSpan(formData.alarmID);
    }
  },
  {
    type: 'custom-form-item',
    model: 'txId',
    formItemProps: { label: i18nt('alarmID') },
    render() {
      return renderSpan(formData.txId);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmStartTime',
    formItemProps: { label: i18nt('alarmStartTime') },
    render() {
      return renderSpan(formData.alarmStartTime);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmEndTime',
    formItemProps: { label: i18nt('alarmEndTime') },
    render() {
      return renderSpan(formData.alarmEndTime);
    }
  },
  {
    type: 'switch',
    model: 'isEqpAlarm',
    formItemProps: { label: i18nt('machineSelfAlarm') },
    componentProps: { checkedValue: 1, uncheckedValue: 0 },
    formItemClass: 'w-min!'
  },
  {
    type: 'custom-form-item',
    model: 'alarmStatus',
    formItemProps: { label: i18nt('alarmState') },
    render() {
      return useRenderTableSingleTag(
        formData.alarmEndTime ? TagState.default : TagState.warning,
        formData.alarmEndTime ? i18nt('closed') : i18nt('alarming')
      );
    }
  },
  {
    type: 'custom-form-item',
    model: 'duration',
    formItemProps: { label: i18nt('duration') },
    render() {
      return renderSpan(formData.duration);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmConsuming',
    formItemProps: { label: i18nt('consuming') },
    render() {
      return renderSpan(formData.alarmConsuming);
    }
  },
  {
    type: 'custom-form-item',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.treeId);
    }
  },

  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('createTime') },
    render() {
      return renderSpan(formData.createTime);
    }
  },
  formData.isManualClose
    ? {
        type: 'custom-form-item',
        model: 'alarmDesc',
        formItemProps: { label: i18nt('closePerson') },
        render() {
          return renderSpan(formData.closedBy);
        }
      }
    : __,
  formData.isManualClose
    ? {
        type: 'custom-form-item',
        model: 'alarmDesc',
        formItemProps: { label: i18nt('closeReason') },
        render() {
          return renderSpan(formData.closeReason);
        }
      }
    : __,
  {
    type: 'custom-form-item',
    model: 'alarmDesc',
    formItemProps: { label: i18nt('alarmDescription') },
    formItemClass: 'col-span-2!',
    render() {
      return renderSpan(formData.alarmDesc);
    }
  }
];
const createColumnsBatch = (): DataTableColumns<BatchInfoType> => [
  { key: 'lotId', title: i18nt('lotNumebr') },
  { key: 'lotPortId', title: 'Port' },
  { key: 'chamberId', title: 'Chamber' },
  { key: 'productId', title: 'Product' },
  { key: 'carrierId', title: 'Carrier ID' },
  { key: 'batchId', title: 'Batch ID' },
  { key: 'reserved', title: 'Reserved' },
  { key: 'state', title: 'State' }
];
const createColumnsExecuteAction = (): DataTableColumns<ExecuteActionType> => [
  { key: 'eqpID', title: i18nt('equipmentNumber') },
  { key: 'alarmID', title: i18nt('alarmCode') },
  { key: 'systemTime', title: i18nt('occurredTime'), width: TABLE_WIDTH_DATETIME },
  { key: 'alarmAction', title: i18nt('executeAction') },
  { key: 'alarmActionConsuming', title: i18nt('consuming') },
  { key: 'relatedPersons', title: i18nt('relatedInformation') },
  { key: 'remark', title: i18nt('remark') }
];

const {
  data: historyRecordData,
  isLoading: isLoadingHistoryRecordData,
  execute: executeHistoryRecordData
} = useAxiosGet<DetailDataType>(AlarmHistoryRecordApis.getAlarmHistoryDetailApi, undefined, undefined, {
  immediate: false
});

const infoForm = ref<Nullable<Omit<DetailDataType, 'actionInfo' | 'lotInfo' | 'systemName'>>>(defaultValues());

const closeModal = () => {
  emit('close-modal');
};

const handleCloseModal = () => {
  closeModal();
  infoForm.value = defaultValues();
};

watch(
  () => props.showModal,
  async (newValue, oldValue, onCleanup) => {
    if (newValue) {
      const { cancel } = await executeHistoryRecordData();
      onCleanup(cancel);
    }
  }
);

const detailFormSchemas = computed(() => initDetailFormSchemas(infoForm.value as DetailDataType));
const tableColumnsBatch = createColumnsBatch();
const tableColumnsExecuteAction = createColumnsExecuteAction();
</script>

<template>
  <base-modal
    :show="showModal"
    :title="$t('viewDetail')"
    :positive-text="undefined"
    @close="handleCloseModal"
    @negative-click="handleCloseModal"
  >
    <base-form v-model="infoForm" :schemas="detailFormSchemas" layout="dialog" disabled />
    <div class="card-title">{{ $t('batchDetail') }}</div>
    <base-table
      :max-height="isLoadingHistoryRecordData ? 60 : 400"
      :loading="isLoadingHistoryRecordData"
      :columns="tableColumnsBatch"
      :data="historyRecordData?.lotInfo"
    />
    <div class="card-title mt">{{ $t('executeActionDetail') }}</div>
    <base-table
      :max-height="isLoadingHistoryRecordData ? 60 : 400"
      :loading="isLoadingHistoryRecordData"
      :columns="tableColumnsExecuteAction"
      :data="historyRecordData?.actionInfo"
    />
  </base-modal>
</template>
