export type CustomType = {
  id: number;
  name: string;
};

export const abscissaList: CustomType[] = [
  { id: 1, name: i18nt('eqpType') },
  { id: 2, name: i18nt('alarmCode') },
  { id: 4, name: i18nt('systemName') },
  { id: 5, name: i18nt('alarmLevel') },
  { id: 6, name: i18nt('eqpName') },
  { id: 7, name: i18nt('product') },
  { id: 8, name: i18nt('alarmDate') },
  { id: 9, name: i18nt('statisticsByWeek') },
  { id: 10, name: i18nt('statisticsByMonth') }
];
