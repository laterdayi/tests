<script lang="tsx">
import type { BarSeriesOption } from 'echarts/charts';
import type { Arrayable } from '@vueuse/core';
import type { DataTableSortState } from 'naive-ui/es/data-table';
import { abscissaList } from './constants';
import type { CustomType } from './constants';
import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';
import { AlarmCountStatisticsApis } from '@/service/apis/ams/query-statistics/alarm-count-statistics';
import { CommonApis } from '@/service/apis/common/common';
import type { ProductionLineLevelType } from '@/service/apis/common/type';
import type { ECOption } from '@/plugins/core/echarts';
import { pageSizeOption } from '@/layout/aside/layout-setting/constants';
import { useChart } from '@/components/base-chart/use-chart/use-chart';
import { alarmCategoryList } from '@/views/ams/constants';

interface QueryType {
  type: number;
  treeIds: string[];
  eqpName: string[];
  alarmId: string;
  level: string;
  alarmCategory: number;
  description: string;
  systemName: string;
  timestamp: string[];
}

interface TableListType {
  alarmDesc: string;
  count: number;
  alarmDetailList: {
    alarmCount: number;
    systemName?: string;
    alarmId: string;
    alarmDec: string;
  }[];
  remark: string;
  expand?: boolean;
  systemName?: string;
}

// 初始化查询表单
const initQueryFormSchemas = (
  executeGetEquipmentNumberChildList: ExecuteFunctionType<OptionsType[]>,
  handleQueryEquipmentNumberList: () => Promise<void>,
  productionLineLevelList: ProductionLineLevelType[] | undefined,
  isLoadingProductionLineLevel: boolean,
  abscissaList: CustomType[],
  alarmLevelList: OptionsType[] | undefined,
  isLoadingAlarmLevel: boolean,
  equipmentNumberChildList?: OptionsType[],
  isLoadingEquipmentNumberChildList?: boolean,
  formData?: Nullable<QueryType>,
  systemNameList?: Ref<OptionsType[] | undefined>,
  isLoadingSystemNameList?: Ref<boolean>
): FormSchemaType => [
  {
    type: 'select',
    model: 'type',
    formItemProps: { label: i18nt('abscissa') },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: abscissaList,
      clearable: false
    }
  },
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      multiple: true,
      checkable: true,
      cascade: true,
      keyField: 'id',
      labelField: 'name',
      options: productionLineLevelList,
      loading: isLoadingProductionLineLevel,
      onUpdateValue: (value: (string | number | null)[]) => {
        if (formData) formData.eqpName = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
              params: { layoutIds: value }
            })
          : handleQueryEquipmentNumberList();
      }
    }
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: equipmentNumberChildList,
      loading: isLoadingEquipmentNumberChildList,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: { label: i18nt('alarmCode') }
  },
  {
    type: 'select',
    model: 'level',
    formItemProps: { label: i18nt('alarmLevel') },
    componentProps: {
      options: alarmLevelList,
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingAlarmLevel
    }
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      loading: isLoadingSystemNameList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'select',
    model: 'alarmCategory',
    formItemProps: { label: i18nt('alarmCategory') },
    componentProps: computed(() => ({
      loading: false,
      options: alarmCategoryList
    }))
  },
  {
    type: 'input',
    model: 'description',
    formItemProps: { label: i18nt('alarmDescription') }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
];
</script>

<script setup lang="tsx">
const appStore = useAppStore();

// 获取产线层级
const { data: productionLineLevelList, isLoading: isLoadingProductionLineLevel } = useAxiosGet<
  ProductionLineLevelType[]
>(CommonApis.getProductionLineLevelQueryApi, __, __, {
  immediate: true
});
// 获取系统名称列表
const { isLoading: isLoadingSystemNameList, data: systemNameList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi,
  {},
  __,
  {
    immediate: true
  }
);

// 获取报警级别
const { data: alarmLevelList, isLoading: isLoadingAlarmLevel } = useAxiosGet<OptionsType[]>(
  AlarmCountStatisticsApis.getAlarmLevelListApi,
  undefined,
  undefined,
  {
    immediate: true
  }
);

// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};

// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(CommonApis.getEqpsByLayoutIdsApi, {}, { paramsSerializer: useParamsSerializer() });

// 查询表单模型
const queryFormSchemas = computed(() =>
  initQueryFormSchemas(
    executeGetEquipmentNumberChildList,
    handleQueryEquipmentNumberList,
    productionLineLevelList.value,
    isLoadingProductionLineLevel.value,
    abscissaList,
    alarmLevelList.value,
    isLoadingAlarmLevel.value,
    equipmentNumberChildList.value,
    isLoadingEquipmentNumberChildList.value,
    formData.value,
    systemNameList,
    isLoadingSystemNameList
  )
);
// 表单参数
const { formData, formRef, resetField } = useForm<Nullable<QueryType>>({
  type: 6,
  treeIds: null,
  eqpName: null,
  alarmId: null,
  level: null,
  description: null,
  systemName: null,
  alarmCategory: null,
  timestamp: useFormatDateRange()
});

const tableData = ref<TableListType[]>([]);
const xAxisData = ref<string[]>([]);
const seriesData = ref<{ value: number; alarmId: string | undefined }[]>([]);

// 展开行
const expandedRowKeys = ref<string[]>([]);

const { pagination, sortOrder, handleResetPageSize, tableRef } = useTable<TableListType>(
  AlarmCountStatisticsApis.getAlarmListApi,
  {
    paramsSerializerQuery: true,
    refactorFormQueryParams: data => ({
      ...data,
      ...useFormatDateTimeParams(data.timestamp)
    }),
    queryFormParams: formData,
    remote: false
  }
);
const handleSorterChange = (opt: DataTableSortState | null) => {
  if (opt) {
    pagination.value.page = 1;
    sortOrder.value.sortName = opt.order !== false ? opt.columnKey : __;
    sortOrder.value.sort = opt.order !== false ? opt.order : __;
    handleSearch();
  }
};

const handleExpand = (row: TableListType) => {
  row.expand = !row.expand;
  if (row.expand) {
    expandedRowKeys.value.push(row.alarmDesc);
  } else {
    const idx = expandedRowKeys.value.findIndex(item => item === row.alarmDesc);
    if (idx >= 0) {
      expandedRowKeys.value.splice(idx, 1);
    }
  }
};

const createColumns = (currentType: Ref<number | undefined>): DataTableColumns<TableListType> => {
  const list: DataTableColumns<TableListType> = [
    useRenderTableIndex(pagination),
    {
      title: () => {
        const titles: { [key in number]: string } = {
          1: i18nt('equipmentType'),
          2: i18nt('alarmCode'),
          4: i18nt('systemName'),
          5: i18nt('alarmLevel'),
          6: i18nt('equipmentNumber'),
          7: i18nt('product'),
          8: i18nt('alarmDate'),
          9: i18nt('statisticsByWeek'),
          10: i18nt('statisticsByMonth')
        };
        return h('span', null, titles[currentType.value ?? 6]);
      },
      key: 'alarmDesc',
      sorter: true
    },
    {
      title: i18nt('alarmCount'),
      key: 'count',
      sorter: true,
      titleColSpan: 2,
      colSpan: () => 2,
      ellipsis: {
        tooltip: true
      },
      render: rowData => {
        return (
          <div style={{ cursor: 'pointer' }}>
            {rowData.alarmDetailList.length ? (
              <base-icon
                color={`${appStore.themePrimary}`}
                icon={rowData.expand ? 'i-carbon:chevron-down' : 'i-carbon:chevron-right'}
                onClick={() => handleExpand(rowData)}
              />
            ) : null}
            <span style={{ marginLeft: '10px' }}>{rowData.count}</span>
          </div>
        );
      }
    },
    {
      type: 'expand',
      expandable: () => true,
      renderExpand: rowData => {
        const columns =
          currentType.value === 4
            ? [
                { title: i18nt('alarmCode'), key: 'alarmId' },
                { title: i18nt('alarmNumber'), key: 'alarmCount' },
                { title: i18nt('alarmDescription'), key: 'alarmDec' }
              ]
            : [
                { title: i18nt('alarmCode'), key: 'alarmId' },
                { title: i18nt('systemName'), key: 'systemName' },
                { title: i18nt('alarmNumber'), key: 'alarmCount' },
                { title: i18nt('alarmDescription'), key: 'alarmDec' }
              ];
        const paginationReactive = reactive({
          page: 1,
          pageSize: appStore.pageSize,
          itemCount: rowData.alarmDetailList.length,
          showSizePicker: true,
          showQuickJumper: true,
          displayOrder: ['size-picker', 'pages', 'quick-jumper'],
          prefix: () =>
            `${i18nt('baseTable.total')} ${rowData.alarmDetailList.length || 0} ${i18nt('baseTable.strip')}`,
          pageSizes: pageSizeOption.map((item: { label: string; value: number }) => {
            return {
              label: item.label,
              value: item.value
            };
          }),
          onChange: (page: number) => {
            paginationReactive.page = page;
          },
          onUpdatePageSize: (pageSize: number) => {
            paginationReactive.pageSize = pageSize;
            paginationReactive.page = 1;
          }
        });
        return (
          <base-table
            class="w-96%! ml-2%! mt "
            columns={columns}
            data={rowData.alarmDetailList || []}
            pagination={paginationReactive}
          />
        );
      }
    }
  ];

  if (currentType.value === 2) {
    list.push({ title: i18nt('alarmDescription'), key: 'remark' });
    list.splice(2, 0, { title: i18nt('systemName'), key: 'systemName' });
  }
  if (currentType.value === 8) {
    list.shift();
  }
  return list;
};

const tableColumns = computed(() => createColumns(currentType));
// 当前操作类型
const currentType = ref<number>();
// 获取数据
const { execute: executeGetNumberOfAlarmsData, isLoading: isLoadingAlarmData } = useAxiosGet<TableListType[]>(
  AlarmCountStatisticsApis.getAlarmListApi
);
const handleSearch = async () => {
  try {
    expandedRowKeys.value = [];
    handleResetPageSize();
    const { data } = await executeGetNumberOfAlarmsData(__, {
      params: {
        ...useOmitNilRequestParams(formData.value),
        ...useFormatDateTimeParams(formData.value.timestamp),
        sortName: sortOrder.value.sortName,
        sort: sortOrder.value.sort
      },
      paramsSerializer: useParamsSerializer()
    });
    if (formData.value.type) {
      currentType.value = formData.value.type;
    }
    nextTick(() => {
      resize();
      if (currentType.value === 8) {
        setOption(alarmDateOptions(data.value ?? []), true);
        tableData.value = data.value?.map(item => {
          return {
            ...item
          };
        }) as [];
      } else {
        filterData(data.value ?? []);
        const xAxisName = abscissaList.find(ele => ele.id === formData.value.type);
        setOption(
          {
            ...BAR_OPTION,
            yAxis: {
              name: i18nt('freq')
            },
            xAxis: {
              name: xAxisName ? xAxisName.name : '',
              type: 'category',
              data: xAxisData.value
            },
            dataZoom: useChartDataZoomOption(xAxisData.value.length),
            series: [
              {
                ...(BAR_OPTION.series as BarSeriesOption[])[0],
                type: 'bar',
                large: true,
                data: seriesData.value
              }
            ]
          },
          true
        );
      }
    });
  } catch (error) {
    console.log(error);
  }
};
// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = useDownloadFile(
  AlarmCountStatisticsApis.getAlarmListApi
);
// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    export: () => {
      executeExportData(
        {
          ...useOmitNilRequestParams({
            ...formData.value,
            sortName: sortOrder.value.sortName,
            sort: sortOrder.value.sort
          }),
          ...useFormatDateTimeParams(formData.value.timestamp)
        },
        { paramsSerializer: useParamsSerializer() }
      );
    }
  };
  permissionAction[permission]?.();
};

// 默认Options
const filterData = (data: TableListType[]) => {
  [tableData.value, xAxisData.value, seriesData.value] = [[], [], []];
  for (let i = 0; i < data.length; i++) {
    const item = data[i];
    tableData.value.push({
      alarmDesc: item.alarmDesc,
      count: item.count,
      alarmDetailList: item.alarmDetailList,
      remark: item.remark,
      systemName: item.systemName || undefined
    });
    xAxisData.value.push(item.alarmDesc);
    seriesData.value.push({ value: item.count, alarmId: item.alarmDesc });
  }
};

// 报警日期 Options
const alarmDateOptions = (data: TableListType[]): ECOption => {
  const labels: string[] = [];
  const xAxis: string[] = [];
  const series: Arrayable<BarSeriesOption> = [];
  const color: string[] = [...CHART_COLOR_LIST];
  for (let i = 0; i < data.length; i++) {
    const item = data[i];
    xAxis.push(item.alarmDesc);
    for (let x = 0; x < item.alarmDetailList.length; x++) {
      const subItem = item.alarmDetailList[x];
      if (!labels.includes(subItem.alarmId)) {
        labels.push(subItem.alarmId);
      }
    }
  }
  for (let i = 0; i < labels.length; i++) {
    const item = labels[i];
    const list: (number | string)[] = [];
    for (let x = 0; x < data.length; x++) {
      const subItem = data[x];
      const dataItem = subItem.alarmDetailList.find(val => val.alarmId === item);
      list.push((item ? dataItem?.alarmCount : '-') ?? '-');
    }
    series.push({
      ...(BAR_OPTION.series as BarSeriesOption[])[0],
      stack: '总量',
      name: item,
      data: list
    });
  }

  for (let i = 0; i < labels.length - CHART_COLOR_LIST.length; i++) {
    color.push(randomHex());
  }
  const xAxisName = abscissaList.find(ele => ele.id === formData.value.type);
  return {
    ...BAR_OPTION,
    dataZoom: useChartDataZoomOption(xAxis.length),
    tooltip: {
      ...BAR_OPTION.tooltip,
      ...useChartTooltipOverflow()
    },
    yAxis: {
      name: i18nt('freq')
    },
    color,
    xAxis: {
      type: 'category',
      data: xAxis,
      name: xAxisName ? xAxisName.name : ''
    },
    series
  };
};

const { elRef: chartRef, setOption, resize } = useChart();

// 相关权限操作
const handleQueryPermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    search: () => {
      handleSearch();
    },
    reset: () => (
      (expandedRowKeys.value = []),
      handleResetPageSize(),
      resetField(),
      handleQueryEquipmentNumberList(),
      handleSearch()
    )
  };
  permissionAction[permission]?.();
};
tryOnMounted(() => {
  handleSearch();
  handleQueryEquipmentNumberList();
});
</script>

<template>
  <div id="alarm-count-statistics">
    <base-card>
      <base-form ref="formRef" v-model="formData" type="query" :schemas="queryFormSchemas">
        <template #header-action>
          <permission-button
            :loading-props="{ searchLoading: isLoadingAlarmData }"
            form
            @handle="handleQueryPermission"
          />
        </template>
      </base-form>
      <!-- 默认 -->
      <base-table
        ref="tableRef"
        v-model:expanded-row-keys="expandedRowKeys"
        class="ml-8%! w-86%!"
        :loading="isLoadingAlarmData"
        :columns="tableColumns"
        :data="tableData"
        :row-key="(rowData:TableListType) => currentType === 2 ? rowData.alarmDesc + rowData.systemName : rowData.alarmDesc"
        :render-expand-icon="() => null"
        :pagination="{
          ...pagination,
          prefix: () => `${i18nt('baseTable.total')} ${tableData.length} ${i18nt('baseTable.strip')}`
        }"
        @update:sorter="handleSorterChange"
      >
        <template #header>
          <permission-button :loading-props="{ exportLoading: isLoadingExportData }" @handle="handlePermission" />
        </template>
        <template #center>
          <div class="flex">
            <div ref="chartRef" class="h-300px w-full" />
          </div>
        </template>
      </base-table>
    </base-card>
  </div>
</template>

<style lang="less" scoped>
:deep(.n-data-table-expand-trigger) {
  display: none;
}
</style>
