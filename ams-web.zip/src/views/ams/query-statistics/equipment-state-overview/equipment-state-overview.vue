<script setup lang="tsx">
import alarmDetails from './components/alarm-details.vue';
import runDetails from './components/run-details.vue';
import { EquipmentStateOverviewApis } from '@/service/apis/ams/query-statistics/equipment-state-overview';
import type { GetEqpStateListType, TypeDemoType } from '@/service/apis/ams/query-statistics/equipment-state-overview';

const appStore = useAppStore();
const { local } = storeToRefs(appStore);
const alarmDetailsRef = ref();
const runDetailsRef = ref();
// 获取全部数据
const {
  data: eqpStateList,
  isLoading: isLoadingEqpStateList,
  execute: getEqpStateList
} = useAxiosGet<GetEqpStateListType>(EquipmentStateOverviewApis.getEqpStateListApi);
const getEqpStateListDetail = async () => {
  await getEqpStateList({
    params: { state: stateIndex.value, language: local.value === 'zh-CN' ? 0 : 1 }
  });
};
// 选中
const stateIndex = ref<number>(2);
tryOnMounted(async () => {
  try {
    await getEqpStateList({ params: { state: stateIndex.value, language: local.value === 'zh-CN' ? 0 : 1 } });
    resume();
  } catch (error) {
    console.log(error);
  }
});
// 顶部选择事件
const typeClick = async (index: number) => {
  pause();
  stateIndex.value = stateIndex.value === index ? 2 : index;
  await getEqpStateList({ params: { state: stateIndex.value, language: local.value === 'zh-CN' ? 0 : 1 } });
  resume();
};
// 公共demo
const typeDemo = (props: TypeDemoType) => {
  return (
    <div
      class={props.class}
      style={{
        border:
          props.type === 1 && stateIndex.value === props.state
            ? `2px solid ${props.color}`
            : `1px solid ${props.color}`,
        backgroundColor: `${props.background}`,
        cursor: 'pointer'
      }}
    >
      <div class="list-title">
        <div class="trapezoid" style={{ borderTop: `30px solid ${props.color}` }} />
        <base-ellipsis class="title-left">{props.title}</base-ellipsis>
        <div class="title-right">{props.state === 1 ? i18nt('alarm') : i18nt('run')}</div>
      </div>
      {props.type === 1 ? (
        <div class="list-text">
          <div class="text-left">{props.total}</div>
          <div class="text-right">{i18nt('platform')}</div>
          {stateIndex.value === props.state ? (
            <base-icon class="text-icon" color={props.color} icon="i-carbon:touch-1" size={20} />
          ) : (
            ''
          )}
        </div>
      ) : (
        <div class="list-time">
          <base-icon class="time-left" color="#c2c2c6" icon="i-carbon:time" />
          <div class="time-right">
            <div class="time-top">{props.duration}</div>
            <div class="time-bottom">{i18nt('stateDuration')}</div>
          </div>
        </div>
      )}
    </div>
  );
};
// 底部详情
const openModal = (eqpId: string, state: number) => {
  // if (state === 0) return;
  if (state === 0) {
    runDetailsRef?.value?.handleOpenModal(eqpId, state, local.value === 'zh-CN' ? 0 : 1);
  } else {
    alarmDetailsRef?.value?.handleOpenModal(eqpId, state, local.value === 'zh-CN' ? 0 : 1);
  }
};
// 定时刷新1分钟
const { pause, resume } = useIntervalFn(getEqpStateListDetail, 60000);
onBeforeUnmount(() => {
  pause();
});
</script>

<template>
  <base-card id="equipment-state-overview">
    <!-- 顶部选择 -->
    <div class="type-top">
      <typeDemo
        class="type-list"
        :type="1"
        cursor="pointer"
        :state="0"
        :total="eqpStateList?.runningNumber"
        color="#19be6b"
        background="#ddf5e9"
        @click="typeClick(0)"
      />
      <typeDemo
        class="type-list"
        :type="1"
        cursor="pointer"
        :state="1"
        :total="eqpStateList?.alarmNumber"
        color="#ED4014"
        background="#FCE3DC"
        @click="typeClick(1)"
      />
    </div>
    <!-- 底部列表 -->
    <base-space :wrap-item="false" class="type-bottom">
      <base-spin :show="isLoadingEqpStateList">
        <div v-for="item in eqpStateList?.list" :key="item.id" class="type-content">
          <div class="type-ul-title">{{ item.levelName }} ({{ item.levelCount }})</div>
          <div class="type-ul">
            <div v-for="dataItem in item.datas" :key="dataItem.eqpId">
              <typeDemo
                class="type-list"
                :type="2"
                :state="dataItem.state"
                :duration="dataItem.duration"
                :title="dataItem.eqpId"
                :cursor="dataItem.state === 1 ? 'pointer' : 'default'"
                :color="dataItem.state === 1 ? '#ED4014' : '#19be6b'"
                :background="dataItem.state === 1 ? '#FCE3DC' : '#ddf5e9'"
                @click="openModal(dataItem.eqpId, dataItem.state)"
              />
            </div>
          </div>
        </div>
      </base-spin>
    </base-space>
    <alarmDetails ref="alarmDetailsRef" />
    <runDetails ref="runDetailsRef" />
  </base-card>
</template>

<style lang="less">
#equipment-state-overview {
  .type-list {
    padding-left: 10px;
    width: 158px;
    height: 88px;
    margin: 0 16px 16px 0;
    border-radius: 5px;
    .list-title {
      height: 30px;
      line-height: 30px;
      position: relative;
      display: flex;
      align-items: center;

      .title-left {
        color: #000000;
        width: 60px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 12px;
        font-weight: 500;
      }
      .title-right {
        position: absolute;
        right: 0px;
        top: 0px;
        color: #ffffff;
        width: 45px;
        line-height: 30px;
      }
      .trapezoid {
        position: absolute;
        right: 0px;
        top: 0px;
        border-left: 30px solid transparent;
        border-right: 0px solid transparent;
        height: 0;
        width: 60px;
      }
    }
    .list-text {
      margin-top: 25px;
      height: 35px;
      line-height: 35px;
      display: flex;
      align-items: center;
      position: relative;
      color: #c2c2c6;
      .text-left {
        margin-right: 8px;
        font-size: 20px;
        color: #5f636f;
      }
      .text-right {
        color: #8d8d96;
      }
      .text-icon {
        position: absolute;
        top: 8px;
        right: 5px;
      }
    }
    .list-time {
      display: flex;
      margin-top: 10px;
      .time-right {
        margin-left: 5px;
        .time-top {
          font-size: 14px;
          font-weight: bold;
          height: 20px;
          line-height: 20px;
        }
        .time-bottom {
          font-size: 10px;
          height: 20px;
          color: #8d8d96;
          line-height: 20px;
        }
      }
    }
  }
  .time-list {
    width: 168px;
    .list-title {
      .title-left {
        width: 80px;
      }
    }
  }
}
</style>

<style lang="less" scoped>
.type-top {
  display: flex;
  align-items: center;
}
.type-bottom {
  height: calc(100vh - 246px);
  overflow-y: scroll;
  .type-content {
    width: calc(100vw - 290px);
    .type-ul-title {
      height: 40px;
      line-height: 40px;
      // font-size: 14px;
      color: #303133;
      font-size: 20px;
      font-weight: 700;
    }
    .type-ul {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
    }
  }
}
</style>
