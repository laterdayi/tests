<script setup lang="tsx">
import { actionCategoryObj, alarmActionType } from '@/views/ams/constants';
import type {
  ActionInfoType,
  DetailFormType,
  EchartsType,
  LotInfoType,
  OperateRecordType
} from '@/service/apis/ams/query-statistics/equipment-alarm-history';
import { EquipmentStateOverviewApis } from '@/service/apis/ams/query-statistics/equipment-state-overview';

// 弹窗开启
const modalIsShow = ref(false);
// 获取详情
const { isLoading: alarmSliceDetailLoading, execute: getAlarmSliceDetail } = useAxiosGet<DetailFormType>(
  EquipmentStateOverviewApis.getAlarmStateDetailApi
);
//  打开弹窗
const handleOpenModal = async (eqpId: EchartsType, state: number, language: number) => {
  resetQueryField();
  lotInfoList.value = [];
  actionInfoList.value = [];
  try {
    const { data } = await getAlarmSliceDetail(__, {
      params: {
        eqpName: eqpId,
        state,
        language
      }
    });
    if (!data.value) return;
    formData.value = data.value;
    lotInfoList.value = data.value.lotInfo;
    actionInfoList.value = data.value.actionInfo;
    operateRecordList.value = data.value.additionalInfo;
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
const renderSpan = (value?: string | number, style?: CSSProperties) => {
  return h('span', { style: { 'font-weight': 'bold', ...style } }, value);
};
// 表单
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<DetailFormType>>({
  systemName: null,
  treeId: null,
  txId: null,
  id: null,
  alarmConsuming: null,
  alarmDesc: null,
  alarmEndTime: null,
  alarmID: null,
  alarmStartTime: null,
  closeReason: null,
  closedBy: null,
  createTime: null,
  duration: null,
  eqpID: null,
  isEqpAlarm: null,
  isManualClose: null,
  actionInfo: [],
  lotInfo: [],
  additionalInfo: []
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    model: 'eqpID',
    formItemProps: { label: i18nt('eqpName') },
    render() {
      return renderSpan(formData.value.eqpID || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    render() {
      return renderSpan(formData.value.systemName || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmID',
    formItemProps: { label: i18nt('alarmCode') },
    render() {
      return renderSpan(formData.value.alarmID || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'txId',
    formItemProps: { label: i18nt('alarmID') },
    render() {
      return renderSpan(formData.value.txId || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmStartTime',
    formItemProps: { label: i18nt('alarmStartTime') },
    render() {
      return renderSpan(formData.value.alarmStartTime || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmEndTime',
    formItemProps: { label: i18nt('alarmEndTime') },
    render() {
      return renderSpan(formData.value.alarmEndTime || '');
    }
  },
  {
    type: 'switch',
    model: 'isEqpAlarm',
    formItemProps: { label: i18nt('machineSelfAlarm') },
    componentProps: { checkedValue: 1, uncheckedValue: 0 },
    formItemClass: 'w-min!'
  },
  {
    type: 'custom-form-item',
    model: 'duration ',
    formItemProps: { label: i18nt('duration') },
    render() {
      return renderSpan(formData.value.duration || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmConsuming',
    formItemProps: { label: i18nt('consuming') },
    render() {
      return renderSpan(formData.value.alarmConsuming || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.value.treeId || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('createTime') },
    render() {
      return renderSpan(formData.value.createTime || '');
    }
  },
  formData.value.closedBy
    ? {
        type: 'custom-form-item',
        model: 'closedBy',
        formItemProps: { label: i18nt('closePerson') },
        render() {
          return renderSpan(formData.value.closedBy || '');
        }
      }
    : __,
  formData.value.closeReason
    ? {
        type: 'custom-form-item',
        model: 'closeReason',
        formItemProps: { label: i18nt('closeReason') },
        render() {
          return renderSpan(formData.value.closeReason || '');
        }
      }
    : __,
  {
    type: 'custom-form-item',
    model: 'alarmDesc',
    formItemProps: { label: i18nt('alarmDescription') },
    render() {
      return renderSpan(formData.value.alarmDesc || '');
    }
  }
]);
// 批次明细
const lotInfoList = ref<LotInfoType[]>();
const lotInfoColumns: DataTableColumns<LotInfoType> = [
  { title: i18nt('lotNumebr'), key: 'lotId' },
  { title: 'Port', key: 'lotPortId' },
  { title: 'Chamber', key: 'chamberId' },
  { title: 'Product', key: 'productId' },
  { title: 'Carrier ID', key: 'carrierId' },
  { title: 'Batch ID', key: 'batchId' },
  { title: 'Reserved', key: 'reserved' },
  { title: 'State', key: 'state' }
];
// 执行结果处理
const executeResultType: {
  [key: number]: {
    type: string;
    name: string;
  };
} = {
  0: {
    type: TagState.warning,
    name: i18nt('processing')
  },
  1: {
    type: TagState.success,
    name: i18nt('success')
  },
  2: {
    type: TagState.primary,
    name: i18nt('failed')
  }
};
// 执行动作明细
const actionInfoList = ref<ActionInfoType[]>();
const actionInfoColumns: DataTableColumns<ActionInfoType> = [
  { title: i18nt('eqpName'), key: 'eqpID' },
  { title: i18nt('alarmCode'), key: 'alarmID' },
  { title: i18nt('occurredTime'), key: 'systemTime', width: TABLE_WIDTH_DATETIME },
  {
    title: i18nt('executeAction'),
    key: 'alarmAction',
    render(rowData) {
      return alarmActionType[rowData.alarmAction as number] ? i18nt(alarmActionType[rowData.alarmAction as number]) : '';
    }
  },
  {
    title: i18nt('actionCategory'),
    key: 'alarmActionCategory',
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      return actionCategoryObj[rowData.alarmActionCategory] || '';
    }
  },
  {
    title: i18nt('executeResult'),
    key: 'result',
    render(rowData) {
      return useRenderTableSingleTag(executeResultType[rowData.result].type as TagStateType, executeResultType[rowData.result].name);
    }
  },
  { title: i18nt('consuming'), key: 'alarmActionConsuming', width: TABLE_WIDTH_DATE },
  { title: i18nt('relatedInformation'), key: 'relatedPersons' },
  { title: i18nt('remark'), key: 'remark' }
];
// 操作记录
const operateRecordList = ref<OperateRecordType[]>();
const operateRecordColumns: DataTableColumns<OperateRecordType> = [
  { title: i18nt('alarmReason'), key: 'alarmReason' },
  { title: i18nt('alarmProcessMethod'), key: 'alarmDispose' },
  { title: i18nt('operator'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('operateTime'), key: 'operateTime', width: TABLE_WIDTH_DATETIME }
];
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-70%!"
    :show="modalIsShow"
    :title="$t('viewDetail')"
    :positive-text="__"
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-Form ref="formRef" v-model="formData" disabled layout="dialog" :schemas="formSchemas" />
    <!-- 批次明细 -->
    <div class="card-title">{{ i18nt('batchDetail') }}</div>
    <base-table class="m-b" :columns="lotInfoColumns" :loading="alarmSliceDetailLoading" :data="lotInfoList" />
    <!-- 执行动作明细 -->
    <div class="card-title">{{ i18nt('executeActionDetail') }}</div>
    <base-table class="m-b" :columns="actionInfoColumns" :loading="alarmSliceDetailLoading" :data="actionInfoList" />
    <!-- 操作明细 -->
    <div class="card-title">{{ i18nt('operateRecord') }}</div>
    <base-table
      class="m-b"
      :columns="operateRecordColumns"
      :loading="alarmSliceDetailLoading"
      :data="operateRecordList"
    />
  </base-modal>
</template>
