<script lang="tsx">
import { renderSpan } from '../common';
import addForm from './components/add-form.vue';
import {
  actionCategoryObj,
  alarmActionType,
  alarmCategoryList,
  alarmCategoryObj,
  alarmStatusType,
  resultOptions
} from '@/views/ams/constants';
import { ActionStatus, AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';
import type {
  AlarmDisposeTableListType,
  AlarmDisposeType,
  AlarmStateType,
  BatchInfoType,
  ChangeStateInfoType,
  DetailDataType,
  ExecuteActionType,
  QueryType,
  TableListType,
  TurnOrderType
} from '@/service/apis/ams/query-statistics/alarm-history-record';
import BaseInputNumber from '@/components/base-ui/base-input-number/base-input-number.vue';
import { CommonApis } from '@/service/apis/common/common';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { AlarmActionListType } from '@/service/apis/ams/system-setting';
</script>

<script setup lang="tsx">
// 初始化查询表单
const initQueryFormSchemas = (
  executeGetEquipmentNumberList: ({ params }: { params: { layoutId: string; check: string } }) => void,
  updataEqpNameValue: (updataValue: { key: keyof Pick<QueryType, 'eqpName'>; value: string[] }) => void,
  productLineList: Ref<OptionsType[] | undefined>,
  isLoadingProductLineList: Ref<boolean>,
  equipmentNumberList: Ref<OptionsType[] | undefined>,
  isLoadingEquipmentNumberList: Ref<boolean>,
  systemNameList?: Ref<OptionsType[] | undefined>,
  isLoadingSystemNameList?: Ref<boolean>,
  machineStateList?: Ref<OptionsType[] | undefined>,
  isLoadingMachineStateList?: Ref<boolean>,
  queryForm?: Nullable<QueryType>
): FormSchemaType => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      keyField: 'id',
      labelField: 'name',
      options: productLineList.value,
      loading: isLoadingProductLineList.value,
      multiple: true,
      checkable: true,
      cascade: true,
      onUpdateValue: (value: string) => {
        executeGetEquipmentNumberList({ params: { layoutId: value, check: '1' } });
        updataEqpNameValue({ key: 'eqpName', value: [] });
      }
    }
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      options: equipmentNumberList.value,
      loading: isLoadingEquipmentNumberList.value,
      labelField: 'name',
      valueField: 'name',
      multiple: true
    }
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: { label: i18nt('alarmCode') }
  },
  {
    type: 'select',
    model: 'alarmState',
    formItemProps: { label: i18nt('alarmState') },
    componentProps: computed(() => ({
      options: machineStateList?.value,
      loading: isLoadingMachineStateList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'select',
    model: 'alarmCategory',
    formItemProps: { label: i18nt('alarmCategory') },
    componentProps: computed(() => ({
      loading: false,
      options: alarmCategoryList
    }))
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList?.value,
      loading: isLoadingSystemNameList?.value,
      labelField: 'name',
      valueField: 'id'
    }))
  },
  {
    type: 'input',
    model: 'lotId',
    formItemProps: { label: i18nt('lotNumebr') }
  },
  {
    type: 'input',
    model: 'description',
    formItemProps: { label: i18nt('alarmDescription') },
    componentProps: { replaceSpace: false }
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('consuming') },
    render() {
      return h('div', { class: 'w-full flex items-center' }, [
        h(BaseInputNumber, {
          style: { width: '50%' },
          placeholder: `${i18nt('baseForm.pleaseInput')}${i18nt('startQueryRange')}`,
          min: 0,
          precision: 0,
          value: queryForm?.consumingStart,
          'on-update:value': (num: number) => {
            queryForm && (queryForm.consumingStart = num);
          }
        }),
        h('span', { class: 'px-6px' }, '~'),
        h(BaseInputNumber, {
          style: { width: '50%' },
          placeholder: `${i18nt('baseForm.pleaseInput')}${i18nt('endQueryRange')}`,
          min: 0,
          precision: 0,
          value: queryForm?.consumingEnd,
          'on-update:value': (num: number) => {
            queryForm && (queryForm.consumingEnd = num);
          }
        })
      ]);
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
];

const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  handleOpenModal: (id: string) => void,
  handleOpenAlarmDisposeModal: (rowData: TableListType) => void,
  hasCustomPermission: (permission: PermissionCustomType) => boolean | undefined,
  handleOpenTurnOrderModal: (rowData: TableListType) => void,
  alarmStateObj: { [key: number]: AlarmStateType }
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('equipmentNumber'),
    key: 'eqpID',
    sorter: true,
    width: TABLE_WIDTH_DATE
  },
  { title: i18nt('alarmDescription'), key: 'alarmDesc' },
  {
    key: 'alarmID',
    title: i18nt('alarmCode'),
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  {
    key: 'txId',
    title: i18nt('alarmID'),
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render: (rowData: TableListType) => useRenderTableTitleEdit(rowData.txId, () => handleOpenModal(rowData.id))
  },
  {
    title: i18nt('alarmStartTime'),
    key: 'alarmStartTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  {
    title: i18nt('alarmEndTime'),
    key: 'alarmEndTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  {
    title: i18nt('alarmState'),
    key: 'alarmState',
    width: TABLE_WIDTH_DATE,
    sorter: true,
    render(rowData) {
      return useRenderTableSingleTag(alarmStatusType[rowData.alarmState] as TagStateType, rowData.alarmState);
    }
  },
  {
    title: i18nt('alarmCategory'),
    key: 'alarmCategory',
    width: TABLE_WIDTH_DATE,
    sorter: true,
    render(rowData) {
      const obj = alarmStateObj[rowData.alarmCategory];
      return useRenderTableSingleTag(obj.type, obj.label);
    }
  },
  {
    title: i18nt('lotNumebr'),
    key: 'lotIdList',
    ...useRenderTableMultiTag('lotIdList')
  },
  { title: i18nt('duration'), key: 'duration', sorter: true, width: TABLE_WIDTH_INFO },
  {
    title: i18nt('consuming'),
    key: 'alarmConsuming',
    sorter: true,
    width: TABLE_WIDTH_INFO
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_INFO },
  { title: i18nt('productionLineLevel'), key: 'treeId' },
  {
    title: i18nt('createTime'),
    key: 'createTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  useRenderTableActionColumn({
    render: rowData => {
      return (
        <div class="flex">
          {useRenderTableFixedButton('action', {
            disabled: !hasCustomPermission('operate'),
            onClick: () => handleOpenAlarmDisposeModal(rowData)
          })}
          <div class="ml-4px"> </div>
          {useRenderTableFixedButton('turnOrder', {
            disabled: !hasCustomPermission('turnOrder') || rowData.alarmState === 'Close',
            onClick: () => handleOpenTurnOrderModal(rowData)
          })}
        </div>
      );
    }
  })
];

// 查看详情
const initDetailFormSchemas = (
  formData: DetailDataType,
  alarmStateObj: { [key: number]: AlarmStateType }
): FormSchemaType => [
  {
    type: 'custom-form-item',
    model: 'eqpID',
    formItemProps: { label: i18nt('equipmentNumber') },
    render() {
      return renderSpan(formData.eqpID);
    }
  },
  {
    type: 'custom-form-item',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    render() {
      return renderSpan(formData.systemName);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmID',
    formItemProps: { label: i18nt('alarmCode') },
    render() {
      return renderSpan(formData.alarmID);
    }
  },
  {
    type: 'custom-form-item',
    model: 'txId',
    formItemProps: { label: i18nt('alarmID') },
    render() {
      return renderSpan(formData.txId);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmStartTime',
    formItemProps: { label: i18nt('alarmStartTime') },
    render() {
      return renderSpan(formData.alarmStartTime);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmEndTime',
    formItemProps: { label: i18nt('alarmEndTime') },
    render() {
      return renderSpan(formData.alarmEndTime);
    }
  },
  {
    type: 'switch',
    model: 'isEqpAlarm',
    formItemProps: { label: i18nt('machineSelfAlarm') },
    componentProps: { checkedValue: 1, uncheckedValue: 0 },
    formItemClass: 'w-min!'
  },
  {
    type: 'custom-form-item',
    model: 'alarmStatus',
    formItemProps: { label: i18nt('alarmState') },
    render() {
      return useRenderTableSingleTag(alarmStatusType[formData.alarmStatus], formData.alarmStatus);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmCategory',
    formItemProps: { label: i18nt('alarmCategory') },
    render() {
      const obj = alarmStateObj[formData.alarmCategory];
      if (!obj) return;
      return useRenderTableSingleTag(obj.type, obj.label);
    }
  },
  formData.alarmCategory === 3
    ? {
        type: 'custom-form-item',
        model: 'alarmCategory',
        formItemProps: { label: i18nt('actionNotExecuted') },
        render() {
          if (formData.alarmCategory === 4) {
            const list = formData.unexecutedAction.map(ele => i18nt(alarmActionType[ele]));
            return useRenderTableTag(list, { ellipsis: true });
          }
        }
      }
    : __,

  {
    type: 'custom-form-item',
    model: 'duration',
    formItemProps: { label: i18nt('duration') },
    render() {
      return renderSpan(formData.duration);
    }
  },
  {
    type: 'custom-form-item',
    model: 'alarmConsuming',
    formItemProps: { label: i18nt('consuming') },
    render() {
      return renderSpan(formData.alarmConsuming);
    }
  },
  {
    type: 'custom-form-item',
    model: 'treeId',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.treeId);
    }
  },

  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('createTime') },
    render() {
      return renderSpan(formData.createTime);
    }
  },
  // formData.isManualClose
  //   ? {
  //       type: 'custom-form-item',
  //       model: 'alarmDesc',
  //       formItemProps: { label: i18nt('switchingPersonnel') },
  //       render() {
  //         return renderSpan(formData.closedBy);
  //       }
  //     }
  //   : __,
  // formData.isManualClose
  //   ? {
  //       type: 'custom-form-item',
  //       model: 'alarmDesc',
  //       formItemProps: { label: i18nt('switchingReason') },
  //       render() {
  //         return renderSpan(formData.closeReason);
  //       }
  //     }
  //   : __,
  {
    type: 'custom-form-item',
    model: 'alarmDesc',
    formItemProps: { label: i18nt('alarmDescription') },
    formItemClass: 'col-span-2!',
    render() {
      return renderSpan(formData.alarmDesc);
    }
  },
  formData.alarmReason
    ? {
        type: 'custom-form-item',
        model: 'alarmReason',
        formItemProps: { label: i18nt('alarmReason') },
        formItemClass: 'col-span-2!',
        render() {
          return renderSpan(formData.alarmReason);
        }
      }
    : __,
  formData.alarmDispose
    ? {
        type: 'custom-form-item',
        model: 'alarmDispose',
        formItemProps: { label: i18nt('alarmProcessMethod') },
        formItemClass: 'col-span-2!',
        render() {
          return renderSpan(formData.alarmDispose);
        }
      }
    : __,
  formData.operator
    ? {
        type: 'custom-form-item',
        model: 'operator',
        formItemProps: { label: i18nt('operator') },
        render() {
          return renderSpan(formData.operator);
        }
      }
    : __,
  formData.operateTime
    ? {
        type: 'custom-form-item',
        model: 'operateTime',
        formItemProps: { label: i18nt('operateTime') },
        render() {
          return renderSpan(formData.operateTime);
        }
      }
    : __,
  {
    type: 'custom-form-item',
    model: 'remark',
    formItemProps: { label: i18nt('remark') },
    formItemClass: 'col-span-2!',
    render() {
      return renderSpan(formData.remark);
    }
  }
];

const initAlarmDisposeFormSchemas = (): FormSchemaType => [
  useRenderFormTextarea({
    model: 'alarmReason',
    label: i18nt('alarmReason'),
    formItemProps: {
      rule: useRules('input', i18nt('alarmReason'))
    }
  }),
  useRenderFormTextarea({
    model: 'alarmDispose',
    label: i18nt('alarmProcessMethod'),
    formItemProps: {
      rule: useRules('input', i18nt('alarmProcessMethod'))
    }
  })
];
// 转单
const initTurnOrderFormFormSchemas = (
  recipientQueryList?: Ref<OptionsType[] | undefined>,
  isLoadingrecipientQuery?: Ref<boolean>
): FormSchemaType => [
  {
    type: 'select',
    model: 'transfereeList',
    formItemProps: {
      label: i18nt('recipientQuery'),
      rule: { type: 'array', ...useRules('change', i18nt('recipientQuery')) }
    },
    componentProps: {
      options: recipientQueryList?.value,
      loading: isLoadingrecipientQuery?.value,
      labelField: 'name',
      valueField: 'id',
      multiple: true
    }
  }
];
const createColumnsBatch = (): DataTableColumns<BatchInfoType> => [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  { key: 'lotId', title: i18nt('lotNumebr') },
  { key: 'lotPortId', title: 'Port' },
  { key: 'chamberId', title: 'Chamber' },
  { key: 'productId', title: 'Product' },
  { key: 'carrierId', title: 'Carrier ID' },
  { key: 'batchId', title: 'Batch ID' },
  { key: 'reserved', title: 'Reserved' },
  { key: 'state', title: 'State' }
];
const createColumnsExecuteAction = (): DataTableColumns<ExecuteActionType> => [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  { key: 'eqpID', title: i18nt('equipmentNumber') },
  { key: 'alarmID', title: i18nt('alarmCode') },
  {
    key: 'systemTime',
    title: i18nt('occurredTime'),
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  { key: 'alarmAction', title: i18nt('executeAction') },
  {
    title: i18nt('actionCategory'),
    key: 'alarmActionCategory',
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      return actionCategoryObj[rowData.alarmActionCategory] || '';
    }
  },
  {
    key: 'result',
    title: i18nt('executeResult'),
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      const find = resultOptions.find(c => c.id === rowData.result);
      return useRenderTableSingleTag(ActionStatus[find?.id || 0] as TagStateType, find?.name || '');
    }
  },
  { key: 'alarmActionConsuming', title: i18nt('actionConsuming') },
  { key: 'relatedPersons', title: i18nt('relatedInformation') },
  { key: 'remark', title: i18nt('remark') }
];
const createColumnsChangeStateInfo = (): DataTableColumns<ChangeStateInfoType> => [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  {
    title: i18nt('switchingStatus'),
    key: 'alarmDispose'
  },
  {
    title: i18nt('switchingTime'),
    key: 'operateTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  { title: i18nt('switchingPersonnel'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('switchingReason'), key: 'reason' },
  { key: 'remark', title: i18nt('remark') }
];
// 操作记录
const createColumnsAlarmDisopse = (
  handleDeleteAlarmDispose: (rowData: AlarmDisposeTableListType) => void,
  deleteIsShow = false
): DataTableColumns<AlarmDisposeTableListType> => {
  const list = [
    { title: i18nt('alarmReason'), key: 'alarmReason' },
    { title: i18nt('alarmProcessMethod'), key: 'alarmDispose' },
    { title: i18nt('operator'), key: 'operator', width: TABLE_WIDTH_NAME },
    { title: i18nt('operateTime'), key: 'operateTime', width: TABLE_WIDTH_DATETIME }
  ];
  return deleteIsShow
    ? [
        {
          title: i18nt('index'),
          key: 'index',
          align: 'center',
          render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
          width: TABLE_WIDTH_INDEX
        },
        ...list,
        useRenderTableActionColumn({
          render: rowData =>
            useRenderTableFixedButton('delete', {
              disabled: !rowData.isHasDeletePower,
              onClick: () => handleDeleteAlarmDispose(rowData)
            })
        })
      ]
    : [
        {
          title: i18nt('index'),
          key: 'index',
          align: 'center',
          render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
          width: TABLE_WIDTH_INDEX
        },
        ...list
      ];
};
const addFormRef = ref();
const { hasCustomPermission } = useRoutes();
const appStore = useAppStore();

// 模板引用
const curdRef = ref<CurdRefType<QueryType, never, TableListType>>();

// 获取报警状态列表
const { isLoading: isLoadingMachineStateList, data: machineStateList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.machineState
  },
  __,
  {
    immediate: true
  }
);

// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi, __);

// 获取设备编号列表
const {
  data: equipmentNumberList,
  isLoading: isLoadingEquipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi, {}, { paramsSerializer: useParamsSerializer() });

// 获取系统名称列表
const {
  isLoading: isLoadingSystemNameList,
  data: systemNameList,
  execute: executeGetSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);
// 执行动作列表
const { execute: executegetAllActionsList } = useAxiosGet<AlarmActionListType[]>(
  AlarmSystemSettingApis.getAllActionsApi
);
const actionList = ref<AlarmActionListType[]>([]);

const route = useRoute();
const { query } = route;
// 是否第一次进入
const flowNoIsShow = ref<boolean>(false);
tryOnMounted(async () => {
  try {
    executeGetProductLineList();
    executeGetEquipmentNumberList();
    executeGetSystemNameList();
    const { data } = await executegetAllActionsList();
    actionList.value =
      data.value?.map(ele => {
        return {
          id: ele.id,
          name: alarmActionType[ele.id] ? i18nt(alarmActionType[ele.id]) : ''
        };
      }) || [];

    if (!curdRef.value) return;
    if (!curdRef.value.queryFormData) return;
    curdRef.value.queryFormData.id = (query.id as string) || null;
    flowNoIsShow.value = true;
    if (!query.id) return;
    handleOpenModal(query.id as string);
  } catch (error) {
    actionList.value = [];
  }
});

// 查询表单参数
const queryFormParams: Nullable<QueryType> = {
  alarmId: null,
  alarmState: null,
  description: null,
  lotId: null,
  eqpName: [],
  timestamp: useFormatDateRange(),
  treeIds: null,
  consumingStart: null,
  systemName: null,
  consumingEnd: null,
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1,
  alarmCategory: null,
  id: null
};
// 查询表单数据 -> 响应式
const curdRefPagination = computed(() => curdRef.value?.pagination);

// 查询表单模型
const queryFormSchemas = computed(() =>
  initQueryFormSchemas(
    executeGetEquipmentNumberList,
    updataEqpNameValue,
    productLineList,
    isLoadingProductLineList,
    equipmentNumberList,
    isLoadingEquipmentNumberList,
    systemNameList,
    isLoadingSystemNameList,
    machineStateList,
    isLoadingMachineStateList,
    curdRef.value?.queryFormData
  )
);

// -------------------------------------------------------------------------------------------- > Modal
const { showModal, openModal, closeModal } = useModal();

const {
  data: historyRecordData,
  isLoading: isLoadingHistoryRecordData,
  execute: executeHistoryRecordData
} = useAxiosGet<DetailDataType>(AlarmHistoryRecordApis.getAlarmHistoryDetailApi);

function defaultValues(): Nullable<Omit<DetailDataType, 'actionInfo' | 'lotInfo' | 'systemName'>> {
  return {
    eqpID: null,
    alarmID: null,
    alarmDesc: null,
    alarmStartTime: null,
    alarmEndTime: null,
    alarmStatus: null,
    isEqpAlarm: null,
    duration: null,
    alarmConsuming: null,
    treeId: null,
    createTime: null,
    remark: null,
    alarmCategory: null,
    unexecutedAction: []
  };
}

const infoForm = ref<Nullable<Omit<DetailDataType, 'actionInfo' | 'lotInfo' | 'systemName'>>>(defaultValues());

const handleOpenModal = async (id: string) => {
  openModal();

  const { data } = await executeHistoryRecordData({
    params: { id, language: appStore.local === LOCAL_DEFAULT ? 0 : 1 }
  });

  const { actionInfo, lotInfo, ...params } = data.value as DetailDataType;

  const actions = (actionInfo || []).map(item => {
    const action = actionList.value.find(act => act.id.toString() === item.alarmAction);
    return {
      ...item,
      alarmAction: action?.name || ''
    };
  });

  historyRecordData.value && (historyRecordData.value.actionInfo = actions as unknown as ExecuteActionType[]);
  infoForm.value = params;
};

const handleCloseModal = () => {
  closeModal();
  infoForm.value = defaultValues();
};

const refactorFormQueryParams = (data: QueryType) => {
  if (!data.timestamp) return;
  return {
    ...data,
    id: flowNoIsShow.value ? data.id : query.id,
    ...useFormatDateTimeParams(data.timestamp)
  };
};

const updataEqpNameValue = (updataValue: { key: keyof Pick<QueryType, 'eqpName'>; value: string[] }) => {
  curdRef.value?.queryFormData && (curdRef.value.queryFormData[updataValue.key] = updataValue.value);
};
// 点击按钮
const handlePermission = (permission: PermissionType) => {
  if (permission === 'reset') {
    executeGetEquipmentNumberList();
  } else if (permission === 'add') {
    addFormRef?.value?.handleOpenModal();
  } else if (permission === 'search') {
    console.log(permission);
    if (!curdRef.value) return;
    if (!curdRef.value.queryFormData) return;
    curdRef.value.queryFormData.id = null;
  }
};

//   报警处理
const {
  data: alarmDisposeTableList,
  isLoading: isLoadingAlarmDisposeTableList,
  execute: executeGetAlarmDisposeTableList
} = useAxiosGet<Record<string, unknown>[]>(AlarmHistoryRecordApis.getAlarmDisposeTableListApi);

const currentHandleData = ref<TableListType | null>(null);
const {
  showModal: showModalAlarmDispose,
  openModal: openAlarmDisposeModal,
  closeModal: closeAlarmDisposeModal
} = useModal();

const {
  formData: alarmDisposeFormData,
  formRef: alarmDisposeFormRef,
  resetField: resetAlarmDisposeField,
  validate: validateAlarmDispose
} = useForm<Nullable<AlarmDisposeType>>({
  alarmReason: null,
  alarmDispose: null
});
const handleOpenAlarmDisposeModal = (rowData: TableListType) => {
  currentHandleData.value = rowData;
  executeGetAlarmDisposeTableList(__, {
    params: { historyId: currentHandleData.value?.id }
  });
  openAlarmDisposeModal();
};
// 新增
const { isLoading: isLoadingAlarmDispose, execute: executeAlarmDispose } = useAxiosPost(
  AlarmHistoryRecordApis.alarmDisposeApi
);
const handleSubmitAlarmDispose = async () => {
  try {
    await validateAlarmDispose();
    await executeAlarmDispose(__, {
      data: { ...alarmDisposeFormData.value, historyId: currentHandleData.value?.id }
    });
    closeAlarmDisposeModal();
  } catch (error) {
    console.log(error);
  }
};
// 转单
const {
  showModal: showModalTurnOrderModal,
  openModal: openTurnOrderModal,
  closeModal: closeTurnOrderModal
} = useModal();
const turnOrderHandleData = ref<TableListType | null>(null);
const {
  formData: turnOrderFormData,
  formRef: turnOrderFormRef,
  resetField: resetturnOrderField,
  validate: validateturnOrder
} = useForm<Nullable<TurnOrderType>>({
  historyId: null,
  transfereeList: null
});

// 获取接收人
const {
  isLoading: isLoadingrecipientQuery,
  data: recipientQueryList,
  execute: executegetAlarmTansferees
} = useAxiosGet<OptionsType[]>(AlarmHistoryRecordApis.getAlarmTansfereesApi);
const turnOrderFormSchemas = computed<FormSchemaType>(() =>
  initTurnOrderFormFormSchemas(recipientQueryList, isLoadingrecipientQuery)
);

// 打开转单弹窗
const handleOpenTurnOrderModal = (rowData: TableListType) => {
  turnOrderHandleData.value = rowData;
  executegetAlarmTansferees(__, {
    params: {
      eqpName: rowData.eqpID,
      historyId: rowData.id
    }
  });
  openTurnOrderModal();
};
// 转单保存
const { isLoading: isLoadingAlarmTansfer, execute: executeAlarmTansfer } = useAxiosPost(
  AlarmHistoryRecordApis.alarmTansferApi
);
const handleSubmitTurnOrder = async () => {
  try {
    await validateturnOrder();
    await executeAlarmTansfer(__, {
      data: { ...turnOrderFormData.value, historyId: turnOrderHandleData.value?.id }
    });
    closeTurnOrderModal();
  } catch (error) {
    console.log(error);
  }
};

// 删除
const handleDeleteAlarmDispose = (rowData: AlarmDisposeTableListType) => {
  const dialog = $dialog.warning({
    title: i18nt('tips'),
    content: i18nt('permission-button.confirmTooltip', { val: i18nt('delete') }),
    onPositiveClick: async () => {
      try {
        dialog.loading = true;
        await useAxiosPost(AlarmHistoryRecordApis.deleteAlarmDisposeApi, { id: rowData.id }, __, { immediate: true });
        executeGetAlarmDisposeTableList(__, {
          params: { historyId: currentHandleData.value?.id }
        });
      } catch (error) {
        console.log(error);
        return false;
      } finally {
        dialog.loading = false;
      }
    }
  });
};

const alarmDisposeFormSchemas = initAlarmDisposeFormSchemas();

// 表格
const tableColumns = createColumns(
  curdRefPagination,
  handleOpenModal,
  handleOpenAlarmDisposeModal,
  hasCustomPermission,
  handleOpenTurnOrderModal,
  alarmCategoryObj
);
const tableColumnsBatch = createColumnsBatch();
const tableColumnsExecuteAction = createColumnsExecuteAction();
const tableColumnsAlarmDispose = createColumnsAlarmDisopse(handleDeleteAlarmDispose, true);
const tableColumnsAlarmDispose1 = createColumnsAlarmDisopse(handleDeleteAlarmDispose);
const tableColumnsChangeStateInfo = createColumnsChangeStateInfo();
const detailFormSchemas = computed(() => initDetailFormSchemas(infoForm.value as DetailDataType, alarmCategoryObj));

// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleResetPageSize();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="alarm-history-record">
    <base-curd
      ref="curdRef"
      :ignore-form-permission-list="['operate', 'turnOrder']"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :delete-api="AlarmHistoryRecordApis.alarmHistoryDeleteApi"
      :read-api="AlarmHistoryRecordApis.getAlarmHistoryListApi"
      :export-api="AlarmHistoryRecordApis.getAlarmHistoryListApi"
      :download-api="AlarmHistoryRecordApis.downloadAlarmHistoryRecordApi"
      :import-api="AlarmHistoryRecordApis.importAlarmHistoryRecordApi"
      :refactor-form-query-params="refactorFormQueryParams"
      params-serializer-query
      :table-props="{
        scrollX: TABLE_WIDTH_SCROLL_MIDDLE
      }"
      @handle="handlePermission"
    />
    <!-- > 报警处理 -->

    <base-modal
      class="w-35%!"
      :loading="isLoadingAlarmDispose"
      :show="showModalAlarmDispose"
      :title="$t('action')"
      @close="closeAlarmDisposeModal"
      @negative-click="closeAlarmDisposeModal"
      @positive-click="handleSubmitAlarmDispose"
      @after-leave="resetAlarmDisposeField(), (currentHandleData = null)"
    >
      <base-form
        ref="alarmDisposeFormRef"
        v-model="alarmDisposeFormData"
        layout="dialog"
        :schemas="alarmDisposeFormSchemas"
      />
      <!-- -------------------------------------------------------------------- > 报警处理方式 -->
      <div class="card-title mt">{{ $t('operateRecord') }}</div>
      <base-table
        :max-height="300"
        :loading="isLoadingAlarmDisposeTableList"
        :columns="tableColumnsAlarmDispose"
        :data="alarmDisposeTableList"
      />
    </base-modal>
    <!-- 转单 -->
    <base-modal
      class="w-35%!"
      :loading="isLoadingAlarmTansfer"
      :show="showModalTurnOrderModal"
      :title="$t('turnOrder')"
      @close="closeTurnOrderModal"
      @negative-click="closeTurnOrderModal"
      @positive-click="handleSubmitTurnOrder"
      @after-leave="resetturnOrderField(), (turnOrderHandleData = null)"
    >
      <base-form ref="turnOrderFormRef" v-model="turnOrderFormData" layout="dialog" :schemas="turnOrderFormSchemas" />
    </base-modal>
    <!--  > 查看详情 -->
    <base-modal
      :show="showModal"
      class="w-70%!"
      :title="i18nt('viewDetail')"
      :positive-text="undefined"
      @close="handleCloseModal"
      @negative-click="handleCloseModal"
    >
      <!-- -------------------------------------------------------------------- > 批次明细 -->
      <base-form v-model="infoForm" :schemas="detailFormSchemas" layout="dialog" disabled />
      <div class="card-title">{{ $t('batchDetail') }}</div>
      <base-table
        :max-height="isLoadingHistoryRecordData ? 60 : 400"
        :loading="isLoadingHistoryRecordData"
        :columns="tableColumnsBatch"
        :data="historyRecordData?.lotInfo"
      />
      <!-- -------------------------------------------------------------------- > 执行动作明细 -->
      <div class="card-title mt">{{ $t('executeActionDetail') }}</div>
      <base-table
        :max-height="isLoadingHistoryRecordData ? 60 : 400"
        :loading="isLoadingHistoryRecordData"
        :columns="tableColumnsExecuteAction"
        :data="historyRecordData?.actionInfo"
      />
      <!-- 状态切换 -->
      <div class="card-title mt">{{ $t('switchingRecord') }}</div>
      <base-table
        :max-height="isLoadingHistoryRecordData ? 60 : 400"
        :loading="isLoadingHistoryRecordData"
        :columns="tableColumnsChangeStateInfo"
        :data="historyRecordData?.changeStateInfo"
      />
      <!-- 操作记录 -->
      <div class="card-title mt">{{ $t('operateRecord') }}</div>
      <base-table
        :loading="isLoadingHistoryRecordData"
        :columns="tableColumnsAlarmDispose1"
        :data="historyRecordData?.additionalInfo"
      />
    </base-modal>
    <addForm ref="addFormRef" @reset-table="resetTable" />
  </div>
</template>
