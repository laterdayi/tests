<script setup lang="tsx">
import { alarmActionType } from '@/views/ams/constants';
import { AlarmHistoryRecordApis } from '@/service/apis/ams/query-statistics/alarm-history-record';
import type {
  ActionInfoDataType,
  FormType,
  LotInfoDataType,
  OperateRecordType
} from '@/service/apis/ams/query-statistics/alarm-history-record';
import { CommonApis } from '@/service/apis/common/common';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { AlarmActionListType } from '@/service/apis/ams/system-setting';

const emit = defineEmits<{
  'reset-table': [];
}>();

// 获取设备编号列表
const {
  data: equipmentNumberList,
  isLoading: isLoadingEquipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
// 系统名称
const { execute: getSystemNameList } = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);
const systemNameList = ref<OptionsType[]>([]);
// 报警代码
const { data: alarmCodeList, execute: executeGetAlarmCodeList } = useAxiosGet<OptionsType[]>(
  AlarmHistoryRecordApis.getAlarmCodeListApi
);
// 操作人列表
const { data: allUserIdsList, execute: exeAllUserIds } = useAxiosGet<OptionsType[]>(
  AlarmHistoryRecordApis.getAllUserIdsApi
);
// 执行动作列表
const { execute: executegetAllActionsList } = useAxiosGet<AlarmActionListType[]>(
  AlarmSystemSettingApis.getAllActionsApi
);
const actionList = ref<AlarmActionListType[]>([]);
// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);

//  打开弹窗
const handleOpenModal = async () => {
  try {
    alarmStartTime.value = null;
    lotInfoData.value = [];
    actionInfoData.value = [];
    operateRecordData.value = [];
    alarmCodeList.value = [];
    await executeGetEquipmentNumberList();
    await exeAllUserIds();
    const { data: actionData } = await executegetAllActionsList();
    actionList.value =
      actionData.value?.map(ele => {
        return {
          id: ele.id,
          name: alarmActionType[ele.id] ? i18nt(alarmActionType[ele.id]) : ''
        };
      }) || [];

    const { data } = await getSystemNameList();
    if (!data.value) return;
    systemNameList.value = data.value ? data.value.filter(ele => ele.id !== 'EAP') : [];
    formData.value.systemName =
      systemNameList.value && systemNameList.value.length !== 0 ? systemNameList.value[0].id : null;
    openModal();
  } catch (error) {
    systemNameList.value = [];
    formData.value.systemName = null;
  }
};
// 表单查询
const { formRef, validate, formData, resetField } = useForm<Nullable<FormType>>({
  eqpId: null,
  systemName: null,
  alarmID: null,
  alarmStartTime: null,
  alarmEndTime: null,
  alarmDesc: null
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: {
      label: i18nt('eqpName'),
      rule: [useRules('input', i18nt('eqpName'))]
    },
    componentProps: {
      options: equipmentNumberList.value,
      loading: isLoadingEquipmentNumberList.value,
      labelField: 'name',
      valueField: 'name',
      onUpdateValue: async value => {
        formData.value.alarmID = '';
        formData.value.alarmDesc = '';
        await executeGetAlarmCodeList({
          params: {
            eqpId: value,
            systemName: formData.value.systemName
          }
        });
      }
    }
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: {
      label: i18nt('systemName'),
      rule: [useRules('change', i18nt('systemName'))]
    },
    componentProps: {
      options: systemNameList.value,
      labelField: 'name',
      valueField: 'id',
      onUpdateValue: async value => {
        formData.value.alarmID = '';
        formData.value.alarmDesc = '';
        await executeGetAlarmCodeList({
          params: {
            eqpId: formData.value.eqpId,
            systemName: value
          }
        });
      }
    }
  },
  {
    type: 'date-picker',
    model: 'alarmStartTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('alarmStartTime'),
      rule: [useRules('change', i18nt('alarmStartTime'))]
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss',
      onUpdateValue: value => {
        actionInfoIsShow.value = false;
        nextTick(() => {
          alarmStartTime.value = value;
          actionInfoData.value.find(ele => (ele.systemTime = value));
          actionInfoIsShow.value = true;
        });
      }
    },
    class: 'w-95%!'
  },
  {
    type: 'date-picker',
    model: 'alarmEndTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('alarmEndTime')
    },
    componentProps: {
      type: 'datetime',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    },
    class: 'w-95%!'
  },
  {
    type: 'select',
    model: 'alarmID',
    formItemProps: { label: i18nt('alarmCode'), rule: [useRules('change', i18nt('alarmCode'))] },
    componentProps: {
      options: alarmCodeList.value,
      labelField: 'id',
      valueField: 'id',
      onUpdateValue: value => {
        const obj = alarmCodeList.value
          ? alarmCodeList.value.length === 0
            ? undefined
            : alarmCodeList.value.find(ele => ele.id === value)
          : undefined;
        formData.value.alarmDesc = obj ? obj.name : '';
      }
    }
  },
  {
    type: 'input',
    model: 'alarmDesc',
    formItemProps: {
      label: i18nt('alarmDescription')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    class: 'w-95%!'
  }
]);
// input超出限制
const rowInput = (value: keyof LotInfoDataType, row: LotInfoDataType, length: number) => {
  if (row[value].length > length) {
    row[value] = row[value].substring(0, length);
  }
};
// 批次明细
const lotInfoData = ref<LotInfoDataType[]>([]);
const lotInfoColumns: DataTableColumns<LotInfoDataType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('lotNumebr')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'lotId',
    render(row) {
      return (
        <>
          <base-input
            class="w-100%!"
            onInput={() => rowInput('lotId', row, 2000)}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('lotNumebr')}
            ref="inputInstRef"
            type="text"
            v-model:value={row.lotId}
          />
        </>
      );
    }
  },
  {
    title: 'Port',
    key: 'loadPortId',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('loadPortId', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}Port`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.loadPortId}
          />
        </>
      );
    }
  },
  {
    title: 'Chamber',
    key: 'chamberId',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('chamberId', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}Chamber`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.chamberId}
          />
        </>
      );
    }
  },
  {
    title: 'Product',
    key: 'productId',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('productId', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}Product`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.productId}
          />
        </>
      );
    }
  },
  {
    title: 'Carrier ID',
    key: 'carrierId',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('carrierId', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}Carrier ID`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.carrierId}
          />
        </>
      );
    }
  },
  {
    title: 'Batch ID',
    key: 'batchId',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('batchId', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}Batch ID`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.batchId}
          />
        </>
      );
    }
  },
  {
    title: 'Reserved',
    key: 'reserved',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('reserved', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}Reserved`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.reserved}
          />
        </>
      );
    }
  },
  {
    title: 'State',
    key: 'state',
    render(row) {
      return (
        <>
          <base-input
            onInput={() => rowInput('state', row, 2000)}
            placeholder={`${i18nt('baseForm.pleaseInput')}State`}
            ref="inputInstRef"
            type="text"
            v-model:value={row.state}
          />
        </>
      );
    }
  },
  {
    title: i18nt('action'),
    key: '',
    // fixed: 'right',
    width: 80,
    render(row, index) {
      return (
        <>
          <base-button
            button-name="delete"
            onClick={() => lotInfoDelete(index)}
            size={componentSize.value}
            type="error"
          >
            删除
          </base-button>
        </>
      );
    }
  }
];
const lotInfoAdd = () => {
  lotInfoData.value.push({
    lotId: '',
    loadPortId: '',
    chamberId: '',
    productId: '',
    carrierId: '',
    batchId: '',
    reserved: '',
    state: ''
  });
};
const lotInfoDelete = (index: number) => {
  lotInfoData.value.splice(index, 1);
};
// 执行动作明细
const actionInfoIsShow = ref<boolean>(true);
const alarmStartTime = ref<number | null>(null);
const actionInfoData = ref<Nullable<ActionInfoDataType>[]>([]);
const disablePreviousDate = (ts: number) => ts > new Date().setHours(23, 59, 59);
const actionInfoColumns: DataTableColumns<ActionInfoDataType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('occurredTime')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'systemTime',
    width: 200,
    render(row) {
      return (
        <>
          <n-date-picker
            clearable
            defaultValue={row.systemTime}
            is-date-disabled={disablePreviousDate}
            onUpdateValue={(value: number) => {
              row.systemTime = value;
            }}
            type="datetime"
            v-model={row.systemTime}
            valueFormat="yyyy-MM-dd HH:mm:ss"
          />
        </>
      );
    }
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('executeAction')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'alarmAction',
    width: 190,
    render(row) {
      return (
        <>
          <base-select
            class="w-100%!"
            label-field="name"
            options={actionList.value}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('executeAction')}
            v-model:value={row.alarmAction}
            value-field="id"
          />
        </>
      );
    }
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('executeResult')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'result',
    width: 190,
    render(row) {
      return (
        <>
          <base-select
            class="w-100%!"
            options={[
              {
                value: '0',
                label: i18nt('processing')
              },
              {
                value: '1',
                label: i18nt('success')
              },
              {
                value: '2',
                label: i18nt('failed')
              }
            ]}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('executeResult')}
            v-model:value={row.result}
          />
        </>
      );
    }
  },
  {
    title: i18nt('relatedInformation'),
    key: 'relatedInfo',
    width: 190,
    render(row) {
      return (
        <>
          <base-input
            onInput={() => {
              if (row.relatedInfo.length > 2000) {
                row.relatedInfo = row.relatedInfo.substring(0, 2000);
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('relatedInformation')}
            ref="inputInstRef"
            type="text"
            v-model:value={row.relatedInfo}
          />
        </>
      );
    }
  },
  {
    title: i18nt('remark'),
    key: 'remark',
    render(row) {
      return (
        <>
          <base-input
            class="w-100%!"
            onInput={() => {
              if (row.remark.length > 2000) {
                row.remark = row.remark.substring(0, 2000);
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('remark')}
            ref="inputInstRef"
            type="text"
            v-model:value={row.remark}
          />
        </>
      );
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 80,
    render(row, index) {
      return (
        <>
          <base-button
            button-name="delete"
            onClick={() => actionInfDelete(index)}
            size={componentSize.value}
            type="error"
          >
            删除
          </base-button>
        </>
      );
    }
  }
];
const actionInfoAdd = () => {
  actionInfoData.value.push({
    systemTime: alarmStartTime.value || null,
    alarmAction: null,
    result: null,
    relatedInfo: '',
    remark: ''
  });
};
const actionInfDelete = (index: number) => {
  actionInfoData.value.splice(index, 1);
};
// 操作记录
const operateRecordData = ref<Nullable<OperateRecordType>[]>([]);
const operateRecordColumns: DataTableColumns<OperateRecordType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('alarmReason')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'alarmReason',
    render(row) {
      return (
        <>
          <base-input
            class="w-100%!"
            onInput={() => {
              if (row.alarmReason.length > 200) {
                row.alarmReason = row.alarmReason.substring(0, 200);
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('alarmReason')}
            ref="inputInstRef"
            replaceSpace={false}
            type="text"
            v-model:value={row.alarmReason}
          />
        </>
      );
    }
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('alarmProcessMethod')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'alarmDispose',
    render(row) {
      return (
        <>
          <base-input
            class="w-100%!"
            onInput={() => {
              if (row.alarmDispose.length > 200) {
                row.alarmDispose = row.alarmDispose.substring(0, 200);
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('alarmProcessMethod')}
            ref="inputInstRef"
            replaceSpace={false}
            type="text"
            v-model:value={row.alarmDispose}
          />
        </>
      );
    }
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('operator')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'operator',
    render(row) {
      return (
        <>
          <base-select
            class="w-100%!"
            options={allUserIdsList.value?.map(ele => {
              return {
                value: ele.id,
                label: ele.name
              };
            })}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('operator')}
            v-model:value={row.operator}
          />
        </>
      );
    }
  },
  {
    title: () => {
      return (
        <>
          <div>
            {i18nt('operateTime')}
            <span
              style={{
                color: '#f56c6c',
                marginLeft: '2px'
              }}
            >
              *
            </span>
          </div>
        </>
      );
    },
    key: 'alarmDispose',
    render(row) {
      return (
        <>
          <n-date-picker
            clearable
            is-date-disabled={disablePreviousDate}
            onUpdateValue={(value: number) => {
              row.operateTime = value;
            }}
            type="datetime"
            v-model={row.operateTime}
            valueFormat="yyyy-MM-dd HH:mm:ss"
          />
        </>
      );
    }
  },
  {
    title: i18nt('action'),
    key: '',
    width: 80,
    render(row, index) {
      return (
        <>
          <base-button
            button-name="delete"
            onClick={() => operateRecordDelete(index)}
            size={componentSize.value}
            type="error"
          >
            删除
          </base-button>
        </>
      );
    }
  }
];
const operateRecordAdd = () => {
  operateRecordData.value.push({
    alarmReason: '',
    alarmDispose: '',
    operator: '',
    operateTime: null
  });
};
const operateRecordDelete = (index: number) => {
  operateRecordData.value.splice(index, 1);
};
// 保存表单
const { isLoading: alarmHistoryLoding, execute: addAlarmHistory } = useAxiosPost(
  AlarmHistoryRecordApis.addAlarmHistoryApi
);
const saveForm = async () => {
  try {
    await validate();
    if (lotInfoData.value.length !== 0 && !lotInfoData.value.every(ele => ele.lotId !== '')) {
      $message.warning(i18nt('batchDetailTips1'));
      return;
    }
    if (
      actionInfoData.value.length !== 0 &&
      !actionInfoData.value.every(ele => ele.systemTime !== null && ele.alarmAction !== null && ele.result !== null)
    ) {
      $message.warning(i18nt('batchDetailTips2'));
      return;
    }
    if (
      operateRecordData.value.length !== 0 &&
      !operateRecordData.value.every(
        ele => ele.alarmReason !== '' && ele.alarmDispose !== '' && ele.operator !== '' && ele.operateTime !== null
      )
    ) {
      $message.warning(i18nt('batchDetailTips3'));
      return;
    }
    await addAlarmHistory({
      data: {
        ...formData.value,
        addHistoryLots: [...lotInfoData.value],
        addHistoryActions: actionInfoData.value.map(ele => {
          return {
            ...ele,
            systemTime: ele.systemTime ? useFormatDate(ele.systemTime, 'YYYY-MM-DD HH:mm:ss') : null
          };
        }),
        addAdditionals: operateRecordData.value.map(ele => {
          return {
            ...ele,
            operateTime: ele.operateTime ? useFormatDate(ele.operateTime, 'YYYY-MM-DD HH:mm:ss') : null
          };
        })
      }
    });
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  closeModal();
  resetField();
  emit('reset-table');
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-65%!"
    :show="showModal"
    :title="$t('add') + $t('alarmHistoryRecord')"
    @positive-click="saveForm"
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-space :wrap-item="false" class="w-100%!">
      <base-spin :show="alarmHistoryLoding" class="w-100%!">
        <!-- 表单 -->
        <base-form ref="formRef" v-model="formData" class="form" layout="dialog" :schemas="formSchemas" />
        <!-- 批次明细 -->
        <div class="flex">
          <div class="card-title">
            {{ i18nt('batchDetail') }}
            <base-tooltip trigger="hover">
              <template #trigger>
                <base-icon icon="i-carbon:warning" class="mt--2" color="#f56c6c" />
              </template>
              {{ i18nt('batchDetailTips') }}
            </base-tooltip>
          </div>
          <base-button class="ml" :size="componentSize" button-name="add" type="info" @click="lotInfoAdd">
            {{ $t('add') }}
          </base-button>
        </div>
        <!-- :scroll-x="TABLE_WIDTH_SCROLL_MINI" -->
        <base-table class="m-b" :max-height="510" :columns="lotInfoColumns" :data="lotInfoData" />
        <!-- 执行动作明细 -->
        <div class="flex m-t">
          <div class="card-title">
            {{ i18nt('executeActionDetail') }}
            <base-tooltip trigger="hover">
              <template #trigger>
                <base-icon icon="i-carbon:warning" class="mt--2" color="#f56c6c" />
              </template>
              {{ i18nt('batchDetailTips4') }}
            </base-tooltip>
          </div>
          <base-button class="ml" :size="componentSize" button-name="add" type="info" @click="actionInfoAdd">
            {{ $t('add') }}
          </base-button>
        </div>
        <base-table
          v-if="actionInfoIsShow"
          :max-height="510"
          class="m-b"
          :columns="actionInfoColumns"
          :data="actionInfoData"
        />
        <!-- 操作记录 -->
        <div class="flex m-t">
          <div class="card-title">
            {{ i18nt('operateRecord') }}
            <base-tooltip trigger="hover">
              <template #trigger>
                <base-icon icon="i-carbon:warning" class="mt--2" color="#f56c6c" />
              </template>
              {{ i18nt('batchDetailTips5') }}
            </base-tooltip>
          </div>
          <base-button class="ml" :size="componentSize" button-name="add" type="info" @click="operateRecordAdd">
            {{ $t('add') }}
          </base-button>
        </div>
        <base-table class="m-b" :max-height="510" :columns="operateRecordColumns" :data="operateRecordData" />
      </base-spin>
    </base-space>
  </base-modal>
</template>

<style scoped lang="less">
:deep(.n-data-table-td) {
  .n-ellipsis {
    width: 100%;
    .expandItem {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      .expandItem-text {
        cursor: pointer;
        max-width: 88%;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        display: -webkit-box;
        overflow: hidden;
        word-break: break-all;
        text-overflow: ellipsis;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        white-space: pre-line;
      }
    }
    .slotError {
      color: #f56c6c;
      font-size: 10px;
      height: 10px;
      line-height: 10px;
      text-align: left;
      margin-top: 5px;
    }
  }
}
</style>
