<script setup lang="tsx">
import type { BarSeriesOption } from 'echarts/charts';
import type { DataTableCreateSummary } from 'naive-ui/es/data-table';
import { CommonApis } from '@/service/apis/common/common';
import { CallStatisticsApis } from '@/service/apis/ams/query-statistics/call-statistics';
import type { CallStatisticsType, TableListType } from '@/service/apis/ams/query-statistics/call-statistics';
import type { QueryType } from '@/service/apis/ams/query-statistics/personnel-repair-statistics';
import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';

const { hasExportPermission } = useRoutes();
// 呼叫异常类型
const { data: flowTypeList, isLoading: isLoadingFlowTypeList } = useAxiosGet<OptionsType[]>(
  CallStatisticsApis.getFlowTypeApi,
  undefined,
  undefined,
  { immediate: true }
);
// 用户组列表
const {
  data: allUserGroupsData,
  execute: executeGetAllUserGroups,
  isLoading: isLoadingAllUserGroups
} = useAxiosGet<OptionsType[]>(CallStatisticsApis.getAllUserGroupsApi);

// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);

const handleQueryProductLineList = () => executeGetProductLineList(__);
// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};
// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(CommonApis.getEqpsByLayoutIdsApi, {}, { paramsSerializer: useParamsSerializer() });
// 查询表单配置项
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryType>>({
  type: 6,
  treeIds: [],
  eqpName: [],
  flowType: null,
  timestamp: useFormatDateRange(14),
  userGroupIds: []
});

const schemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: computed(() => ({
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      labelField: 'name',
      keyField: 'id',
      multiple: true,
      cascade: true,
      checkable: true,
      onUpdateValue: (value: (string | number | null)[]) => {
        if (formData.value) formData.value.eqpName = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
            params: { layoutIds: value }
          })
          : handleQueryEquipmentNumberList();
      }
    }))
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: equipmentNumberChildList.value,
      loading: isLoadingAllUserGroups.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'select',
    model: 'userGroupIds',
    formItemProps: { label: i18nt('userGroup') },
    componentProps: {
      multiple: true,
      options: allUserGroupsData.value,
      loading: isLoadingEquipmentNumberChildList.value,
      labelField: 'name',
      valueField: 'id'
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('callTime') },
    componentProps: { type: 'datetimerange', clearable: false }
  },
  {
    type: 'select',
    model: 'flowType',
    formItemProps: { label: i18nt('abnormalityType') },
    componentProps: {
      options: flowTypeList.value,
      loading: isLoadingFlowTypeList.value,
      labelField: 'name',
      valueField: 'id'
    }
  }
]);
// 重构查询表单参数函数
const refactorFormQueryParams = (data: QueryType) => {
  if (!data.timestamp) return;
  return {
    ...data,
    ...useFormatDateTimeParams(data.timestamp)
  };
};
// 表格配置
const {
  handleSorterChange,
  pagination,
  handleResetPageSize,
  isLoadingQuery,
  tableData,
  mergedQueryFormData,
  executeQueryList: getCallStatistics,
  tableRef
} = useTable<CallStatisticsType>(CallStatisticsApis.getCallStatisticsApi, {
  queryFormParams: formData,
  paramsSerializerQuery: true,
  refactorFormQueryParams
});

const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(pagination),
  {
    title: i18nt('personnel'),
    key: 'name',
    sorter: true
  },
  { title: i18nt('numberOfRepairs'), key: 'num', sorter: true },
  { title: `${i18nt('downtimeDuration')}(${i18nt('minute')})`, key: 'downtime', sorter: true },
  {
    title: `${i18nt('averageDowntimeDuration')}(${i18nt('minute')})`,
    key: 'avgDownTime'
  }
];
// 总结栏
const createSummary: DataTableCreateSummary = () => {
  return {
    index: {
      value: <div />,
      colSpan: 1
    },
    name: {
      value: <div>{i18nt('grandTotal')}</div>,
      colSpan: 1
    },
    num: {
      value: <div> {tableData?.value?.totalNum || 0}</div>,
      colSpan: 1
    },
    downtime: {
      value: <div> {tableData?.value?.totalDownTime || 0}</div>,
      colSpan: 1
    },
    avgDownTime: {
      value: <div> {tableData?.value?.totalAvgDownTime || 0}</div>,
      colSpan: 1
    }
  };
};
// 图表配置
const chartRef = ref<ChartRefType | null>(null);
const xAxisData = ref<string[]>([]);
const callStatisticsBarData = ref<number[]>([]);
const downtimeDurationBarData = ref<number[]>([]);

const handleSearch = (list: TableListType[]) => {
  xAxisData.value = list.map(ele => ele.name) || [];
  callStatisticsBarData.value = list.map(ele => ele.num) || [];
  downtimeDurationBarData.value = list.map(ele => ele.downtime) || [];
  nextTick(() => {
    if (chartRef.value) {
      chartRef.value?.setOption(
        {
          ...BAR_OPTION,
          legend: {
            data: [i18nt('downtimeDuration'), i18nt('numberOfRepairs')]
          },
          xAxis: {
            name: i18nt('personnel'),
            type: 'category',
            data: xAxisData.value,
            nameGap: 30,
            axisTick: {
              alignWithLabel: true
            }
          },
          yAxis: [
            {
              type: 'value',
              name: i18nt('minute'),
              minInterval: 1
            },
            {
              type: 'value',
              name: i18nt('freq'),
              minInterval: 1,
              splitLine: {
                show: false
              }
            }
          ],
          dataZoom: useChartDataZoomOption(xAxisData.value.length),
          series: [
            {
              ...(BAR_OPTION.series as BarSeriesOption[])[0],
              type: 'bar',
              name: i18nt('downtimeDuration'),
              large: true,
              data: downtimeDurationBarData.value
            },
            {
              type: 'line',
              name: i18nt('numberOfRepairs'),
              yAxisIndex: 1,
              data: callStatisticsBarData.value
            }
          ]
        },
        true
      );
      chartRef.value?.resize();
    }
  });
};

tryOnMounted(async () => {
  handleQueryProductLineList();
  handleQueryEquipmentNumberList();
  await getCallStatistics();
  executeGetAllUserGroups();
});

watch(tableData, newValue => {
  if (!newValue) return;
  if (tableData.value?.callStatistics?.length === 0) {
    chartRef.value?.setEmptyOption();
  } else {
    handleSearch(newValue.callStatistics);
  }
});
// 按钮事件
const handleButton = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      handleResetPageSize();
      resetQueryField();
      getCallStatistics();
      handleQueryEquipmentNumberList();
    },
    search: () => {
      handleResetPageSize();
      getCallStatistics();
    },
    export: () => handleExport()
  };
  columnsList[permission as string]();
};
// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = useDownloadFile(
  CallStatisticsApis.getCallStatisticsApi
);
const handleExport = () => {
  let params = { ...mergedQueryFormData.value };
  if (formData) params = refactorFormQueryParams?.(params);
  executeExportData?.(params, {
    paramsSerializer: useParamsSerializer()
  });
};
</script>

<template>
  <div id="maintain--completion-analysis">
    <base-card>
      <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
        <template #header-action>
          <permission-button form :loading-props="{ searchLoading: isLoadingQuery }" @handle="handleButton" />
        </template>
      </base-form>
      <permission-button
        v-if="hasExportPermission"
        :loading-props="{ exportLoading: isLoadingExportData }"
        @handle="handleButton"
      />
      <!-- 默认 -->
      <base-table
        ref="tableRef"
        remote
        :columns="tableColumns"
        :data="tableData?.callStatistics ?? []"
        :loading="isLoadingQuery"
        :summary="createSummary"
        :pagination="pagination"
        @update:sorter="handleSorterChange"
      >
        <template #center>
          <div class="flex">
            <base-chart ref="chartRef" :loading="isLoadingQuery" />
          </div>
        </template>
      </base-table>
    </base-card>
  </div>
</template>
