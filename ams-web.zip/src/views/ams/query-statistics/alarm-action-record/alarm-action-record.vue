<script lang="tsx">
import { h } from 'vue';
import { renderSpan } from '../common';
import { actionCategoryList, actionCategoryObj, alarmActionType, resultOptions } from '@/views/ams/constants';
import BaseInputNumber from '@/components/base-ui/base-input-number/base-input-number.vue';
import { ActionStatus, AlarmActionRecordApis } from '@/service/apis/ams/query-statistics/alarm-action-record';
import type {
  ActionListType,
  ActionType,
  AlarmActionProps,
  ExecuteActionType,
  FormParamsProps,
  QueryActionInfoType
} from '@/service/apis/ams/query-statistics/alarm-action-record';
import { CommonApis } from '@/service/apis/common/common';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { AlarmActionListType } from '@/service/apis/ams/system-setting';

// 初始化查询表单
const initQueryFormSchemas = (
  executeGetEquipmentNumberList: ({ params }: { params: { layoutId: string; check: string } }) => void,
  updataEqpNameValue: (updataValue: { key: keyof Pick<QueryActionInfoType, 'eqpName'>; value: string[] }) => void,
  productLineList: Ref<OptionsType[] | undefined>,
  isLoadingProductLineList: Ref<boolean>,
  eqpNameList?: OptionsType[],
  isLoadingEqpName?: boolean,
  actionList?: AlarmActionProps[],
  queryFormData?: Nullable<QueryActionInfoType>,
  systemNameList?: Ref<OptionsType[] | undefined>,
  isLoadingsystemName?: Ref<boolean | undefined>
): FormSchemaType => {
  return [
    {
      type: 'tree-select',
      model: 'treeIds',
      formItemProps: { label: i18nt('productionLineLevel') },
      componentProps: {
        keyField: 'id',
        labelField: 'name',
        options: productLineList.value,
        loading: isLoadingProductLineList.value,
        multiple: true,
        checkable: true,
        cascade: true,
        onUpdateValue: (value: string) => {
          executeGetEquipmentNumberList({ params: { layoutId: value, check: '1' } });
          updataEqpNameValue({ key: 'eqpName', value: [] });
        }
      }
    },
    {
      type: 'select',
      model: 'eqpName',
      formItemProps: {
        label: i18nt('eqpName')
      },
      componentProps: {
        options: eqpNameList,
        loading: isLoadingEqpName,
        valueField: 'name',
        labelField: 'name',
        multiple: true
      }
    },
    {
      type: 'select',
      model: 'alarmAction',
      formItemProps: {
        label: i18nt('executeAction')
      },
      componentProps: {
        options: actionList,
        valueField: 'id',
        labelField: 'name'
      }
    },
    {
      type: 'select',
      model: 'systemName',
      formItemProps: {
        label: i18nt('systemName')
      },
      componentProps: {
        options: systemNameList?.value,
        labelField: 'name',
        valueField: 'id',
        loading: isLoadingsystemName?.value
      }
    },
    {
      type: 'input',
      model: 'alarmId',
      formItemProps: {
        label: i18nt('alarmCode')
      }
    },
    {
      type: 'input',
      model: 'txId',
      formItemProps: {
        label: i18nt('alarmID')
      }
    },
    {
      type: 'select',
      model: 'alarmActionCategory',
      formItemProps: {
        label: i18nt('actionCategory')
      },
      componentProps: {
        options: actionCategoryList
      }
    },
    {
      type: 'select',
      model: 'result',
      formItemProps: {
        label: i18nt('executeResult')
      },
      componentProps: {
        options: resultOptions,
        valueField: 'id',
        labelField: 'name'
      }
    },
    {
      type: 'custom-form-item',
      model: '',
      formItemProps: { label: i18nt('consuming') },
      render() {
        return h('div', { style: { width: '100%', display: 'flex', 'align-items': 'center' } }, [
          h(BaseInputNumber, {
            style: { width: '50%' },
            placeholder: `${i18nt('baseForm.pleaseInput')}${i18nt('startQueryRange')}`,
            min: 0,
            value: queryFormData?.consumingStart,
            'on-update:value': (num: number) => {
              queryFormData && (queryFormData.consumingStart = num);
            }
          }),
          h('span', { style: { padding: '0 6px' } }, '~'),
          h(BaseInputNumber, {
            style: { width: '50%' },
            placeholder: `${i18nt('baseForm.pleaseInput')}${i18nt('endQueryRange')}`,
            min: 0,
            value: queryFormData?.consumingEnd,
            'on-update:value': (val: number | null) => {
              queryFormData && (queryFormData.consumingEnd = val);
            }
          })
        ]);
      }
    },
    {
      type: 'date-picker',
      model: 'timestamp',
      modelValue: 'formatted-value',
      formItemProps: { label: i18nt('occurredTime') },
      componentProps: { type: 'datetimerange', clearable: false }
    }
  ];
};

const initFormSchemas = (
  formData: FormParamsProps,
  resultOptions: { id: number; name: string }[],
  executeActionColumns: DataTableColumns<ExecuteActionType>,
  actionList?: AlarmActionProps[]
): FormSchemaType => {
  return [
    {
      type: 'custom-form-item',
      model: 'eqpID',
      formItemProps: {
        label: i18nt('eqpId')
      },
      render() {
        return renderSpan(formData.eqpID);
      }
    },
    {
      type: 'custom-form-item',
      model: 'alarmID',
      formItemProps: {
        label: i18nt('alarmCode')
      },
      render() {
        return renderSpan(formData.alarmID);
      }
    },
    {
      type: 'custom-form-item',
      model: 'txId',
      formItemProps: {
        label: i18nt('alarmID')
      },
      render() {
        return renderSpan(formData.txId);
      }
    },
    {
      type: 'custom-form-item',
      model: 'systemTime',
      formItemProps: {
        label: i18nt('occurredTime')
      },
      render() {
        return renderSpan(formData.systemTime);
      }
    },
    {
      type: 'custom-form-item',
      model: 'alarmAction',
      formItemProps: {
        label: i18nt('executeAction')
      },
      render() {
        const find = (actionList || []).find((c: AlarmActionProps) => c.id.toString() === formData.alarmAction);
        return renderSpan(find?.name || '');
      }
    },
    {
      type: 'custom-form-item',
      formItemProps: {
        label: i18nt('actionCategory')
      },
      formItemClass: 'w-full!',
      render() {
        return actionCategoryObj[formData.alarmActionCategory] || '';
      }
    },
    {
      type: 'custom-form-item',
      formItemProps: {
        label: i18nt('executeResult')
      },
      formItemClass: 'w-full!',
      render() {
        const findRes = resultOptions.find(act => act.id === Number(formData.result)) || { id: 0, name: '' };
        return useRenderTableSingleTag(ActionStatus[findRes?.id || 0] as TagStateType, findRes?.name || '');
      }
    },
    {
      type: 'custom-form-item',
      model: 'systemName',
      formItemProps: {
        label: i18nt('systemName')
      },
      formItemClass: 'col-span-2!',
      render() {
        return renderSpan(formData.systemName);
      }
    },
    {
      type: 'custom-form-item',
      model: 'relatedPersons',
      formItemProps: {
        label: i18nt('relatedInformation')
      },
      formItemClass: 'col-span-2!',
      render() {
        return renderSpan(formData.relatedPersons);
      }
    },
    {
      type: 'custom-form-item',
      model: 'remark',
      formItemProps: {
        label: i18nt('remark')
      },
      formItemClass: 'col-span-2!',
      render() {
        return renderSpan(formData.remark);
      }
    },
    formData?.details
      ? {
          type: 'custom-form-item',
          model: '',
          formItemProps: {
            label: ''
          },
          formItemClass: 'col-span-2! ',
          render() {
            return <base-table class="w-90%! ml-5%!" columns={executeActionColumns} data={formData.details} />;
          }
        }
      : __
  ];
};

const createColumns = (
  curdRef: Ref<CurdRefType<QueryActionInfoType, ActionType, ActionListType> | undefined>,
  pagination: ComputedRef<PaginationProps | undefined>,
  actionList?: AlarmActionProps[]
): DataTableColumns<ActionListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    key: 'txId',
    title: i18nt('alarmID'),
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render: (rowData: ActionListType) =>
      useRenderTableTitleEdit(rowData.txId, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  {
    title: i18nt('eqpId'),
    key: 'eqpID',
    sorter: true,
    width: TABLE_WIDTH_DATE
  },
  {
    title: i18nt('alarmCode'),
    key: 'alarmID',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  { title: i18nt('systemName'), key: 'systemName', width: TABLE_WIDTH_DATE },
  { title: i18nt('occurredTime'), key: 'systemTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  {
    title: i18nt('executeAction'),
    key: 'alarmAction',
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      const find = (actionList || [] || []).find((c: AlarmActionProps) => c.id.toString() === rowData.alarmAction);
      return h('span', find?.name || '');
    }
  },
  {
    title: i18nt('actionCategory'),
    key: 'alarmActionCategory',
    sorter: true,
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      return actionCategoryObj[rowData.alarmActionCategory] || '';
    }
  },
  {
    title: i18nt('executeResult'),
    key: 'result',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      const find = resultOptions.find(c => c.id === Number(rowData.result));
      return useRenderTableSingleTag(ActionStatus[find?.id || 0] as TagStateType, find?.name || '');
    }
  },
  { key: 'alarmActionConsuming', title: i18nt('consuming'), sorter: true, width: TABLE_WIDTH_DATE },
  { title: i18nt('relatedInformation'), key: 'relatedPersons', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('remark'), key: 'remark' }
];
</script>

<script setup lang="tsx">
// 模板引用
const curdRef = ref<CurdRefType<QueryActionInfoType, ActionType, ActionListType>>();
const curdRefPagination = computed(() => curdRef.value?.pagination);
// 执行动作列表
const { execute: executegetAllActionsList } = useAxiosGet<AlarmActionListType[]>(
  AlarmSystemSettingApis.getAllActionsApi
);
const actionList = ref<AlarmActionListType[]>([]);

// 系统名称
const {
  data: systemNameList,
  isLoading: isLoadingsystemName,
  execute: getSystemNameList
} = useAxiosGet<OptionsType[]>(CommonApis.getSystemNameListApi);

// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);

// 获取设备编号列表
const {
  data: equipmentNumberList,
  isLoading: isLoadingEquipmentNumberList,
  execute: executeGetEquipmentNumberList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi, {}, { paramsSerializer: useParamsSerializer() });
tryOnMounted(async () => {
  try {
    const { data } = await executegetAllActionsList();
    actionList.value =
      data.value?.map(ele => {
        return {
          id: ele.id,
          name: alarmActionType[ele.id] ? i18nt(alarmActionType[ele.id]) : ''
        };
      }) || [];
    executeGetProductLineList();
    executeGetEquipmentNumberList();
    getSystemNameList();
  } catch (error) {
    actionList.value = [];
  }
});
// 查询表单
const queryFormParams: Nullable<QueryActionInfoType> = {
  eqpName: [],
  treeIds: null,
  txId: null,
  alarmId: null,
  alarmAction: null,
  result: null,
  alarmActionCategory: null,
  timestamp: useFormatDateRange(),
  consumingStart: null,
  consumingEnd: null,
  systemName: []
};
const queryFormSchemas = computed<FormSchemaType>(() =>
  initQueryFormSchemas(
    executeGetEquipmentNumberList,
    updataEqpNameValue,
    productLineList,
    isLoadingProductLineList,
    equipmentNumberList.value,
    isLoadingEquipmentNumberList.value,
    actionList.value,
    curdRef.value?.queryFormData,
    systemNameList,
    isLoadingsystemName
  )
);
// 查看详情
const formParams: Nullable<FormParamsProps> = {
  eqpID: null,
  alarmID: null,
  systemTime: null,
  alarmAction: null,
  result: null,
  remark: null,
  alarmActionConsuming: null,
  relatedPersons: null,
  alarmActionCategory: null,
  txId: null,
  systemName: null,
  details: []
};
const executeActionColumns: DataTableColumns<ExecuteActionType> = [
  { title: i18nt('receivingAccount'), key: 'userID', width: TABLE_WIDTH_NAME },
  { title: i18nt('receivingIdentifier'), key: 'account' },
  {
    title: i18nt('executeResult'),
    key: 'result',
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      const findRes = resultOptions.find(act => act.id === rowData.result) || { id: 0, name: '' };
      return useRenderTableSingleTag(ActionStatus[findRes?.id || 0] as TagStateType, findRes?.name || '');
    }
  },
  { title: i18nt('occurredTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME }
];

const formSchemas = computed<FormSchemaType>(() =>
  initFormSchemas(curdRef.value?.formData as FormParamsProps, resultOptions, executeActionColumns, actionList.value)
);
// 表格
const tableColumns = computed(() => createColumns(curdRef, curdRefPagination, actionList.value));

const refactorFormQueryParams = (data: QueryActionInfoType) => ({
  ...data,
  ...useFormatDateTimeParams(data.timestamp)
});

const updataEqpNameValue = (updataValue: { key: keyof Pick<QueryActionInfoType, 'eqpName'>; value: string[] }) => {
  curdRef.value?.queryFormData && (curdRef.value.queryFormData[updataValue.key] = updataValue.value);
};

const handlePermission = (permission: PermissionType) => {
  if (permission === 'reset') {
    executeGetEquipmentNumberList();
  }
};
</script>

<template>
  <div id="alarm-action-history">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      params-serializer-query
      :form-params="formParams"
      :form-schemas="formSchemas"
      :columns="tableColumns"
      :read-api="AlarmActionRecordApis.getListApi"
      :edit-detail-api="AlarmActionRecordApis.getInfoApi"
      :export-api="AlarmActionRecordApis.getListApi"
      :refactor-form-query-params="refactorFormQueryParams"
      @handle="handlePermission"
    />
  </div>
</template>
