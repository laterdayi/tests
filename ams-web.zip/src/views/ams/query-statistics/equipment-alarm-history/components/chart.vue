<script setup lang="ts">
import type { CustomSeriesOption } from 'echarts/charts';
import type { CustomSeriesRenderItemAPI, CustomSeriesRenderItemReturn } from 'echarts/types/dist/shared.js';
import { useChart } from '@/components/base-chart/use-chart/use-chart';
import echarts from '@/plugins/core/echarts';
import type { ECOption } from '@/plugins/core/echarts';
import type { EchartsType, StatisticsDataType } from '@/service/apis/ams/query-statistics/equipment-alarm-history';

interface PropsType {
  // 标题
  title?: string;
  // 标题位置
  xAxisData?: MixedArray;
  // 数据源
  seriesData: EchartsType[];
  // 提示信息
  statisticsData: StatisticsDataType[];
  // dataZoom
  dataZoom?: boolean;
  // 标题位置
  titleAlign?: 'left' | 'right' | 'center';
}

const props = defineProps<PropsType>();

const emit = defineEmits<{
  'open-modal': [item: EchartsType];
}>();

const renderItem = (params: CustomSeriesRenderItemParamsType, api: CustomSeriesRenderItemAPI) => {
  const categoryIndex = api.value(0);
  const start = api.coord([api.value(1), categoryIndex]);
  const end = api.coord([api.value(2), categoryIndex]);
  const height = (api?.size?.([0, 1]) as number[])[1] * 0.6;
  const rectShape = echarts.graphic.clipRectByRect(
    {
      x: start[0],
      y: start[1],
      width: end[0] - start[0],
      height
    },
    {
      x: params.coordSys.x as number,
      y: params.coordSys.y as number,
      width: params.coordSys.width as number,
      height: params.coordSys.height as number
    }
  );
  return (
    rectShape &&
    ({
      type: 'rect',
      transition: ['shape'],
      shape: rectShape,
      style: { ...api.style() }
    } as CustomSeriesRenderItemReturn)
  );
};
// 处理tooltip时间
const timeHandle = (str: number) => {
  const time = useFormatDate(str, 'MM-DD HH:mm:ss SSS');
  const timeList = time.split(' ');
  return `${timeList[0]} ${timeList[1]}.${timeList[2]}`;
};
const initOptions: ECOption = {
  tooltip: {
    formatter: params => {
      if (!Array.isArray(params)) {
        const value = params.value as [number, number, number, { state: string; startTime: string; endTime: string }];
        const data = params?.data as { alarmCount: string };
        return `
        ${params?.marker} ${params?.name}<br/>
        ${i18nt('startTime')}: ${timeHandle(value[1])}<br/>
        ${i18nt('endTime')}: ${timeHandle(value[2])}<br/>
        ${i18nt('alarmNumber')}: ${data?.alarmCount}
      `;
      }
      return '';
    }
  },
  title: {
    text: props.title,
    left: 'left'
  },
  xAxis: {
    axisLabel: {
      formatter: (val: number) => useFormatDate(val, 'MM-DD HH:mm:ss'),
      showMinLabel: true,
      showMaxLabel: true
    },
    splitLine: {
      show: false
    },
    max: val => val.max,
    min: val => val.min
  },
  grid: { height: 100, top: '0%', left: '90px', right: '90px' },
  yAxis: { show: false, data: [] },
  series: [
    {
      type: 'custom',
      renderItem,
      itemStyle: {
        opacity: 0.8
      },
      encode: { x: [1, 2], y: 0 },
      data: []
    }
  ]
};
const { elRef, getInstance, setOption, option, setEmptyOption } = useChart({ initOptions });
// 空数据
const isEmptyData = () => {
  let isOk = false;
  if (!props.seriesData.length) {
    setEmptyOption();
    isOk = true;
  }
  return isOk;
};

tryOnMounted(() => {
  if (isEmptyData()) return;
  const _options: ECOption = { ...option };
  if (option) setOption(_options, true);
  getInstance()?.on('click', params => {
    if (params.color === '#00FF00') return;
    emit('open-modal', params.data as EchartsType);
  });
});

watch(
  () => props.seriesData,
  newVal => {
    if (option?.series) {
      (option.series as CustomSeriesOption[])[0] = {
        ...(option.series as CustomSeriesOption[])[0],
        data: toRaw(newVal)
      };
    }
    if (option) setOption(option, true);
  },
  {
    immediate: true
  }
);
</script>

<template>
  <div id="chart">
    <div ref="elRef" class="h-150px! w-full" v-bind="$attrs" />
    <div class="statistics-list">
      <div v-for="(item, index) in statisticsData" :key="index" class="statistics">
        <div class="h-10px statisticsColor w-26px" :style="{ backgroundColor: item.color }" />
        <div class="statisticsText">{{ i18nt('lengthOfTime') }}: {{ item.totalInterval }}</div>
        <div>{{ i18nt('percent') }}: {{ item.percent }}%</div>
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped>
.statistics-list {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  width: 100%;
  padding: 0 50px;
  margin-bottom: 16px;

  .statistics {
    display: flex;
    align-items: center;
    margin-right: 16px;
    font-size: 12px;
    color: #303133;
    .statisticsColor {
      border-radius: 10px;
    }
    .statisticsText {
      margin: 0 8px;
    }
  }
}
</style>
