<script setup lang="tsx">
import { actionCategoryObj, alarmActionType } from '@/views/ams/constants';
import type {
  ActionInfoType,
  DetailFormType,
  EchartsType,
  HandleOpenModalHistoryType,
  LotInfoType,
  ModalListType,
  OperateRecordType
} from '@/service/apis/ams/query-statistics/equipment-alarm-history';
import { EquipmentAlarmHistoryApis } from '@/service/apis/ams/query-statistics/equipment-alarm-history';

// 弹窗开启
const modalIsShow = ref(false);
// 获取详情
const refactorFormQueryParams = (data: HandleOpenModalHistoryType) => {
  return { ...data, ...queryData.value };
};
const {
  handleSorterChange,
  pagination,
  isLoadingQuery: alarmSliceDetailLoading,
  tableData,
  handleReset,
  executeQueryList: getList
} = useTable<DetailFormType[]>(EquipmentAlarmHistoryApis.getAlarmSliceDetailApi, { refactorFormQueryParams });

//  打开弹窗
const appStore = useAppStore();
const { local } = storeToRefs(appStore);
const modalList = ref<ModalListType[]>();
const queryData = ref<HandleOpenModalHistoryType>();
const handleOpenModal = async (item: EchartsType) => {
  handleReset();
  modalList.value = [];
  expandedList.value = [];
  try {
    queryData.value = {
      eqpId: item.name,
      startTime: item.startTime,
      endTime: item.endTime,
      language: local.value === 'zh-CN' ? 0 : 1
    };
    await getList();
    modalIsShow.value = true;
  } catch (error) {
    console.log(error);
  }
};
watch(tableData, newValue => {
  if (!newValue) return;
  modalList.value = newValue.map(ele => {
    const {
      id,
      eqpID,
      alarmID,
      alarmStartTime,
      alarmEndTime,
      lotInfo,
      actionInfo,
      additionalInfo,
      alarmConsuming,
      ...obj
    } = ele;
    return {
      id,
      eqpID,
      alarmID,
      alarmStartTime,
      alarmEndTime,
      expandIsShow: false,
      formData: {
        ...obj,
        id,
        eqpID,
        alarmID,
        alarmStartTime,
        alarmEndTime,
        alarmConsuming: alarmConsuming.toString()
      },
      lotInfo,
      actionInfo,
      additionalInfo
    } as ModalListType;
  });
});
const renderSpan = (value?: string | number, style?: CSSProperties) => {
  return h('span', { style: { 'font-weight': 'bold', ...style } }, value);
};

// 表单
const formSchemas = (data: DetailFormType): FormSchemaType => {
  return [
    {
      type: 'custom-form-item',
      model: 'eqpID',
      formItemProps: { label: i18nt('eqpName') },
      render() {
        return renderSpan(data.eqpID);
      }
    },
    {
      type: 'custom-form-item',
      model: 'systemName',
      formItemProps: { label: i18nt('systemName') },
      render() {
        return renderSpan(data.systemName);
      }
    },
    {
      type: 'custom-form-item',
      model: 'alarmID',
      formItemProps: { label: i18nt('alarmCode') },
      render() {
        return renderSpan(data.alarmID);
      }
    },
    {
      type: 'custom-form-item',
      model: 'txId',
      formItemProps: { label: i18nt('alarmID') },
      render() {
        return renderSpan(data.txId);
      }
    },
    {
      type: 'custom-form-item',
      model: 'alarmStartTime',
      formItemProps: { label: i18nt('alarmStartTime') },
      render() {
        return renderSpan(data.alarmStartTime);
      }
    },
    {
      type: 'custom-form-item',
      model: 'alarmEndTime',
      formItemProps: { label: i18nt('alarmEndTime') },
      render() {
        return renderSpan(data.alarmEndTime);
      }
    },
    {
      type: 'switch',
      model: 'isEqpAlarm',
      formItemProps: { label: i18nt('machineSelfAlarm') },
      componentProps: { checkedValue: 1, uncheckedValue: 0 },
      formItemClass: 'w-min!'
    },
    {
      type: 'custom-form-item',
      model: 'duration',
      formItemProps: { label: i18nt('duration') },
      render() {
        return renderSpan(data.duration);
      }
    },
    {
      type: 'custom-form-item',
      model: 'alarmConsuming',
      formItemProps: { label: i18nt('consuming') },
      render() {
        return renderSpan(data.alarmConsuming);
      }
    },
    {
      type: 'custom-form-item',
      model: 'treeId',
      formItemProps: { label: i18nt('productionLineLevel') },
      render() {
        return renderSpan(data.treeId);
      }
    },
    {
      type: 'custom-form-item',
      model: 'createTime',
      formItemProps: { label: i18nt('createTime') },
      render() {
        return renderSpan(data.createTime);
      }
    },
    data.closedBy
      ? {
          type: 'custom-form-item',
          model: 'closedBy',
          formItemProps: { label: i18nt('closePerson') },
          render() {
            return renderSpan(data.closedBy);
          }
        }
      : __,
    data.closeReason
      ? {
          type: 'custom-form-item',
          model: 'closeReason',
          formItemProps: { label: i18nt('closeReason') },
          render() {
            return renderSpan(data.closeReason);
          }
        }
      : __,
    {
      type: 'custom-form-item',
      model: 'alarmDesc',
      formItemProps: { label: i18nt('alarmDescription') },
      render() {
        return renderSpan(data.alarmDesc);
      }
    }
  ];
};
// 批次明细
const lotInfoColumns: DataTableColumns<LotInfoType> = [
  { title: i18nt('lotNumebr'), key: 'lotId' },
  { title: 'Port', key: 'lotPortId' },
  { title: 'Chamber', key: 'chamberId' },
  { title: 'Product', key: 'productId' },
  { title: 'Carrier ID', key: 'carrierId' },
  { title: 'Batch ID', key: 'batchId' },
  { title: 'Reserved', key: 'reserved' },
  { title: 'State', key: 'state' }
];
// 执行结果处理
const executeResultType: {
  [key: number]: {
    type: string;
    name: string;
  };
} = {
  0: {
    type: TagState.warning,
    name: i18nt('processing')
  },
  1: {
    type: TagState.success,
    name: i18nt('success')
  },
  2: {
    type: TagState.primary,
    name: i18nt('failed')
  }
};
// 执行动作明细
const actionInfoColumns: DataTableColumns<ActionInfoType> = [
  { title: i18nt('eqpName'), key: 'eqpID' },
  { title: i18nt('alarmCode'), key: 'alarmID' },
  { title: i18nt('occurredTime'), key: 'systemTime', width: TABLE_WIDTH_DATETIME },
  {
    title: i18nt('executeAction'),
    key: 'alarmAction',
    render(rowData) {
      return alarmActionType[rowData.alarmAction as number]
        ? i18nt(alarmActionType[rowData.alarmAction as number])
        : '';
    }
  },
  {
    title: i18nt('actionCategory'),
    key: 'alarmActionCategory',
    width: TABLE_WIDTH_INFO,
    render(rowData) {
      return actionCategoryObj[rowData.alarmActionCategory] || '';
    }
  },
  {
    title: i18nt('executeResult'),
    key: 'result',
    render(rowData) {
      return useRenderTableSingleTag(
        executeResultType[rowData.result].type as TagStateType,
        executeResultType[rowData.result].name
      );
    }
  },
  { title: i18nt('consuming'), key: 'alarmActionConsuming', width: TABLE_WIDTH_DATE },
  { title: i18nt('relatedInformation'), key: 'relatedPersons' },
  { title: i18nt('remark'), key: 'remark' }
];
// 操作记录
const operateRecordColumns: DataTableColumns<OperateRecordType> = [
  { title: i18nt('alarmReason'), key: 'alarmReason' },
  { title: i18nt('alarmProcessMethod'), key: 'alarmDispose' },
  { title: i18nt('operator'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('operateTime'), key: 'operateTime', width: TABLE_WIDTH_DATETIME }
];
const expandedList = ref<(string | number)[]>([]);
const style = { cursor: 'pointer' };
const tableColumns: DataTableColumns<ModalListType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX,
    render(rowData, rowIndex: number) {
      return (
        <span
          class="expandItem"
          onClick={() => tableRowClick(rowData)}
          style={{
            ...style,
            justifyContent: 'center'
          }}
        >
          {rowIndex + 1 + ((pagination?.value?.page ?? 1) - 1) * (pagination?.value?.pageSize ?? 10)}
        </span>
      );
    }
  },
  {
    title: i18nt('alarmCode'),
    key: 'alarmID',
    sorter: true,
    width: TABLE_WIDTH_INFO,
    titleColSpan: 2,
    colSpan: () => 2,
    ellipsis: {
      tooltip: true
    },
    render(rowData) {
      return (
        <div class="expandItem" style={style}>
          <div onClick={() => tableRowClick(rowData)}>
            {!rowData.expandIsShow ? (
              <base-icon color={`${appStore.themePrimary}`} icon="i-carbon:chevron-right" />
            ) : (
              <base-icon color={`${appStore.themePrimary}`} icon="i-carbon:chevron-down" />
            )}
          </div>
          <base-tooltip
            disabled={!(rowData.alarmID.length > 16)}
            placement="bottom"
            trigger="hover"
            v-slots={{
              trigger: () => (
                <span
                  class="expandItem-text"
                  onClick={() => tableRowClick(rowData)}
                  style={{
                    borderWidth: '0px',
                    color: `${appStore.themePrimary}`,
                    marginLeft: '10px'
                  }}
                >
                  {rowData.alarmID}
                </span>
              )
            }}
          >
            <span> {rowData.alarmID} </span>
          </base-tooltip>
        </div>
      );
    }
  },
  {
    type: 'expand',
    expandable: () => true,
    renderExpand: rowData => {
      return (
        <div class="px py">
          {rowData.expandIsShow ? (
            <div>
              <base-Form
                disabled
                layout="dialog"
                modelValue={rowData.formData}
                schemas={formSchemas(rowData.formData)}
              />
              <div class="card-title">{i18nt('batchDetail')}</div>
              <base-table columns={lotInfoColumns} data={rowData.lotInfo} />
              <div class="card-title m-t-12px">{i18nt('executeActionDetail')}</div>
              <base-table class="m-b-12px" columns={actionInfoColumns} data={rowData.actionInfo} />
              <div class="card-title m-t-12px">{i18nt('operateRecord')}</div>
              <base-table class="m-b-12px" columns={operateRecordColumns} data={rowData.additionalInfo} />
            </div>
          ) : (
            __
          )}
        </div>
      );
    }
  },
  {
    title: i18nt('eqpId'),
    key: 'eqpId',
    render(rowData) {
      return (
        <span class="expandItem " onClick={() => tableRowClick(rowData)} style={style}>
          {rowData.eqpID}
        </span>
      );
    }
  },
  {
    title: i18nt('alarmStartTime'),
    sorter: true,
    key: 'alarmStartTime',
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render(rowData) {
      return (
        <span class="expandItem " onClick={() => tableRowClick(rowData)} style={style}>
          {rowData.alarmStartTime}
        </span>
      );
    }
  },
  {
    title: i18nt('alarmEndTime'),
    key: 'alarmEndTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render(rowData) {
      return (
        <span class="expandItem " onClick={() => tableRowClick(rowData)} style={style}>
          {rowData.alarmEndTime}
        </span>
      );
    }
  }
];
const tableRowClick = (row: ModalListType) => {
  if (row.expandIsShow) {
    const index = expandedList.value.findIndex(ele => ele === row.id);
    expandedList.value.splice(index, 1);
  } else {
    expandedList.value.push(row.id);
  }
  row.expandIsShow = !row.expandIsShow;
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-70%!"
    :show="modalIsShow"
    :title="$t('viewDetail')"
    :positive-text="__"
    @close="cancelModal"
    @negative-click="cancelModal"
  >
    <base-table
      :loading="alarmSliceDetailLoading"
      :expanded-row-keys="expandedList"
      :columns="tableColumns"
      :data="modalList"
      :pagination="pagination"
      remote
      @update:sorter="handleSorterChange"
    />
  </base-modal>
</template>

<style scoped lang="less">
:deep(.n-data-table-td) {
  .n-ellipsis {
    width: 100%;
    .expandItem {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      .expandItem-text {
        cursor: pointer;
        max-width: 88%;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        display: -webkit-box;
        overflow: hidden;
        word-break: break-all;
        text-overflow: ellipsis;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        white-space: pre-line;
      }
    }
  }
}
</style>
