<script setup lang="tsx">
import Chart from './components/chart.vue';
import detailForm from './components/detail-form.vue';
import type {
  AlarmSliceType,
  EchartsType,
  QueryType,
  SeriesDataType
} from '@/service/apis/ams/query-statistics/equipment-alarm-history';
import { EquipmentAlarmHistoryApis } from '@/service/apis/ams/query-statistics/equipment-alarm-history';
import { CommonApis } from '@/service/apis/common/common';

const appStore = useAppStore();
const { local } = storeToRefs(appStore);
const echartRef = ref();
const detailFormRef = ref();
//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelQueryApi,
  __,
  __,
  {
    immediate: true
  }
);
//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
handleQueryEquipmentList();
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });

// 表单
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<QueryType>({
  timestamp: useFormatDateRange(1),
  treeIds: [],
  eqpNames: []
});

// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: {
      type: 'datetimerange',
      clearable: false
    }
  },
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        formData.value.eqpNames = []
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
              params: { layoutIds: value }
            })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpNames',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'name'
    }
  }
]);
// 获取全部数据
const {
  data: alarmSliceList,
  isLoading: isLoadingAlarmSliceList,
  execute: getAlarmSlice
} = useAxiosGet<AlarmSliceType[]>(EquipmentAlarmHistoryApis.getAlarmSliceApi, __, {
  paramsSerializer: useParamsSerializer()
});
// onMounted生命周期
const seriesDataNew = ref<SeriesDataType[]>([]);
tryOnMounted(async () => {
  try {
    await getAlarmSlice({
      params: useOmitNilRequestParams({
        ...formData.value,
        ...useFormatDateTimeParams(formData.value.timestamp),
        language: local.value === 'zh-CN' ? 0 : 1
       })
    });
    seriesDataHandle(alarmSliceList.value || []);
  } catch (error) {
    console.log(error);
  }
});
const seriesDataHandle = (list: AlarmSliceType[]) => {
  seriesDataNew.value = list.map((ele: AlarmSliceType, echartIndex: number) => {
    return {
      id: ele.id,
      levelCount: ele.levelCount,
      levelName: ele.levelName,
      echartIsShow:
        echartIndex === 0 ? true : !(!(formData.value.treeIds.length !== 0) && !(formData.value.eqpNames.length !== 0)),
      // echartIsShow: true,
      datas: ele.datas.map((eleLevel, index: number) => {
        return {
          name: eleLevel.eqpId,
          datas: eleLevel.datas.map(eleEchart => {
            return {
              name: eleLevel.eqpId,
              alarmCount: eleEchart.alarmCount,
              startTime: eleEchart.startTime,
              endTime: eleEchart.endTime,
              value: [
                index,
                new Date(eleEchart.startTime).getTime(),
                new Date(eleEchart.endTime).getTime(),
                eleEchart.interval
              ],
              itemStyle: {
                color: eleEchart.color
              }
            };
          }),
          statisticsData: eleLevel.statisticsData
        };
      })
    };
  });
};

// 产线层级点击事件
const echartsClick = (item: SeriesDataType) => {
  item.echartIsShow = !item.echartIsShow;
};
const getAlarmSliceReset = async () => {
  seriesDataNew.value = [];
  alarmSliceList.value = [];
  await getAlarmSlice({
    params: useOmitNilRequestParams({
      ...formData.value,
      ...useFormatDateTimeParams(formData.value.timestamp),
        language: local.value === 'zh-CN' ? 0 : 1
    })
  });
  seriesDataHandle(alarmSliceList.value || []);
};
// 按钮事件
const handleButton = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      resetQueryField();
      handleQueryEquipmentList();
      getAlarmSliceReset();
    },
    search: () => {
      getAlarmSliceReset();
    }
  };
  columnsList[permission as string]();
};
// 打开详情
const openModal = (item: EchartsType) => {
  detailFormRef?.value?.handleOpenModal(item);
};
</script>

<template>
  <base-card id="spares-basic-information">
    <!-- 搜索 -->
    <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
      <template #header-action>
        <permission-button form :loading-props="{ searchLoading: isLoadingAlarmSliceList }" @handle="handleButton" />
      </template>
    </base-form>
    <div v-for="item in seriesDataNew" :key="item.id" class="levelList">
      <div class="level" @click="echartsClick(item)">{{ item.levelName }} ({{ item.levelCount }})</div>
      <div v-if="item.echartIsShow">
        <chart
          v-for="(itemChart, index) in item.datas"
          :key="index"
          ref="echartRef"
          :series-data="itemChart.datas"
          :title="itemChart.name"
          :statistics-data="itemChart.statisticsData"
          @open-modal="openModal"
        />
      </div>
    </div>

    <detailForm ref="detailFormRef" />
  </base-card>
</template>

<style lang="less" scoped>
.levelList {
  width: 98%;
  margin-left: 2%;
  border-bottom: 4px solid #f3f3f3;
  .level {
    cursor: pointer;
    line-height: 50px;
    font-size: 20px;
    font-weight: bold;
    color: #333639;
  }
}
</style>
