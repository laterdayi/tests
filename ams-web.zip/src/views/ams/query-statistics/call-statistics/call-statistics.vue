<script setup lang="tsx">
import type { BarSeriesOption } from 'echarts/charts';
import type { CallbackDataParams } from 'echarts/types/dist/shared.js';
import type { DataTableCreateSummary } from 'naive-ui/es/data-table';
import { CommonApis } from '@/service/apis/common/common';
import { CallStatisticsApis } from '@/service/apis/ams/query-statistics/call-statistics';
import type {
  CallStatisticsType,
  QueryType,
  TableListType,
  typeListType
} from '@/service/apis/ams/query-statistics/call-statistics';
import { BAR_OPTION } from '@/components/base-chart/use-chart/options/bar';

const { hasExportPermission } = useRoutes();
// 呼叫异常类型
const { data: flowTypeList, isLoading: isLoadingFlowTypeList } = useAxiosGet<OptionsType[]>(
  CallStatisticsApis.getFlowTypeApi,
  undefined,
  undefined,
  { immediate: true }
);

// 获取权限产线层级列表
const {
  data: productLineList,
  execute: executeGetProductLineList,
  isLoading: isLoadingProductLineList
} = useAxiosGet<OptionsType[]>(CommonApis.getProductionLineLevelQueryApi);
const handleQueryProductLineList = () => executeGetProductLineList(__);
// 获取设备编号列表
const { execute: executeGetEquipmentNumberList } = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberListApi);
const handleQueryEquipmentNumberList = async () => {
  try {
    const { data } = await executeGetEquipmentNumberList();
    equipmentNumberChildList.value = data.value;
  } catch (error) {
    console.log(error);
  }
};
// 获取子设备编号列表
const {
  data: equipmentNumberChildList,
  isLoading: isLoadingEquipmentNumberChildList,
  execute: executeGetEquipmentNumberChildList
} = useAxiosGet<OptionsType[]>(CommonApis.getEqpsByLayoutIdsApi, {}, { paramsSerializer: useParamsSerializer() });
// 查询表单配置项
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryType>>({
  type: 1,
  treeIds: [],
  eqpName: [],
  // timestamp: useFormatDateRange(14, { format: 'YYYY-MM-DD' })
  timestamp: useFormatDateRange(14),
  timeFlag: 0,
  flowType: null
});

const typeList: typeListType[] = [
  { id: 5, name: i18nt('eqpType') },
  { id: 4, name: i18nt('eqpName') },
  { id: 1, name: i18nt('statisticsByDay') },
  { id: 2, name: i18nt('statisticsByWeek') },
  { id: 3, name: i18nt('statisticsByMonth') }
];

const schemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'type',
    formItemProps: { label: i18nt('abscissa') },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      options: typeList,
      clearable: false
    }
  },
  {
    type: 'select',
    model: 'timeFlag',
    formItemProps: { label: i18nt('timeType') },
    componentProps: {
      clearable: false,
      options: [
        {
          label: i18nt('callTime'),
          value: 0
        },
        {
          label: i18nt('closingTime'),
          value: 1
        }
      ]
    }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: formData.value.timeFlag === 1 ? i18nt('closingTime') : i18nt('callTime') },
    componentProps: { type: 'datetimerange', clearable: false }
  },
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: computed(() => ({
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      labelField: 'name',
      keyField: 'id',
      multiple: true,
      cascade: true,
      checkable: true,
      onUpdateValue: (value: (string | number | null)[]) => {
        if (formData.value) formData.value.eqpName = [];
        value?.length
          ? executeGetEquipmentNumberChildList(__, {
              params: { layoutIds: value }
            })
          : handleQueryEquipmentNumberList();
      }
    }))
  },
  {
    type: 'select',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      multiple: true,
      options: equipmentNumberChildList.value,
      loading: isLoadingEquipmentNumberChildList.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'select',
    model: 'flowType',
    formItemProps: { label: i18nt('abnormalityType') },
    componentProps: {
      options: flowTypeList.value,
      loading: isLoadingFlowTypeList.value,
      labelField: 'name',
      valueField: 'id'
    }
  }
]);
// 重构查询表单参数函数
const refactorFormQueryParams = (data: QueryType) => {
  if (!data.timestamp) return;
  return {
    ...data,
    ...useFormatDateTimeParams(data.timestamp)
  };
};
// 表格配置
const {
  handleSorterChange,
  pagination,
  handleResetPageSize,
  isLoadingQuery,
  tableData,
  mergedQueryFormData,
  executeQueryList: getCallStatistics,
  tableRef
} = useTable<CallStatisticsType>(CallStatisticsApis.getCallStatisticsApi, {
  queryFormParams: formData,
  paramsSerializerQuery: true,
  refactorFormQueryParams
});

const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(pagination),
  {
    title: () => {
      return xName.value;
    },
    key: 'name',
    sorter: true
  },
  { title: i18nt('callsNumber'), key: 'num', sorter: true },
  { title: `${i18nt('downtimeDuration')}(${i18nt('minute')})`, key: 'downtime', sorter: true },
  {
    title: `${i18nt('averageDowntimeDuration')}(${i18nt('minute')})`,
    key: 'avgDownTime'
  },
  { title: `${i18nt('downtimeRatio')}(%)`, key: 'downRate', sorter: true }
];
// 总结栏
const createSummary: DataTableCreateSummary = () => {
  return {
    index: {
      value: <div />,
      colSpan: 1
    },
    name: {
      value: <div>{i18nt('grandTotal')}</div>,
      colSpan: 1
    },
    num: {
      value: <div> {tableData?.value?.totalNum || 0}</div>,
      colSpan: 1
    },
    downtime: {
      value: <div> {tableData?.value?.totalDownTime || 0}</div>,
      colSpan: 1
    },
    avgDownTime: {
      value: <div> {tableData?.value?.totalAvgDownTime || 0}</div>,
      colSpan: 1
    },
    downRate: {
      value: <div> {tableData?.value?.totalDownTimeRate || 0}</div>,
      colSpan: 1
    }
  };
};
// 图表配置
const chartRef = ref<ChartRefType | null>(null);
const xName = ref<string>('');
const handleSearch = (list: TableListType[]) => {
  const xAxisData = list.map(ele => ele.name) || [];

  const downtimeDurationBarData = list.map(ele => ele.downtime) || [];
  const callStatisticsBarData = list.map(ele => ele.num) || [];
  const downRatelineData = list.map(ele => ele.downRate) || [];
  nextTick(() => {
    if (chartRef.value) {
      chartRef.value?.setOption(
        {
          ...BAR_OPTION,
          legend: {
            data: [i18nt('downtimeDuration'), i18nt('callsNumber'), i18nt('downtimeRatio')]
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'shadow'
            },
            formatter: params => {
              const data = params as CallbackDataParams[];
              let dataStr = `<div><p  style="font-weight:bold;margin:8px;">${data[0].name}</p></div>`;
              for (let i = 0; i < data.length; i++) {
                dataStr += `
                <div style="margin: 0 8px;">
                  <span style="display:inline-block;margin-right:5px;width:10px;height:10px;background-color:${
                    data[i].color
                  };"></span>
                  <span>${data[i].seriesName}</span>
                  <span style="float:right;color:#000000;margin-left:20px;">${data[i].data}${i === 2 ? ' %' : ''}</span>
                </div>`;
              }

              return dataStr;
            }
          },
          yAxis: [
            {
              type: 'value',
              name: i18nt('minute'),
              minInterval: 1
            },
            {
              type: 'value',
              name: i18nt('freq'),
              minInterval: 1,
              splitLine: {
                show: false
              }
            }
          ],
          xAxis: {
            name: xName.value,
            type: 'category',
            data: xAxisData,
            nameGap: 30,
            axisTick: {
              alignWithLabel: true
            }
          },
          dataZoom: useChartDataZoomOption(xAxisData.length),
          series: [
            {
              ...(BAR_OPTION.series as BarSeriesOption[])[0],
              type: 'bar',
              name: i18nt('downtimeDuration'),
              large: true,
              data: downtimeDurationBarData
            },
            {
              type: 'line',
              name: i18nt('callsNumber'),
              yAxisIndex: 1,
              data: callStatisticsBarData,
              label: {
                show: true
              }
            },
            {
              type: 'line',
              name: i18nt('downtimeRatio'),
              yAxisIndex: 1,
              data: downRatelineData,
              label: {
                show: true
              }
            }
          ]
        },
        true
      );
      chartRef.value?.resize();
    }
  });
};

tryOnMounted(async () => {
  handleQueryProductLineList();
  handleQueryEquipmentNumberList();
  await getCallStatistics();
});
watch(tableData, newValue => {
  if (!newValue) return;
  const xObj = typeList.find(ele => ele.id === formData.value.type);
  xName.value = xObj ? xObj.name : '';
  if (tableData.value?.callStatistics?.length === 0) {
    chartRef.value?.setEmptyOption();
  } else {
    handleSearch(newValue.callStatistics);
  }
});
// 按钮事件
const handleButton = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      handleResetPageSize();
      resetQueryField();
      getCallStatistics();
      handleQueryEquipmentNumberList();
    },
    search: () => {
      getCallStatistics();
    },
    export: () => handleExport()
  };
  columnsList[permission as string]();
};

// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = useDownloadFile(
  CallStatisticsApis.getCallStatisticsApi
);
const handleExport = () => {
  let params = { ...mergedQueryFormData.value };
  if (formData) params = refactorFormQueryParams?.(params);
  executeExportData?.(params, {
    paramsSerializer: useParamsSerializer()
  });
};
</script>

<template>
  <div id="maintain--completion-analysis">
    <base-card>
      <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
        <template #header-action>
          <permission-button form :loading-props="{ searchLoading: isLoadingQuery }" @handle="handleButton" />
        </template>
      </base-form>
      <permission-button
        v-if="hasExportPermission"
        :loading-props="{ exportLoading: isLoadingExportData }"
        @handle="handleButton"
      />
      <!-- 默认 -->
      <base-table
        ref="tableRef"
        remote
        :loading="isLoadingQuery"
        :pagination="pagination"
        :columns="tableColumns"
        :data="tableData?.callStatistics || []"
        :summary="createSummary"
        @update:sorter="handleSorterChange"
      >
        <template #center>
          <div class="flex">
            <base-chart ref="chartRef" :loading="isLoadingQuery" />
          </div>
        </template>
      </base-table>
    </base-card>
  </div>
</template>
