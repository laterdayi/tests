export const styles = {
  'font-weight': 'bold'
};

export const renderSpan = (value?: string | number, style?: CSSProperties) => {
  return h('span', { style: { ...styles, ...style } }, value);
};
