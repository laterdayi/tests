<script setup lang="tsx">
import modifyRecordModel from './components/modify-record-model.vue';
import { OperateRecordApis } from '@/service/apis/ams/operate-record/delete-record';
import type { QueryType, TableListType } from '@/service/apis/ams/operate-record/delete-record';

const appStore = useAppStore();
const { local } = storeToRefs(appStore);
// 模板引用
const curdRef = ref<CurdRefType<QueryType, undefined, TableListType>>();
// 查询表单配置
const queryFormParams: Nullable<QueryType> = {
  old: null,
  tableName: 'AlarmSettingEntity',
  operateType: 'Delete',
  timestamp: useFormatDateRange(7),
  language: local.value === 'zh-CN' ? 0 : 1
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'old',
    formItemProps: { label: i18nt('deletedContent') }
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
]);
// 重构查询
const refactorFormQueryParams = (data: QueryType) => ({ ...data, ...useFormatDateTimeParams(data.timestamp) });
const curdRefPagination = computed(() => curdRef.value?.pagination);
// 表格数据配置
const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('deletedContent'),
    key: 'old',
    sorter: true
  },
  {
    title: i18nt('deletedBy'),
    key: 'creator',
    sorter: true,
    width: TABLE_WIDTH_NAME
  },
  { title: i18nt('deletionTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME_MILLISECOND },
  useRenderTableActionColumn({
    width: TABLE_WIDTH_ACTION,
    render(row) {
      return (
        <base-button onClick={() => modifyRecordCLick(row)} text type="primary">
          {i18nt('modifyRecord')}
        </base-button>
      );
    }
  })
];
// 修改历史记录
const modifyRecordModelRef = ref();
const modifyRecordCLick = ({ keyId }: { keyId: string }) => {
  modifyRecordModelRef?.value?.handleOpenModal(keyId);
};
</script>

<template>
  <div id="spares-model-manage">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :read-api="OperateRecordApis.getListApi"
      :export-api="OperateRecordApis.getListApi"
    />
    <!-- 修改记录 -->
    <modifyRecordModel ref="modifyRecordModelRef" />
  </div>
</template>
