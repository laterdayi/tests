<script setup lang="tsx">
import { SystemLogApis } from '@/service/apis/ams/operate-record/system-log';
import type { QueryType, TableListType } from '@/service/apis/ams/operate-record/system-log';
import { CommonApis } from '@/service/apis/common/common';

const appStore = useAppStore();
const { local } = storeToRefs(appStore);
// 获取设备编号列表
const { data: eqpIdList, isLoading: isLoadingEqpId } = useAxiosGet<OptionsType[]>(
  CommonApis.getEquipmentNumberIdListApi,
  __,
  __,
  {
    immediate: true
  }
);
// 获取 获取日志级别
const { data: alarmLevelList, isLoading: isLoadingAlarmLevel } = useAxiosGet<OptionsType[]>(
  SystemLogApis.alarmLevelListApi,
  __,
  __,
  {
    immediate: true
  }
);
// 获取获取系统名称
const { data: systemNameList, isLoading: isLoadingSystemName } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi,
  __,
  __,
  {
    immediate: true
  }
);
// 模板引用
const curdRef = ref<CurdRefType<QueryType, undefined, TableListType>>();
// 查询表单配置
const queryFormParams: Nullable<QueryType> = {
  name: null,
  eqpId: null,
  alarmId: null,
  logLevel: null,
  systemName: null,
  timestamp: useFormatDateRange(7),
  language: local.value === 'zh-CN' ? 0 : 1
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'name',
    formItemProps: { label: i18nt('keyWord') }
  },

  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('eqpId') },
    componentProps: computed(() => ({
      options: eqpIdList.value,
      labelField: 'name',
      valueField: 'name',
      loading: isLoadingEqpId.value
    }))
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: { label: i18nt('alarmCode') }
  },
  {
    type: 'select',
    model: 'logLevel',
    formItemProps: { label: i18nt('logLevel') },
    componentProps: computed(() => ({
      options: alarmLevelList.value,
      labelField: 'enumName',
      valueField: 'enumName',
      loading: isLoadingAlarmLevel.value
    }))
  },
  {
    type: 'select',
    model: 'systemName',
    formItemProps: { label: i18nt('systemName') },
    componentProps: computed(() => ({
      options: systemNameList.value,
      labelField: 'name',
      valueField: 'id',
      loading: isLoadingSystemName.value
    }))
  },
  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('timeRange') },
    componentProps: { type: 'datetimerange', clearable: false }
  }
]);
// 重构查询
const refactorFormQueryParams = (data: QueryType) => ({ ...data, ...useFormatDateTimeParams(data.timestamp) });
const curdRefPagination = computed(() => curdRef.value?.pagination);
// 表格数据配置
const logLevelObj: { [key: string]: string } = {
  INFO: '#FFFFFF',
  WARNING: '#FFFF00',
  ERROR: '#FF0000',
  FATAL: '#A52A2A'
};
const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('eqpId'),
    key: 'eqpId',
    sorter: true,
    width: TABLE_WIDTH_NAME
  },
  {
    title: i18nt('alarmCode'),
    key: 'alarmId',
    sorter: true,
    width: TABLE_WIDTH_NAME
  },
  {
    title: i18nt('logLevel'),
    key: 'logLevel',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return (
        <base-tag color={{ color: logLevelObj[rowData.logLevel], textColor: '#000000' }} size="small">
          {rowData.logLevel}
        </base-tag>
      );
    }
  },

  {
    title: i18nt('systemName'),
    key: 'systemName',
    sorter: true,
    width: TABLE_WIDTH_NAME
  },
  { title: i18nt('description'), key: 'logDesc', sorter: true },
  { title: i18nt('alarmInfo'), key: 'message' },
  { title: i18nt('iPAddress'), key: 'ip', sorter: true, width: TABLE_WIDTH_IP },
  { title: i18nt('remark'), key: 'remark' },
  { title: i18nt('createTime'), key: 'logTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];
</script>

<template>
  <div id="spares-model-manage">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :read-api="SystemLogApis.getListApi"
      :export-api="SystemLogApis.getListApi"
    />
  </div>
</template>
