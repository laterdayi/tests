<script setup lang="tsx">
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { GetGeneralSettingsType, PtFormType } from '@/service/apis/ams/system-setting';

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 获取通用设置
const { isLoading: isLoadingGetCallCommonSetting, execute: executeCallCommonSetting } = useAxiosGet<PtFormType>(
  AlarmSystemSettingApis.getCallCommonSettingApi
);

const handleUpReportGet = async () => {
  try {
    const { data } = await executeCallCommonSetting();
    if (!data.value) return;
    updateField({
      ...data.value,
      mailSendTime: data.value.mailSendTime === '' ? null : data.value.mailSendTime,
      morningShiftTime: data.value.morningShiftTime === '' ? null : data.value.morningShiftTime,
      productTopRefreshTime: data.value.productTopRefreshTime || 5,
      refreshTime: data.value.refreshTime || 10,
      rollTime: data.value.rollTime || 3
    });
  } catch (error) {
    console.log('获取通用设置', error);
  }
};
tryOnMounted(() => {
  handleUpReportGet();
});
// 页面表单
const { formData, formRef, updateField } = useForm<Nullable<PtFormType>>({
  // callTotalUseTime: null,
  mailSendTime: null,
  morningShiftTime: null,
  productTopRefreshTime: 5,
  refreshTime: 10,
  rollTime: 3
});

const generalSettingsFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'time-picker',
    model: 'mailSendTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('emailReminderTime')
    },
    componentProps: {
      clearable: false,
      format: 'HH:mm',
      valueFormat: 'HH:mm',
      class: 'w-100%!'
    }
  },
  {
    type: 'time-picker',
    model: 'morningShiftTime',
    modelValue: 'formatted-value',
    formItemProps: {
      label: i18nt('productionEarlyShiftTim')
    },
    componentProps: {
      clearable: false,
      format: 'HH:mm',
      valueFormat: 'HH:mm',
      class: 'w-100%!'
    }
  },
  {
    type: 'input-number',
    model: 'productTopRefreshTime',
    formItemProps: {
      label: i18nt('equipmentRefreshFrequency')
    },
    componentProps: {
      min: 5,
      max: 15,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, i18nt('minute')) }]
  },
  {
    type: 'input-number',
    model: 'refreshTime',
    formItemProps: {
      label: i18nt('dashboardRefreshFrequency')
    },
    componentProps: {
      min: 10,
      max: 20,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, i18nt('second')) }]
  },
  {
    type: 'input-number',
    model: 'rollTime',
    formItemProps: {
      label: i18nt('dashboardScrollingFrequency')
    },
    componentProps: {
      min: 3,
      max: 10,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, i18nt('second')) }]
  }
]);

// 通用设置保存
const { isLoading: isLoadingSetCallCommonSetting, execute: executeSetCallCommonSetting } = useAxiosPost<
  GetGeneralSettingsType[]
>(AlarmSystemSettingApis.setCallCommonSettingApi);
const handleAddGeneralSetting = async () => {
  try {
    await executeSetCallCommonSetting(__, {
      data: {
        ...formData.value
      }
    });
    handleUpReportGet();
  } catch (error) {
    console.log('保存通用设置', error);
  }
};
</script>

<template>
  <base-spin :show="isLoadingSetCallCommonSetting || isLoadingGetCallCommonSetting">
    <div class="flex justify-between">
      <base-form
        ref="formRef"
        v-model="formData"
        layout="base"
        :schemas="generalSettingsFormSchemas"
        :label-width="200"
      />
      <base-button
        :size="componentSize"
        :loading="isLoadingSetCallCommonSetting"
        :disabled="isLoadingSetCallCommonSetting"
        type="primary"
        button-name="save"
        @click="handleAddGeneralSetting"
      >
        {{ $t('save') }}
      </base-button>
    </div>
  </base-spin>
</template>

<style scoped lang="less">
.noData {
  color: #c0c0c0;
  font-size: 18px;
}
</style>
