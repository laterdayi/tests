<script setup lang="ts">
import { ref } from 'vue';
import { alarmActionEnum } from '@/views/ams/constants';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';

interface FormProps {
  holdlotSwicth: '0' | '1';
  holdeqpSwitch: '0' | '1';
  sendEmailSwitch: '0' | '1';
  sendwxSwitch: '0' | '1';
  lockeqpSwitch: '0' | '1';
}

const initQueryFormData = ref<FormProps>({
  holdlotSwicth: '1',
  holdeqpSwitch: '1',
  sendEmailSwitch: '1',
  sendwxSwitch: '0',
  lockeqpSwitch: '0'
});

const queryFormSchemas: FormSchemaType = alarmActionEnum.map(item => {
  return {
    type: 'switch',
    model: item.model,
    formItemProps: {
      label: i18nt(item.name)
    },
    componentProps: {
      checkedValue: 1,
      uncheckedValue: 0
    }
  };
});

const { execute } = useAxiosGet<FormProps>(AlarmSystemSettingApis.getActionInfoApi);

const { execute: saveExecute, isLoading } = useAxiosPost<FormProps>(AlarmSystemSettingApis.saveSettingApi);

const init = async () => {
  try {
    const { data } = await execute();
    initQueryFormData.value = data.value as FormProps;
  } catch (error) {
    console.log(error);
  }
};

const update = async () => {
  try {
    await saveExecute({ data: initQueryFormData.value });
    // 错误的情况回退状态
    await init();
  } catch (error) {
    console.log(error);
  }
};

init();
</script>

<template>
  <div class="flex justify-between">
    <base-form v-model="initQueryFormData" :schemas="queryFormSchemas" layout="base" :label-width="160" />
    <base-button button-name="save" type="primary" :loading="isLoading" :disabled="isLoading" @click="update">
      {{ $t('save') }}
    </base-button>
  </div>
</template>
