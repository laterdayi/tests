<script setup lang="tsx">
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type { AlarmDashboardSettingType } from '@/service/apis/ams/system-setting';

//  获取报警看板设置
const { isLoading: isLoadingGetAlarmDashboard, execute: executeGetAlarmDashboard }
  = useAxiosGet<AlarmDashboardSettingType>(AlarmSystemSettingApis.getAlarmDashboardSettingApi);
const handleGetAlarmDashboard = async () => {
  try {
    const { data } = await executeGetAlarmDashboard();
    if (data.value?.interval && data.value.alarmNums) {
      updateField(data.value);
    }
  } catch (error) {
    console.log('获取报警看板设置', error);
  }
};
tryOnMounted(() => {
  handleGetAlarmDashboard();
});
//  设置报警看板设置
const { formData, updateField, validate, formRef } = useForm<Nullable<AlarmDashboardSettingType>>({
  interval: 10,
  alarmNums: 20
});

const initFormSchemas = (): FormSchemaType => [
  {
    type: 'input-number',
    model: 'interval',
    formItemProps: {
      label: i18nt('timeRefreshFrequency'),
      rule: useRules('input-number', i18nt('timeRefreshFrequency'))
    },
    componentSlots: [{ name: 'suffix', render: () => h('span', null, i18nt('second')) }]
  },
  {
    type: 'input-number',
    model: 'alarmNums',
    formItemProps: { label: i18nt('displayAlarmNumber'), rule: useRules('input-number', i18nt('displayAlarmNumber')) },
    componentProps: { max: 100 },
    componentSlots: [{ name: 'suffix', render: () => h('span', null, i18nt('baseTable.strip')) }]
  }
];
const { isLoading: isLoadingSetAlarmDashboard, execute: executeSetAlarmDashboard } = useAxiosPost(
  AlarmSystemSettingApis.setAlarmDashboardSettingApi
);
// 保存
const handleSubmitAlarmDashboad = async () => {
  try {
    await validate();
    await executeSetAlarmDashboard(__, { data: formData.value });
    handleGetAlarmDashboard();
  } catch (error) {
    console.log('报警看板设置', error);
  }
};
</script>

<template>
  <base-spin :show="isLoadingGetAlarmDashboard || isLoadingSetAlarmDashboard">
    <div class="flex justify-between">
      <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="initFormSchemas()" :label-width="200" />
      <base-button
        :loading="isLoadingSetAlarmDashboard"
        :disabled="isLoadingSetAlarmDashboard"
        type="primary"
        button-name="save"
        @click="handleSubmitAlarmDashboad"
      >
        {{ $t('save') }}
      </base-button>
    </div>
  </base-spin>
</template>

<style scoped lang="less">
.noData {
  color: #c0c0c0;
  font-size: 18px;
}
</style>
