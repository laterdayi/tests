<script setup lang="tsx">
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting';
import type {
  GeneralSettingsType,
  GeneralSettingsTypeListType,
  GetGeneralSettingsType,
  GroupUserSettingType,
  LockTypeSettingType,
  UpReportSettingType,
  WorkWXGroupNotifySettingType
} from '@/service/apis/ams/system-setting';
import { CommonApis } from '@/service/apis/common/common';

// 获取系统名称
const { data: systemNameData, execute: executeSystemNameList } = useAxiosGet<OptionsType[]>(
  CommonApis.getSystemNameListApi
);
// 获取webHook
const workWXGroup = ref<Nullable<WorkWXGroupNotifySettingType>>({
  webhookKey: null,
  systemName: null
});
const { execute: executeGetWorkWechat } = useAxiosGet<WorkWXGroupNotifySettingType>(
  AlarmSystemSettingApis.getWorkWechatGroupSettingApi
);

// 获取通用设置
const { isLoading: isLoadingGetGeneralSettin, execute: executeUpReportGet } = useAxiosGet<GetGeneralSettingsType[]>(
  AlarmSystemSettingApis.getGeneralSettingApi
);
// 通用设置处理(此处数据变动随时增加删除)
const generalSettingsTypeList = ref<GeneralSettingsTypeListType[]>([]);
// 是否拥有数据
const noDataIsShow = ref<boolean>(false);
const handleUpReportGet = async () => {
  try {
    const { data } = await executeUpReportGet();
    if (!data.value) return;
    noDataIsShow.value = data.value.length !== 0;
    generalSettingsTypeList.value = data.value.map(ele => {
      return {
        key: ele.name,
        type: ele.type
      };
    });
    generalSettingsFormData.value = data.value.reduce((acc: GeneralSettingsType, cur: GetGeneralSettingsType) => {
      const index = generalSettingsTypeList.value.findIndex(ele => ele.key === cur.name);
      if (index !== -1) {
        const typeKey = generalSettingsTypeList.value[index].type as keyof GetGeneralSettingsType;
        acc[typeKey] = cur[typeKey] as string &
          UpReportSettingType &
          LockTypeSettingType &
          GroupUserSettingType &
          WorkWXGroupNotifySettingType;
        return acc;
      }
      return {};
    }, {} as GeneralSettingsType);
    if (generalSettingsFormData.value.workWXGroup) {
      generalSettingsFormData.value.workWXGroup.systemName =
        generalSettingsFormData.value.workWXGroup.systemName === ''
          ? null
          : generalSettingsFormData.value.workWXGroup.systemName;
      await executeSystemNameList();
      if (workWXGroup.value.systemName) {
        workWechatHandle(workWXGroup.value.systemName);
      }
    }
  } catch (error) {
    noDataIsShow.value = false;
    generalSettingsTypeList.value = [];
    generalSettingsFormData.value = {};
    console.log('获取通用设置', error);
  }
};
tryOnMounted(() => {
  handleUpReportGet();
});
// 页面表单
const { formData: generalSettingsFormData, formRef: generalSettingsFormRef } = useForm<Nullable<GeneralSettingsType>>({
  upReport: {
    upReportLimit: null,
    notifyType: 0,
    notifyByAllLevel: 1
  },
  lockType: {
    lockType: 0
  },
  groupUser: {
    isSyncGroupUser: 1
  },
  workWXGroup: {
    webhookKey: null,
    systemName: null
  }
});
// 处理通用设置表单Schemas
const generalSettingsTypeObj: {
  [key: string]: (type: string) => FormSchemaType;
} = {
  // 逐级上报设置
  UpReportSetting: (type: string) => {
    const data = generalSettingsFormData.value[type as keyof GeneralSettingsType] as UpReportSettingType;
    return [
      {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: '' },
        render() {
          return (
            <div
              style={{
                textAlign: 'center',
                width: '100%',
                marginLeft: '200px',
                fontWeight: 'bold'
              }}
            >
              {i18nt('gradualReportingSettings')}
            </div>
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: {
          label: i18nt('reportingLevel'),
          rule: {
            required: true,
            trigger: ['blur', 'input'],
            validator: () => {
              if (!data.upReportLimit) {
                return new Error(`${i18nt('baseForm.pleaseInput')}${i18nt('reportingLevel')}`);
              }
            }
          }
        },
        render() {
          if (!data) return;
          return (
            <base-input-number
              class="w-100%!"
              max={3}
              min={1}
              v-model:value={data.upReportLimit}
              v-slots={{
                suffix: () => <span>{i18nt('level')}</span>
              }}
            >
            </base-input-number>
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('notifyUserType') },
        render() {
          if (!data) return;
          return (
            <base-select
              class="w-100%!"
              clearable={false}
              options={[
                {
                  label: i18nt('notifyByUser'),
                  value: 0
                },
                {
                  label: i18nt('notifyByUserGroup'),
                  value: 1
                }
              ]}
              v-model:value={data.notifyType}
            />
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('notifySubordinateUsers') },
        render() {
          if (!data) return;
          return <base-switch checked-value={1} unchecked-value={0} v-model:value={data.notifyByAllLevel} />;
        }
      }
    ];
  },
  // 锁机设置
  LockTypeSetting: (type: string) => {
    const data = generalSettingsFormData.value[type as keyof GeneralSettingsType] as LockTypeSettingType;
    return [
      {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: '' },
        render() {
          return (
            <div
              style={{
                textAlign: 'center',
                width: '100%',
                marginLeft: '200px',
                fontWeight: 'bold'
              }}
            >
              {i18nt('lockSettings')}
            </div>
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('lockType') },
        render() {
          if (!data) return;
          return <base-switch checked-value={1} unchecked-value={0} v-model:value={data.lockType} />;
        }
      }
    ];
  },
  // 用户组设置
  GroupUserSetting: (type: string) => {
    const data = generalSettingsFormData.value[type as keyof GeneralSettingsType] as GroupUserSettingType;
    return [
      {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: '' },
        render() {
          return (
            <div
              style={{
                textAlign: 'center',
                width: '100%',
                marginLeft: '200px',
                fontWeight: 'bold'
              }}
            >
              {i18nt('userGroupConfiguration')}
            </div>
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('notifyUsersSynchronously') },
        render() {
          if (!data) return;
          return <base-switch checked-value={1} unchecked-value={0} v-model:value={data.isSyncGroupUser} />;
        }
      }
    ];
  },
  // 企业微信群组通知置
  WorkWXGroupNotifySetting: (type: string) => {
    const data = generalSettingsFormData.value[type as keyof GeneralSettingsType] as WorkWXGroupNotifySettingType;
    return [
      {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: '' },
        render() {
          return (
            <div
              style={{
                textAlign: 'center',
                width: '100%',
                marginLeft: '200px',
                fontWeight: 'bold'
              }}
            >
              {i18nt('generalSettingsTips')}
            </div>
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('systemName') },
        render() {
          if (!data) return;
          return (
            <base-select
              class="w-100%!"
              clearable={false}
              label-field="name"
              on-update:value={(value: string) => {
                workWechatHandle(value);
              }}
              options={systemNameData.value}
              placeholder={`${i18nt('baseForm.pleaseSelect')}${i18nt('systemName')}`}
              v-model:value={data.systemName}
              value-field="id"
            />
          );
        }
      },
      {
        type: 'custom-form-item',
        formItemProps: { label: 'Webhook' },
        render() {
          if (!data) return;
          return (
            <div class="w-100%!">
              <base-input
                autosize={{
                  minRows: 9,
                  maxRows: 9
                }}
                class="w-100%! mb"
                onInput={(val: string) => {
                  data.webhookKey = val.replace(/[ \t\n\r]+/g, '');
                }}
                placeholder={`${i18nt('baseForm.pleaseInput')}Webhook,${i18nt('spcUserGroupBindingTips')}`}
                type="textarea"
                v-model:value={data.webhookKey}
              />
              <div class="webhookTips">* {i18nt('generalSettingsTips2')}</div>
            </div>
          );
        }
      }
    ];
  }
};
// 处理webhook
const workWechatHandle = async (systemName: string) => {
  try {
    const { data: workWechatData } = await executeGetWorkWechat({
      params: {
        systemName
      }
    });
    if (!workWechatData.value) return;
    generalSettingsFormData.value.workWXGroup = {
      webhookKey: workWechatData.value.webhookKey,
      systemName
    };
  } catch (error) {
    console.log(error);
  }
};
const generalSettingsFormSchemas = computed<FormSchemaType>(() => {
  return generalSettingsTypeList.value.reduce((acc: FormSchemaType, cur: GeneralSettingsTypeListType) => {
    return [...acc, ...(generalSettingsTypeObj[cur.key] ? generalSettingsTypeObj[cur.key](cur.type) : [])];
  }, []);
});

// 通用设置保存
const { isLoading: isLoadingAddGeneralSetting, execute: executeAddGeneralSetting } = useAxiosPost<
  GetGeneralSettingsType[]
>(AlarmSystemSettingApis.addGeneralSettingApi);
const handleAddGeneralSetting = async () => {
  try {
    if (generalSettingsFormData.value.upReport && !generalSettingsFormData.value.upReport.upReportLimit) return;
    if (generalSettingsFormData.value.workWXGroup) {
      workWXGroup.value = { ...generalSettingsFormData.value.workWXGroup };
    }
    await executeAddGeneralSetting(__, {
      data: generalSettingsTypeList.value.map(ele => {
        return {
          name: ele.key,
          [ele.type]: {
            ...(generalSettingsFormData.value[ele.type as keyof GeneralSettingsType] as GeneralSettingsType)
          }
        };
      })
    });
    handleUpReportGet();
  } catch (error) {
    console.log('保存通用设置', error);
  }
};
</script>

<template>
  <base-spin :show="isLoadingAddGeneralSetting || isLoadingGetGeneralSettin">
    <div v-if="noDataIsShow" class="flex justify-between">
      <base-form
        ref="generalSettingsFormRef"
        v-model="generalSettingsFormData"
        layout="base"
        :schemas="generalSettingsFormSchemas"
        :label-width="200"
      />
      <base-button
        :loading="isLoadingAddGeneralSetting"
        :disabled="isLoadingAddGeneralSetting"
        type="primary"
        button-name="save"
        @click="handleAddGeneralSetting"
      >
        {{ $t('save') }}
      </base-button>
    </div>
    <div v-else class="mt noData text-center w-100%">{{ i18nt('noData') }}</div>
  </base-spin>
</template>

<style scoped lang="less">
.noData {
  color: #c0c0c0;
  font-size: 18px;
}
:deep(.n-form-item-blank) {
  .webhookTips {
    margin-left: 12px;
    font-size: 14px;
    color: #f56c6c;
    line-height: 20px;
  }
}
</style>
