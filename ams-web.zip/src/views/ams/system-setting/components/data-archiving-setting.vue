<script setup lang="ts">
import { ref } from 'vue';
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting.js';

interface FormProps {
  holdlotSwicth: '0' | '1';
  holdeqpSwitch: '0' | '1';
  sendEmailSwitch: '0' | '1';
  sendwxSwitch: '0' | '1';
  lockeqpSwitch: '0' | '1';
}

const initQueryFormData = ref<FormProps>({
  holdlotSwicth: '1',
  holdeqpSwitch: '1',
  sendEmailSwitch: '1',
  sendwxSwitch: '0',
  lockeqpSwitch: '0'
});
const queryFormSchemas: FormSchemaType = [
  {
    type: 'switch',
    model: 'holdlotSwicth',
    formItemProps: {
      label: i18nt('HoldLot')
    },
    componentProps: {
      checkedValue: '1',
      uncheckedValue: '0'
    }
  },
  {
    type: 'switch',
    model: 'holdeqpSwitch',
    formItemProps: {
      label: i18nt('HoldEquipment')
    },
    componentProps: {
      checkedValue: '1',
      uncheckedValue: '0'
    }
  },
  {
    type: 'switch',
    model: 'sendEmailSwitch',
    formItemProps: {
      label: i18nt('SendEmail')
    },
    componentProps: {
      checkedValue: '1',
      uncheckedValue: '0'
    }
  },
  {
    type: 'switch',
    model: 'sendwxSwitch',
    formItemProps: {
      label: i18nt('SendSMS')
    },
    componentProps: {
      checkedValue: '1',
      uncheckedValue: '0'
    }
  },
  {
    type: 'switch',
    model: 'lockeqpSwitch',
    formItemProps: {
      label: i18nt('LockEquipment')
    },
    componentProps: {
      checkedValue: '1',
      uncheckedValue: '0'
    }
  }
];

const { execute } = useAxiosGet<FormProps>(AlarmSystemSettingApis.getActionInfoApi);
const { execute: saveExecute, isLoading } = useAxiosPost<FormProps>(AlarmSystemSettingApis.saveSettingApi);

const save = () => {
  saveExecute({ data: initQueryFormData.value });
};

execute().then(res => {
  initQueryFormData.value = res.data.value as FormProps;
});
</script>

<template>
  <base-card :title="$t('dataArchivingSetting')">
    <base-form
      v-model="initQueryFormData"
      :schemas="queryFormSchemas"
      layout="base"
      label-placement="top"
      label-align="left"
    />
    <div class="flex">
      <base-button button-name="save" type="primary" :loading="isLoading" :disabled="isLoading" @click="save">
        {{ $t('save') }}
      </base-button>
    </div>
  </base-card>
</template>

<style scoped lang="less">
.typeList {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  .title {
    font-size: 1rem;
    font-weight: var(--n-title-font-weight);
    transition: color var(--duration) var(--n-bezier);
    color: var(--n-title-text-color);
  }
  .text {
    font-size: var(--n-font-size);
    color: var(--n-text-color);
  }
}
.typeActive {
  background: #f0faff;

  .title {
    color: #2d8cf0;
  }
  .text {
    color: #2d8cf0;
  }
}
</style>
