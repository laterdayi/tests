<script lang="ts" setup>
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting.js';
import { CommonApis } from '@/service/apis/common/common';
import tinymce from '@/components/project/tinymce/tinymce.vue';
import type { EditorType, NestedMenuItemContents, ToolbarType } from '@/components/project/tinymce/type';

// 获取模版名称
const { data: selectItemData, execute: executeGetSelectItem } = useAxiosGet<OptionsType[]>(
  CommonApis.getSelectItemListApi,
  {
    type: AttributeType.templateType,
    responseType: 1
  }
);

const templateName = ref<string>(i18nt('templateName'));
const templateNameList = ref<ToolbarType[]>([]);
const menuDateButtonList = ref<ToolbarType[]>([]);

tryOnMounted(async () => {
  try {
    await tinymceRef.value.initWrapper();
    const { data } = await executeGetSelectItem();
    if (!data.value) return;
    templateNameList.value = data.value.map(ele => {
      return {
        value: `{${ele.id}}`,
        text: ele.id
      };
    });
  } catch (error) {
    console.log(error);
  }
});
// 获取钉钉模版设置
const { execute: executeMailTemplate } = useAxiosGet<string>(AlarmSystemSettingApis.getDingTalkTemplateApi);
// 获取默认回填
const getMailTemplate = async () => {
  try {
    const { data } = await executeMailTemplate({
      params: {
        templateName: templateName.value
      }
    });
    tinymceRef?.value?.setContent(data.value || '');
  } catch (error) {
    console.log(error);
  }
};
// 保存钉钉模版设置
const { isLoading, execute: executeSaveMailTemplate } = useAxiosPost(AlarmSystemSettingApis.dingTalkTemplateSettingApi);
const save = () => {
  if (templateName.value === i18nt('templateName')) {
    $message.error(i18nt('baseForm.pleaseSelect') + i18nt('templateName'));
    return;
  }
  executeSaveMailTemplate({ data: { templateName: templateName.value, content: tinymceRef?.value?.getContent() } });
};
// 富文本配置
const tinymceRef = ref();
const toolbar = `templateName | menuDateButton`;
const editorSetup = (editor: EditorType) => {
  editor.ui.registry.addMenuButton('templateName', {
    text: templateName.value,
    fetch: callback => {
      const items = templateNameList.value.map(opt => {
        return {
          type: 'menuitem',
          text: opt.text,
          onAction: async () => {
            const item = selectItemData.value?.find(ele => ele.id === opt.text);
            menuDateButtonList.value =
              item?.name.split(',').map(ele => {
                return {
                  value: `{${ele}}`,
                  text: ele
                };
              }) || [];
            templateName.value = opt.text;

            await getMailTemplate();
            editor?.destroy();
            editor.remove();
            await tinymceRef.value.initWrapper();
          }
        };
      });
      callback(items as NestedMenuItemContents[]);
    }
  });
  if (menuDateButtonList.value.length !== 0) {
    editor.ui.registry.addMenuButton('menuDateButton', {
      text: i18nt('selectParam'),
      fetch: callback => {
        const items: NestedMenuItemContents[] = menuDateButtonList.value.map(opt => {
          return {
            type: 'menuitem',
            text: opt.text,
            onAction: () => editor.insertContent(opt.value)
          };
        });
        callback(items);
      }
    });
  }
};
</script>

<template>
  <div id="ding-talk-template-settings" class="flex justify-between ml">
    <tinymce ref="tinymceRef" class="w-100%" :toolbar="toolbar" :editor-setup="editorSetup" />
    <base-button class="ml" button-name="save" type="primary" :loading="isLoading" :disabled="isLoading" @click="save">
      {{ $t('save') }}
    </base-button>
  </div>
</template>
