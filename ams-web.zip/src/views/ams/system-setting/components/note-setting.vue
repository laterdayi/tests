<script lang="ts" setup>
import { AlarmSystemSettingApis } from '@/service/apis/ams/system-setting.js';
import tinymce from '@/components/project/tinymce/tinymce.vue';
import type { EditorType, NestedMenuItemContents } from '@/components/project/tinymce/type';

// 保存短信模版
const { isLoading, execute: executeSaveSMSTemplate } = useAxiosPost(AlarmSystemSettingApis.saveSMSSettingApi);

const save = () => {
  executeSaveSMSTemplate({ data: { setting: tinymceRef?.value?.getContent({ format: 'text' }) } });
};
// 获取短信模版
const { execute: executeSMSTemplate } = useAxiosGet<string>(AlarmSystemSettingApis.getSMSSettingApi);

const contentText = ref<string>('');
const getSMSTemplate = async () => {
  try {
    const { data } = await executeSMSTemplate();
    contentText.value = data.value || '';
    tinymceRef?.value?.setContent(data.value as string);
  } catch (error) {
    console.log(error);
  }
};

tryOnMounted(async () => {
  await getSMSTemplate();
});
// 富文本配置
const tinymceRef = ref();
const toolbar = 'menuDateButton';
const editorSetup = (editor: EditorType) => {
  editor.ui.registry.addMenuButton('menuDateButton', {
    text: i18nt('selectParam'),
    fetch: callback => {
      const options = [
        { value: '{Equipment}', text: 'Equipment' },
        { value: '{System}', text: 'System' },
        { value: '{Lot}', text: 'Lot' },
        { value: '{Product}', text: 'Product' },
        { value: '{Alarm Code}', text: 'Alarm Code' },
        { value: '{Alarm Time}', text: 'Alarm Time' },
        { value: '{Alarm Message}', text: 'Alarm Message' },
        { value: '{Alarm Action}', text: 'Alarm Action' },
        { value: '{Remark}', text: 'Remark' }
      ];

      const items: NestedMenuItemContents[] = options.map(opt => {
        return {
          type: 'menuitem',
          text: opt.text,
          onAction: () => editor.insertContent(opt.value)
        };
      });
      callback(items);
    }
  });
};
</script>

<template>
  <div id="sms-template-setting" class="flex justify-between ml">
    <tinymce
      ref="tinymceRef"
      class="w-100%"
      :toolbar="toolbar"
      :content-text="contentText"
      :editor-setup="editorSetup"
    />
    <base-button button-name="save" class="ml" type="primary" :loading="isLoading" :disabled="isLoading" @click="save">
      {{ $t('save') }}
    </base-button>
  </div>
</template>
