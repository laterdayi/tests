<script setup lang="tsx">
import alarmActionSwitch from './components/alarm-action-switch.vue';
import mailTemplateSetting from './components/mail-template-setting.vue';
import SmsTemplateSetting from './components/sms-template-setting.vue';
import alarmDashboardSetting from './components/alarm-dashboard-setting.vue';
import generalSettings from './components/general-settings.vue';
import weChatTemplateSetting from './components/we-chat-template-setting.vue';
import feiShuTemplateSetting from './components/fei-shu-template-setting.vue';
import repairSetting from './components/repair-setting.vue';
import dingTalkTemplateSettings from './components/ding-talk-template-settings.vue';

const { hasCustomPermission } = useRoutes();
</script>

<template>
  <div id="system-setting">
    <base-card
      v-if="
        hasCustomPermission('alarmActionSetting') ||
        hasCustomPermission('mailTemplateSetting') ||
        hasCustomPermission('weChatTemplateSetting') ||
        hasCustomPermission('feishuTemplateSettings') ||
        hasCustomPermission('smsTemplateSetting') ||
        hasCustomPermission('dingTalkTemplateSettings') ||
        hasCustomPermission('alarmDashboardSetting')
      "
      :class="`w-${TABS_PANE_WIDTH}px!`"
    >
      <!-- 报警动作开关 -->
      <base-tabs placement="left">
        <n-tab-pane
          v-if="hasCustomPermission('alarmActionSetting')"
          name="alarmActionSetting"
          :tab="$t('alarmActionSetting')"
        >
          <alarm-action-switch />
        </n-tab-pane>
        <!-- 邮件模版设置 -->
        <n-tab-pane
          v-if="hasCustomPermission('mailTemplateSetting')"
          name="mailTemplateSetting"
          :tab="$t('mailTemplateSetting')"
        >
          <mail-template-setting />
        </n-tab-pane>
        <!-- 企业微信模版设置 -->
        <n-tab-pane
          v-if="hasCustomPermission('weChatTemplateSetting')"
          name="weChatTemplateSetting"
          :tab="$t('weChatTemplateSetting')"
        >
          <weChatTemplateSetting />
        </n-tab-pane>
        <!-- 飞书微信模版设置 -->
        <n-tab-pane
          v-if="hasCustomPermission('feishuTemplateSettings')"
          name="feishuTemplateSettings"
          :tab="$t('feishuTemplateSettings')"
        >
          <feiShuTemplateSetting />
        </n-tab-pane>
        <!-- 短信模板设置 -->
        <n-tab-pane
          v-if="hasCustomPermission('smsTemplateSetting')"
          name="smsTemplateSetting"
          :tab="$t('smsTemplateSetting')"
        >
          <sms-template-setting />
        </n-tab-pane>
        <!-- 钉钉模板设置 -->
        <n-tab-pane
          v-if="hasCustomPermission('dingTalkTemplateSettings')"
          name="dingTalkTemplateSettings"
          :tab="$t('dingTalkTemplateSettings')"
        >
          <ding-talk-template-settings />
        </n-tab-pane>
        <!-- 报警看板设置 -->
        <n-tab-pane
          v-if="hasCustomPermission('alarmDashboardSetting')"
          name="alarmDashboardSetting"
          :tab="$t('alarmDashboardSetting')"
        >
          <alarmDashboardSetting />
        </n-tab-pane>
        <!-- 报修设置 -->
        <n-tab-pane v-if="hasCustomPermission('repairSettings')" name="repairSettings" :tab="$t('repairSettings')">
          <repairSetting />
        </n-tab-pane>
        <!-- 通用设置 -->
        <n-tab-pane v-if="hasCustomPermission('generalSettings')" name="generalSettings" :tab="$t('generalSettings')">
          <generalSettings />
        </n-tab-pane>
      </base-tabs>
    </base-card>
  </div>
</template>
