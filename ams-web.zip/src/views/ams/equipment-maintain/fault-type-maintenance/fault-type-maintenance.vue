<script setup lang="tsx">
import addForm from './components/add-form.vue';
import { FaultTypeMaintenanceApis } from '@/service/apis/ams/equipment-maintain/fault-type-maintenance';
import type {
  EditType,
  EquipmentType,
  QueryType,
  TableListType
} from '@/service/apis/ams/equipment-maintain/fault-type-maintenance';
import { FaultConfigurationApis } from '@/service/apis/ams/equipment-maintain/fault-configuration';

const { hasEditPermission } = useRoutes();
// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
const addFormRef = ref();
// 获取树数据
const { isLoading: isLoadingEquipmentList, execute: executeGetEquipmentList } = useAxiosGet<EquipmentType[]>(
  FaultConfigurationApis.getEquipmentListApi
);
const equipmentList = ref<EquipmentType[]>([]);

tryOnMounted(async () => {
  try {
    const { data } = await executeGetEquipmentList();
    if (!data.value) return;
    equipmentList.value = removeInnerLevel(data.value);
  } catch (error) {
    console.log(error);
  }
});
// 查询表单配置
const queryFormParams: Nullable<QueryType> = {
  eqpType: null,
  faultName: null
};
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-form-item',
    model: 'eqpType',
    formItemProps: {
      label: i18nt('equipmentType')
    },
    render() {
      return (
        <base-tree-select
          checkable={false}
          key-field="id"
          label-field="name"
          loading={isLoadingEquipmentList.value}
          onUpdateValue={(value: string) => {
            if (!curdRef.value) return;
            if (!curdRef.value.queryFormData) return;
            curdRef.value.queryFormData.eqpType = value;
          }}
          options={equipmentList.value}
          value={curdRef?.value?.queryFormData?.eqpType}
        />
      );
    }
  },
  {
    type: 'input',
    model: 'faultName',
    formItemProps: {
      label: i18nt('typeOfMalfunction')
    },
    formItemClass: 'col-span-2!'
  },
]);

// 表格数据配置
const curdRefPagination = computed(() => curdRef.value?.pagination);
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    key: 'eqpType',
    title: i18nt('equipmentType'),
    sorter: true,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.eqpType, () =>
        addFormRef.value.handleOpenModal(rowData.id, hasEditPermission.value))
  },
  { title: i18nt('typeOfMalfunction'), key: 'faultName', sorter: true },
  { title: i18nt('creator'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('createTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('remark'), key: 'remark' }
];
// 刷新页面
const resetTable = () => {
  curdRef?.value?.handleSearch();
};
// 相关权限操作
const handlePermission = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    add: () => addFormRef.value.handleOpenModal(__, true),
    edit: () => addFormRef.value.handleOpenModal(curdRef?.value?.tableRef?.selectedKeys[0], hasEditPermission.value)
  };
  columnsList[permission as string]?.();
};
// 树处理
const removeInnerLevel = (tree: EquipmentType[], level = 0): EquipmentType[] => {
  return (tree || []).map((node: EquipmentType) => {
    const { id, name } = node;
    if (level === 2 || (node.children && node.children.length === 0)) {
      return {
        id,
        level,
        name
      };
    }
    return {
      id,
      level,
      name,
      children: removeInnerLevel(node.children ?? [], level + 1)
    };
  });
};
</script>

<template>
  <div id="fault-configuration">
    <base-curd
      ref="curdRef"
      multi-edit
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :read-api="FaultTypeMaintenanceApis.getListApi"
      :delete-api="FaultTypeMaintenanceApis.deleteApi"
      :import-api="FaultTypeMaintenanceApis.importApi"
      :export-api="FaultTypeMaintenanceApis.getListApi"
      :download-api="FaultTypeMaintenanceApis.downloadApi"
      @handle="handlePermission"
    />
    <addForm ref="addFormRef" @reset-table="resetTable" />
  </div>
</template>
