<script setup lang="tsx">
import { FaultConfigurationApis } from '@/service/apis/ams/equipment-maintain/fault-configuration';
import type { EditType, EquipmentType } from '@/service/apis/ams/equipment-maintain/fault-configuration';
import { CommonApis } from '@/service/apis/common/common';

const emit = defineEmits<{
  'reset-table': []
}>();

// 获取树数据
const { isLoading: isLoadingEquipmentList, execute: executeGetEquipmentList } = useAxiosGet<EquipmentType[]>(
  FaultConfigurationApis.getEquipmentListApi
);
// 获取故障类型
const {
  data: daultTypeList,
  isLoading: isLoadingFaultType,
  execute: executeGetFaultTypet
} = useAxiosGet<EquipmentType[]>(FaultConfigurationApis.getFaultTypeListApi);
// 获取电子表单
const {
  data: checkFormList,
  isLoading: isLoadingCheckFormList,
  execute: executeGetCheckFormList
} = useAxiosGet<EquipmentType[]>(FaultConfigurationApis.getCheckFormListApi);
// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
// 弹窗title
const modalTitle = ref<string>('');
// 接口设置
const modalUrl = ref<string>('');
// 是否是详情页
const viewDetailIsShow = ref<boolean>(false);
// 获取表单详情
const { execute: executeGetDetails } = useAxiosGet<EditType>(FaultConfigurationApis.getDetailApi);
const editIsShow = ref<boolean>(false);
//  打开弹窗
const handleOpenModal = async (id: string, isShow: boolean) => {
  resetField();
  daultTypeList.value = [];
  selectedKeysList.value = [];
  viewDetailIsShow.value = !isShow;
  try {
    executeGetCheckFormList({ params: { category: 6 } });
    const { data } = await executeGetEquipmentList();
    if (!data.value) return;
    equipmentList.value = removeInnerLevel(data.value);

    if (id) {
      modalTitle.value = isShow ? i18nt('edit') + i18nt('faultConfiguration') : i18nt('viewDetail');
      modalUrl.value = FaultConfigurationApis.updateApi;

      const { data } = await executeGetDetails({
        params: { id }
      });
      if (!data.value) return;
      formData.value = data.value;
      selectedKeysList.value = [data.value.eqpType];
      editIsShow.value = true;
    } else {
      modalTitle.value = i18nt('add') + i18nt('faultConfiguration');
      modalUrl.value = FaultConfigurationApis.addApi;
      editIsShow.value = false;
    }
    openModal();
  } catch (error) {
    equipmentList.value = [];
    console.log(error);
  }
};
// 左侧树
const selectedKeysList = ref<string[]>([]);
const equipmentList = ref<EquipmentType[]>([]);
// 树点击
const nodeProps = ({ option }: { option: TreeOption<EquipmentType> }) => {
  return {
    onClick() {
      if (editIsShow.value) return;
      const { id = '', level = 0 } = option;
      formData.value.faultName = null;
      restoreValidation();
      if (level === 2) {
        selectedKeysList.value = [id];
        executeGetFaultTypet({
          params: {
            eqpType: id
          }
        });
      } else {
        selectedKeysList.value = [];
        daultTypeList.value = [];
      }
    }
  };
};
// 树处理
const removeInnerLevel = (tree: EquipmentType[], level = 0): EquipmentType[] => {
  return (tree || []).map((node: EquipmentType) => {
    const { id, name } = node;
    if (level === 2 || (node.children && node.children.length === 0)) {
      return {
        id,
        level,
        name
      };
    }
    return {
      id,
      level,
      name,
      children: removeInnerLevel(node.children ?? [], level + 1)
    };
  });
};
// 表单配置
const { formData, resetField, restoreValidation, validate, formRef } = useForm<Nullable<EditType>>({
  eqpType: null,
  faultName: null,
  faultDescription: null,
  eFormId: null,
  sopName: null,
  sop: null,
  remark: null
});
// SOP上传格式
const ASTRICT_SOP_RULE = {
  rule: [
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/pdf',
    'video/mp4',
    'video/webm',
    'video/ogg',
    'video/avi',
    'video/quicktime',
    'video/mpeg',
    'image/jpg',
    'image/png',
    'image/gif',
    'image/jpeg',
    'image/svg+xml',
    'image/svg',
    'image/x-icon'
  ],
  error: i18nt('uploadFileTips.astrictSOPHint')
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'faultName',
    formItemProps: {
      label: i18nt('typeOfMalfunction'),
      rule: [useRules('change', i18nt('typeOfMalfunction'))]
    },
    componentProps: {
      options: daultTypeList?.value,
      loading: isLoadingFaultType?.value,
      disabled: editIsShow.value,
      labelField: 'name',
      valueField: 'name'
    },
    formItemClass: 'col-span-2!'
  },
  useRenderFormTextarea({
    model: 'faultDescription',
    label: i18nt('faultDescription'),
    formItemClass: 'col-span-2!'
  }),
  {
    type: 'select',
    model: 'eFormId',
    formItemProps: {
      label: i18nt('electronForm')
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingCheckFormList.value,
      options: checkFormList.value
    },
    formItemClass: 'col-span-2!'
  },

  useRenderFormUpload({
    model: 'sop',
    label: 'SOP',
    rule: {
      rule: [...ASTRICT_SOP_RULE.rule],
      error: ASTRICT_SOP_RULE.error
    },
    astrictFileSize: 10,
    onFinished({ data, file }) {
      if (!formData.value) return;
      formData.value.sopName = file.name;
      formData.value.sop = data;
    },
    onRemoved() {
      if (!formData.value) return;
      formData.value.sopName = null;
      formData.value.sop = null;
    },
    componentProps: {
      action: CommonApis.uploadFileApi,
      listType: 'text',
      fileList:
        formData.value && formData.value.sopName
          ? [
              {
                id: formData.value && formData.value.sopName ? formData.value.sopName : '',
                name: formData.value && formData.value.sopName ? formData.value.sopName : '',
                status: 'finished'
              }
            ]
          : []
    },
    formData: formData.value,
    formItemClass: 'col-span-2! useRenderFormUpload'
  }),
  {
    type: 'custom-form-item',
    model: '',
    formItemProps: { label: '' },
    render() {
      return <div class="m-l-120px c-red font-size-12px">{i18nt('uploadFileTips.astrictSOPHint')}</div>;
    },
    formItemClass: 'col-span-2! useRenderFormUpload'
  },
  useRenderFormTextarea({
    model: 'remark',
    label: i18nt('remark'),
    formItemClass: 'col-span-2!'
  })
]);
// 提交
const { isLoading: isLoadingChangeExecutor, execute: executeChangeExecutor } = useAxiosPost('');
const handleSubmitChangeExecutor = async () => {
  try {
    if (selectedKeysList.value.length === 0) {
      $message.warning(i18nt('baseForm.pleaseSelect', { val: i18nt('eqpType') }));
      return;
    }
    await validate();
    await executeChangeExecutor(modalUrl.value, {
      data: {
        ...formData.value,
        eqpType: selectedKeysList.value.toString()
      }
    });

    emit('reset-table');
    closeModal();
  } catch (error) {
    console.log(error);
  }
};

defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :loading="isLoadingChangeExecutor"
    :show="showModal"
    :title="modalTitle"
    :positive-text="viewDetailIsShow ? '' : i18nt('confirm')"
    :inside-scroll="false"
    @close="closeModal"
    @negative-click="closeModal"
    @positive-click="handleSubmitChangeExecutor"
    @after-leave="resetField"
  >
    <div class="flex">
      <base-tree
        :disabled="viewDetailIsShow || editIsShow"
        :selected-keys="selectedKeysList"
        :node-props="nodeProps"
        class="modal-content-height"
        layout="dialog"
        :loading="isLoadingEquipmentList"
        :data="equipmentList ?? []"
        key-field="id"
        :checkable="false"
        label-field="name"
      />
      <div class="w-100%">
        <base-form
          ref="formRef"
          v-model="formData"
          :disabled="viewDetailIsShow"
          layout="dialog"
          :schemas="formSchemas"
        />
      </div>
    </div>
  </base-modal>
</template>

<style lang="less" scoped>
:deep(.useRenderFormUpload) {
  .n-form-item-feedback-wrapper {
    display: none;
  }
}
</style>
