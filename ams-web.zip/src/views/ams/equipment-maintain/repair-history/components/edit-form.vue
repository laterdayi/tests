<script setup lang="tsx">
import { CallRepairHistoryApis } from '@/service/apis/ams/equipment-maintain/repair-history';
import type { DetailFormType, EQPAlarmCodeType, FormType, TableListType } from '@/service/apis/ams/equipment-maintain/repair-history';

// 获取故障类型
const {
  data: faultNameList,
  isLoading: isLoadingFaultName,
  execute: executeGetFaultName
} = useAxiosGet<EQPAlarmCodeType[]>(CallRepairHistoryApis.getFaultNameListApi);

// 获取详情
const { execute: executeGetCallDetail } = useAxiosGet<DetailFormType>(CallRepairHistoryApis.getCallDetailApi);
// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
//  打开弹窗
const faultNameIsShow = ref<boolean>(false)
const handleOpenModal = async (row: TableListType) => {
  try {
    await executeGetFaultName({
      params: {
        eqpId: row.eqpId
      }
    });
    const { data } = await executeGetCallDetail({ params: { id: row.id } });
    if (!data.value) return;
    updateField({
      id: row.id,
      faultDescription: data.value.faultDescription,
      faultReason: data.value.faultReason,
      measure: data.value.measure,
      faultName: data.value.faultName,
    });
    faultNameIsShow.value = !!data.value.faultName
    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 表单查询
const { formRef, validate, formData, resetField, updateField } = useForm<Nullable<FormType>>({
  faultDescription: null,
  faultReason: null,
  measure: null,
  faultName: null
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'faultName',
    formItemProps: {
      label: i18nt('typeOfMalfunction'),
      rule: useRules('change', i18nt('typeOfMalfunction'))
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingFaultName.value,
      options: faultNameList.value,
      disabled: faultNameIsShow.value
    }
  },
  useRenderFormTextarea({
    model: 'faultDescription',
    label: i18nt('faultDescription'),
    formItemProps: {
      rule: useRules('input', i18nt('faultDescription'))
    }
  }),
  useRenderFormTextarea({
    model: 'faultReason',
    label: i18nt('faultCause')
  }),
  useRenderFormTextarea({
    model: 'measure',
    label: i18nt('improvementMeasures')
  })
]);

// 保存表单
const { isLoading: isLoadingRepairReport, execute: executeRepairReport } = useAxiosPost(
  CallRepairHistoryApis.repairReportUpdateApi
);
const saveForm = async () => {
  try {
    await validate();

    await executeRepairReport({
      data: { ...formData.value }
    });
    closeModal();
    resetField();
  } catch (error) {
    console.log(error);
  }
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-65%!"
    :show="showModal"
    :loading="isLoadingRepairReport"
    :title="$t('edit') + $t('repairReport')"
    @positive-click="saveForm"
    @close="closeModal"
    @negative-click="closeModal"
  >
    <!-- 表单 -->
    <base-form ref="formRef" v-model="formData" class="form" layout="dialog" :schemas="formSchemas" />
  </base-modal>
</template>
