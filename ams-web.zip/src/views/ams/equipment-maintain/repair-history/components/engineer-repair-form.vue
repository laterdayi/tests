<script setup lang="tsx">
import type { DataTableSortState } from 'naive-ui/es/data-table';
import engineerRepairDrawer from './engineer-repair-drawer.vue';
import { CallRepairHistoryApis } from '@/service/apis/ams/equipment-maintain/repair-history';
import type {
  DetailFormType,
  EQPAlarmCodeType,
  EngineerRepairFormType,
  EngineerRepairTableListType,
  EngineerRepairTableQueryType,
  MaintenanceFormDataType,
  MaintenanceInformationType,
  RepairStageType
} from '@/service/apis/ams/equipment-maintain/repair-history';

import { handleTableTransformList, tableLenght } from '@/components/project/form-designer/utils/form-item-method';

const emit = defineEmits<{
  'reset-from': [];
  'before-download': [];
  'download-success': [];
  'download-error': [];
}>();
const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const { currentRoutePowers } = useRoutes();
const router = useRouter();

// 是否拥有暂存权限
const stagingIsShow = ref<boolean>(false);
const clearStagingIsShow = ref<boolean>(false);
// 获取SOP+电子表单
const maintenanceInformationData = ref<Nilable<MaintenanceInformationType>>({
  callFaultConfigId: null,
  faultDescription: null,
  eFormId: null,
  sop: null,
  sopName: null,
  prefix: null
});
const { execute: executeGetMaintenanceInformation } = useAxiosGet<MaintenanceInformationType>(
  CallRepairHistoryApis.getMaintenanceInformationApi
);

// 获取暂存SOP+电子表单
const { execute: executeGetRepairStage } = useAxiosGet<RepairStageType>(CallRepairHistoryApis.getRepairStageApi);

// 获取复机条件
const { data: recoveryConditiontList, execute: executeGetRecoveryConditiontList } = useAxiosGet<OptionsType[]>(
  CallRepairHistoryApis.getRecoveryConditiontListApi
);
// 获取故障类型
const {
  data: faultNameList,
  isLoading: isLoadingFaultName,
  execute: executeGetFaultName
} = useAxiosGet<EQPAlarmCodeType[]>(CallRepairHistoryApis.getFaultNameListApi);

// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
// 存储数据
const modelForm = ref();
const stageFlagIndex = ref<number>(1);
const callEFormHistoryId = ref<string>('');
//  打开弹窗
const handleOpenModal = async (row: DetailFormType, callEFormId: string) => {
  try {
    stagingIsShow.value = (currentRoutePowers.value || []).includes('staging');
    clearStagingIsShow.value = (currentRoutePowers.value || []).includes('clearStaging');
    modelForm.value = row;

    tableQuery.value.eqpTypeId = row.eqpType;
    callEFormHistoryId.value = callEFormId;
    pagination.value.pageSize = 5;
    await executeGetFaultName({
      params: {
        eqpId: row.eqpId
      }
    });
    await executeGetRecoveryConditiontList();
    stageFlagIndex.value = row.stageFlag;
    if (row.stageFlag === 1) {
      const { data } = await executeGetRepairStage({
        params: {
          callId: row.id
        }
      });
      if (!data.value) return;
      maintenanceInformationData.value = {
        faultDescription: data.value.faultDescription,
        eFormId: data.value.eFormId,
        sop: data.value.sop,
        sopName: data.value.sopName,
        callFaultConfigId: data.value.callFaultConfigId,
        prefix: data.value.prefix
      };
      if (data.value.table) {
        maintenanceFormData.value = {
          formInfoData: { ...maintenanceInformationData.value },
          table: data.value.table,
          fromResult: 1
        };
        const list = handleTableTransformList(data.value.table) || [];
        tableLenghtIsShow.value = tableLenght(list) || false;
      }

      updateField({
        lotId: data.value.lotId,
        faultName: data.value.faultName,
        faultDescription: data.value.faultDescription,
        faultReason: data.value.faultReason,
        improveMeasure: data.value.improveMeasure,
        recoveryConditions: data.value.recoveryConditions
      });
      if (data.value.faultName) {
        tableQuery.value.faultName = data.value.faultName;
        tableQuery.value.eqpTypeId = row.eqpType;
        getRepairReportList();
      }
    } else {
      updateField({
        lotId: row.lotId
      });
    }

    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 表单
const { formData, resetField, formRef, validate, updateField, restoreValidation } = useForm<
  Nilable<EngineerRepairFormType>
>({
  lotId: null,
  faultName: null,
  faultDescription: null,
  faultReason: null,
  improveMeasure: null,
  recoveryConditions: []
});
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'lotId',
    formItemProps: {
      label: 'Lot ID'
    },
    componentProps: {
      disabled: true
    }
  },
  {
    type: 'select',
    model: 'faultName',
    formItemProps: {
      label: i18nt('typeOfMalfunction'),
      rule: useRules('change', i18nt('typeOfMalfunction'))
    },
    componentProps: {
      valueField: 'id',
      labelField: 'name',
      loading: isLoadingFaultName.value,
      options: faultNameList.value,
      disabled: stageFlagIndex.value === 1 && !!modelForm?.value?.faultName,
      clearable: false,
      onUpdateValue: async (value: string) => {
        maintenanceFormData.value = undefined;
        tableLenghtIsShow.value = false;
        try {
          const { data } = await executeGetMaintenanceInformation({
            params: {
              eqpType: modelForm.value.eqpType,
              faultName: value
            }
          });
          if (!data.value) return;
          maintenanceInformationData.value = { ...data.value };
          updateField({
            faultDescription: data.value.faultDescription
          });
          tableQuery.value.faultName = value;
          getRepairReportList();
          restoreValidation();
        } catch (error) {
          maintenanceFormData.value = undefined;
          tableData.value = [];
          maintenanceInformationData.value.eFormId = null;
          maintenanceInformationData.value.sopName = null;
          maintenanceInformationData.value.callFaultConfigId = null;
          console.log(error);
        }
      }
    }
  },

  {
    type: 'custom-form-item',
    model: 'recoveryConditions',
    formItemProps: { label: i18nt('restorationConditions') },
    render() {
      return (
        <n-checkbox-group v-model:value={formData.value.recoveryConditions}>
          <n-space item-style="display: flex;">
            {recoveryConditiontList.value?.map(ele => {
              return <n-checkbox label={ele.name} value={ele.id} />;
            })}
          </n-space>
        </n-checkbox-group>
      );
    }
  },
  maintenanceInformationData.value && maintenanceInformationData.value.eFormId
    ? {
        type: 'custom-form-item',
        render() {
          return (
            <div
              style={{
                marginLeft: '50px'
              }}
            >
              <span
                style={{
                  color: '#f56c6c',
                  marginRight: '5px'
                }}
              >
                *
              </span>
              <span class="mr">{i18nt('checkList')}</span>
              <base-button
                buttonName={
                  maintenanceFormData.value ? (tableLenghtIsShow.value ? 'saved' : 'confirmed') : 'unconfirmed'
                }
                class="mr"
                onClick={engineerRepairDrawerClick}
                size={componentSize.value}
                type="primary"
              >
                {maintenanceFormData.value
                  ? tableLenghtIsShow.value
                    ? i18nt('saved')
                    : i18nt('confirmed')
                  : i18nt('unconfirmed')}
              </base-button>
            </div>
          );
        }
      }
    : __,
  {
    type: 'input',
    model: 'faultDescription',
    formItemProps: {
      label: i18nt('faultDescription'),
      rule: useRules('input', i18nt('faultDescription'))
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'faultReason',
    formItemProps: {
      label: i18nt('faultCause')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input',
    model: 'improveMeasure',
    formItemProps: {
      label: i18nt('improvementMeasures')
    },
    componentProps: {
      type: 'textarea',
      minlength: 0,
      maxlength: MAX_LENGTH_DESCRIPTION,
      showCount: true
    },
    formItemClass: 'col-span-2!'
  },
  maintenanceInformationData.value && maintenanceInformationData.value.sopName
    ? {
        type: 'custom-form-item',
        model: 'recoveryConditions',
        formItemProps: { label: 'SOP' },
        render() {
          return useRenderTableTitleEdit(maintenanceInformationData.value.sopName || '', () => {
            window.open(`${window.$CONFIG?.projectConfig?.ossUrl}${maintenanceInformationData.value?.sop}`);
          });
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  tableData.value && tableData.value.length !== 0
    ? {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('historicalMaintenanceReport') },
        render() {
          return (
            <div>
              <base-table
                columns={tableColumns}
                data={tableData.value}
                loading={isLoadingQuery.value}
                max-height={195}
                onUpdate:sorter={(options: DataTableSortState | null) => {
                  handleSorterChange(options);
                }}
                pagination={{
                  ...pagination.value,
                  pageSizes: [
                    { label: `5 ${i18nt('stripPage')}`, value: 5 },
                    { label: `10 ${i18nt('stripPage')}`, value: 10 },
                    { label: `15 ${i18nt('stripPage')}`, value: 15 },
                    { label: `20 ${i18nt('stripPage')}`, value: 20 },
                    { label: `25 ${i18nt('stripPage')}`, value: 25 },
                    { label: `30 ${i18nt('stripPage')}`, value: 30 },
                    { label: `35 ${i18nt('stripPage')}`, value: 35 }
                  ]
                }}
                ref="tableRef"
                remote
              />
            </div>
          );
        },
        formItemClass: 'col-span-2!'
      }
    : __
]);
// 历史记录配置
const tableQuery = ref<Nilable<EngineerRepairTableQueryType>>({
  eqpTypeId: null,
  faultName: null
});
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  tableData,
  executeQueryList: getRepairReportList
} = useTable<EngineerRepairTableListType[]>(CallRepairHistoryApis.getRepairReportListApi, {
  queryFormParams: tableQuery
});

const tableColumns: DataTableColumns<EngineerRepairTableListType> = [
  useRenderTableIndex(pagination),
  {
    title: i18nt('callNumber'),
    key: 'flowNo',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render(rowData) {
      return useRenderTableTitleEdit(rowData.flowNo, () => {
        const { href } = router.resolve({
          path: `/ams/equipment-maintain/maintenance-engineer-query/${JSON.stringify({
            faultName: encodeURIComponent(formData.value.faultName || ''),
            eqpType: modelForm.value.eqpType
          })}`
        });
        window.open(href, '_blank');
      });
    }
  },
  {
    title: i18nt('eqpId'),
    key: 'eqpId',
    sorter: true
  },
  {
    title: i18nt('faultDescription'),
    key: 'faultDescription'
  },
  {
    title: i18nt('faultCause'),
    key: 'faultReason'
  },
  {
    title: i18nt('improvementMeasures'),
    key: 'measure'
  },
  {
    title: i18nt('repairCompletionTime'),
    key: 'repairCompleteTime',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  }
];
const engineerRepairDrawerRef = ref();
// 检查表点击
const engineerRepairDrawerClick = () => {
  engineerRepairDrawerRef.value?.handleOpenModal(
    tableLenghtIsShow.value,
    maintenanceInformationData.value,
    maintenanceFormData.value
  );
};
// 抽屉传值
const maintenanceFormData = ref<MaintenanceFormDataType>();
// 是否暂存
const tableLenghtIsShow = ref<boolean>(false);
const drawerFrom = (isShow: boolean, item?: MaintenanceFormDataType) => {
  maintenanceFormData.value = item;
  tableLenghtIsShow.value = isShow;
};

// 保存表单
const { isLoading: isLoadingRepairComplete, execute: executeRepairComplete } = useAxiosPost(
  CallRepairHistoryApis.repairCompleteApi
);
const saveFormType = ref<number>(2);
const saveForm = async (type: number) => {
  try {
    saveFormType.value = type;
    if (type === 2) {
      await validate();
      if (maintenanceInformationData.value && maintenanceInformationData.value.eFormId) {
        if (!maintenanceFormData.value) {
          return $message.warning(i18nt('notEmpty', { val: i18nt('checkList') }));
        }
      }
    }
    const { eFormId, prefix } = maintenanceFormData.value?.formInfoData ?? {};
    await executeRepairComplete(__, {
      data: {
        ...formData.value,
        id: modelForm.value.id,
        eFormId,
        prefix,
        table: maintenanceFormData.value?.table,
        completeFlag: type,
        callEFormHistoryId: callEFormHistoryId.value
      }
    });
    cancelModal(2);
  } catch (error) {
    console.log(error);
  }
};
// 获取故障类型
const { isLoading: isLoadingClearStageEForm, execute: executeClearStageEForm } = useAxiosPost(
  CallRepairHistoryApis.clearStageEFormApi
);
// 清除暂存
const clearStagingForm = async () => {
  try {
    const { data } = await executeClearStageEForm(__, {
      data: {
        callEFormId: callEFormHistoryId.value,
        callId: modelForm.value.id
      }
    });
    if (!data.value) return;
    cancelModal(2);
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = (type = 1) => {
  // 重置表单并去除验证
  resetField();
  maintenanceFormData.value = undefined;
  tableLenghtIsShow.value = false;
  tableData.value = [];
  maintenanceInformationData.value = {
    callFaultConfigId: null,
    eFormId: null,
    sop: null,
    sopName: null,
    prefix: null,
    faultDescription: null
  };
  if (type === 2) {
    emit('reset-from');
  }
  closeModal();
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    class="w-55%!"
    :show="showModal"
    :loading="isLoadingClearStageEForm || isLoadingRepairComplete"
    :title="i18nt('engineerRepair')"
    @close="cancelModal()"
    @after-leave="resetField()"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="formSchemas" />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal()">
        {{ $t('cancel') }}
      </base-button>
      <base-button
        v-if="stagingIsShow"
        :loading="isLoadingRepairComplete && saveFormType === 1"
        type="info"
        :size="componentSize"
        button-name="staging"
        @click="saveForm(1)"
      >
        {{ $t('staging') }}
      </base-button>
      <base-button
        v-if="clearStagingIsShow && stageFlagIndex === 1"
        type="info"
        :loading="isLoadingClearStageEForm"
        :size="componentSize"
        button-name="clearStaging"
        @click="clearStagingForm"
      >
        {{ $t('clearStaging') }}
      </base-button>
      <base-button
        type="info"
        :size="componentSize"
        :loading="isLoadingRepairComplete && saveFormType === 2"
        :disabled="tableLenghtIsShow"
        button-name="confirm"
        @click="saveForm(2)"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
    <!-- 维修确认 -->
    <engineerRepairDrawer ref="engineerRepairDrawerRef" @drawer-from="drawerFrom" />
  </base-modal>
</template>
