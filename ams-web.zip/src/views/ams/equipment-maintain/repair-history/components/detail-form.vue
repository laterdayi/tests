<script setup lang="tsx">
import type { RowKey } from 'naive-ui/es/data-table/src/interface';
import takeOrderForm from './take-order-form.vue';
import engineerRepairForm from './engineer-repair-form.vue';
import engineerRepairDrawer from './engineer-repair-drawer.vue';
import { CallRepairHistoryApis } from '@/service/apis/ams/equipment-maintain/repair-history';
import type {
  ChangeHistoryType,
  DetailFormType,
  HistoryFormType,
  OperateRecordListType,
  TableListType,
  qcTableDataType
} from '@/service/apis/ams/equipment-maintain/repair-history';

import type { FormItemListType } from '@/components/project/form-designer/utils/form-item-type';

const emit = defineEmits<{
  'reset-from': [];
  'reset-table': [];
  'areset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const currentRoutePowers = ref<string[]>();

// 是否详情可编辑
const negativeIsShow = ref<boolean>(true);
// 弹窗备份
const detailFormRow = ref<TableListType>();
// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
// 获取详情
const { isLoading: isLoadingViewDetailData, execute: executeGetCallDetail } = useAxiosGet<DetailFormType>(
  CallRepairHistoryApis.getCallDetailApi
);
// 获取lotId
const { data: eqpLotInfoData, execute: executeGetEqpLotInfo } = useAxiosGet<{ lotno: string }>(
  CallRepairHistoryApis.getEqpLotInfoApi
);
//  获取操作记录
const operateRecordList = ref<OperateRecordListType[]>();
const { isLoading: isLoadingOperateRecordList, execute: executeGetOperateRecordList } = useAxiosGet<
  OperateRecordListType[]
>(CallRepairHistoryApis.getRepairHistoryApi);

//  打开弹窗
const handleOpenModal = (row: TableListType, isShow: boolean, currentRoutePowersList: string[]) => {
  try {
    currentRoutePowers.value = currentRoutePowersList;
    negativeIsShow.value = isShow;
    detailFormRow.value = row;
    resetFrom();
    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 刷新表单
const resetFrom = async () => {
  try {
    const { data: detailData } = await executeGetCallDetail({ params: { id: detailFormRow?.value?.id } });
    if (!detailData.value) return;
    formData.value = detailData.value;
    if (!detailData.value.lotId || detailData.value.lotId === '') {
      await executeGetEqpLotInfo({ params: { id: detailFormRow?.value?.id } });
      formData.value.lotId = eqpLotInfoData.value?.lotno;
    }

    if (detailData.value.faultDescription) {
      historyFormData.value.keyId = detailFormRow?.value?.id;
      await historyQueryList();
    }
    const { data: operateRecorData } = await executeGetOperateRecordList({
      params: { callId: detailFormRow?.value?.id }
    });
    if (!operateRecorData.value) return;
    operateRecordList.value = operateRecorData.value;
  } catch (error) {
    console.log(error);
  }
};
// 表单
const { formData, resetField } = useForm<Nilable<DetailFormType>>({
  creator: null,
  createTime: null,
  line: null,
  eqpId: null,
  flowType: null,
  faultName: null,
  callType: null,

  faultDescription: null,
  lotId: null,
  faultReason: null,
  measure: null,
  stageFlag: null
});
const renderSpan = (value?: string | number, style?: CSSProperties) => {
  return h('span', { style: { 'font-weight': 'bold', ...style } }, value);
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'custom-node',
    render() {
      return h('div', { class: 'card-title col-span-2!' }, i18nt('callInformation'));
    }
  },
  {
    type: 'custom-form-item',
    model: 'creator',
    formItemProps: { label: i18nt('caller') },
    render() {
      return renderSpan(formData.value.creator || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'createTime',
    formItemProps: { label: i18nt('callTime') },
    render() {
      return renderSpan(formData.value.createTime || '');
    }
  },

  {
    type: 'custom-form-item',
    model: 'levelName',
    formItemProps: { label: i18nt('productionLineLevel') },
    render() {
      return renderSpan(formData.value.line || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'eqpName',
    formItemProps: { label: i18nt('equipmentNumber') },
    render() {
      return renderSpan(formData.value.eqpId || '');
    }
  },

  {
    type: 'custom-form-item',
    model: 'flowType',
    formItemProps: { label: i18nt('abnormalityType') },
    render() {
      return renderSpan(formData.value.flowType || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'callType',
    formItemProps: { label: i18nt('callType') },
    render() {
      return renderSpan(formData.value.callType || '');
    }
  },
  {
    type: 'custom-form-item',
    model: 'productName',
    formItemProps: { label: i18nt('typeOfMalfunction') },
    render() {
      return renderSpan(formData.value.faultName || '');
    }
  },
  // 维修报告
  formData.value.faultDescription
    ? {
        type: 'custom-node',
        render() {
          return h('div', { class: 'card-title col-span-2!' }, i18nt('repairReport'));
        }
      }
    : __,
  formData.value.faultDescription
    ? {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: i18nt('lotNumebr') },
        render() {
          return renderSpan(formData.value.lotId || '');
        }
      }
    : __,

  formData.value.faultDescription
    ? {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: i18nt('faultDescription') },
        render() {
          return renderSpan(formData.value.faultDescription || '');
        }
      }
    : __,

  formData.value.faultDescription
    ? {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: i18nt('faultCause') },
        render() {
          return renderSpan(formData.value.faultReason || '');
        }
      }
    : __,

  formData.value.faultDescription
    ? {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: i18nt('improvementMeasures') },
        render() {
          return renderSpan(formData.value.measure || '');
        }
      }
    : __,
  formData.value.faultDescription && historyData.value?.length !== 0
    ? {
        type: 'custom-form-item',
        model: '',
        formItemProps: { label: '' },
        formItemClass: 'col-span-2!',
        render() {
          return (
            <base-table
              class="w-100%!"
              columns={historyColumns}
              data={historyData.value}
              pagination={historyPagination.value}
              remote
            />
          );
        }
      }
    : __
]);
// 修改记录
const historyFormData = ref<HistoryFormType>({
  keyId: '',
  tableName: 'CallEntity',
  operateType: 'Update'
});
const {
  pagination: historyPagination,
  tableData: historyData,
  executeQueryList: historyQueryList
} = useTable<ChangeHistoryType[]>(CallRepairHistoryApis.tableChangeHistoryApi, {
  queryFormParams: historyFormData
});

const historyColumns: DataTableColumns<ChangeHistoryType> = [
  useRenderTableIndex(historyPagination),
  {
    title: i18nt('modifyContent'),
    key: 'new'
  },
  {
    title: i18nt('modifier'),
    key: 'creator',
    width: TABLE_WIDTH_INFO
  },
  {
    title: i18nt('modifyTime'),
    key: 'createTime',
    width: TABLE_WIDTH_DATETIME
  }
];

const operateTypeObj: { [key: number]: string } = {
  1: i18nt('initiateCall'),
  2: i18nt('takeAnOrder'),
  3: i18nt('turnOrder'),
  4: i18nt('RepairActionEnum_RepairComplete'),
  5: i18nt('EnumCategory_Spot'),
  6: i18nt('maintenanceStaging'),
  7: i18nt('forceUnlock')
};

// 操作记录
const tableColumns: DataTableColumns<OperateRecordListType> = [
  {
    title: i18nt('index'),
    key: 'index',

    width: TABLE_WIDTH_INDEX,
    render: (rowData, rowIndex) => <span>{rowIndex + 1}</span>
  },
  {
    title: i18nt('operator'),
    titleColSpan: 2,
    colSpan: () => 2,
    ellipsis: {
      tooltip: true
    },
    key: 'operator',
    width: TABLE_WIDTH_NAME
  },
  {
    type: 'expand',
    expandable: () => true,
    width: TABLE_WIDTH_INDEX,
    renderExpand: rowData => {
      return (
        <div class="px py">
          {/* QC表格 */}
          {rowData.qcTableData && rowData?.qcTableData.length !== 0 ? (
            <base-table class="mt" columns={qcTableColumns} data={rowData?.qcTableData} default-expand-all />
          ) : (
            __
          )}
        </div>
      );
    }
  },
  { title: i18nt('operateTime'), key: 'operateTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('remark'), key: 'description' },
  {
    title: i18nt('action'),
    key: 'actionType',
    width: TABLE_WIDTH_DATE,
    render: rowData => {
      return (
        <div>
          <Base-Tag
            class={rowData.operateType === 5 ? 'cursor-pointer' : rowData.callEFormId ? 'cursor-pointer' : 'default'}
            onClick={() => tableRowClick(rowData)}
            type={rowData.operateType === 5 ? 'primary' : rowData.callEFormId ? 'primary' : 'default'}
          >
            {operateTypeObj[rowData.operateType]}
            {rowData.operateType === 5 ? (
              <base-icon
                class="text-icon m-l"
                color={`${appStore.themePrimary}`}
                icon={rowData.iconIsShow ? 'i-carbon:chevron-up' : 'i-carbon:chevron-down'}
                size={20}
              />
            ) : (
              __
            )}
          </Base-Tag>
        </div>
      );
    }
  }
];
// 获取QC表格
const { isLoading: isLoadingRecoveryConditionList, execute: executeGetRecoveryConditionList } = useAxiosGet<
  qcTableDataType[]
>(CallRepairHistoryApis.getRecoveryConditionListApi);

// 操作记录详情
const { execute: executeGetCallEFormHistory } = useAxiosGet<FormItemListType>(
  CallRepairHistoryApis.getCallEFormHistoryApi
);
const engineerRepairDrawerRef = ref();
const tableRowClick = async (row: OperateRecordListType) => {
  if (row.operateType === 5) {
    const index = expandedList.value.findIndex(ele => ele === row.id);
    if (index === -1) {
      row.iconIsShow = true;
      try {
        const { data } = await executeGetRecoveryConditionList({
          params: {
            callHistoryId: row.id
          }
        });
        if (!data.value) return;
        expandedList.value = [row.id];
        row.qcTableData = data.value;
      } catch (error) {
        console.log(error);
        expandedList.value[index] = null;
      }
    } else {
      expandedList.value[index] = null;
    }
  } else {
    if (!row.callEFormId) return;
    try {
      const { data } = await executeGetCallEFormHistory({ params: { id: row.callEFormId } });
      if (!data.value) return;
      engineerRepairDrawerRef.value?.handleOpenModal(
        false,
        '',
        {
          table: data.value.table,
          fromResult: data.value.fromResult
        },
        1,
        data.value.formName
      );
    } catch (error) {
      console.log(error);
    }
  }
};
// 操作记录展开
const expandedList = ref<(string | null)[]>([]);
// QC审核结果
const resultObj: {
  [key: number]: {
    type: 'default' | 'warning' | 'primary' | 'success' | 'error';
    title: string;
  };
} = {
  0: {
    type: TagState.warning,
    title: i18nt('notDetected')
  },
  1: {
    type: TagState.success,
    title: i18nt('through')
  },
  2: {
    type: TagState.error,
    title: i18nt('notThrough')
  }
};
// QC表格类型
const qcTableColumns: DataTableColumns<qcTableDataType> = [
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    render: (rowData, rowIndex) => h('span', null, rowIndex + 1),
    width: TABLE_WIDTH_INDEX
  },
  { title: i18nt('restorationConditions'), key: 'condition' },

  {
    title: i18nt('inspectionResults'),
    key: 'result',
    render(rowData) {
      return useRenderTableSingleTag(resultObj[rowData.result].type, resultObj[rowData.result].title);
    }
  },
  { title: i18nt('inspectionTime'), key: 'updateTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('remark'), key: 'remark' }
];
// 接单
const takeOrderFormRef = ref();
// 工程师维修
const engineerRepairFormRef = ref();

// 按钮权限
const operateButtonPermissionList = [
  // 接单
  {
    key: 'isBtnTakeOver',
    text: 'takeAnOrder',
    click: () => {
      expandedList.value = [];
      takeOrderFormRef.value?.handleOpenModal(formData.value, 1);
    }
  },
  // 转单
  {
    key: 'isBtnHandOver',
    text: 'turnOrder',
    click: () => {
      expandedList.value = [];
      takeOrderFormRef.value?.handleOpenModal(formData.value, 2);
    }
  },
  // 工程师维修
  {
    key: 'isBtnRepairConfirm',
    text: 'engineerRepair',
    click: () => {
      expandedList.value = [];
      const item = operateRecordList.value?.find(ele => ele.operateType === 6);
      engineerRepairFormRef.value?.handleOpenModal(formData.value, item?.callEFormId);
    }
  }
];
// 验证是否拥有按钮权限
const verifyButton = (text: string) => {
  if (!currentRoutePowers.value) return;
  return currentRoutePowers.value.findIndex(ele => ele === text) !== -1;
};
// 关闭弹窗
const cancelModal = () => {
  expandedList.value = [];
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
  emit('areset-table');
  closeModal();
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="showModal"
    :title="$t('viewDetail')"
    :positive-text="__"
    :negative-text="__"
    @close="cancelModal"
    @after-leave="resetField()"
    @negative-click="cancelModal"
  >
    <div class="h-full overflow-auto">
      <base-spin :show="isLoadingViewDetailData">
        <base-form v-model="formData" disabled layout="dialog" :schemas="formSchemas" />
      </base-spin>
      <div class="card-title">{{ $t('operateRecord') }}</div>
      <base-table
        :loading="isLoadingOperateRecordList || isLoadingRecoveryConditionList"
        :expanded-row-keys="expandedList ? (expandedList as RowKey[]) : []"
        :columns="tableColumns"
        :data="operateRecordList"
      />
    </div>

    <template #action>
      <div v-if="negativeIsShow" class="flex justify-between w-full">
        <div>
          <template v-for="item in operateButtonPermissionList" :key="item.key">
            <base-button
              v-if="formData?.[item.key as keyof DetailFormType] && verifyButton(item.text)"
              class="mr"
              :size="componentSize"
              type="primary"
              :button-name="item.text"
              @click="item.click()"
            >
              {{ $t(item.text) }}
            </base-button>
          </template>
        </div>
      </div>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">
        {{ $t('cancel') }}
      </base-button>
    </template>
    <!-- 接单 -->
    <takeOrderForm ref="takeOrderFormRef" @reset-from="resetFrom" />
    <!-- 工程师维修 -->
    <engineerRepairForm ref="engineerRepairFormRef" @reset-from="resetFrom" />
    <!-- 操作记录详情 -->
    <engineerRepairDrawer ref="engineerRepairDrawerRef" />
  </base-modal>
</template>
