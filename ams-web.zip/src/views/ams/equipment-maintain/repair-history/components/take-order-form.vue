<script setup lang="tsx">
import { CallRepairHistoryApis } from '@/service/apis/ams/equipment-maintain/repair-history';
import type { DetailFormType, FlowType, TakeOrderFormType } from '@/service/apis/ams/equipment-maintain/repair-history';
import { CallEquipmentOverviewApis } from '@/service/apis/ams/equipment-call/call-equipment-overview';

const emit = defineEmits<{
  'reset-from': []
}>();
const useStore = useUserStore();
const { userInfo } = storeToRefs(useStore);

const { showModal, openModal, closeModal } = useModal();

// 获取接收人员
const { isLoading: isLoadingNotifyUsersByFlowType, execute: executeGetNotifyUsersByFlowType } = useAxiosGet<FlowType[]>(
  CallRepairHistoryApis.getNotifyUsersByFlowTypeApi
);
const notifyUsersByFlowTypeData = ref<FlowType[]>([]);
const titleType = ref<number>(1);

//  打开弹窗
const handleOpenModal = async (detailFormRow: DetailFormType, type: number) => {
  titleType.value = type;
  resetField();
  try {
    if (type === 1) {
      updateField({
        userId: userInfo.value?.user.userID
      });
    } else {
      const { data } = await executeGetNotifyUsersByFlowType({
        params: {
          eqpId: detailFormRow.eqpId
        }
      });
      if (!data.value) return;
      notifyUsersByFlowTypeData.value = userListHandle(data.value);
    }
    updateField({
      id: detailFormRow.id
    });
    openModal();
  } catch (error) {
    console.log(error);
  }
};
// 处理通知用户树数据
const userListHandle = (list: FlowType[]): FlowType[] => {
  if (!list?.length) return [];
  return list.map(ele => {
    const { children, ...obj } = ele;
    return {
      ...obj,
      ...(children && children.length === 0 ? {} : { children: userListHandle(children || []) })
    };
  });
};
// 表单查询
const modalSchemas = computed<FormSchemaType>(() => [
  titleType.value === 1
    ? {
        type: 'input',
        model: 'userId',
        formItemProps: {
          label: i18nt('employeeID'),
          rule: [useRules('input', i18nt('employeeID')), useRuleStringLength(0, 50)]
        },
        componentProps: {
          // onBlur: () => userIdBlur(),
          onKeydown: (e: KeyboardEvent) => {
            if (e.key === 'Enter') {
              userIdBlur();
            }
          }
        },
        formItemClass: 'col-span-2!'
      }
    : __,
  titleType.value === 2
    ? {
        type: 'select',
        model: 'transferee',
        formItemProps: {
          label: i18nt('recipientQuery'),
          rule: { ...useRules('change', i18nt('recipientQuery')) }
        },
        componentProps: {
          loading: isLoadingNotifyUsersByFlowType.value,
          options: notifyUsersByFlowTypeData.value,
          valueField: 'id',
          labelField: 'name'
        }
      }
    : __,
  titleType.value === 2
    ? useRenderFormTextarea({
      label: i18nt('remark'),
      formItemProps: { rule: useRules('input', i18nt('remark')) },
      model: 'description',
      formItemClass: 'col-span-2!'
    })
    : __
]);
// 员工工号验证
const { execute: executeCheckUserApi } = useAxiosGet<{
  code: number
  data: number
  message: number
}>(CallEquipmentOverviewApis.checkUserApi);
const userIdBlur = async () => {
  try {
    await executeCheckUserApi({
      params: { userId: formData.value.userId }
      // showTooltip: false
    });
  } catch (error) {
    formData.value.userId = null;
    console.log(error);
  }
};
const { validate, formData, resetField, formRef, updateField } = useForm<Nullable<TakeOrderFormType>>({
  id: null,
  userId: null,
  type: null,
  transferee: null,
  description: null
});
// 保存表单

const { execute: executeAdd, isLoading: isLoadingAdd } = useAxiosPost('');
const saveForm = async () => {
  try {
    await validate();
    const { id, userId, transferee, description } = formData.value;
    await executeAdd(
      titleType.value === 1 ? CallRepairHistoryApis.takeOverCallApi : CallRepairHistoryApis.transferCallApi,
      {
        data:
          titleType.value === 1
            ? {
                id,
                userId,
                type: 1
              }
            : {
                id,
                transferee,
                description
              }
      }
    );
    closeModal();
    emit('reset-from');
  } catch (error) {
    console.log(error);
  }
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    :show="showModal"
    :loading="isLoadingAdd"
    :title="i18nt(titleType === 1 ? 'takeAnOrder' : 'turnOrder')"
    @close="closeModal"
    @negative-click="closeModal"
    @positive-click="saveForm"
    @after-leave="resetField()"
  >
    <base-form ref="formRef" v-model="formData" layout="dialog" :schemas="modalSchemas" />
  </base-modal>
</template>
