<script setup lang="tsx">
import editForm from './components/edit-form.vue';
import detailForm from './components/detail-form.vue';
import { CallRepairHistoryApis, CallState } from '@/service/apis/ams/equipment-maintain/repair-history';
import type { EQPAlarmCodeType, QueryType, TableListType } from '@/service/apis/ams/equipment-maintain/repair-history';
import { CommonApis } from '@/service/apis/common/common';
import { CallEquipmentOverviewApis } from '@/service/apis/ams/equipment-call/call-equipment-overview';

const { currentRoutePowers } = useRoutes();
const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 模板引用
const curdRef = ref<CurdRefType<QueryType, TableListType>>();
// 新增弹窗
const editFormRef = ref();
// 详情弹窗
const detailFormRef = ref();

//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelQueryApi,
  __,
  __,
  {
    immediate: true
  }
);
// 呼叫异常类型
const { data: flowTypeList, isLoading: isLoadingFlowTypeList } = useAxiosGet<OptionsType[]>(
  CallEquipmentOverviewApis.getFlowTypeApi,
  undefined,
  undefined,
  { immediate: true }
);
// 获取故障类型
const { data: faultNameList, isLoading: isLoadingFaultName } = useAxiosGet<EQPAlarmCodeType[]>(
  CallRepairHistoryApis.getFaultTypeApi,
  undefined,
  undefined,
  { immediate: true }
);

//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });
const route = useRoute();
const { query } = route;
// 是否第一次进入
const flowNoIsShow = ref<boolean>(false);
tryOnMounted(() => {
  handleQueryEquipmentList();

  if (!curdRef.value) return;
  if (!curdRef.value.queryFormData) return;
  curdRef.value.queryFormData.flowNo = (query.callNumber as string) || null;
  flowNoIsShow.value = true;
});

// 搜索栏
const queryFormParams: Nullable<QueryType> = {
  treeIds: null,
  eqpIds: null,
  state: null,
  timestamp: useFormatDateRange(),
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1,
  flowNo: null,
  flowType: null,
  faultName: null,
  downTimeStart: null,
  downTimeEnd: null
};
// 重置搜索栏
const refactorFormQueryParams = (data: QueryType) => {
  return {
    ...data,
    flowNo: flowNoIsShow.value ? data.flowNo : query.callNumber,
    ...useFormatDateTimeParams(data.timestamp)
  };
};

const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'flowNo',
    formItemProps: {
      label: i18nt('callNumber')
    }
  },
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        if (curdRef?.value?.queryFormData) curdRef.value.queryFormData.eqpIds = [];
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
              params: { layoutIds: value }
            })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpIds',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'name',
      multiple: true
    }
  },
  {
    type: 'select',
    model: 'faultName',
    formItemProps: { label: i18nt('typeOfMalfunction') },
    componentProps: {
      options: faultNameList.value,
      loading: isLoadingFaultName.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      options: currentStatusList
    }
  },
  {
    type: 'select',
    model: 'flowType',
    formItemProps: { label: i18nt('abnormalityType') },
    componentProps: {
      options: flowTypeList.value,
      loading: isLoadingFlowTypeList.value,
      labelField: 'name',
      valueField: 'id'
    }
  },

  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('callTime') },
    componentProps: { type: 'datetimerange', clearable: false }
  },
  {
    type: 'custom-form-item',
    model: 'productName',
    formItemProps: { label: i18nt('downtimeDuration') },
    render() {
      if (!curdRef.value) return;
      if (!curdRef.value.queryFormData) return;
      return (
        <div class="flex items-center">
          <base-input-number
            class="mr"
            max={99999}
            min={0}
            on-blur={() => {
              if (!curdRef.value) return;
              if (!curdRef.value.queryFormData) return;
              if (!curdRef.value.queryFormData.downTimeStart) return;
              if (!curdRef.value.queryFormData.downTimeEnd) return;
              if (curdRef.value.queryFormData.downTimeStart > curdRef.value.queryFormData.downTimeEnd) {
                curdRef.value.queryFormData.downTimeStart = null;
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('start') + i18nt('lengthOfTime')}
            precision={0}
            v-model:value={curdRef.value.queryFormData.downTimeStart}
          >
            {{
              suffix: () => h('span', null, i18nt('minute'))
            }}
          </base-input-number>
          -
          <base-input-number
            class="ml"
            max={99999}
            min={0}
            on-blur={() => {
              if (!curdRef.value) return;
              if (!curdRef.value.queryFormData) return;
              if (!curdRef.value.queryFormData.downTimeStart) return;
              if (!curdRef.value.queryFormData.downTimeEnd) return;
              if (curdRef.value.queryFormData.downTimeEnd < curdRef.value.queryFormData.downTimeStart) {
                curdRef.value.queryFormData.downTimeEnd = null;
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('end') + i18nt('lengthOfTime')}
            precision={0}
            v-model:value={curdRef.value.queryFormData.downTimeEnd}
          >
            {{
              suffix: () => h('span', null, i18nt('minute'))
            }}
          </base-input-number>
        </div>
      );
    }
  }
]);
// 当前状态数组
const currentStatusList = [
  {
    value: 1,
    label: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  {
    value: 2,
    label: i18nt('underRepair')
  },
  {
    value: 3,
    label: i18nt('underInspection')
  },
  {
    value: 9,
    label: i18nt('finalizeTheOrder')
  }
];
// 当前状态对象
const currentStatusObj: {
  [key: number]: {
    color: string;
    title: string;
  };
} = {
  [CallState.toTakeOver]: {
    color: '#F56C6C',
    title: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  [CallState.underRepair]: {
    color: '#F0AD4E',
    title: i18nt('underRepair')
  },
  [CallState.underInspection]: {
    color: '#8B4513',
    title: i18nt('underInspection')
  },
  [CallState.finalizeTheOrder]: {
    color: '#5CB85C',
    title: i18nt('finalizeTheOrder')
  }
};
// 是否转单
const isTransferObj: {
  [key: number]: {
    type: 'default' | 'warning' | 'primary' | 'success' | 'error';
    title: string;
  };
} = {
  0: {
    type: TagState.error,
    title: i18nt('no')
  },
  1: {
    type: TagState.success,
    title: i18nt('yes')
  }
};
// 列表
const curdRefPagination = computed(() => curdRef.value?.pagination);
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('callNumber'),
    key: 'flowNo',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render(rowData) {
      return rowData.state === CallState.finalizeTheOrder
        ? rowData.flowNo
        : useRenderTableTitleEdit(rowData.flowNo, () =>
            detailFormRef.value?.handleOpenModal(rowData, true, currentRoutePowers.value));
    }
  },
  {
    key: 'eqpId',
    title: i18nt('eqpName'),
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },
  {
    title: i18nt('currentState'),
    key: 'state',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return (
        <base-tag
          color={{
            color: currentStatusObj[rowData.state].color,
            textColor: '#FFFFFF',
            borderColor: currentStatusObj[rowData.state].color
          }}
          size={componentSize.value}
        >
          {currentStatusObj[rowData.state].title}
        </base-tag>
      );
    }
  },
  {
    title: i18nt('abnormalityType'),
    key: 'flowType',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('callType'),
    key: 'callType',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('typeOfMalfunction'),
    key: 'faultName',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('transferOrderOrNot'),
    key: 'isTransfer',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return useRenderTableSingleTag(isTransferObj[rowData.isTransfer].type, isTransferObj[rowData.isTransfer].title);
    }
  },
  { title: i18nt('caller'), sorter: true, key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('callTime'), sorter: true, key: 'createTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('orderTaker'), key: 'receiver', width: TABLE_WIDTH_NAME },
  { title: i18nt('orderTakerName'), key: 'receiverName', width: TABLE_WIDTH_NAME },
  { title: i18nt('orderTakingTime'), key: 'receiveTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('repairCompletionTime'), key: 'repairCompleteTime', width: TABLE_WIDTH_DATETIME },
  { title: `${i18nt('downtimeDuration')}(${i18nt('minute')})`, key: 'downTime' },
  { title: i18nt('currentResponsiblePerson'), sorter: true, key: 'currentHandler', width: TABLE_WIDTH_NAME },
  { title: i18nt('currentResponsiblePersonName'), key: 'currentHandlerName', width: TABLE_WIDTH_NAME },
  { title: i18nt('lastDisposeTime'), sorter: true, key: 'systemTime', width: TABLE_WIDTH_DATETIME },
  useRenderTableActionColumn({
    render: rowData =>
      useRenderTableFixedButton('viewDetail', {
        onClick: () => detailFormRef.value?.handleOpenModal(rowData, false, [])
      })
  })
];
// 操作按钮;
const handlePermission = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    edit: () => editFormRef.value?.handleOpenModal(curdRef?.value?.tableRef?.selectedRows[0]),
    reset: () => {
      handleQueryEquipmentList();
    }
  };
  if (permissionAction[permission]) permissionAction[permission]();
};
// 按钮权限控制
const formPermissionDisable = computed(() => {
  const selectedRows = curdRef?.value?.tableRef?.selectedRows;
  let editIsShow = false;
  if (selectedRows?.length === 1) {
    const { state, flowType, callType } = selectedRows[0];
    const stateIsShow = state === 3 ? 1 : state === 9 ? 1 : 2;
    const flowTypeIsShow = flowType.toUpperCase() !== 'QC' ? 1 : 2;
    const callTypeIsShow = callType.toUpperCase() === 'DOWN' ? 1 : 2;
    editIsShow = stateIsShow === 1 ? (flowTypeIsShow === 1 ? callTypeIsShow !== 1 : true) : true;
  } else {
    editIsShow = true;
  }
  return {
    edit: editIsShow
  };
});
// 刷新表格
const resetTable = () => {
  curdRef?.value?.tableRef?.clearSelected();
  curdRef?.value?.handleSearch();
};
</script>

<template>
  <div id="repair-manage">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :table-props="{ scrollX: TABLE_WIDTH_SCROLL_SMALL + 500 }"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :refactor-form-query-params="refactorFormQueryParams"
      :columns="tableColumns"
      :read-api="CallRepairHistoryApis.getCallListApi"
      :export-api="CallRepairHistoryApis.getCallListApi"
      :ignore-form-permission-list="['takeAnOrder', 'turnOrder', 'engineerRepair', 'staging', 'clearStaging']"
      modal-title="repair"
      :form-permission-disable="formPermissionDisable"
      @handle="handlePermission"
    />
    <!-- 编辑 -->
    <editForm ref="editFormRef" @reset-table="resetTable" />
    <!-- 查看详情 -->
    <detailForm ref="detailFormRef" @reset-table="resetTable" />
  </div>
</template>
