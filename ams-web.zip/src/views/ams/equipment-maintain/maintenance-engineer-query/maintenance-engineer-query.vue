<script setup lang="tsx">
import detailForm from './components/detail-form.vue';
import { CallRepairHistoryApis, CallState } from '@/service/apis/ams/equipment-maintain/repair-history';
import type { EQPAlarmCodeType, QueryType, TableListType } from '@/service/apis/ams/equipment-maintain/repair-history';
import { CommonApis } from '@/service/apis/common/common';
import { CallEquipmentOverviewApis } from '@/service/apis/ams/equipment-call/call-equipment-overview';

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);

// 详情弹窗
const detailFormRef = ref();
//  产线层级
const { data: productLineList, isLoading: isLoadingProductLineList } = useAxiosGet<OptionsType[]>(
  CommonApis.getProductionLineLevelQueryApi,
  __,
  __,
  {
    immediate: true
  }
);
// 呼叫异常类型
const { data: flowTypeList, isLoading: isLoadingFlowTypeList } = useAxiosGet<OptionsType[]>(
  CallEquipmentOverviewApis.getFlowTypeApi,
  undefined,
  undefined,
  { immediate: true }
);
// 获取故障类型
const faultNameList = ref<EQPAlarmCodeType[]>();
const { isLoading: isLoadingFaultName, execute: executeGetFaultType } = useAxiosGet<EQPAlarmCodeType[]>(
  CallRepairHistoryApis.getFaultTypeApi
);

//  设备编号
const {
  data: multiChildEquipmentList,
  isLoading: isLoadingEquipmentList,
  execute: handleQueryEquipmentList
} = useAxiosGet<OptionsType[]>(CommonApis.getEquipmentNumberIdListApi);
//  获取子设备编号
const { execute: executeGetMultiChildEquipmentList, isLoading: isLoadingMultiChildEquipmentList } = useAxiosGet<
  OptionsType[]
>(CommonApis.getEqpsByLayoutIdsApi, __, { paramsSerializer: useParamsSerializer() });
const route = useRoute();
const { params } = route;
tryOnMounted(async () => {
  try {
    handleQueryEquipmentList();
    const item = JSON.parse(params.faultName as string);
    formData.value.treeIds = [item.eqpType.toString()];
    const { data } = await executeGetFaultType();
    if (data.value) {
      faultNameList.value = data.value;
      const typeIndex = data.value.findIndex(ele => ele.id === item.faultName);
      formData.value.faultName = typeIndex !== -1 ? item.faultName : null;
    }
    getList();
  } catch (error) {
    console.log(error);
  }
});
// 表单
const { formRef, formData, resetField } = useForm<Nullable<QueryType>>({
  treeIds: null,
  eqpIds: null,
  state: null,
  timestamp: useFormatDateRange(),
  language: appStore.local === LOCAL_DEFAULT ? 0 : 1,
  flowNo: null,
  flowType: null,
  faultName: null,
  downTimeStart: null,
  downTimeEnd: null
});
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'tree-select',
    model: 'treeIds',
    formItemProps: { label: i18nt('productionLineLevel') },
    componentProps: {
      options: productLineList?.value,
      loading: isLoadingProductLineList?.value,
      multiple: true,
      cascade: true,
      checkable: true,
      labelField: 'name',
      keyField: 'id',
      onUpdateValue: async (value: (string | number | null)[]) => {
        formData.value.eqpIds = [];
        const { data } = value?.length
          ? await executeGetMultiChildEquipmentList(__, {
              params: { layoutIds: value }
            })
          : await handleQueryEquipmentList();
        multiChildEquipmentList.value = data.value;
      }
    }
  },
  {
    type: 'select',
    model: 'eqpIds',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: {
      options: multiChildEquipmentList?.value,
      loading: isLoadingMultiChildEquipmentList?.value || isLoadingEquipmentList?.value,
      labelField: 'name',
      valueField: 'name',
      multiple: true
    }
  },
  {
    type: 'select',
    model: 'faultName',
    formItemProps: { label: i18nt('typeOfMalfunction') },
    componentProps: {
      options: faultNameList.value,
      loading: isLoadingFaultName.value,
      labelField: 'name',
      valueField: 'name'
    }
  },
  {
    type: 'input',
    model: 'flowNo',
    formItemProps: {
      label: i18nt('callNumber')
    }
  },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('currentState') },
    componentProps: {
      options: currentStatusList
    }
  },

  {
    type: 'select',
    model: 'flowType',
    formItemProps: { label: i18nt('abnormalityType') },
    componentProps: {
      options: flowTypeList.value,
      loading: isLoadingFlowTypeList.value,
      labelField: 'name',
      valueField: 'id'
    }
  },

  {
    type: 'date-picker',
    model: 'timestamp',
    modelValue: 'formatted-value',
    formItemProps: { label: i18nt('callTime') },
    componentProps: { type: 'datetimerange', clearable: false }
  },
  {
    type: 'custom-form-item',
    model: 'productName',
    formItemProps: { label: i18nt('downtimeDuration') },
    render() {
      return (
        <div class="flex items-center">
          <base-input-number
            class="mr"
            max={99999}
            min={0}
            on-blur={() => {
              if (!formData.value) return;
              if (!formData.value.downTimeStart) return;
              if (!formData.value.downTimeEnd) return;
              if (formData.value.downTimeStart > formData.value.downTimeEnd) {
                formData.value.downTimeStart = null;
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('start') + i18nt('lengthOfTime')}
            precision={0}
            v-model:value={formData.value.downTimeStart}
          >
            {{
              suffix: () => h('span', null, i18nt('minute'))
            }}
          </base-input-number>
          -
          <base-input-number
            class="ml"
            max={99999}
            min={0}
            on-blur={() => {
              if (!formData.value) return;
              if (!formData.value.downTimeStart) return;
              if (!formData.value.downTimeEnd) return;
              if (formData.value.downTimeEnd < formData.value.downTimeStart) {
                formData.value.downTimeEnd = null;
              }
            }}
            placeholder={i18nt('baseForm.pleaseInput') + i18nt('end') + i18nt('lengthOfTime')}
            precision={0}
            v-model:value={formData.value.downTimeEnd}
          >
            {{
              suffix: () => h('span', null, i18nt('minute'))
            }}
          </base-input-number>
        </div>
      );
    }
  }
]);
// 表格配置项
// 表格查询传值更改
const refactorFormQueryParams = (data: QueryType) => {
  return { ...data, ...useFormatDateTimeParams(data.timestamp) };
};
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  tableData,
  tableRef,
  executeQueryList: getList
} = useTable<TableListType[]>(CallRepairHistoryApis.getCallListApi, {
  queryFormParams: formData,
  refactorFormQueryParams,
  paramsSerializerQuery: true
});

// 当前状态数组
const currentStatusList = [
  {
    value: 1,
    label: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  {
    value: 2,
    label: i18nt('underRepair')
  },
  {
    value: 3,
    label: i18nt('underInspection')
  },
  {
    value: 9,
    label: i18nt('finalizeTheOrder')
  }
];
// 当前状态对象
const currentStatusObj: {
  [key: number]: {
    color: string;
    title: string;
  };
} = {
  [CallState.toTakeOver]: {
    color: '#F56C6C',
    title: i18nt('RepairOperateStateEnum_ToTakeOver')
  },
  [CallState.underRepair]: {
    color: '#F0AD4E',
    title: i18nt('underRepair')
  },
  [CallState.underInspection]: {
    color: '#8B4513',
    title: i18nt('underInspection')
  },
  [CallState.finalizeTheOrder]: {
    color: '#5CB85C',
    title: i18nt('finalizeTheOrder')
  }
};
// 是否转单
const isTransferObj: {
  [key: number]: {
    type: 'default' | 'warning' | 'primary' | 'success' | 'error';
    title: string;
  };
} = {
  0: {
    type: TagState.error,
    title: i18nt('no')
  },
  1: {
    type: TagState.success,
    title: i18nt('yes')
  }
};
const renderIndex = computed<PaginationProps>(() => ({
  page: pagination?.value?.page,
  pageSize: pagination.value.pageSize
}));
const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(renderIndex),
  {
    title: i18nt('callNumber'),
    key: 'flowNo',
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND,
    render(rowData) {
      return useRenderTableTitleEdit(rowData.flowNo, () => detailFormRef.value?.handleOpenModal(rowData, true, []));
    }
  },
  {
    key: 'eqpId',
    title: i18nt('eqpName'),
    sorter: true,
    width: TABLE_WIDTH_DATETIME_MILLISECOND
  },

  {
    title: i18nt('currentState'),
    key: 'state',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return (
        <base-tag
          color={{
            color: currentStatusObj[rowData.state].color,
            textColor: '#FFFFFF',
            borderColor: currentStatusObj[rowData.state].color
          }}
          size={componentSize.value}
        >
          {currentStatusObj[rowData.state].title}
        </base-tag>
      );
    }
  },
  {
    title: i18nt('abnormalityType'),
    key: 'flowType',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('callType'),
    key: 'callType',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('typeOfMalfunction'),
    key: 'faultName',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('transferOrderOrNot'),
    key: 'isTransfer',
    sorter: true,
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return useRenderTableSingleTag(isTransferObj[rowData.isTransfer].type, isTransferObj[rowData.isTransfer].title);
    }
  },
  { title: i18nt('caller'), sorter: true, key: 'creator', width: TABLE_WIDTH_NAME },
  { title: i18nt('callTime'), sorter: true, key: 'createTime', width: TABLE_WIDTH_DATETIME },

  { title: i18nt('orderTaker'), key: 'receiver', width: TABLE_WIDTH_NAME },
  { title: i18nt('orderTakerName'), key: 'receiverName', width: TABLE_WIDTH_NAME },
  { title: i18nt('orderTakingTime'), key: 'receiveTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('repairCompletionTime'), key: 'repairCompleteTime', width: TABLE_WIDTH_DATETIME },

  { title: `${i18nt('downtimeDuration')}(${i18nt('minute')})`, key: 'downTime' },
  { title: i18nt('currentResponsiblePerson'), sorter: true, key: 'currentHandler', width: TABLE_WIDTH_NAME },
  { title: i18nt('currentResponsiblePersonName'), key: 'currentHandlerName', width: TABLE_WIDTH_NAME },
  { title: i18nt('lastDisposeTime'), sorter: true, key: 'systemTime', width: TABLE_WIDTH_DATETIME }
];

// 按钮事件
const handleButton = (permission: PermissionType) => {
  const columnsList: { [key: string]: () => void } = {
    reset: () => {
      resetField();
      pagination.value.page = 1;
      handleQueryEquipmentList();
      getList();
    },
    search: () => {
      pagination.value.page = 1;
      getList();
    }
  };
  columnsList[permission as string]();
};
// 刷新表格
const resetTable = () => {
  tableRef?.value?.clearSelected();
  getList();
};
</script>

<template>
  <base-card id="spares-basic-information">
    <!-- 搜索 -->
    <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" label-align="right" layout="page">
      <template #header-action>
        <permission-button form :loading-props="{ searchLoading: isLoadingQuery }" @handle="handleButton" />
      </template>
    </base-form>
    <!-- 表格 -->
    <base-table
      ref="tableRef"
      class="mt"
      remote
      :scroll-x="TABLE_WIDTH_SCROLL_SMALL + 500"
      :columns="tableColumns"
      :data="tableData ?? []"
      :loading="isLoadingQuery"
      :pagination="pagination"
      @update:sorter="handleSorterChange"
    />
    <!-- 查看详情 -->
    <detailForm ref="detailFormRef" @reset-table="resetTable" />
  </base-card>
</template>
