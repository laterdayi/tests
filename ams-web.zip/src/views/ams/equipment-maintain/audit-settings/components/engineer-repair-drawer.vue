<script setup lang="tsx">
import { useCloned } from '@vueuse/core';
import formDesigner from '@/components/project/form-designer/form-designer.vue';
import type { WidgetType } from '@/components/project/form-designer/utils/designer-type';
import {
  FormItemMethodApis,
  handleTableTransformList,
  handleValidateFormIsMaxItemValue,
  handleValidateFormIsPass,
  handleValidateStagingFormIsPass,
  tableLenght
} from '@/components/project/form-designer/utils/form-item-method';
import type { FormItemListType } from '@/components/project/form-designer/utils/form-item-type';

import type {
  MaintenanceFormDataType,
  MaintenanceInformationType
} from '@/service/apis/ams/equipment-maintain/repair-history';

const emit = defineEmits<{
  'drawer-from': [isShow: boolean, value: MaintenanceFormDataType | undefined];
}>();

// 表单存储
const formInfoData = ref<MaintenanceInformationType>();
// 获取表单列表信息
const { execute: executeGetFormItemList } = useAxiosPost<FormItemListType>(
  FormItemMethodApis.getFormItemListApi,
  __,
  __,
  {
    shallow: false
  }
);
// 表单数据
const formDesignerRef = ref();
const widgetList = ref<WidgetType[]>([]);
const formName = ref<string>();
// 存储回填数据
const maintenanceDrawerOld = ref<MaintenanceFormDataType>();

//  打开弹窗
const showDrawer = ref<boolean>(false);
// 展示类型
const drawerType = ref<number>(2);
const fromResult = ref<number | undefined>(1);
// 是否暂存
const tableLenghtIsShow = ref<boolean>(false);
const handleOpenModal = async (
  isShow: boolean,
  maintenanceInformationData: MaintenanceInformationType,
  drawerForm?: MaintenanceFormDataType,
  type = 2,
  formNameOpen?: string
) => {
  drawerType.value = type;
  tableLenghtIsShow.value = isShow;
  formInfoData.value = maintenanceInformationData;
  formName.value = formNameOpen;
  try {
    if (drawerForm) {
      maintenanceDrawerOld.value = drawerForm;
      const { cloned } = useCloned(maintenanceDrawerOld);
      if (!cloned.value) return;
      widgetList.value = cloned.value.table ? [cloned.value.table] : [];
      fromResult.value = cloned.value.fromResult;
    } else {
      if (maintenanceInformationData.eFormId) {
        // 获取表单列表信息
        const { data } = await executeGetFormItemList(__, {
          data: { formId: maintenanceInformationData.eFormId },
          showTooltip: false
        });
        if (!data.value) return;
        widgetList.value = data.value.table ? [data.value.table] : [];
      }
    }
    showDrawer.value = true;
  } catch (error) {
    console.log(error);
  }
};

// 确认
const handleSubmitFormConfirm = () => {
  const list = handleTableTransformList(formDesignerRef.value.designerHandle().widgetList[0]) || [];
  // 表格长度验证
  if (handleValidateFormIsMaxItemValue(list)) return;
  tableLenghtIsShow.value = tableLenght(list) || false;
  // 表格效验验证

  if (!tableLenghtIsShow.value) {
    if (!handleValidateFormIsPass(list)) return;
  } else {
    if (!handleValidateStagingFormIsPass(list)) return;
  }

  if (!formInfoData.value) return;
  const obj = {
    formInfoData: formInfoData.value,
    table: formDesignerRef.value.designerHandle().widgetList[0]
  };
  emit('drawer-from', tableLenghtIsShow.value, obj);
  showDrawer.value = false;
};
// 关闭抽屉
const cancelDrawer = () => {
  showDrawer.value = false;
  if (!maintenanceDrawerOld.value) return;
  emit('drawer-from', tableLenghtIsShow.value, maintenanceDrawerOld.value);
  showDrawer.value = false;
};

const tagStateType: { [keys in number]: 'default' | 'success' | 'error' | 'primary' | 'info' | 'warning' } = {
  1: 'success',
  0: 'error'
};
const tagStateText: { [keys in number]: string } = {
  1: 'Pass',
  0: 'Fail'
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <!--  维修完成 -->
  <base-drawer
    v-model:show="showDrawer"
    width="85%"
    :title="formName || i18nt('RepairActionEnum_RepairComplete')"
    @mask-click="() => cancelDrawer"
  >
    <div v-if="drawerType === 1" class="card-title">
      <base-tag class="ml" :type="tagStateType[fromResult || 0]">
        {{ tagStateText[fromResult || 0] }}
      </base-tag>
    </div>

    <formDesigner
      ref="formDesignerRef"
      :basic-fields="[]"
      :basic-fields-contro="[]"
      :basic-fields-shared="[]"
      :basic-fields-project="[]"
      :project-name="null"
      :form-height="drawerType === 1 ? 161 : 120"
      :widget-list="widgetList"
      :preview-type="2"
      :preview-is-show="false"
      :table-item-component-is-show="drawerType === 1"
    />

    <template #footer>
      <base-button class="m-r" button-name="cancel" ghost @click="cancelDrawer">
        {{ $t('cancel') }}
      </base-button>
      <base-button v-if="drawerType === 2" button-name="confirm" type="primary" ghost @click="handleSubmitFormConfirm">
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-drawer>
</template>
