<script setup lang="ts">
import { AlarmSettingControlApis } from '@/service/apis/ams/equipment-maintain/alarm-setting-control';
import type { EditType, QueryType, TableListType } from '@/service/apis/ams/equipment-maintain/alarm-setting-control';

// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();

// 查询表单配置
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'eqpType',
    formItemProps: {
      label: i18nt('machineType'),
      rule: [useRuleStringLength(0, 50)]
    }
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: {
      label: i18nt('alarmEncoding'),
      rule: [useRuleStringLength(0, 50)]
    }
  },
  {
    type: 'input',
    model: 'alarmDescription',
    formItemProps: {
      label: i18nt('alarmInstructions'),
      rule: [useRuleStringLength(0, 50)]
    }
  },
  {
    type: 'input',
    model: 'alid',
    formItemProps: {
      label: 'ALID(DEC)'
    }
  },
  {
    type: 'input-number',
    model: 'lockLimit',
    formItemProps: {
      label: i18nt('lockScreenFreqLimit')
    },
    componentProps: {
      min: 0,
      max: 99999,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, i18nt('freq')) }]
  },
  {
    type: 'input-number',
    model: 'frequency',
    formItemProps: {
      label: i18nt('frequencyH')
    },
    componentProps: {
      min: 0,
      max: 99999,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, 'H') }]
  },
  {
    type: 'switch',
    model: 'isOP',
    formItemProps: { label: i18nt('OPHandlingOrNot') },
    componentProps: { checkedValue: 'Y', uncheckedValue: 'N' }
  },
  {
    type: 'switch',
    model: 'isValid',
    formItemProps: { label: i18nt('effectiveOrNot') },
    componentProps: { checkedValue: 'Y', uncheckedValue: 'N' }
  }
]);
const queryFormParams: Nullable<QueryType> = {
  eqpType: null,
  alarmId: null,
  alarmDescription: null,
  alid: null,
  lockLimit: null,
  frequency: null,
  isOP: null,
  isValid: null
};
// 弹窗表单配置
const formParams: Nullable<EditType> = {
  eqpType: null,
  alarmId: null,
  alarmDescription: null,
  alid: null,
  lockLimit: null,
  frequency: null,
  isOP: 'Y',
  isValid: 'Y'
};
const formSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'eqpType',
    formItemProps: {
      label: i18nt('machineType'),
      rule: [useRules('input', i18nt('machineType')), useRuleStringLength(0, 50)]
    }
  },
  {
    type: 'input',
    model: 'alarmId',
    formItemProps: {
      label: i18nt('alarmEncoding'),
      rule: [useRules('input', i18nt('alarmEncoding')), useRuleStringLength(0, 50)]
    }
  },
  useRenderFormTextarea({
    label: i18nt('alarmInstructions'),
    formItemProps: { rule: useRules('input', i18nt('alarmInstructions')) },
    model: 'alarmDescription',
    formItemClass: 'col-span-2!'
  }),
  {
    type: 'input',
    model: 'alid',
    formItemProps: {
      label: 'ALID(DEC)',
      rule: [useRuleStringLength(0, 50)]
    },
    formItemClass: 'col-span-2!'
  },
  {
    type: 'input-number',
    model: 'lockLimit',
    formItemProps: {
      label: i18nt('lockScreenFreqLimit')
    },
    componentProps: {
      min: 0,
      max: 99999,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, i18nt('freq')) }],

  },
  {
    type: 'input-number',
    model: 'frequency',
    formItemProps: {
      label: i18nt('frequencyH')
    },
    componentProps: {
      min: 0,
      max: 99999,
      precision: 0
    },
    slots: [{ name: 'suffix', render: () => h('span', null, 'H') }],
  },
  {
    type: 'switch',
    model: 'isOP',
    formItemProps: { label: i18nt('OPHandlingOrNot') },
    componentProps: { checkedValue: 'Y', uncheckedValue: 'N' },
    formItemClass: 'w-min!'
  },
  {
    type: 'switch',
    model: 'isValid',
    formItemProps: { label: i18nt('effectiveOrNot') },
    componentProps: { checkedValue: 'Y', uncheckedValue: 'N' },
    formItemClass: 'w-min!'
  },

]);
// 表格数据配置
const curdRefPagination = computed(() => curdRef.value?.pagination);
const tableColumns: DataTableColumns<TableListType> = [
  { type: 'selection' },
  useRenderTableIndex(curdRefPagination),
  {
    title: i18nt('machineType'),
    key: 'eqpType',
    sorter: true,
    render: (rowData: TableListType) =>
      useRenderTableTitleEdit(rowData.eqpType, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  {
    title: i18nt('alarmEncoding'),
    key: 'alarmId',
    sorter: true
  },
  {
    title: i18nt('alarmInstructions'),
    key: 'alarmDescription'
  },
  {
    title: i18nt('OPHandlingOrNot'),
    key: 'isOP',
    sorter: true,
    width: TABLE_WIDTH_DATE
  },
  {
    title: 'ALID(DEC)',
    key: 'alid'
  },
  {
    title: `${i18nt('lockScreenFreqLimit')}(${i18nt('freq')})`,
    key: 'lockLimit',
    sorter: true,
    width: TABLE_WIDTH_DATETIME
  },
  {
    title: `${i18nt('frequencyH')}(${i18nt('freq')})`,
    key: 'frequency',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  {
    title: i18nt('effectiveOrNot'),
    key: 'isValid',
    sorter: true,
    width: TABLE_WIDTH_STATE
  },
  { title: i18nt('registrant'), key: 'creator', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('registrationTime'), key: 'createTime', sorter: true, width: TABLE_WIDTH_DATETIME },
  { title: i18nt('updater'), key: 'editor', sorter: true, width: TABLE_WIDTH_NAME },
  { title: i18nt('updateTime'), key: 'editTime', sorter: true, width: TABLE_WIDTH_DATETIME }
];
</script>

<template>
  <div id="spares-model-manage">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :form-props="{
        labelWidth: 130
      }"
      :read-api="AlarmSettingControlApis.getListApi"
      :delete-api="AlarmSettingControlApis.deleteApi"
      modal-title="alarmSettingControl"
      :create-api="AlarmSettingControlApis.addApi"
      :edit-detail-api="AlarmSettingControlApis.getDetailApi"
      :update-api="AlarmSettingControlApis.updateApi"
      :export-api="AlarmSettingControlApis.getListApi"
      :import-api="AlarmSettingControlApis.importApi"
      :download-api="AlarmSettingControlApis.downloadApi"
    />
  </div>
</template>
