<script lang="ts">
import { OpenState } from '@/constants/enum';
import { CommonApis } from '@/service/apis/common/common';
import { EquipmentUnlockApis } from '@/service/apis/ams/equipment-maintain/equipment-unlock';

interface QueryType {
  eqpId?: string
  state?: OpenState
}

interface TableListType {
  eqpId: string
  id: string
  isLock: OpenState
  lockTime: string
  operator: string
  reason: string
  releaseTime: string
}
</script>

<script setup lang="ts">
const { hasCustomPermission } = useRoutes();
const { showModal, openModal, closeModal } = useModal();

// 获取设备编号列表
const { data: equipmentNumberList, isLoading: isLoadingEquipmentNumberList } = useAxiosGet<OptionsType[]>(
  CommonApis.getEquipmentNumberIdListApi,
  {},
  { paramsSerializer: useParamsSerializer() },
  {
    immediate: true
  }
);

// 模板引用
const curdRef = ref<CurdRefType<QueryType, never, TableListType>>();
// 查询表单模型
const queryFormSchemas = computed<FormSchemaType>(() => [
  {
    type: 'select',
    model: 'eqpId',
    formItemProps: { label: i18nt('equipmentNumber') },
    componentProps: computed(() => ({
      multiple: true,
      options: equipmentNumberList?.value,
      loading: isLoadingEquipmentNumberList?.value,
      labelField: 'name',
      valueField: 'name'
    }))
  },
  {
    type: 'select',
    model: 'state',
    formItemProps: { label: i18nt('whetherLockMachine') },
    componentProps: {
      options: [
        { label: i18nt('lockMachine'), value: 1 },
        { label: i18nt('unlockMachine'), value: 0 }
      ]
    }
  }
]);
const queryFormParams: Nullable<QueryType> = { eqpId: null, state: null };
const curdRefPagination = computed(() => curdRef.value?.pagination);

const currentOperateId = ref('');

const { formRef, validate, formData, resetField } = useForm<Nullable<{ reason: string }>>({
  reason: null
});

const formSchemas: FormSchemaType = [
  {
    type: 'input',
    model: 'reason',
    formItemProps: {
      label: i18nt('unlockReason'),
      rule: useRules('input', i18nt('unlockReason'))
    },
    componentProps: { type: 'textarea' }
  }
];

// 解锁
const { isLoading: isLoadingUnlock, execute: executeUnlock } = useAxiosPost(EquipmentUnlockApis.equipmentUnlockApi);

const handleSubmitUnlock = async () => {
  try {
    const { reason } = formData.value;
    await validate();
    await executeUnlock({
      data: { reason, id: currentOperateId.value }
    });
    closeModal();
    resetField();
    curdRef.value?.handleSearch();
  } catch (error) {
    console.log(error);
  }
};

const handleClose = () => {
  closeModal();
  resetField();
};

const tableColumns: DataTableColumns<TableListType> = [
  useRenderTableIndex(curdRefPagination),
  { title: i18nt('equipmentNumber'), key: 'eqpId', sorter: true, width: TABLE_WIDTH_INFO },
  {
    title: i18nt('whetherLockMachine'),
    key: 'isLock',
    width: TABLE_WIDTH_STATE,
    render(rowData) {
      return useRenderTableSingleTag(
        rowData.isLock ? TagState.error : TagState.success,
        rowData.isLock ? i18nt('lockMachine') : i18nt('unlockMachine')
      );
    }
  },
  { title: i18nt('lockMachineTime'), key: 'lockTime', width: TABLE_WIDTH_DATETIME },
  { title: i18nt('unlockPerson'), key: 'operator', width: TABLE_WIDTH_NAME },
  { title: i18nt('unlockTime'), key: 'releaseTime', width: TABLE_WIDTH_DATETIME },
  { title: `${i18nt('lockMachine')}/${i18nt('unlockReason')}`, key: 'reason' },
  useRenderTableActionColumn({
    render: (rowData: TableListType) => {
      return useRenderTableFixedButton('equipmentUnlock', {
        disabled: !hasCustomPermission('equipmentUnlock') || rowData.isLock === OpenState.close,
        onClick: () => {
          currentOperateId.value = rowData.id;
          openModal();
        }
      });
    }
  })
];
</script>

<template>
  <div id="supplier-manage">
    <base-curd
      ref="curdRef"
      params-serializer-query
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :columns="tableColumns"
      :read-api="EquipmentUnlockApis.getEquipmentLockListApi"
      :ignore-form-permission-list="['equipmentUnlock']"
    />
    <base-modal
      class="w-35%!"
      :loading="isLoadingUnlock"
      :show="showModal"
      :title="$t('unlock')"
      @close="handleClose"
      @negative-click="handleClose"
      @positive-click="handleSubmitUnlock"
    >
      <base-form ref="formRef" v-model="formData" type="query" layout="dialog" :schemas="formSchemas" />
    </base-modal>
  </div>
</template>
