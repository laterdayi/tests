import type { AlarmStateType } from '@/service/apis/ams/query-statistics/alarm-history-record';

export interface AlarmStatisticsDataType {
  totalAlarmCount: number;
  onGoingCount: number;
  closeAlarmCount: number;
  alarmEqpCount: number;
  totalEqpCount: number;
  alarmEqpPercent: number;
}
export interface AlarmActionProps {
  id: string;
  name: string;
  model: string;
}

// 查找对应的报警动作
export const alarmActionType: { [key: number]: string } = {
  1: 'HoldLot',
  2: 'HoldEquipment',
  3: 'SendEmail',
  4: 'SendSMS',
  5: 'LockEquipment',
  6: 'SendWeChatMessage',
  7: 'SendEnterpriseWeChatMessage',
  8: 'SendMWSMSSwitch',
  9: 'SendfeishuSwitch',
  10: 'holdInhibitEqpSwitch',
  11: 'SendRepair',
  12: 'qywxGroupNotifySwitch',
  13: 'sendDingTalkSwitch'
};
export const alarmActionEnum: AlarmActionProps[] = [
  { id: '1', name: 'HoldLot', model: 'holdlotSwicth' },
  { id: '2', name: 'HoldEquipment', model: 'holdeqpSwitch' },
  { id: '3', name: 'SendEmail', model: 'sendEmailSwitch' },
  { id: '4', name: 'SendSMS', model: 'sendSMSSwitch' },
  { id: '5', name: 'LockEquipment', model: 'lockeqpSwitch' },
  { id: '6', name: 'SendWeChatMessage', model: 'sendwxSwitch' },
  { id: '7', name: 'SendEnterpriseWeChatMessage', model: 'sendqywxSwitch' },
  { id: '8', name: 'SendMWSMSSwitch', model: 'sendMWSMSSwitch' },
  { id: '9', name: 'SendfeishuSwitch', model: 'sendfeishuSwitch' },
  { id: '10', name: 'holdInhibitEqpSwitch', model: 'holdInhibitEqpSwitch' },
  { id: '11', name: 'SendRepair', model: 'sendRepair' },
  { id: '12', name: 'qywxGroupNotifySwitch', model: 'qywxGroupNotifySwitch' },
  { id: '13', name: 'sendDingTalkSwitch', model: 'sendDingTalkSwitch' }
];
export const formatAlarmList = (actionList: AlarmActionProps[]) => {
  return (actionList || []).reduce((prev: AlarmActionProps[], curv) => {
    const find = alarmActionEnum.find((item: AlarmActionProps) => item.id === curv.id);
    if (find) {
      prev.push(find);
    }
    return prev;
  }, []);
};
// 报警状态
export const alarmStatusType: {
  [key: string]: TagStateType;
} = {
  Open: TagState.error,
  Acknowledge: TagState.primary,
  Pending: TagState.warning,
  Close: TagState.success
};
export const resultOptions = [
  { id: 0, name: i18nt('processing') },
  { id: 1, name: i18nt('success') },
  { id: 2, name: i18nt('failed') }
];
// 动作类别
export const actionCategoryList = [
  {
    value: 0,
    label: i18nt('alarmTriggered')
  },
  {
    value: 1,
    label: i18nt('alarmCleared')
  },
  {
    value: 2,
    label: i18nt('escalationReported')
  },
  {
    label: i18nt('manualAlarm'),
    value: 3
  }
];
export const actionCategoryObj: {
  [key: number]: string;
} = {
  0: i18nt('alarmTriggered'),
  1: i18nt('alarmCleared'),
  2: i18nt('escalationReported'),
  3: i18nt('manualAlarm'),
  4: i18nt('manualAlarm')
};

// 报警类别
export const alarmCategoryList = [
  {
    label: i18nt('validAlarm'),
    value: 0
  },
  {
    label: i18nt('invalidAlarm'),
    value: 1
  },
  {
    label: i18nt('notTriggered'),
    value: 2
  },
  {
    label: i18nt('duplicateAlarm'),
    value: 3
  },
  {
    label: i18nt('manualAlarm'),
    value: 4
  },
  {
    label: i18nt('filterAlarms'),
    value: 6
  }
];
export const alarmCategoryObj: {
  [key: string]: AlarmStateType;
} = {
  0: {
    label: i18nt('validAlarm'),
    type: TagState.success
  },
  1: {
    label: i18nt('invalidAlarm'),
    type: TagState.error
  },
  2: {
    label: i18nt('notTriggered'),
    type: TagState.warning
  },
  3: {
    label: i18nt('duplicateAlarm'),
    type: TagState.primary
  },
  4: {
    label: i18nt('manualAlarm'),
    type: TagState.success
  },
  5: {
    label: i18nt('manualAlarm'),
    type: TagState.success
  },
  6: {
    label: i18nt('filterAlarms'),
    type: TagState.success
  }
};
