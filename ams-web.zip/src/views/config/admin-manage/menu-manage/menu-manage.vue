<script lang="tsx">
import type { SortableEvent } from 'sortablejs';
import type { SelectOption } from 'naive-ui';
import { PRESET_PERMISSION_BUTTON } from '@/components/permission-button/permission-button.vue';
import { MenuManageApis } from '@/service/apis/config/admin-manage/menu-manage';
import { ICONS } from '@/assets/icons';
import { LayoutType } from '@/constants/enum';
import { PERMISSION_BUTTON_CUSTOM_SETS } from '@/components/permission-button/constants';
import type { MenuListType } from '@/service/apis/common/type';
import type { BaseFormRefType } from '@/components/base-ui/base-form/hooks';

enum MenuType {
  web = 1,
  app = 2
}

type EditType = Omit<
  MenuListType,
  'hasChildren' | 'name' | 'isLeaf' | 'path' | 'pid' | 'type' | 'is_superadmin' | 'label' | 'powersList' | 'powers'
> & {
  cache: number;
  layoutType?: LayoutType;
  description: string;
  parentId?: string;
  powers: (string | null | undefined)[];
  powersPosition: string[];
  cnTitle: string;
  enTitle: string;
  badge: number;
};

const initFormSchemas = (
  formData: Ref<Nullable<EditType>>,
  menuList: Ref<MenuListType[] | undefined>,
  showIcon: Ref<boolean>,
  handleUpdateCustomPermission: (val: string[]) => void,
  unselectedPermissionOptions: ComputedRef<SelectOption[]>,
  formRef: BaseFormRefType | null
): FormSchemaType => [
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('menuCategory') },
    render() {
      return (
        <>
          <n-radio-group v-model:value={formData.value.category}>
            <n-radio-button value={1}>{i18nt('web')}</n-radio-button>
            <n-radio-button value={2}>{i18nt('app')}</n-radio-button>
          </n-radio-group>
        </>
      );
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('menuIsVisible') },
    render() {
      return (
        <>
          <n-radio-group v-model:value={formData.value.visible}>
            <n-radio-button value={1}>{i18nt('visible')}</n-radio-button>
            <n-radio-button value={0}>{i18nt('inVisible')}</n-radio-button>
          </n-radio-group>
        </>
      );
    }
  },
  {
    type: 'custom-form-item',
    formItemProps: { label: i18nt('externalLink') },
    render() {
      return (
        <>
          <n-radio-group v-model:value={formData.value.link}>
            <n-radio-button value={1}>{i18nt('yes')}</n-radio-button>
            <n-radio-button value={0}>{i18nt('no')}</n-radio-button>
          </n-radio-group>
        </>
      );
    }
  },
  {
    type: 'input',
    model: 'routeName',
    formItemProps: {
      label: i18nt(formData?.value?.link ? 'linkName' : 'routeName'),
      rule: [
        useRules('input', formData?.value?.link ? i18nt('linkName') : i18nt('routeName')),
        useRuleStringLength(0, 100)
      ],
      path: 'routeName'
    },
    componentProps: {
      onInput: (value: string) => (formData.value.routeAddress = kebabCase(value))
    }
  },
  formData.value.category === MenuType.app
    ? __
    : {
        type: 'input',
        model: 'routeAddress',
        formItemProps: {
          label: i18nt(formData?.value?.link ? 'linkPath' : 'routePath'),
          rule: useRuleStringLength(0, 150)
        }
      },
  formData.value?.link || formData.value.category === MenuType.app
    ? __
    : {
        type: 'input',
        model: 'componentPath',
        formItemProps: { label: i18nt('componentPath'), rule: useRuleStringLength(0, 150) }
      },
  formData.value?.link || formData.value.category === MenuType.app
    ? __
    : {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('layout') },
        render() {
          return (
            <>
              <base-popover
                v-slots={{
                  trigger: () => (
                    <n-radio-group v-model:value={formData.value.layoutType}>
                      <n-radio-button value={LayoutType.default}>{i18nt('layout1')}</n-radio-button>
                      <n-radio-button value={LayoutType.blank}>{i18nt('layout2')}</n-radio-button>
                    </n-radio-group>
                  )
                }}
              >
                <span v-html={i18nt('layoutTips')}></span>
              </base-popover>
            </>
          );
        }
      },
  {
    type: 'input-number',
    model: 'order',
    formItemProps: {
      label: i18nt('order'),
      rule: [
        useRules('input-number', 'onlyPositiveIntZeroRule', { required: true, message: i18nt('order') }),
        useRuleNumberLength()
      ]
    }
  },
  {
    type: 'tree-select',
    model: 'parentId',
    formItemProps: { label: i18nt('parentMenu') },
    componentProps: {
      options: useFormatTreeTranslate(menuList.value, 'routeName'),
      keyField: 'id',
      labelField: 'routeName'
    }
  },
  formData.value.category === MenuType.web
    ? {
        type: 'custom-form-item',
        model: 'icon',
        formItemProps: { label: i18nt('icon'), rule: { ...useRules('input', i18nt('icon')), key: 'icon' } },
        render() {
          return (
            <>
              <base-popover
                onClickoutside={() => (showIcon.value = false)}
                show={showIcon.value}
                trigger="click"
                v-slots={{
                  trigger: () => (
                    <n-input
                      onClick={() => (showIcon.value = true)}
                      placeholder={i18nt('pleaseSelectIcon')}
                      readonly
                      v-model:value={formData.value.icon}
                      v-slots={{
                        suffix: () =>
                          formData.value?.icon ? <base-icon icon={formData.value.icon}></base-icon> : <div></div>
                      }}
                    >
                    </n-input>
                  )
                }}
                width="trigger"
              >
                <n-scrollbar class="max-h-340px" v-if={formData.value.category === MenuType.web}>
                  <div class="grid grid-cols-9">
                    {ICONS.map(item => (
                      <base-icon
                        class="mr mb mt cursor-pointer"
                        icon={item}
                        key={item}
                        onClick={() => {
                          formData.value.icon = item;
                          showIcon.value = false;
                          formRef?.baseFormRef?.validate(__, rule => rule?.key === 'icon');
                        }}
                      >
                      </base-icon>
                    ))}
                  </div>
                </n-scrollbar>
              </base-popover>
            </>
          );
        }
      }
    : {
        type: 'input',
        model: 'icon',
        formItemProps: { label: i18nt('icon'), rule: useRules('input', i18nt('icon')) }
      },
  formData.value.category === MenuType.app
    ? {
        type: 'input',
        model: 'cnTitle',
        formItemProps: { label: i18nt('cnTitle') },
        componentProps: { 'replaceSpace': false }
      }
    : __,
  formData.value.category === MenuType.app
    ? {
        type: 'input',
        model: 'enTitle',
        formItemProps: { label: i18nt('enTitle') },
        componentProps: { 'replaceSpace': false }
      }
    : __,
  formData.value.category === MenuType.app
    ? {
        type: 'input-number',
        model: 'badge',
        componentProps: {
          min: 0
        },
        formItemProps: {
          label: i18nt('badge'),
          rule: [
            useRules('input-number', 'onlyPositiveIntZeroRule', { required: false, message: i18nt('badge') }),
            useRuleNumberLength()
          ]
        }
      }
    : __,
  useRenderFormTextarea(),
  formData.value?.link || formData.value.category === MenuType.app
    ? __
    : {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('isCache') },
        render() {
          return (
            <>
              <n-radio-group v-model:value={formData.value.cache}>
                <n-radio-button value={1}>{i18nt('yes')}</n-radio-button>
                <n-radio-button value={0}>{i18nt('no')}</n-radio-button>
              </n-radio-group>
            </>
          );
        }
      },
  formData.value?.link || formData.value.category === MenuType.app
    ? __
    : useRenderFormSwitch({ key: 'isClosePower', label: i18nt('permissionButton'), formItemClass: 'w-min!' }),
  formData.value?.isClosePower && formData.value?.link === 0 && formData.value.category !== MenuType.app
    ? {
        type: 'custom-form-item',
        formItemProps: { label: i18nt('permissionButton') },
        formItemClass: 'col-span-2!',
        render() {
          return (
            <>
              <n-checkbox-group v-model:value={formData.value.powers}>
                <div id="permission-button-area">
                  {formData.value?.powersPosition?.map((item, index) => (
                    <n-checkbox class="mr-5px mb-15px" key={item} value={item}>
                      {i18nt(item)}

                      <div
                        class="inline-block rounded-full w-16px h-16px bg-red relative bottom-10px left-5px cursor-pointer"
                        onClick={e => {
                          e.stopPropagation();
                          const findPowerIndex = findIndex(formData.value.powers, power => power === item);
                          if (findPowerIndex !== -1) formData.value.powers?.splice(findPowerIndex, 1);
                          formData.value.powersPosition?.splice(index, 1);
                        }}
                      >
                        <base-icon
                          class="relative bottom-4px left-1px"
                          color="#fff"
                          icon="i-carbon:close"
                          size={14}
                        >
                        </base-icon>
                      </div>
                    </n-checkbox>
                  ))}
                </div>
                {unselectedPermissionOptions.value.length ? (
                  <base-popselect
                    multiple
                    onUpdateValue={handleUpdateCustomPermission}
                    options={unselectedPermissionOptions.value}
                  >
                    <base-button
                      button-name="otherPermission"
                      class="mt-5px"
                      type="primary"
                      v-slots={{
                        icon: () => <base-icon icon="i-carbon:add" />
                      }}
                    >
                      {i18nt('otherPermission')}
                    </base-button>
                  </base-popselect>
                ) : (
                  <div></div>
                )}
              </n-checkbox-group>
            </>
          );
        }
      }
    : __
];
</script>

<script setup lang="tsx">
const routeStore = useRouteStore();

// 获取菜单列表
const {
  data: menuList,
  execute: executeGetMenuList,
  isLoading: isLoadingMenuList
} = useAxiosGet<MenuListType[]>(MenuManageApis.getMenuListApi);

// 获取菜单节点详情
const {
  data: currentMenuNodeData,
  execute: executeGetMenuNodeDetail,
  isLoading: isLoadingGetCurrentNodeData
} = useAxiosGet<EditType>(MenuManageApis.getMenuNodeDetailApi);

const { formData, resetField, restoreValidation, updateField, validate, formRef } = useForm<Nullable<EditType>>({
  cache: 0,
  category: MenuType.web,
  componentPath: null,
  description: null,
  icon: null,
  id: null,
  isClosePower: 1,
  link: 0,
  order: 1,
  parentId: null,
  powers: PRESET_PERMISSION_BUTTON.map((item, index) => (index > 3 ? null : item)),
  powersPosition: PRESET_PERMISSION_BUTTON,
  routeAddress: null,
  routeName: null,
  visible: 1,
  layoutType: LayoutType.default,
  cnTitle: null,
  enTitle: null,
  badge: null
});

// -------------------------------------------------------------------------------------------- > 自定义权限

// 自定义权限按钮
const customPermissionButtonSets = JSON.parse(JSON.stringify(PERMISSION_BUTTON_CUSTOM_SETS));

const allPermissionSets = ref<string[]>([]);

// 获取所有权限
const handleGetAllPermission = (componentPath?: string) => {
  allPermissionSets.value = [
    ...PRESET_PERMISSION_BUTTON,
    ...(customPermissionButtonSets[
      componentPath?.substring(0, componentPath?.lastIndexOf('/')) as keyof typeof customPermissionButtonSets
    ] ?? [])
  ] as string[];
};

const unselectedPermissionOptions = computed<SelectOption[]>(() =>
  difference(allPermissionSets.value, formData.value.powersPosition ?? []).map(item => ({
    label: i18nt(item),
    value: item
  }))
);

const handleUpdateCustomPermission = (val: string[]) => {
  formData.value.powersPosition = intersection(allPermissionSets.value, [
    ...(formData.value.powersPosition ?? []),
    ...val
  ]);
  formData.value.powers = [...(formData.value.powers ?? []), ...val];
};

const schemas = computed(() =>
  initFormSchemas(
    formData,
    menuList,
    showIcon,
    handleUpdateCustomPermission,
    unselectedPermissionOptions,
    formRef.value
  )
);

tryOnMounted(() => {
  executeGetMenuList();
  initSortable();
});

// 排序
const { initSortable, destroy } = useSortable('permission-button-area', {
  onEnd({ newIndex, oldIndex }: SortableEvent) {
    if (newIndex === undefined || oldIndex === undefined) return;
    setTimeout(() => {
      const buttonPositionItem = formData.value?.powersPosition?.splice(oldIndex, 1)[0];
      formData.value?.powersPosition?.splice(newIndex, 0, buttonPositionItem as string);
    }, 400);
  }
});

// 当前节点
const currentSelectNode = ref<TreeOption<MenuListType> | null>(null);

// 节点操作
const nodeProps = ({ option }: { option: TreeOption<MenuListType> }) => ({
  onClick: async () => {
    try {
      if (!option.id) return;
      restoreValidation();
      destroy();
      currentSelectNode.value = option;
      const { data } = await executeGetMenuNodeDetail(__, { params: { id: option.id } });
      if (data.value) {
        handleGetAllPermission(option.componentPath);
        const params = {
          ...data.value,
          powersPosition: data.value?.powersPosition.length ? data.value?.powersPosition : [...allPermissionSets.value]
        };
        resetField();
        updateField(params);
      }
      nextTick(() => initSortable());
    } catch (error) {
      console.log('getMenuNodeDetail：异常', error);
    }
  }
});

// 添加子级
const handleAddChild = () => (resetField(), (formData.value.parentId = currentSelectNode.value?.id));

// 添加同级
const handleAddSiblingChild = () => (resetField(), (formData.value.parentId = currentSelectNode.value?.pid));

// 显示图标
const showIcon = ref(false);

// 保存菜单
const handleSaveMenu = async () => {
  try {
    await validate();
    let params = {};
    if (formData.value.category === MenuType.web) {
      params = {
        ...formData.value,
        powers: formData.value?.link ? [] : intersection(formData?.value.powersPosition, formData?.value?.powers),
        powersPosition: formData.value?.isClosePower ? formData.value?.powersPosition : []
      };
    } else {
      const { category, routeName, link, icon, order, description, parentId, id, cnTitle, enTitle, badge } =
        formData.value;
      params = {
        id,
        category,
        routeName,
        link,
        icon,
        order,
        description,
        parentId,
        cnTitle,
        enTitle,
        badge
      };
    }
    await useAxiosPost(formData.value?.id ? MenuManageApis.updateMenuApi : MenuManageApis.createMenuApi, params, __, {
      immediate: true
    });
    handleReset();
  } catch (error) {
    console.log('保存菜单异常：', error);
  }
};

// 删除菜单
const handleDeleteMenu = () => {
  const dialog = $dialog.warning({
    content: `${i18nt('confirmDelete')}【 ${i18nt(currentMenuNodeData.value?.routeName ?? '')} 】${i18nt('menu')} ？`,
    onPositiveClick: async () => {
      try {
        dialog.loading = true;
        await useAxiosPost(
          MenuManageApis.deleteMenuApi,
          __,
          { data: { ids: [currentSelectNode.value?.id] } },
          { immediate: true }
        );
        handleReset();
      } catch (error) {
        console.log('删除菜单：异常', error);
        return false;
      } finally {
        dialog.loading = false;
      }
    }
  });
};

const handleReset = () => {
  currentSelectNode.value = null;
  allPermissionSets.value = [];
  resetField();
  executeGetMenuList();
  routeStore.getDynamicRoutes();
};
</script>

<template>
  <div id="menu-manage" class="flex layout-content-page-vh">
    <base-card
      :title="$t('menuList')"
      class="mr"
      :content-style="{ height: '100%', overflow: 'hidden' }"
      :class="`w-${TREE_WIDTH_CONTAINER}px!`"
    >
      <base-tree
        wrapper-class="h-full"
        class="h-full"
        :expand-on-click="false"
        layout="dialog"
        :checkable="false"
        :loading="isLoadingMenuList"
        :data="useFormatTreeTranslate(menuList, 'routeName') ?? []"
        key-field="id"
        label-field="routeName"
        :node-props="nodeProps"
      />
    </base-card>

    <base-card>
      <base-spin :show="isLoadingGetCurrentNodeData">
        <base-form ref="formRef" v-model="formData" :schemas="schemas" layout="dialog" />
        <base-space :wrap-item="false" justify="center">
          <base-button class="mr" type="primary" button-name="save" @click="handleSaveMenu">
            <template #icon> <base-icon icon="i-carbon:save" /></template>
            {{ $t('save') }}
          </base-button>
          <base-button
            v-if="formData?.link !== 1"
            :disabled="!currentSelectNode"
            class="mr"
            type="primary"
            button-name="add"
            @click="handleAddChild"
          >
            <template #icon> <base-icon icon="i-carbon:add" /></template>
            {{ $t('addChild') }}
          </base-button>
          <base-button
            class="mr"
            type="primary"
            :disabled="!currentSelectNode"
            button-name="addSibling"
            @click="handleAddSiblingChild"
          >
            <template #icon> <base-icon icon="i-carbon:add" /></template>
            {{ $t('addSibling') }}
          </base-button>
          <base-button
            class="mr"
            type="primary"
            button-name="deleteMenu"
            :disabled="!currentSelectNode"
            @click="handleDeleteMenu"
          >
            <template #icon> <base-icon icon="i-carbon:delete" /></template>
            {{ $t('deleteMenu') }}
          </base-button>
        </base-space>
      </base-spin>
    </base-card>
  </div>
</template>
