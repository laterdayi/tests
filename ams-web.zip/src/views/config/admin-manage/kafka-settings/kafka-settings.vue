<script setup lang="ts">
import addForm from './components/add-form.vue';
import { KafkaSettingsApis } from '@/service/apis/config/admin-manage/kafka-settings';
import type { RowType } from '@/service/apis/config/admin-manage/kafka-settings';

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const { hasCustomPermission } = useRoutes();
const hasEditPermission = hasCustomPermission('updatePartition');

// 表单
const { formRef, formData } = useForm<Nullable<{ server: string; topic: string }>>({
  server: null,
  topic: null
});
const serverIsShow = ref<boolean>(false);
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'server',
    formItemProps: {
      label: 'Kafka Server'
    },
    class: 'w-150!'
  }
]);
const schemasServer = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'topic',
    formItemProps: {
      label: 'Topic'
    }
  }
]);
const addFormRef = ref();
// 表格配置项
const {
  pagination,
  isLoadingQuery,
  tableData,
  error,
  tableRef,
  executeQueryList: getList
} = useTable<RowType[]>(KafkaSettingsApis.getListApi, { queryFormParams: formData, remote: false });
const tableDataNew = ref<RowType[]>([]);

watch([tableData, error, formData], newValue => {
  if (newValue[1]) {
    tableDataNew.value = [];
    serverIsShow.value = false;
    formData.value.topic = null;
  } else {
    serverIsShow.value = !!formData.value.server;
    if (!newValue[0]) return;
    tableDataNew.value = formData.value.topic
      ? newValue[0]
          .filter((ele: RowType) => {
            if (formData.value.topic) {
              return ele.topicName.includes(formData.value.topic);
            }
            return null;
          })
          .map((ele: RowType) => {
            return {
              ...ele,
              id: ele.topicName
            };
          })
      : newValue[0].map((ele: RowType) => {
          return {
            ...ele,
            id: ele.topicName
          };
        });
  }
});
// 获取表格数据

const tableColumns: DataTableColumns<RowType> = [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: 'Topic',
    key: 'topicName',
    sorter: 'default',
    width: 350,
    render: (row: RowType) =>
      useRenderTableTitleEdit(row.topicName, () =>
        addFormRef?.value?.open?.(true, formData.value.server, row, hasEditPermission))
  },
  {
    title: 'Partition Count',
    key: 'partitionCount'
  }
];
// 刷新表格
const resetTable = () => {
  tableRef?.value?.clearSelected();
  getList();
};
// 按钮事件
const handleButton = (permission: 'connect' | 'reset' | 'addTopic' | 'updatePartition') => {
  switch (permission) {
    case 'connect':
      pagination.value.page = 1;
      getList();
      break;
    case 'reset':
      pagination.value.page = 1;
      formData.value.topic = null;
      getList();
      break;
    case 'addTopic':
      addFormRef.value.open(false, formData.value.server, __, hasEditPermission);
      break;
    case 'updatePartition':
      addFormRef.value.open(true, formData.value.server, tableRef?.value?.selectedRows[0], hasEditPermission);
      break;
    default:
      break;
  }
};
</script>

<template>
  <div id="kafka-settings">
    <base-card>
      <!-- 搜索 -->
      <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" layout="page">
        <template #header-action>
          <base-button :size="componentSize" type="primary" button-name="connect" @click="handleButton('connect')">
            <base-icon icon="i-carbon:search" />{{ $t('connect') }}
          </base-button>
        </template>
      </base-form>
      <base-form
        v-if="serverIsShow"
        ref="formRef"
        v-model="formData"
        type="query"
        class="m-t-12px"
        :schemas="schemasServer"
        layout="page"
      >
        <template #header-action>
          <base-button
            class="m-l-12px"
            :size="componentSize"
            type="primary"
            button-name="connect"
            @click="handleButton('connect')"
          >
            <base-icon icon="i-carbon:search" />{{ $t('search') }}
          </base-button>
          <base-button
            class="m-l-12px"
            :size="componentSize"
            type="primary"
            button-name="connect"
            @click="handleButton('reset')"
          >
            <base-icon icon="i-carbon:search" />{{ $t('reset') }}
          </base-button>
        </template>
      </base-form>
      <!-- 表格 -->
      <base-table
        ref="tableRef"
        :columns="tableColumns"
        :data="tableDataNew ?? []"
        :loading="isLoadingQuery || isLoadingQuery"
        :pagination="{
          ...pagination,
          prefix: () => `${i18nt('baseTable.total')} ${tableDataNew.length} ${i18nt('baseTable.strip')}`
        }"
      >
        <template #header>
          <base-button
            :disabled="tableDataNew.length === 0"
            :size="componentSize"
            type="primary"
            button-name="addTopic"
            @click="handleButton('addTopic')"
          >
            <base-icon icon="i-carbon:add" /> {{ $t('addTopic') }}
          </base-button>
          <base-button
            class="button"
            :disabled="tableDataNew.length === 0 ? true : tableRef?.selectedKeys.length !== 1 ? true : false"
            :size="componentSize"
            type="primary"
            button-name="updatePartition"
            @click="handleButton('updatePartition')"
          >
            <base-icon icon="i-carbon:edit" />{{ $t('updatePartition') }}
          </base-button>
        </template>
      </base-table>
      <!-- 新增 -->
      <addForm ref="addFormRef" @reset-table="resetTable" />
    </base-card>
  </div>
</template>

<style scoped lang="less">
#kafka-settings {
  .button {
    margin-left: 12px;
  }
}
</style>
