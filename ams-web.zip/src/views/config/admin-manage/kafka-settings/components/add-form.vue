<script setup lang="tsx">
import { KafkaSettingsApis } from '@/service/apis/config/admin-manage/kafka-settings';
import type { FormType, RowType } from '@/service/apis/config/admin-manage/kafka-settings';

const emit = defineEmits<{
  'reset-table': [];
}>();

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
// 是否拥有编辑权限
const hasEditPermissionIsShow = ref<boolean>(true);
// 接口设置
const modalUrl = ref<string>('');
// 弹窗开启
const modalIsShow = ref(false);
// 弹窗title
const modalTitle = ref<string>('');
const serverForm = ref<string>('');
const editIsShow = ref<boolean>(false);
const partitionCountMax = ref<number>(1);
// 打开弹窗
const open = (edit: boolean, server: string, row: RowType, isShow: boolean) => {
  serverForm.value = server;
  editIsShow.value = edit;
  if (edit) {
    hasEditPermissionIsShow.value = isShow;
    modalTitle.value = isShow ? i18nt('edit') + i18nt('kafkaSettings') : i18nt('viewDetail');

    modalForm.value = {
      topic: row.topicName,
      partitionCount: row.partitionCount
    };
    partitionCountMax.value = row.partitionCount + 1;
    modalUrl.value = KafkaSettingsApis.updateApi;
  } else {
    partitionCountMax.value = 1;
    modalTitle.value = i18nt('add') + i18nt('kafkaSettings');
    modalUrl.value = KafkaSettingsApis.addFormApi;
  }
  modalIsShow.value = true;
};
// 表单查询
const inputIsShow = ref<boolean>(false);
const modalSchemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'topic',
    formItemProps: {
      label: i18nt('topicName'),
      rule: [useRules('input', i18nt('topicName')), useRuleStringLength(0, 100)]
    },
    componentProps: {
      disabled: !!editIsShow.value
    },
    class: 'w-95%!'
  },

  {
    type: 'input-number',
    model: 'partitionCount',
    formItemProps: {
      label: 'Partition Count',
      rule: [
        useRules('input-number', 'onlyPositiveIntRule', { required: true, message: i18nt('partitionCount') }),
        useRuleNumberSize(partitionCountMax.value, 20)
      ]
    },
    componentProps: {
      onFocus: () => {
        inputIsShow.value = true;
      }
    },
    class: 'w-95%!'
  }
]);
const {
  formRef,
  validate,
  formData: modalForm,
  resetField
} = useForm<Nullable<FormType>>({
  topic: null,
  partitionCount: null
});
// 保存表单
const { execute: saveFormAdd } = useAxiosPost('');
const saveFormLoading = ref<boolean>(false);
const saveForm = async () => {
  try {
    if (inputIsShow.value) {
      await validate();
    }
    saveFormLoading.value = true;
    await saveFormAdd(modalUrl.value, {
      data: {
        ...modalForm.value,
        server: serverForm.value
      }
    });
    saveFormLoading.value = false;
    cancelModal();
  } catch (error) {
    console.log(error);
  }
};
// 关闭弹窗
const cancelModal = () => {
  modalIsShow.value = false;
  inputIsShow.value = false;
  hasEditPermissionIsShow.value = true;
  // 重置表单并去除验证
  resetField();
  emit('reset-table');
};
defineExpose({
  open
});
</script>

<template>
  <base-modal
    :show="modalIsShow"
    class="w-60%!"
    preset="confirm"
    :title="modalTitle"
    :mask-closable="false"
    :show-icon="false"
    negative-text=""
    positive-text=""
    @close="cancelModal"
  >
    <base-form
      ref="formRef"
      v-model="modalForm"
      class="form"
      :label-width="140"
      layout="dialog"
      :schemas="modalSchemas"
      :disabled="!hasEditPermissionIsShow"
    />
    <template #action>
      <base-button :size="componentSize" button-name="cancel" @click="cancelModal">{{ $t('cancel') }}</base-button>
      <base-button
        v-if="hasEditPermissionIsShow"
        :size="componentSize"
        :disabled="saveFormLoading"
        :loading="saveFormLoading"
        type="primary"
        button-name="confirm"
        @click="saveForm"
      >
        {{ $t('confirm') }}
      </base-button>
    </template>
  </base-modal>
</template>
