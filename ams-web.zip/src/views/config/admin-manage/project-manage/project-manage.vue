<script lang="tsx">
import BaseSwitch from '@c/base-ui/base-switch/base-switch.vue';
import { CommonApis } from '@/service/apis/common/common';
import type { MenuListType } from '@/service/apis/common/type';
import { ProjectManageApis } from '@/service/apis/config/admin-manage/project-manage';

interface QueryType {
  name: string | null;
}
interface MenuAssignmentType {
  id: number;
  isLeaf: number;
  powersList: string[];
}
interface TableListType {
  id: string;
  code: string;
  name: string;
  admin: string;
  description: string;
  manager: string;
  logo: string;
  minilogo: string;
  createTime: string;
  status: number;
  eqpSum: number;
  eqpCount: number;
  modules: string[];
  moduleStrs: string;
  license: string;
  createDate: string;
}
interface EditType {
  code: string;
  name: string;
  logo: string;
  minilogo: string;
  admin: string;
  manager: string;
  modules: string[];
  license: string;
  description: string;
  status: OpenStateType;
}
// 初始化查询表单
const initQueryFormSchemas = (): FormSchemaType => [
  {
    type: 'input',
    model: 'name',
    formItemProps: {
      label: i18nt('keyword')
    }
  }
];
const createColumns = (
  pagination: ComputedRef<PaginationProps | undefined>,
  curdRef: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>,
  handleProjectStateChange: (row: TableListType, rowIndex: number) => void
): DataTableColumns<TableListType> => [
  { type: 'selection' },
  useRenderTableIndex(pagination),
  {
    title: i18nt('projectCode'),
    key: 'code',
    sorter: true,
    render: rowData =>
      useRenderTableTitleEdit(rowData.code, () => curdRef?.value?.openEditModal?.(rowData, EditModalEntry.title))
  },
  { title: i18nt('projectName'), key: 'name', sorter: true },
  { title: i18nt('adminAccount'), key: 'admin', sorter: true },
  { title: i18nt('projectManager'), key: 'manager', width: TABLE_WIDTH_STATE },
  { title: i18nt('eqpCount'), key: 'eqpCount', width: TABLE_WIDTH_STATE },
  { title: i18nt('usedNumber'), key: 'eqpSum', width: TABLE_WIDTH_STATE },
  { title: i18nt('description'), key: 'description' },
  {
    title: `${i18nt('startUse')}/${i18nt('stopUse')}`,
    key: 'status',
    render(rowData, rowIndex) {
      return h(BaseSwitch, {
        value: !!rowData.status,
        onUpdateValue: () => handleProjectStateChange?.(rowData, rowIndex)
      });
    },
    width: TABLE_WIDTH_STATE
  },
  { title: i18nt('createTime'), key: 'createTime', width: TABLE_WIDTH_DATETIME, sorter: true }
];
const initFormSchemas = (
  curdRef?: Ref<CurdRefType<QueryType, EditType, TableListType> | undefined>,
  productList?: OptionsType[]
): FormSchemaType => [
  {
    type: 'input',
    model: 'code',
    formItemProps: {
      label: i18nt('projectCode'),
      rule: [useRules('input', i18nt('projectCode')), useRuleStringLength(4, 8)]
    },
    componentProps: { disabled: !!curdRef?.value?.isEditMode }
  },
  {
    type: 'input',
    model: 'name',
    formItemProps: {
      label: i18nt('projectName'),
      rule: [useRules('input', i18nt('projectName')), useRuleStringLength()]
    }
  },
  {
    type: 'input',
    model: 'admin',
    formItemProps: {
      label: i18nt('adminAccount'),
      rule: [useRules('input', i18nt('adminAccount')), useRuleStringLength()]
    },
    componentProps: { disabled: !!curdRef?.value?.isEditMode }
  },
  {
    type: 'select',
    model: 'modules',
    formItemProps: { label: i18nt('product') },
    componentProps: { valueField: 'id', labelField: 'name', options: productList, multiple: true }
  },
  {
    type: 'input',
    model: 'manager',
    formItemProps: { label: i18nt('projectManager'), rule: useRuleStringLength() }
  },
  curdRef?.value?.isEditMode ? __ : useRenderFormSwitch({ label: `${i18nt('startUse')}/${i18nt('stopUse')}` }),
  useRenderFormUpload({
    model: 'logo',
    label: i18nt('logo'),
    rule: ASTRICT_IMG_RULE,
    componentProps: {
      action: CommonApis.uploadFileBase64Api,
      listType: 'image-card',
      fileList:
        curdRef?.value?.isEditMode && curdRef?.value?.formData?.logo
          ? [
              {
                id: curdRef?.value?.formData?.logo,
                name: curdRef?.value?.formData?.logo,
                status: 'finished',
                url: `${curdRef?.value?.formData?.logo}`
              }
            ]
          : []
    },
    formData: curdRef?.value?.formData,
    onFinished: () => curdRef?.value?.validate(),
    formItemClass: 'col-span-2!'
  }),
  useRenderFormUpload({
    model: 'minilogo',
    label: i18nt('miniLogo'),
    rule: ASTRICT_IMG_RULE,
    componentProps: {
      action: CommonApis.uploadFileBase64Api,
      listType: 'image-card',
      fileList:
        curdRef?.value?.isEditMode && curdRef?.value?.formData?.minilogo
          ? [
              {
                id: curdRef?.value?.formData?.minilogo,
                name: curdRef?.value?.formData?.minilogo,
                status: 'finished',
                url: `${curdRef?.value?.formData?.minilogo}`
              }
            ]
          : []
    },
    formData: curdRef?.value?.formData,
    onFinished: () => curdRef?.value?.validate(),
    formItemClass: 'col-span-2!'
  }),
  useRenderFormTextarea({ formItemClass: 'col-span-2!' }),
  useRenderFormTextarea({
    model: 'license',
    label: i18nt('license'),
    formItemClass: 'col-span-2!'
  })
];
</script>

<script setup lang="tsx">
// 模板引用
const curdRef = ref<CurdRefType<QueryType, EditType, TableListType>>();
const curdRefPagination = computed(() => curdRef.value?.pagination);
const queryFormParams: QueryType = { name: null };
const queryFormSchemas = initQueryFormSchemas();
// 产品列表
const { data: productList, execute: executeGetProductList } = useAxiosGet<OptionsType[]>(CommonApis.getProductListApi);
// 菜单列表
const {
  data: menuList,
  execute: executeGetMenuList,
  isLoading: isLoadingMenuList
} = useAxiosGet<TreeOption<MenuListType>[]>(CommonApis.getAllMenusListApi);
const formParams = {
  code: __,
  name: __,
  logo: __,
  minilogo: __,
  admin: __,
  manager: __,
  modules: __,
  license: __,
  description: __,
  status: OpenState.open
};
const formSchemas = computed<FormSchemaType>(() => initFormSchemas(curdRef, productList.value));

// 更新启用状态
const handleProjectStateChange = (row: TableListType, rowIndex: number) => {
  $dialog.warning({
    content: i18nt(row.status ? 'dialog.stopUse' : 'dialog.startUse', { val: row.name }),
    onPositiveClick: async () => {
      const params = { id: row.id, status: row.status ^ 1 };
      const { data } = await useAxiosPost(ProjectManageApis.updateStateApi, params, __, {
        immediate: true
      });
      !!data.value &&
        curdRef.value?.handleUpdateRow(items => {
          items[rowIndex].status ^= 1;
        });
    }
  });
};

const {
  handleIndeterminate,
  halfSelectedKeys,
  checkAllKeys,
  clearSelectedList,
  updatecheckAllKeys,
  updatehalfSelectedKeys
} = useTree();

// 树-更新选中
const handleCheck = (
  keys: string[],
  options: (TreeOption | null)[],
  meta: {
    node: TreeOption<MenuListType> | null;
    action: 'check' | 'uncheck';
  }
) => {
  try {
    const { action, node } = meta;
    if (!node?.id) return;
    if (node?.isLeaf) {
      flatRowData.value[node.id].powersList = action === 'check' ? flatRowData.value[node.id]?.powers : [];
    } else {
      if (!node.children?.length) return;
      handleDeepUpdatePermissionCheck(node.children, action);
    }
    updatecheckAllKeys(keys);
  } catch (error) {
    console.log('handleClick异常：', error);
  }
};

// 更新按钮权限
const handleDeepUpdatePermissionCheck = (children: MenuListType[], action: 'check' | 'uncheck') => {
  if (!children?.length) return;
  for (let i = 0; i < children?.length; i++) {
    const item = children?.[i];
    flatRowData.value[item.id].powersList = action === 'check' ? flatRowData.value[item.id]?.powers : [];
    if (item.children?.length) {
      handleDeepUpdatePermissionCheck(item.children, action);
    }
  }
};

// 更新树checked
const handleUpdateTreeCheck = (value: string | number, option: TreeOption<MenuListType>) => {
  const _checkAllKeys = toRaw(checkAllKeys.value);
  if (!_checkAllKeys.includes(option.id!)) updatecheckAllKeys([..._checkAllKeys!, option.id!]);
};

// 节点渲染
const renderLabel = ({ option }: { option: TreeOption<MenuListType> }) =>
  h('div', { class: 'w-160px' }, i18nt(option.routeName ?? ''));

// 渲染权限按钮
const renderSuffix = ({ option }: { option: TreeOption<MenuListType> }) => {
  if (option.isClosePower) {
    return (
      <>
        <n-checkbox-group
          onUpdate:value={(value: string | number, meta: { actionType: 'check' | 'uncheck'; value: string | number }) =>
            handleUpdateTreeCheck(value, option)
          }
          v-model:value={flatRowData.value[option.id ?? ''].powersList}
        >
          <base-space>
            {option.powers?.map((power: string) => {
              return <n-checkbox key={power} label={i18nt(power)} value={power} />;
            })}
          </base-space>
        </n-checkbox-group>
      </>
    );
  }
  return undefined;
};
// 保存权限分配
const saveMenuAssignment = async () => {
  try {
    const data = [
      ...halfSelectedKeys.value.map(item => ({
        id: item,
        isLeaf: 1,
        powersList: toRaw(flatRowData.value[item])?.powersList ?? []
      })),
      ...checkAllKeys.value.map(item => {
        const { powersList, powersPosition } = toRaw(flatRowData.value[item]);
        return {
          id: item,
          isLeaf: 0,
          powersList: intersection(powersPosition, powersList)
        };
      })
    ];
    const { execute, data: result } = useAxiosPost(ProjectManageApis.setMenuAssignmentApi, {
      id: curdRef.value?.tableRef?.selectedKeys.at(0),
      menus: data
    });
    await execute();
    if (result?.value) {
      closeModal();
      clearSelectedList();
    }
  } catch (error) {
    console.log(error);
  }
};
// 更新权限按钮选中项
const updatePermissionButtonChecked = (data: MenuAssignmentType[]) => {
  try {
    if (!data.length) return;
    // 设置权限
    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      if (flatRowData.value[item.id]) {
        flatRowData.value[item.id].powersList = item.powersList;
      }
    }
  } catch (error) {
    console.log('更新权限按钮选中项异常：', error);
  }
};
// 扁平后数据
const flatRowData = ref<{ [key: string]: TreeOption<MenuListType> }>({});
// 填充扁平数据
const fillFlatRowData = (data?: TreeOption<MenuListType>[]) => {
  try {
    if (!data?.length) return;
    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      if (item.id) {
        flatRowData.value[item.id] = { ...item, children: [] };
        if (item.children?.length) fillFlatRowData(item.children);
      }
    }
  } catch (error) {
    console.log('填充扁平数据异常：', error);
  }
};
// 获取权限分配
const getMenuAssignment = async (idList?: MixedArray) => {
  try {
    await executeGetMenuList();
    fillFlatRowData(menuList.value);
    const { data } = await useAxiosGet<MenuAssignmentType[]>(
      ProjectManageApis.getMenuAssignmentApi,
      __,
      { params: { id: idList?.at(0) } },
      { immediate: true }
    );
    if (data.value) {
      updatePermissionButtonChecked(data.value);
      updatecheckAllKeys(data?.value?.filter(item => !item.isLeaf).map(item => item.id));
      updatehalfSelectedKeys(data?.value?.filter(item => item.isLeaf).map(item => item.id));
    }
  } catch (error) {
    console.log('获取菜单分配权限异常：', error);
  }
};
// -------------------------------------------------------------------------------------------- > Modal
const { showModal, openModal, closeModal } = useModal();
// 相关权限操作
const handlePermission = async (permission: PermissionType) => {
  switch (permission) {
    case 'permissionAssign':
      await getMenuAssignment(curdRef?.value?.tableRef?.selectedKeys);
      openModal();
      break;
    default:
      break;
  }
};
const tableColumns = createColumns(curdRefPagination, curdRef, handleProjectStateChange);
</script>

<template>
  <div id="project-manage">
    <base-curd
      ref="curdRef"
      :query-form-params="queryFormParams"
      :query-form-schemas="queryFormSchemas"
      :form-permission-disable="{ permissionAssign: curdRef?.tableRef?.selectedKeys?.length !== 1 }"
      :table-shallow-ref="false"
      :form-params="formParams"
      :form-schemas="formSchemas"
      :create-api="ProjectManageApis.createProjectApi"
      :update-api="ProjectManageApis.updateProjectApi"
      :read-api="ProjectManageApis.getProjectListApi"
      :edit-detail-api="ProjectManageApis.getProjectDetailApi"
      :delete-api="ProjectManageApis.deleteProjectApi"
      :columns="tableColumns"
      modal-title="project"
      @handle="handlePermission"
      @after-open-add-modal="executeGetProductList"
      @after-open-edit-modal="executeGetProductList"
    />
    <base-modal
      :show="showModal"
      :inside-scroll="false"
      :title="i18nt('menuAssignment')"
      @close="closeModal()"
      @after-leave="clearSelectedList(), (flatRowData = {})"
      @negative-click="closeModal()"
      @positive-click="saveMenuAssignment()"
    >
      <base-tree
        class="base-tree modal-content-height"
        :default-checked-keys="checkAllKeys"
        :loading="isLoadingMenuList"
        :data="menuList ?? []"
        :render-label="renderLabel"
        key-field="id"
        :watch-props="['defaultCheckedKeys']"
        :render-suffix="renderSuffix"
        @update:checked-keys="handleCheck"
        @update:indeterminate-keys="handleIndeterminate"
      />
    </base-modal>
  </div>
</template>

<style lang="less" scoped>
:deep(.base-tree .n-tree-node .n-tree-node-content) {
  align-items: flex-start !important;
}
</style>
