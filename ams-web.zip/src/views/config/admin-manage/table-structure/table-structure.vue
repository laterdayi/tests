<script setup lang="tsx">
import { TableStructureApis } from '@/service/apis/config/admin-manage/table-structure';
import type { RowType } from '@/service/apis/config/admin-manage/table-structure';

interface QueryType {
  tableName: string;
}
const appStore = useAppStore();
// 表单
const {
  formRef,
  formData,
  resetField: resetQueryField
} = useForm<Nullable<QueryType>>({
  tableName: null
});
// 查询表单配置项
const schemas = computed<FormSchemaType>(() => [
  {
    type: 'input',
    model: 'tableName',
    formItemProps: {
      label: i18nt('tableName')
    }
  }
]);
// 表格配置项
// 表格内部子集配置
// 子集选中
const expandedList = ref<MixedArray>([]);
// 子集查询
const rowColums = [
  {
    title: i18nt('index'),
    width: 50,
    render(row: RowType, index: number) {
      return <>{index + 1}</>;
    }
  },
  {
    title: i18nt('columnName'),
    width: 200,
    key: 'columnName'
  },
  {
    title: i18nt('columnNo'),
    width: 100,
    key: 'columnIndex'
  },
  {
    title: i18nt('columnType'),
    width: 200,
    key: 'dataType'
  },
  {
    title: i18nt('dataLength'),
    width: 100,
    key: 'length'
  },
  {
    title: i18nt('canBeBlank'),
    width: 50,
    key: 'isNullable',
    render(row: RowType) {
      return <span>{row.isNullable === 0 ? i18nt('EnumCheck_No') : i18nt('EnumCheck_Yes')}</span>;
    }
  },
  {
    title: i18nt('columnDescription'),
    width: 280,
    key: 'description'
  },
  {
    title: i18nt('primaryKeyOrNot'),
    width: 50,
    key: 'isPK',
    render(row: RowType) {
      return <span>{row.isPK === '0' ? i18nt('EnumCheck_No') : i18nt('EnumCheck_Yes')}</span>;
    }
  },
  {
    title: i18nt('default'),
    width: 280,
    key: 'default'
  }
];
const rowTable = ref<RowType[]>([]);
const rowLoading = ref<boolean>(false);
// 表格传值拦截
const refactorFormQueryParams = (data: RowType) => {
  return data;
};
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  mergedQueryFormData,
  tableData,
  executeQueryList: getList,
  tableRef
} = useTable<RowType[]>(TableStructureApis.getListApi, { queryFormParams: formData, refactorFormQueryParams });
const tableList = ref<RowType[]>();
watch(tableData, newValue => {
  tableList.value = newValue;
});
// 获取表格数据
getList();
// 父表格点击事件
const tableRowClick = async (row: RowType) => {
  try {
    if (row.expandIsShow) {
      row.expandIsShow = false;
      expandedList.value = [];
    } else {
      rowLoading.value = true;
      const { execute } = useAxiosGet<RowType[]>(TableStructureApis.getAttributeNameListApi);
      const { data } = await execute({
        params: {
          tableName: row.tableName
        }
      });
      rowLoading.value = false;
      tableList?.value?.forEach((ele: RowType) => {
        ele.expandIsShow = false;
      });
      row.expandIsShow = true;
      expandedList.value = [];
      expandedList.value.push(row.id);
      if (!data.value) return;
      rowTable.value = data.value;
    }
  } catch (error) {
    console.log(error);
  }
};

const tableColumns: DataTableColumns<RowType> = [
  { type: 'selection' },
  {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX,
    render: (row: RowType, rowIndex: number) =>
      h(
        'span',
        { class: 'expandItem', style: { justifyContent: 'center' }, onClick: () => tableRowClick(row) },
        {
          default: () => rowIndex + 1 + ((pagination?.value?.page ?? 1) - 1) * (pagination?.value?.pageSize ?? 10)
        }
      )
  },
  {
    title: i18nt('tableName'),
    key: 'tableName',
    sorter: true,
    sortOrder: mergedQueryFormData?.value?.sort,
    titleColSpan: 2,
    colSpan: () => 2,
    ellipsis: {
      tooltip: true
    },
    render(row: RowType) {
      return (
        <div class="expandItem" onClick={() => tableRowClick(row)}>
          {!row.expandIsShow ? (
            <base-icon color={`${appStore.themePrimary}`} icon="i-carbon:chevron-right" />
          ) : (
            <base-icon color={`${appStore.themePrimary}`} icon="i-carbon:chevron-down" />
          )}
          <base-tooltip
            disabled={!(row.tableName.length > 170)}
            placement="bottom"
            trigger="hover"
            v-slots={{
              trigger: () => <span class="expandItem-text">{row.tableName}</span>
            }}
          >
            <span> {row.tableName} </span>
          </base-tooltip>
        </div>
      );
    }
  },
  {
    type: 'expand',
    expandable: () => true,
    renderExpand: () => {
      return (
        <base-table columns={rowColums} data={rowTable.value} max-height="405" scroll-x={TABLE_WIDTH_SCROLL_SMALL} />
      );
    }
  }
];
// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = useDownloadFile(
  TableStructureApis.exportTablInfoApi
);
const handleExport = () => {
  let params = { ...mergedQueryFormData.value };
  if (formData) params = refactorFormQueryParams?.(params);
  executeExportData?.(params);
};

// 按钮事件
const handleButton = (permission: PermissionType) => {
  switch (permission) {
    case 'reset':
      resetQueryField();
      pagination.value.page = 1;
      getList();
      break;
    case 'search':
      pagination.value.page = 1;
      getList();
      break;
    case 'export':
      handleExport();
      break;
    default:
      break;
  }
};
</script>

<template>
  <base-card>
    <!-- 搜索 -->
    <base-form ref="formRef" v-model="formData" type="query" :schemas="schemas" layout="page">
      <template #header-action>
        <permission-button form @handle="handleButton" />
      </template>
    </base-form>
    <!-- 表格 -->
    <base-table
      ref="tableRef"
      remote
      :bordered="false"
      :columns="tableColumns"
      :data="tableList ?? []"
      :loading="isLoadingQuery || rowLoading || isLoadingExportData"
      :pagination="pagination"
      :expanded-row-keys="expandedList"
      @update:sorter="handleSorterChange"
    >
      <template #header>
        <permission-button
          :loading-props="{ exportLoading: isLoadingExportData }"
          :select-length="tableRef?.selectedKeys?.length"
          @handle="handleButton"
        />
      </template>
    </base-table>
  </base-card>
</template>

<style scoped lang="less">
:deep(.n-data-table-td) {
  .n-ellipsis {
    width: 100%;
    .expandItem {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      cursor: pointer;
      .expandItem-text {
        margin-left: 10px;
        max-width: 88%;

        display: -webkit-box;
        overflow: hidden;
        word-break: break-all;
        text-overflow: ellipsis;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        white-space: pre-line;
      }
    }
  }
  .w-full {
    margin-top: -20px;
    // max-height: 435px;
    // overflow: auto;
    .n-data-table-thead {
      .n-data-table-th {
        background-color: rgba(235, 238, 245, 0.9);
      }
    }
    .n-data-table-tr {
      .n-data-table-td--last-row {
        border-bottom: 1px solid var(--n-merged-border-color) !important;
      }
    }
  }
}
</style>
