// @unocss-include

import { NEllipsis } from 'naive-ui';
import type {
  ButtonProps,
  EllipsisProps,
  FormItemProps,
  InputProps,
  PaginationProps,
  SwitchProps,
  TagProps,
  UploadFileInfo,
  UploadProps
} from 'naive-ui';

import type { TableBaseColumn, TableColumn } from 'naive-ui/es/data-table/src/interface';
import BaseTag from '@c/base-ui/base-tag/base-tag.vue';
import BaseSwitch from '@c/base-ui/base-switch/base-switch.vue';
import BaseButton from '@c/base-ui/base-button/base-button.vue';
import type { HTMLAttributes } from 'vue';
import type { AstrictFileType } from '@/components/base-ui/base-upload/hooks';
import type { RenderSlotType } from '@/components/base-ui/base-form/type';

const appStore = useAppStore();

interface RenderTableMultiTagsOptionType {
  tagNodeProps?: HTMLAttributes & TagProps
  ellipsis?: boolean
}
type RenderTableMultiTagsDataType = string | any[] | ((rowData: any) => any[]);

// -------------------------------------------------------------------------------------------- > Common

// 渲染文本省略标签
export const useRenderEllipsisLabel = ({
  option,
  key,
  contentProps,
  componentProps
}: {
  option: TreeOption<any>
  key: string
  contentProps?: HTMLAttributes | null | undefined
  componentProps?: EllipsisProps & HTMLAttributes
}) => h(NEllipsis, { ...TOOLTIP, ...componentProps }, { default: () => h('span', { ...contentProps }, option[key]) });

// -------------------------------------------------------------------------------------------- > Form

// 渲染表单状态项
export const useRenderFormSwitch = ({
  key,
  label = i18nt('valid'),
  formItemClass,
  componentProps,
  formItemProps
}: {
  key?: string
  label?: string
  formItemClass?: string | string[]
  componentProps?: SwitchProps
  formItemProps?: FormItemProps
} = {}): BaseForm.Schema.Item => ({
  type: 'switch',
  model: key ?? 'status',
  formItemProps: { label, ...formItemProps },
  componentProps: { checkedValue: OpenState.open, uncheckedValue: OpenState.close, ...componentProps },
  componentClass: 'w-min!',
  formItemClass
});

// 渲染输入域
export const useRenderFormTextarea = ({
  model = 'description',
  label = i18nt('description'),
  formItemProps,
  componentProps,
  maxlength = MAX_LENGTH_DESCRIPTION,
  componentSlots,
  componentClass,
  formItemClass
}: {
  model?: string
  label?: string
  maxlength?: number
  formItemProps?: FormItemProps
  componentProps?: InputProps & { replaceSpace?: boolean }
  componentSlots?: RenderSlotType[]
  componentClass?: string | string[]
  formItemClass?: string | string[]
} = {}): BaseForm.Schema.Item => {
  return {
    type: 'input',
    model,
    formItemProps: { label, ...formItemProps },
    componentProps: { type: 'textarea', maxlength, showCount: true, ...componentProps },
    componentSlots,
    componentClass,
    formItemClass
  };
};

// 渲染上传
export const useRenderFormUpload = ({
  model = 'filePath',
  label = i18nt('file'),
  astrictFileSize,
  rule,
  formItemProps,
  componentProps: extraComponentProps,
  componentClass,
  formItemClass,
  formData,
  componentSlots,
  onFinished,
  onErrored,
  onRemoved
}: {
  model?: string
  label?: string
  formItemProps?: FormItemProps
  componentProps?: Omit<UploadProps, 'onFinish' | 'onError' | 'onRemove'>
  rule?: AstrictFileType
  astrictFileSize?: number
  formData?: MaybeRef<any>
  componentClass?: string | string[]
  formItemClass?: string | string[]
  componentSlots?: RenderSlotType[]
  onFinished?: ({ data, file }: { data: any; file: UploadFileInfo }) => Promise<void | undefined> | undefined | void
  onErrored?: () => Promise<void | undefined> | undefined | void
  onRemoved?: () => Promise<void | undefined> | undefined | void
} = {}): BaseForm.Schema.Item => {
  const { fileList: _fileList, ...otherComponentProps } = extraComponentProps as UploadProps;
  // 上传
  const { beforeUpload, customRequest, fileList, onRemove, onFinish, handleUploadChange } = useUpload({
    model,
    astrictFileType: rule,
    astrictFileSize,
    formData,
    clearFileList: false,
    defaultFileList: _fileList ?? [],
    onFinished,
    onErrored,
    onRemoved
  });
  return {
    type: 'upload',
    model,
    formItemProps: { label, ...formItemProps },
    componentProps: computed(() => ({
      shouldUseThumbnailUrl: () => true,
      fileList: fileList.value,
      onChange: handleUploadChange,
      accept: rule?.rule.toString(),
      onBeforeUpload: beforeUpload,
      customRequest,
      onRemove,
      onFinish,
      ...otherComponentProps
    })),
    componentSlots,
    componentClass,
    formItemClass
  };
};

// -------------------------------------------------------------------------------------------- > Table

// 渲染表格结果高亮
export const useRenderTableHighlight = (data: string, filterText?: string) => {
  if (filterText) {
    const pattern = new RegExp(`(${filterText})`, 'gi');
    const parts = data.split(pattern) as any;
    for (let i = 1; i < parts.length; i += 2) {
      parts[i] = h('mark', null, parts[i]);
    }
    return h('span', null, ...parts);
  }
  return h('span', null, data);
};

// 渲染表格固定列
export const useRenderTableActionColumn = <T>(props: Omit<TableBaseColumn<T>, 'key'>): TableColumn<T> => ({
  title: i18nt('action'),
  key: 'action',
  fixed: 'right',
  width: TABLE_WIDTH_ACTION,
  ...props
});

// 渲染表格固定列按钮
export const useRenderTableFixedButton = (content: string, props: ButtonProps) =>
  h(
    BaseButton,
    {
      text: true,
      type: 'primary',
      buttonName: content,
      ...props
    },
    { default: () => i18nt(content) }
  );

// 渲染表格可点击标题
export const useRenderTableTitleEdit = (
  content: string | number,
  execute: () => void,
  { translate }: { translate?: boolean } = {}
) => {
  return h(
    'span',
    {
      class: 'cursor-pointer',
      style: {
        color: appStore.themePrimary
      },
      onClick: () => {
        execute();
        useButtonClickRecord('edit');
      }
    },
    translate ? i18nt(content) : content
  );
};

// 渲染表格禁用 Swtich
export const useRenderTableSwitch = (value: boolean) => h(BaseSwitch, { value, disabled: true, size: 'small' });

// 渲染表格单个 Tag
export const useRenderTableSingleTag = (type: TagProps['type'], content: string | number) =>
  h(BaseTag, { type, size: 'small' }, { default: () => content });

// 渲染表格多个 Tag > ellipsis + render
export const useRenderTableMultiTag = (
  data: RenderTableMultiTagsDataType,
  options: RenderTableMultiTagsOptionType = {}
) => {
  const { ellipsis = true } = options;
  return {
    ellipsis: ellipsis ? TOOLTIP : false,
    render: (rowData: any) => renderTableMultiTag(rowData, data, options)
  };
};

const renderTableMultiTag = (
  rowData: any,
  data: RenderTableMultiTagsDataType,
  options: RenderTableMultiTagsOptionType = {}
) => {
  if (typeof data === 'string') {
    return useRenderTableTag(rowData[data], options);
  } else if (Array.isArray(data)) {
    return useRenderTableTag(data, options);
  } else if (typeof data === 'function') {
    return useRenderTableTag(data(rowData), options);
  }
  throw new Error('Invalid data type');
};

// 渲染表格多个 Tag > Vnode
export const useRenderTableTag = (data: string[], options: RenderTableMultiTagsOptionType = {}) => {
  const { tagNodeProps, ellipsis = true } = options;
  const result = data?.map(item =>
    h(
      BaseTag,
      { class: 'm-2px ', type: 'primary', size: 'small', bordered: false, ...tagNodeProps },
      { default: () => item }
    )
  );
  return ellipsis ? result : h('div', { class: 'text-left' }, result);
};

// 渲染表格序号
export const useRenderTableIndex = (pagination: MaybeComputedRef<PaginationProps | undefined>): TableColumn<Object> => {
  return {
    title: i18nt('index'),
    key: 'index',
    align: 'center',
    width: TABLE_WIDTH_INDEX,
    render: (rowData: Object, rowIndex: number) =>
      h('span', undefined, {
        default: () => rowIndex + 1 + ((pagination?.value?.page ?? 1) - 1) * (pagination?.value?.pageSize ?? 10)
      })
  };
};

// -------------------------------------------------------------------------------------------- > Tree

// 格式化树 - 翻译
export const useFormatTreeTranslate = <T extends { [key: string]: any } = any>(
  list: T[] | undefined,
  field: string
): T[] => {
  if (!list?.length) return [];
  return list.map(item => {
    const _item: any = { ...item, children: useFormatTreeTranslate(item.children, field) };
    _item[`${field}`] = i18nt(item[field]);
    return _item;
  });
};
