import { Utf8 } from 'crypto-es/lib/core';
import type { CipherCfg } from 'crypto-es/lib/cipher-core';
import { CBC, Pkcs7 } from 'crypto-es/lib/cipher-core';
import { AES } from 'crypto-es/lib/aes';
import { MD5 } from 'crypto-es/lib/md5';

export const encryptAes = ({
  plaintext,
  key,
  iv,
  mode = CBC,
  padding = Pkcs7
}: {
  plaintext: string;
  key: string;
  iv: string;
  mode?: CipherCfg['mode'];
  padding?: CipherCfg['padding'];
}): string | undefined => {
  const aesKey = Utf8.parse(key);
  const aesIv = Utf8.parse(iv);
  const encrypted = AES.encrypt(plaintext, aesKey, { mode, padding, iv: aesIv });
  return encrypted.toString();
};

export const encryptMd5 = (plaintext: string): string => MD5(plaintext).toString();
