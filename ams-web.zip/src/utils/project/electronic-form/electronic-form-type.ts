import { API_PREFIX_CONFIG } from '@/service/apis/common/common';

export const ElectronicFormApis = {
  // 获取改机信息
  getChangeMachineInfoApi: `${API_PREFIX_CONFIG}/Attributes/GetSelectItemList`,
  // 获取表单项列表
  getFormItemListApi: `${API_PREFIX_CONFIG}/GenerateForm/GetFormItems`,
  // 检查表单项
  validateFormItemApi: `${API_PREFIX_CONFIG}/GenerateForm/JudgeFormItemResult`
};
// 表单项列表
export interface FormItemListType {
  formName: string
  formType: string
  fromResult: number
  itemList: ItemListType[]
  sampleNum: number
  testNum: number
}
// 表单类型
export enum ItemListDataType {
  // 数字
  number = 1,
  // 字符串
  string,
  // 布尔
  boolean,
  // 单选 selct
  select,
  // 多选 select
  multiSelct,
  // 单选
  radio,
  // 多选
  checkbox,
  // 系统带入
  systemImport,
  // 上传
  upload,
  // 小数
  numberInput
}
// 是否需要校验
export enum ValidateFormItem {
  no,
  yes
}
// 校验结果
export enum ValidateFormItemResult {
  // 不通过
  fail,
  // 通过
  pass
}
// 校验表单项
export interface ValidateFormItemResultType {
  judgeReason: string
  result: ValidateFormItemResult
}
// 表格类型
export enum ItemListBelongTo {
  // 设备
  eqp = 1,
  // 组别
  group,
  // 金样
  goldSample
}
// 数值类型
export type RenderComponentType = {
  [key in ItemListDataType]: {
    label: string
    render: (formItemList: Ref<ItemListType[] | undefined>, rowData: ItemListType, index: number) => VNode
  };
};

// 表单项类型
export interface ItemListType {
  id: string
  belongTo: ItemListBelongTo

  category: ItemListCategory
  itemGroup: string
  dataSource: string
  dataSourceList: string[]

  isCheck: number
  judgeType: number
  failValue: string
  apply: number
  finalResult: ItemListFinalResult
  itemOrder: number
  judgeReason: string
  isTemp?: boolean

  itemName: string
  attachmentName?: string
  attachmentFile?: string
  attachment: number

  itemValue: string
  result: ValidateFormItemResult
  standard: string
  unit: string
  dataType: ItemListDataType

  remark: string
  tableIsShow?: boolean
  Ball?: string
  Stitch?: string
  Loop?: string
  WirePullBallShear?: string
  idNew?: string
  disabled?: boolean
  operateIsShow?: boolean

  maxItemValue?: number
  maxItemValueIsShow?: boolean

  lowLimit?: number | null | undefined
  highLimit?: number | null | undefined
  sampleNo?: string
  sample?: ItemListTypeSample[]
  dataList?: ItemListTypeSampleTypeDataList[]
}
// 表格类别列表
export enum ItemListCategory {
  // 公用
  common,
  // 维保
  mlaintenance,
  // 点检
  spot,
  // Alarm
  alarm,
  // 备件
  spare,
  // 生产验证
  productReview,
  // 报修
  repair,
  // 改机
  changeMachine
}
export enum ItemListFinalResult {
  // 表单结果
  formResult = -1,
  // 普通项
  ordinaryItem
}
export interface ItemListTypeSample {
  highLimit?: number | null | undefined
  lowLimit?: number | null | undefined
  sampleNo?: string
  dataList?: ItemListTypeSampleTypeDataList[]
}
export interface ItemListTypeSampleTypeDataList {
  dataNo: string
  dataValue: string
  dataResult?: number
}

// export enum FormInfoRequestFormType {
//   // 改机确认
//   changeMachineConfirm = 5,
//   // QC确认
//   qcConfirm,
//   // 设备接收
//   equipmentReceive
// }

// export interface OperateRecordDetailType {
//   formName: string;
//   formType: string;
//   fromResult: ValidateFormItemResult;
//   itemList: OperateRecordDetailItemListType[];
//   typeTableData?: ItemListType[];
//   nameTableData?: ItemListType[];
//   sampleNum: number;
//   testNum: number;
// }

// export type OperateRecordDetailSetsType = { [key in string]: OperateRecordDetailType };
// export const validateFormItemResultStateText: { [keys in ValidateFormItemResult]: string } = {
//   [ValidateFormItemResult.pass]: 'Pass',
//   [ValidateFormItemResult.fail]: 'Fail'
// };
// export const validateFormItemResultStateType: { [keys in ValidateFormItemResult]: string } = {
//   [ValidateFormItemResult.pass]: 'success',
//   [ValidateFormItemResult.fail]: 'error'
// };
