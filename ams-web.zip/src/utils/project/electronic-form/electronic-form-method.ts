import { NCheckbox, NCheckboxGroup, NRadio, NRadioGroup } from 'naive-ui';
import type { UploadFileInfo } from 'naive-ui';
import BaseInput from '@c/base-ui/base-input/base-input.vue';
import BaseSelect from '@c/base-ui/base-select/base-select.vue';
import BaseSwitch from '@c/base-ui/base-switch/base-switch.vue';
import BaseInputNumber from '@c/base-ui/base-input-number/base-input-number.vue';
import BaseUpload from '@c/base-ui/base-upload/base-upload.vue';
import BaseIcon from '@c/base-icon.vue';
import BaseTooltip from '@c/base-ui/base-tooltip/base-tooltip.vue';

import {
  ElectronicFormApis,
  ItemListBelongTo,
  ItemListDataType,
  ValidateFormItem,
  ValidateFormItemResult
} from './electronic-form-type';
import type {
  ItemListType,
  ItemListTypeSampleTypeDataList,
  RenderComponentType,
  ValidateFormItemResultType
} from './electronic-form-type';
import { CommonApis } from '@/service/apis/common/common';

// 附件上传
const { execute: imgChange, isLoading } = useAxiosPost<number>(CommonApis.uploadFileApi);
// 上表格数据处理
export const handleTableData = (itemList: ItemListType[], tableIsShow = false) => {
  const list = itemList
    .filter((item: ItemListType) => item.belongTo !== ItemListBelongTo.goldSample)
    .map((ele: ItemListType) => {
      if (ele.remark) {
        const list = ele.remark.replace(/\s*/g, '').split('|');
        if (list[0] === 'check:') {
          ele.tableIsShow = true;
          ele.Ball = list[1].split('Ball')[1];
          ele.Stitch = list[2].split('Stitch')[1];
          ele.Loop = list[3].split('Loop')[1];
          ele.WirePullBallShear = list[4].split('WirePull&BallShear')[1];
        }
      }
      return {
        ...ele,
        itemValue: ele.dataType === ItemListDataType.upload ? (ele.attachmentFile || '') : ele.itemValue
      };
    });
  return list.filter((item: ItemListType) => (tableIsShow ? item.tableIsShow : !item.tableIsShow));
};
export const useRenderFormItemComponent = (): RenderComponentType => ({
  [ItemListDataType.number]: {
    label: i18nt('EnumCheckItemDataType_Numerical'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseInputNumber, {
          value: rowData.itemValue === '' ? null : Number(rowData.itemValue),
          min: 0,
          precision: 0,
          status: valiedateComponentState(rowData),
          onBlur: () => {
            handleGetValidateFormItemResult(formItemList, index, rowData);
          },
          onUpdateValue: (v: number | null) => {
            handleUpdateFormItemValue(formItemList, index, v ? String(v) : '');
          }
        }),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.string]: {
    label: i18nt('EnumCheckItemDataType_Input'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseInput, {
          value: String(rowData.itemValue),
          onBlur: () => {
            handleGetValidateFormItemResult(formItemList, index, rowData);
          },
          onUpdateValue: (v: string) => {
            handleUpdateFormItemValue(formItemList, index, String(v));
          }
        }),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.boolean]: {
    label: i18nt('EnumCheckItemDataType_Boolean'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseSwitch, {
          value: rowData.itemValue,
          checkedValue: rowData.dataSourceList && rowData.dataSourceList.length !== 0 ? rowData.dataSourceList[1] : '1',
          uncheckedValue:
            rowData.dataSourceList && rowData.dataSourceList.length !== 0 ? rowData.dataSourceList[0] : '0',
          onUpdateValue: (v: string) => {
            rowData.operateIsShow = true;
            handleUpdateFormItemValue(formItemList, index, String(v));
            handleGetValidateFormItemResult(formItemList, index, rowData);
          }
        }),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.select]: {
    label: i18nt('EnumCheckItemDataType_RadioList'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseSelect, {
          value: rowData.itemValue || null,
          options: rowData.dataSourceList.map(item => ({ label: item, value: item })),
          onUpdateValue: (v: string) => {
            handleUpdateFormItemValue(formItemList, index, v && String(v));
            handleGetValidateFormItemResult(formItemList, index, rowData);
          }
        }),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.multiSelct]: {
    label: i18nt('EnumCheckItemDataType_MultiSelectList'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseSelect, {
          value: rowData.itemValue === '' ? null : rowData.itemValue.split(','),
          multiple: true,
          options: rowData.dataSourceList.map(item => ({ label: item, value: item })),
          onUpdateValue: (v: string[]) => {
            handleUpdateFormItemValue(formItemList, index, v.join(','));
            handleGetValidateFormItemResult(formItemList, index, rowData);
          }
        }),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.radio]: {
    label: i18nt('EnumCheckItemDataType_RadioCheckbox'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(
          NRadioGroup,
          {
            value: rowData.itemValue,
            onUpdateValue: v => {
              handleUpdateFormItemValue(formItemList, index, v);
              handleGetValidateFormItemResult(formItemList, index, rowData);
            }
          },
          {
            default: () =>
              rowData.dataSourceList.map(item => h(NRadio, { key: item, value: item }, { default: () => item }))
          }
        ),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.checkbox]: {
    label: i18nt('EnumCheckItemDataType_MultiCheckbox'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(
          NCheckboxGroup,
          {
            value: rowData.itemValue === '' ? null : rowData.itemValue.split(','),
            onUpdateValue: v => {
              handleUpdateFormItemValue(formItemList, index, v.join(','));
              handleGetValidateFormItemResult(formItemList, index, rowData);
            }
          },
          {
            default: () => rowData.dataSourceList.map(item => h(NCheckbox, { value: item, label: item }))
          }
        ),
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.systemImport]: {
    label: i18nt('EnumCheckItemDataType_SystemOut'),
    render() {
      return h(BaseInput);
    }
  },
  [ItemListDataType.upload]: {
    label: i18nt('EnumCheckItemDataType_Attachment'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseUpload, {
          loading: isLoading.value,
          disabled: isLoading.value,
          value: String(rowData.itemValue),
          defaultUpload: false,
          showFileList: false,
          max: 999,
          onChange: async (options: { file: UploadFileInfo; fileList: UploadFileInfo[] }) => {
            if (!options.file.file) return;
            const params = new FormData();
            params.append('file', options.file.file ?? '');
            const { data } = await imgChange({
              data: params
            });
            handleUpdateFormItemValueName(formItemList, index, String(options.file.name));
            handleUpdateFormItemValue(formItemList, index, String(data.value));
            options.fileList = [];
          }
        }),
        rowData.attachmentName
          ? h(
            'div',
            {
              style: {
                cursor: 'pointer'
              }
            },
            [
              h(
                'span',
                {
                  style: {
                    marginRight: '10px'
                  }
                },
                rowData.attachmentName
              ),
              h(BaseIcon, {
                icon: 'i-carbon:trash-can',
                size: 15,
                color: 'var(--error-color)',
                onClick: () => {
                  handleUpdateFormItemValueName(formItemList, index, String(''));
                  handleUpdateFormItemValue(formItemList, index, String(''));
                }
              })
            ]
          )
          : '',
        renderValidateFeedback(rowData)
      ]);
    }
  },
  [ItemListDataType.numberInput]: {
    label: i18nt('EnumCheckItemDataType_Decimal'),
    render(formItemList, rowData, index) {
      return h('div', null, [
        h(BaseInputNumber, {
          value: rowData.itemValue === '' ? null : Number(rowData.itemValue),
          min: 0,
          status: valiedateComponentState(rowData),
          onBlur: () => {
            handleGetValidateFormItemResult(formItemList, index, rowData);
          },
          onUpdateValue: (v: number | null) => {
            handleUpdateFormItemValue(formItemList, index, v ? String(v) : '');
          }
        }),
        renderValidateFeedback(rowData)
      ]);
    }
  }
});
// 获取校验表单项结果
const handleGetValidateFormItemResult = async (
  formItemList: Ref<ItemListType[] | undefined>,
  index: number,
  rowData: ItemListType
) => {
  try {
    if (rowData.isCheck === ValidateFormItem.no) {
      const isShow = rowData.maxItemValue && rowData.itemValue.length > rowData.maxItemValue;
      handleUpdateFormItemValidateResult(formItemList, index, isShow ? 0 : 1, `${rowData.maxItemValue}`, !!isShow);
    } else {
      if (rowData.maxItemValue && rowData.itemValue.length > rowData.maxItemValue) {
        handleUpdateFormItemValidateResult(formItemList, index, 0, `${rowData.maxItemValue}`, true);
        return;
      }
      if (rowData.itemValue === '' || rowData.itemValue === null) return;
      const { data } = await useAxiosGet<ValidateFormItemResultType>(
        ElectronicFormApis.validateFormItemApi,
        {
          itemId: rowData.id,
          itemValue: rowData.itemValue
        },
        __,
        { immediate: true }
      );
      if (data.value !== __) {
        handleUpdateFormItemValidateResult(formItemList, index, data.value?.result, data.value?.judgeReason);
      }
    }
  } catch (error) {
    console.log('获取校验表单项结果异常：', error);
  }
};
// 循环校验表单是否通过(布尔值暂时不作处理)
export const handleValidateFormIsPass = (formItemList: Ref<ItemListType[] | undefined>) => {
  if (!formItemList.value) return;
  const list = formItemList.value?.filter(ele => ele.dataType !== ItemListDataType.boolean);
  const res = every(list, { result: ValidateFormItemResult.pass });
  if (!res) $notification.warning({ title: i18nt('tips'), content: i18nt('validateFormIsPassTips') });
  return res;
};
// 循环校验表单是否有长度报错
export const handleValidateFormIsMaxItemValue = (formItemList: Ref<ItemListType[] | undefined>) => {
  if (!formItemList.value) return;
  const isShow = formItemList.value.some(ele => ele.maxItemValueIsShow === true);
  if (isShow) $notification.warning({ title: i18nt('tips'), content: i18nt('validateFormIsMaxItemValueTips') });
  return isShow;
};
// 循环校验表单是否为空
export const handleValidateChangeMachineForm = (formItemList: Ref<ItemListType[] | undefined>) => {
  let isOk = true;
  let content = '';
  formItemList.value
    ?.filter(ele => ele.dataType !== ItemListDataType.boolean)
    .forEach(item => {
      if (item.itemValue === '' || item.itemValue === null) {
        isOk = false;
        content += `${i18nt('notEmpty', { val: item.itemName })}\n`;
      }
    });
  if (!isOk) $notification.warning({ title: i18nt('tips'), content });
  return isOk;
};
// 更新表单列表 - result & reason
const handleUpdateFormItemValidateResult = (
  formItemList: Ref<ItemListType[] | undefined>,
  index: number,
  result: ValidateFormItemResult,
  reason: string,
  maxItemValueIsShow = false
) => {
  if (formItemList.value) {
    formItemList.value[index].result = result;
    formItemList.value[index].judgeReason = reason;
    formItemList.value[index].maxItemValueIsShow = maxItemValueIsShow;
  }
};

// 更新表单列表 - ItemValue
const handleUpdateFormItemValue = (formItemList: Ref<ItemListType[] | undefined>, index: number, val: string) => {
  if (formItemList.value) {
    formItemList.value[index].itemValue = val;
    if (formItemList.value[index].dataType === ItemListDataType.upload) {
      formItemList.value[index].result = val ? ValidateFormItemResult.pass : ValidateFormItemResult.fail;
    } else {
      // 还原到未校验的状态
      if (!val) {
        formItemList.value[index].result = ValidateFormItemResult.fail;
        formItemList.value[index].judgeReason = '';
        formItemList.value[index].maxItemValueIsShow = false;
      }
    }
  }
};
// 更新表单列表 - ItemValue(附件)
const handleUpdateFormItemValueName = (formItemList: Ref<ItemListType[] | undefined>, index: number, val: string) => {
  if (formItemList.value) {
    formItemList.value[index].attachmentName = val;
  }
};
// 组件验证状态
const valiedateComponentState = (rowData: ItemListType) =>
  rowData?.result === ValidateFormItemResult.fail && rowData.judgeReason ? 'error' : 'success';

// 验证反馈
const renderValidateFeedback = (rowData: ItemListType) => {
  return (
    rowData?.result === ValidateFormItemResult.fail
    && rowData.judgeReason
    && (rowData.maxItemValueIsShow
      ? h(
        'div',
        {
          class: 'mt-10px',
          style: {
            color: 'var(--error-color)'
          }
        },
        rowData.itemName + i18nt('validateFailMaxItemValue') + rowData.maxItemValue
      )
      : h(
        'div',
        {
          class: 'mt-10px',
          style: {
            color: 'var(--error-color)'
          }
        },
        rowData.itemName + i18nt('validateFail')
      ))
  );
};

// 生成金样数据
export const handleTableColSpan = (
  itemList: ItemListType[],
  { sampleNum, testNum }: { sampleNum: number; testNum: number }
) => {
  const list = [];
  for (let i = 0; i < itemList.length; i++) {
    list.push(...generateSampleData(sampleNum, testNum, i, itemList[i]));
  }
  return list;
};
// 回填生成数据
export const handleTableColSpanBackfill = (
  data: ItemListType[] = [],
  { sampleNum, testNum }: { sampleNum: number; testNum: number }
) => {
  const itemListNew = data.reduce((newList: ItemListType[], oldList) => {
    const { sample = [] } = oldList;
    const oldListNew: ItemListType[] = [];
    for (let i = 0; i < sampleNum; i++) {
      const {
        highLimit = null,
        lowLimit = null,
        sampleNo = '',
        dataList = []
      } = sample[i] || {
        highLimit: null,
        lowLimit: null,
        unit: '',
        sampleNo: '',
        dataList: []
      };
      const dataListObj = [];
      for (let j = 0; j < testNum; j++) {
        if (dataList[j]) {
          const {
            dataNo = '',
            dataResult,
            dataValue = ''
          } = dataList[j] || {
            dataNo: '',
            dataValue: '',
            dataResult: undefined
          };
          dataListObj.push({ dataNo: `${dataNo}`, dataResult, dataValue: `${dataValue}` });
        } else {
          dataListObj.push({ dataNo: `${j + 1}`, dataResult: undefined, dataValue: '' });
        }
      }
      oldListNew.push({
        ...oldList,
        highLimit: Number(highLimit),
        lowLimit: Number(lowLimit),
        sampleNo,
        dataList: dataListObj
      });
    }
    return newList.concat(oldListNew);
  }, [] as ItemListType[]);
  return itemListNew;
};
// 生成下表格行数据
const generateSampleData = (sampleNum: number, testNum: number, index: number, data: ItemListType) => {
  const result: ItemListType[] = [];
  const { id } = data;
  for (let i = 0; i < sampleNum; i++) {
    const list = [];
    for (let j = 0; j < testNum; j++) {
      list.push({
        dataNo: `data${j + 1}`,
        dataValue: '',
        dataResult: 0
      });
    }
    result.push({
      ...data,
      lowLimit: null,
      highLimit: null,
      disabled: true,
      sampleNo: `${i + 1}`,
      idNew: `${id}+${index}+${i}`,
      dataList: list
    });
  }
  return result;
};
// 生成动态表头
export const handleTableColumns = ({ testNum }: { testNum: number }, backfillIsShow?: boolean) => {
  const list: DataTableColumns<ItemListType> = [];
  for (let i = 0; i < testNum; i++) {
    list.push({
      title: `Data${i + 1}`,
      key: `Data${i + 1}`,
      width: 120,
      render(row) {
        const appStore = useAppStore();
        const { themePrimary } = storeToRefs(appStore);
        return backfillIsShow
          ? h(
            'div',
            {
              class: 'flex flex-center justify-between items-center'
            },
            [
              h(BaseInput, {
                onBlur: () => dataValueBlur(row, i),
                disabled: row.disabled,
                placeholder: '',
                class: 'w-50%!',
                clearable: false,
                value: row.dataList ? row.dataList[i].dataValue : '',
                onInput: (value: string) => {
                  if (!row.dataList) return;
                  row.dataList[i].dataValue = value || '';
                }
              }),
              h(
                BaseTooltip,
                {
                  trigger: 'hover'
                },
                {
                  default: () => {
                    if (!row.dataList) return;
                    return Number(row.dataList[i].dataResult) === 1 ? 'Pass' : 'Fail';
                  },
                  trigger: () =>
                    h(BaseSwitch, {
                      class: 'w-50%!',
                      disabled: true,
                      checkedValue: 1,
                      uncheckedValue: 0,
                      defaultValue: 0,
                      railStyle: ({ checked }: { checked: boolean }) => {
                        return {
                          background: checked ? themePrimary.value : 'rgb(255, 73, 73)'
                        };
                      },
                      value: row.dataList ? row.dataList[i].dataResult : ''
                    })
                }
              )
            ]
          )
          : h('span', row.dataList ? row.dataList[i].dataValue : '');
      }
    });
  }
  return list;
};

// 表头输入框失焦事件

// 验证接口修改
const checkSampleLimitApi = ref<string>();
export const dataApiHandle = (api: string) => {
  checkSampleLimitApi.value = api;
};
// 验证data
const { execute: executeCheckSampleLimitApi } = useAxiosPost<number>('');
const dataValueBlur = async (row: ItemListType, index: number) => {
  try {
    const { lowLimit, highLimit } = row;
    if (!row.dataList) return;
    const dataValue = row.dataList[index].dataValue;
    if (dataValue === 'NA') {
      if (index === 0) {
        for (let i = 0; i < row.dataList.length; i++) {
          row.dataList[i].dataValue = 'NA';
          row.dataList[i].dataResult = 1;
        }
      } else {
        row.dataList[index].dataValue = 'NA';
        row.dataList[index].dataResult = 1;
      }
    } else if (lowLimit && highLimit) {
      // 不是一个数字
      if (isNaN(Number(lowLimit)) || isNaN(Number(highLimit))) {
        row.dataList[index].dataValue = '';
        row.dataList[index].dataResult = 0;
      } else {
        const { data } = await executeCheckSampleLimitApi(checkSampleLimitApi.value, {
          data: {
            lowLimit,
            highLimit,
            dataValue
          }
        });
        if (data.value) {
          row.dataList[index].dataResult = data.value;
        } else {
          row.dataList[index].dataValue = '';
          row.dataList[index].dataResult = 0;
        }
      }
    }
  } catch (error) {
    console.log(error);
    if (!row.dataList) return;
    row.dataList[index].dataValue = '';
  }
};
// 下表格上下限验证
export const validSampleLimit = (list: ItemListType[] = []) => {
  const lowLimitIsShow = list.every(ele => ele.lowLimit);
  const highLimitIsShow = list.every(ele => ele.highLimit);
  const isShow = lowLimitIsShow && highLimitIsShow;
  if (!isShow) {
    $notification.warning({ title: i18nt('tips'), content: i18nt('validSampleLimitTips') });
  }
  return isShow;
};
// 下表格data验证
export const validSampleItem = (list: ItemListType[] = []) => {
  const arr = list.reduce((newList, oldList) => {
    const { dataList = [] } = oldList;
    return newList.concat(dataList);
  }, [] as ItemListTypeSampleTypeDataList[]);
  const dataValueIsShow = arr.every(item => item.dataValue !== '');
  const dataResultIsShow = arr.every(item => item.dataResult !== 0);
  const isShow = dataValueIsShow && dataResultIsShow;
  if (!isShow) {
    $notification.warning({ title: i18nt('tips'), content: i18nt('validSampleItemTips') });
  }
  return isShow;
};
// 下表格数据转换
export const handleGoldSampleTableData = (list: ItemListType[] = []) => {
  if (!list.length) return;
  const listNew: ItemListType[] = [];
  for (let i = 0; i < list.length; i++) {
    const { id, highLimit, lowLimit, sampleNo, dataList, ...obj } = list[i];
    const index = listNew.findIndex(v => v.id === id);
    if (index === -1) {
      listNew.push({
        ...obj,
        id,
        sample: [{ highLimit, lowLimit, sampleNo, dataList }]
      });
    } else {
      listNew[index]?.sample?.push({ highLimit, lowLimit, sampleNo, dataList });
    }
  }
  return listNew;
};
