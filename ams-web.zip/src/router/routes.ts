import type { RouteRecordRaw } from 'vue-router';

export enum Routes {
  LOGIN = '/login',
  LOGIN_ESWIN = '/login-eswin',
  WORKBENCH = '/workbench',
  NOT_FOUND = '/404'
}

// 登录名单
export const ROUTE_LOGIN_LIST: string[] = [Routes.LOGIN, Routes.LOGIN_ESWIN];

// 路由守卫白名单
export const ROUTE_GUARD_WHITE_LIST: string[] = [...ROUTE_LOGIN_LIST, Routes.NOT_FOUND];

// 路由表
export const publicRoutes: RouteRecordRaw[] = [
  { path: '/', redirect: Routes.WORKBENCH },
  { path: Routes.LOGIN, name: 'login', meta: { title: 'login' }, component: () => import('@/views/login/login.vue') },
  {
    path: Routes.WORKBENCH,
    component: () => import('@/layout/layout.vue'),
    children: [
      {
        path: '',
        name: 'workbench',
        meta: { title: 'workbench' },
        component: () => import('@/views/workbench/workbench.vue')
      }
    ]
  },
  {
    path: '/personal',
    component: () => import('@/layout/layout.vue'),
    children: [
      {
        path: '',
        name: 'personal',
        meta: { title: 'personal' },
        component: () => import('@/views/personal/personal.vue')
      }
    ]
  },
  {
    path: '/redirect',
    component: () => import('@/layout/layout.vue'),
    children: [{ path: '/redirect/:path(.*)*', component: () => import('@/views/redirect/redirect.vue') }]
  },
  {
    name: '404',
    path: '/:pathMatch(.*)*',
    component: () => import('@/views/error-page/error-page-not-found.vue'),
    meta: { title: 'notFoundPage' }
  }
];

// 固定路由
export const fixedRouteList = [...publicRoutes.map(item => item.path), '/redirect/:path(.*)*'];
