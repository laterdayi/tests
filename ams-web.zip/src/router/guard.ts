import type { NavigationGuardNext, Router } from 'vue-router';
import { ROUTE_GUARD_WHITE_LIST, ROUTE_LOGIN_LIST, Routes } from '@/router/routes';
import { getRoutePathLogin, parseRouterPath } from '@/router/utils';
import { useRouteStore } from '@/stores/route';
import { useUserStore } from '@/stores/user';

const siteTitle = useTitle();

export function setupRouterGuard(router: Router) {
  // -------------------------------------------------------------------------------------------- > 路由前置守卫 > SSO + 默认
  router.beforeEach(async (to, from, next) => {
    $loadingBar?.start();
    const userStore = useUserStore();
    if (window.$CONFIG?.projectConfig?.sso?.open) {
      // 如果 SSO 模式
      if (to.query.code) {
        // url存在 code 时, 跳转工作台 | sso认证中心
        next();
      } else if (to.query.logout) {
        // url存在 logout 时, 退出登录 & 跳转登录页
        await userStore.logout();
        const ROUTE_PATH_LOGIN = getRoutePathLogin();
        next({ path: ROUTE_PATH_LOGIN, replace: true });
      } else {
        await beforeGuard(to, from, next);
      }
    } else {
      await beforeGuard(to, from, next);
    }
  });

  // 路由前置守卫 > 默认
  async function beforeGuard(to: RouteLocationNormalized, from: RouteLocationNormalized, next: NavigationGuardNext) {
    const userStore = useUserStore();
    const routeStore = useRouteStore();
    // 如果登录
    if (userStore.userInfo?.token) {
      if (ROUTE_LOGIN_LIST.includes(to.path)) {
        next(Routes.WORKBENCH);
        // 如果没有路由
      } else if (!routeStore.hasRoutes) {
        // 获取用户信息
        userStore.getUserInfo();
        // 获取路由
        const routes = await routeStore.getDynamicRoutes();
        if (routes?.length) {
          // 默认取第一个
          const defaultModel = routeStore.workbenchList.find(item => item.meta.link !== 1);
          if (defaultModel?.name) routeStore.setCurrentModule(defaultModel.name);
          // 动态添加路由
          routes?.forEach(route => {
            router.addRoute(route);
          });
          if (to.name === '404') {
            // 动态路由没有加载导致404，等待权限路由加载好了，回到之前的路由
            // 若路由是从根路由重定向过来的，重新回到根路由
            const path = to.redirectedFrom?.name === Routes.WORKBENCH ? '/' : to.fullPath;
            next({ path, replace: true, query: to.query });
            return false;
          }
          next();
        } else {
          next();
        }
      } else {
        next();
      }
      // 如果白名单存在，前往该路由
    } else if (ROUTE_GUARD_WHITE_LIST.includes(to.path)) {
      next();
    } else {
      const ROUTE_PATH_LOGIN = getRoutePathLogin();
      // 否则进入登录
      next({ path: ROUTE_PATH_LOGIN, query: { redirectUrl: to.query.redirect ? from.path : to.path } });
    }
  }

  // -------------------------------------------------------------------------------------------- > 路由后置守卫
  router.afterEach(to => {
    const routeStore = useRouteStore();
    const parsePath = parseRouterPath(to.path);
    //  对比router path 和 当前模式
    if (parsePath !== routeStore.currentModule) {
      const res = routeStore.workbenchList.filter(item => item.path === parsePath);
      if (res?.[0]?.path) routeStore.setCurrentModule(camelCase(res?.[0]?.path));
    }
    // 更改网站标题
    const title = to?.meta?.title;
    if (title) {
      siteTitle.value = `${i18nt(title as string)}${window.$CONFIG?.[i18nLocal]?.websiteTitleSuffix}`;
    }
    $loadingBar?.finish();
  });
}
