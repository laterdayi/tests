import type { RouteRecordRaw } from 'vue-router';
import { Routes } from './routes';
import { BASE_LAYOUT, BLANK_LAYOUT } from '@/constants/app';
import type { RouteType } from '@/service/apis/common/type';

const modules = import.meta.glob('../views/**/*.vue');
const Layout = import.meta.glob('../layout/*.vue');

// 解析路由地址：/tms or/tms/config > tms
export const parseRouterPath = (path: string): string => {
  return path.split('/')[1];
};

// 转换返回 Vue Component
export const generateAsyncRouter = (parentPrefix: string | undefined, routes: RouteType[]) => {
  const isTopRoute = parentPrefix === '/';
  const result: RouteRecordRaw[] = routes.reduce((routeList: RouteRecordRaw[], route) => {
    if (route.meta.link !== 1) {
      const path = isTopRoute ? `${parentPrefix}${route.path}` : route.path;
      const name = isTopRoute ? route.name : `${parentPrefix}-${route.name}`;
      const routeItem: RouteRecordRaw = {
        path,
        name,
        redirect: camelCase(route.redirect),
        meta: route.meta,
        component: getLayout(isTopRoute ? 'Layout' : route.component),
        children: isTopRoute
          ? [
              {
                ...route,
                path: '',
                component: getLayout(route.component),
                redirect: camelCase(route.redirect),
                meta: route.meta,
                children: []
              }
            ]
          : []
      };
      if (route?.children?.length) {
        routeItem.children = generateAsyncRouter(name, route.children);
      }
      routeList.push(routeItem);
    }
    return routeList;
  }, []);
  return result;
};

// 转换对应组件
const getLayout = (component: string) => {
  switch (component) {
    case BASE_LAYOUT:
      return Layout['../layout/layout.vue'];
    case BLANK_LAYOUT:
      return Layout['../layout/blank-layout.vue'];
    default:
      return modules[`../views/${component}.vue`];
  }
};

// 获取登录地址
export const getRoutePathLogin = () => {
  const path = window.$CONFIG?.projectConfig?.sign
    ? `${Routes.LOGIN}-${window.$CONFIG.projectConfig.sign.toLowerCase()}`
    : Routes.LOGIN;
  return path;
};
