<script setup lang="ts">
interface PropsType {
  // 图标名
  icon: string
  // 是否根据系统颜色
  useThemeColor?: boolean
  // 图标大小
  size?: number
  // 旋转
  rotate?: '0' | '90' | '180' | '270'
  // 颜色
  color?: string
}

withDefaults(defineProps<PropsType>(), {
  size: 20,
  useThemeColor: false,
  rotate: '0',
  icon: undefined,
  color: undefined
});

const appStore = useAppStore();
const { themePrimary } = storeToRefs(appStore);
</script>

<template>
  <div
    :style="{ fontSize: `${size}px`, color: useThemeColor ? themePrimary : color }"
    :class="[icon, `rotate-${rotate}`]"
  />
</template>
