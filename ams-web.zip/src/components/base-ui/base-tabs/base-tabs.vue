<script setup lang="ts">
import type { TabsProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TabsProps {}
const props = withDefaults(defineProps<PropsType>(), {});

const slots = useSlots();
</script>

<template>
  <n-tabs :type="props.type ?? 'line'" :animated="props.animated ?? true">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-tabs>
</template>
