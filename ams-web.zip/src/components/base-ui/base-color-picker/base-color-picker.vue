<script setup lang="ts">
import type { ColorPickerProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ColorPickerProps {}
defineProps<PropsType>();
</script>

<template>
  <n-color-picker :modes="['hex']" :actions="['clear']" />
</template>
