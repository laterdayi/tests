<script setup lang="ts">
import type { AnchorLinkProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AnchorLinkProps {}
defineProps<PropsType>();
</script>

<template>
  <n-anchor-link>
    <slot />
  </n-anchor-link>
</template>
