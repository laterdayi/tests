<script setup lang="ts">
import type { AnchorProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AnchorProps {}
defineProps<PropsType>();
</script>

<template>
  <n-anchor>
    <slot />
  </n-anchor>
</template>
