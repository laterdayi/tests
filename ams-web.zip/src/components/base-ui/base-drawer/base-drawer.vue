<script setup lang="ts">
import type { DrawerProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ DrawerProps {
  // 标题
  title?: string
  // 宽度
  width?: DrawerProps['width']
}
defineProps<PropsType>();
const slots = useSlots();
</script>

<template>
  <n-drawer :width="width ? width : 500" :auto-focus="false">
    <n-drawer-content :title="title">
      <slot />
      <template v-if="slots.footer" #footer>
        <slot name="footer" />
      </template>
    </n-drawer-content>
  </n-drawer>
</template>
