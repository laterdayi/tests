export const useDrawer = () => {
  // 显示
  const showDrawer = ref(false);

  // 打开
  const openDrawer = () => {
    showDrawer.value = true;
  };

  // 关闭
  const closeDrawer = () => {
    showDrawer.value = false;
  };

  return {
    showDrawer,
    closeDrawer,
    openDrawer
  };
};
