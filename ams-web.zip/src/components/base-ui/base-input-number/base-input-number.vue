<script setup lang="ts">
import type { InputNumberProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ InputNumberProps {
  // 禁用
  disabled?: InputNumberProps['disabled']
  // 表单标签
  label?: string
}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-input-number
    class="min-component-width!"
    clearable
    :disabled="disabled"
    :min="1"
    :placeholder="disabled ? '' : `${$t('baseForm.pleaseInput')}${label ?? ''}`"
  >
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-input-number>
</template>
