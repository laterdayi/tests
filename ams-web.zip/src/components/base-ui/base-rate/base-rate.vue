<script setup lang="ts">
import type { RateProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ RateProps {}
defineProps<PropsType>();
</script>

<template>
  <n-rate />
</template>
