export const usePopover = () => {
  // 显示
  const showPopover = ref(false);

  // 打开
  const openPopover = () => {
    showPopover.value = true;
  };

  // 关闭
  const closePopover = () => {
    showPopover.value = false;
  };

  return {
    showPopover,
    closePopover,
    openPopover
  };
};
