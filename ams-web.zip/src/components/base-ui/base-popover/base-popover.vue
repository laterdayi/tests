<script setup lang="ts">
import type { PopoverProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ PopoverProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-popover scrollable :class="[`max-w-${TOOLTIP_MAX_WIDTH}`, `max-h-${TOOLTIP_MAX_HEIGHT}`]">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-popover>
</template>
