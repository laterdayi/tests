<script setup lang="ts">
import type { TimePickerProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TimePickerProps {}
defineProps<PropsType>();
</script>

<template>
  <n-time-picker clearable value-format="HH:mm:ss" />
</template>
