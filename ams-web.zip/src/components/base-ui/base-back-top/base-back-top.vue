<script setup lang="ts">
import type { BackTopProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ BackTopProps {}
defineProps<PropsType>();
</script>

<template>
  <n-back-top>
    <slot />
  </n-back-top>
</template>
