<script setup lang="ts">
import type { CardProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CardProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-card>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-card>
</template>
