<script setup lang="ts">
import type { CountdownProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CountdownProps {}
defineProps<PropsType>();
</script>

<template>
  <n-countdown />
</template>
