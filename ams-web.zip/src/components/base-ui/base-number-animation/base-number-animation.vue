<script setup lang="ts">
import type { NumberAnimationProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ NumberAnimationProps {}
defineProps<PropsType>();
</script>

<template>
  <n-number-animation />
</template>
