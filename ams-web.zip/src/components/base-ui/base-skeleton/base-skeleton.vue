<script setup lang="ts">
import type { SkeletonProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ SkeletonProps {}
defineProps<PropsType>();
</script>

<template>
  <n-skeleton />
</template>
