<script setup lang="ts">
import type { ImageGroupProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ImageGroupProps {}
defineProps<PropsType>();
</script>

<template>
  <n-image-group show-toolbar-tooltip>
    <slot />
  </n-image-group>
</template>
