<script setup lang="ts">
import type { ImageProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ImageProps {}
defineProps<PropsType>();
</script>

<template>
  <n-image show-toolbar-tooltip>
    <template #placeholder>
      <slot name="placeholder" />
    </template>
  </n-image>
</template>
