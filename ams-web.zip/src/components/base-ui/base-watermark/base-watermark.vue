<script setup lang="ts">
import type { WatermarkProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ WatermarkProps {}
defineProps<PropsType>();
</script>

<template>
  <n-watermark>
    <slot />
  </n-watermark>
</template>
