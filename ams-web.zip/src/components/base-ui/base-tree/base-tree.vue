<script setup lang="ts">
import type { TreeProps } from 'naive-ui';
import BaseIcon from '@c/base-icon.vue';

interface PropsType extends /** @vue-ignore */ TreeProps {
  // 加载
  loading: boolean;
  // 是否显示过滤
  showFilterInput?: boolean;
  // Input class
  inputClass?: string;
  // Wrapper class
  wrapperClass?: string;
}

defineOptions({ inheritAttrs: false });

withDefaults(defineProps<PropsType>(), {
  loading: false,
  showFilterInput: true,
  inputClass: undefined,
  wrapperClass: undefined
});

// 展开开关图标
const renderSwitcherIcon = () => h(BaseIcon, { icon: 'i-carbon:chevron-right', size: 14 });

// 搜索文字
const searchText = ref('');
</script>

<template>
  <div :class="wrapperClass">
    <base-input
      v-if="showFilterInput"
      v-model:value="searchText"
      class="mb w-full"
      :class="inputClass"
      :placeholder="$t('baseTree.filter')"
    />
    <base-spin :show="loading" class="tree-spin">
      <n-tree
        class="overflow-auto"
        block-line
        cascade
        key-field="id"
        checkable
        :show-irrelevant-nodes="false"
        expand-on-click
        default-expand-all
        :pattern="showFilterInput ? searchText : __"
        :render-switcher-icon="renderSwitcherIcon"
        v-bind="$attrs"
      />
    </base-spin>
  </div>
</template>

<style scoped lang="less">
.tree-spin {
  height: v-bind(
    "showFilterInput ? `calc(100% - ${light.common.heightMedium} - ${standardVars.standardSize}px)` : '100%'"
  );
  :deep(.n-spin-content) {
    height: 100%;
  }
}
</style>
