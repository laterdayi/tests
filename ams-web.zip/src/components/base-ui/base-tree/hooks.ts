export const useTree = <T>() => {
  // 选中列表
  const selectedKeys = ref<KeysType[]>([]);

  // 搜索文字
  const searchText = ref('');

  // 半选列表 keys
  const halfSelectedKeys = ref<KeysType[]>([]);

  // 半选列表 rows
  const halfSelectedRows = ref<T[]>([]) as Ref<T[]>;

  // 全选列表 keys
  const checkAllKeys = ref<KeysType[]>([]);

  // 全选列表 rows
  const checkAllRows = ref<T[]>([]) as Ref<T[]>;

  // 更新全选列表
  const updatecheckAllKeys = (val: KeysType[]) => (checkAllKeys.value = val);

  // 更新半选列表
  const updatehalfSelectedKeys = (val: KeysType[]) => (halfSelectedKeys.value = val);

  // 选中列表是否为空
  const validateListIsEmpty = (msg: string) => {
    if (!halfSelectedKeys.value.length && !checkAllKeys.value.length) {
      $message.warning(msg);
      throw msg;
    }
  };

  // 节点勾选项发生变化时的回调函数
  const handleCheck = (keys: KeysType[], options: T[]) => {
    checkAllKeys.value = keys;
    checkAllRows.value = options;
  };

  // 节点部分勾选项发生变化时的回调函数
  const handleIndeterminate = (keys: KeysType[], options: T[]) => {
    halfSelectedKeys.value = keys;
    halfSelectedRows.value = options;
  };

  // 根据条件过滤全选列表 keys
  const getFilteredCheckAllKeys = (predicate: (value: T, index: number) => boolean, key = 'id') => {
    const keys = getFilteredCheckAllRows(predicate).map((v: any) => v[key]);
    return keys;
  };
  // 根据条件过滤全选列表 row
  const getFilteredCheckAllRows = (predicate: (value: T, index: number) => boolean) => {
    const rows = toRaw(checkAllRows.value).filter((item, index) => predicate(item, index));
    return rows;
  };

  // 清空列表
  const clearSelectedList = () => (updatecheckAllKeys([]), updatehalfSelectedKeys([]));

  return {
    checkAllRows,
    getFilteredCheckAllKeys,
    getFilteredCheckAllRows,
    halfSelectedRows,
    validateListIsEmpty,
    clearSelectedList,
    updatehalfSelectedKeys,
    updatecheckAllKeys,
    selectedKeys,
    searchText,
    halfSelectedKeys,
    checkAllKeys,
    handleCheck,
    handleIndeterminate
  };
};
