# useTree Hooks

## Return

| Name                   | Type                       | Default     | Description                        |
| ---------------------- | -------------------------- | ----------- | ---------------------------------- |
| searchText             | `Ref<string>`              | `undefined` | 搜索文字                           |
| halfSelectedKeys       | `Ref<(string \|number)[]>` | `undefined` | 半选列表 keys                      |
| halfSelectedRows       | `Ref<T[]>`                 | `undefined` | 半选列表 Rows                      |
| checkAllKeys           | `Ref<(string \|number)[]>` | `undefined` | 全选列表 Keys                      |
| checkAllRows           | `Ref<T[]>`                 | `undefined` | 全选列表 Rows                      |
| updatehalfSelectedKeys | `(val: T[]) => T[]`        | `undefined` | 更新半选列表                       |
| updatecheckAllKeys     | `(val: T[]) => T[]`        | `undefined` | 更新全选列表                       |
| handleCheck            | `(keys: T[]) => T[]`       | `undefined` | 节点勾选项发生变化时的回调函数     |
| handleIndeterminate    | `(keys: T[]) => T[]`       | `undefined` | 节点部分勾选项发生变化时的回调函数 |
| clearSelectedList      | `() => void`               | `undefined` | 清空列表                           |
