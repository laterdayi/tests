<script setup lang="ts">
import type { SwitchProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ SwitchProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-switch>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-switch>
</template>
