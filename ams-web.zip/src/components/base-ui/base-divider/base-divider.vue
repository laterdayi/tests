<script setup lang="ts">
import type { DividerProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ DividerProps {}
defineProps<PropsType>();
</script>

<template>
  <n-divider>
    <slot />
  </n-divider>
</template>
