<script setup lang="ts">
import type { CalendarProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CalendarProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-calendar>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-calendar>
</template>
