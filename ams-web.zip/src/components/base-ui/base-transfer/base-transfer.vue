<script setup lang="ts">
import type { TransferProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TransferProps {}
defineProps<PropsType>();
</script>

<template>
  <n-transfer source-filterable />
</template>
