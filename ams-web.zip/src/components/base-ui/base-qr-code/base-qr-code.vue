<script setup lang="ts">
import type { QrCodeProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ QrCodeProps {}
const props = withDefaults(defineProps<PropsType>(), {});
</script>

<template>
  <n-qr-code :size="props.size ?? QRCODE_SIZE" />
</template>
