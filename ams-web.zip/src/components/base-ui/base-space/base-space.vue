<script setup lang="ts">
import type { SpaceProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ SpaceProps {}
defineProps<PropsType>();
</script>

<template>
  <n-space>
    <slot />
  </n-space>
</template>
