<script setup lang="ts">
import type { ListProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ListProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-list>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-list>
</template>
