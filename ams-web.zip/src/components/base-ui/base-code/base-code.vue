<template>
  <n-code />
</template>
