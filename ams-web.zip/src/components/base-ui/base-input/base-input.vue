<script setup lang="ts">
import type { InputProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ InputProps {
  // Class
  class?: string | string[]
  // 类型
  type?: InputProps['type']
  // 值
  value?: InputProps['value']
  // 禁用
  disabled?: InputProps['disabled']
  // 是否过滤空格
  replaceSpace?: boolean
  // 表单类型
  formType?: FormType
  // 表单标签
  label?: string
}

const props = withDefaults(defineProps<PropsType>(), {
  class: undefined,
  type: 'text',
  value: undefined,
  replaceSpace: true,
  formType: undefined,
  label: undefined,
  disabled: false
});

const emit = defineEmits<{
  'update:value': [val: string]
}>();

const slots = useSlots();

// 去除所有空格
const handleInput = (val: string) => {
  emit(
    'update:value',
    props.type === 'textarea' || !props.replaceSpace || props.formType === 'query' ? val : val.replace(/\s*/g, '')
  );
};
</script>

<template>
  <n-input
    class="min-component-width!"
    clearable
    :type="type"
    :disabled="disabled"
    :placeholder="disabled ? '' : `${$t('baseForm.pleaseInput')}${label ?? ''}`"
    :class="props.class"
    :value="value"
    @input="handleInput"
  >
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-input>
</template>
