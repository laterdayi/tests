<script setup lang="ts">
import type { TooltipProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TooltipProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-tooltip scrollable :class="[`max-w-${TOOLTIP_MAX_WIDTH}`, `max-h-${TOOLTIP_MAX_HEIGHT}`]">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-tooltip>
</template>
