<script setup lang="ts">
import type { MentionProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ MentionProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-mention>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-mention>
</template>
