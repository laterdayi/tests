<script setup lang="ts">
import type { PopselectProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ PopselectProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-popselect trigger="hover">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-popselect>
</template>
