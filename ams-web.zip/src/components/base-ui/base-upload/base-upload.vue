<script setup lang="ts">
import type { UploadProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ UploadProps {
  // Class
  class?: string | string[];
  // Loading
  loading?: boolean;
  // 按钮名称
  buttonName?: string;
  // 拖拽上传
  directoryDnd?: UploadProps['directoryDnd'];
  // 最大值
  max?: UploadProps['max'];
  // 文件列表的内建样式
  listType?: UploadProps['listType'];
}
const props = withDefaults(defineProps<PropsType>(), {
  class: undefined,
  loading: false,
  buttonName: undefined,
  directoryDnd: false,
  max: 1,
  listType: undefined
});
</script>

<template>
  <n-upload :class="props.class" :max="max" :list-type="listType">
    <n-upload-dragger v-if="directoryDnd">
      <div>
        <base-icon icon="i-carbon:folder-details-reference" :size="36" color="gray" />
        <div>{{ $t('uploadHint') }}</div>
      </div>
    </n-upload-dragger>
    <base-button
      v-else-if="listType !== 'image-card'"
      :button-name="buttonName ?? 'uploadFile'"
      :disabled="loading"
      :loading="loading"
      type="primary"
    >
      <template #icon>
        <base-icon icon="i-carbon:document-import" />
      </template>
      <slot>
        {{ $t('uploadFile') }}
      </slot>
    </base-button>
  </n-upload>
</template>
