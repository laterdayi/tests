import type { UploadCustomRequestOptions, UploadFileInfo } from 'naive-ui';

export interface AstrictFileType {
  rule: string | string[]
  error: string
}
type UploadErrorType = { index: number; msgCode: number };
type UploadResponseType = number | UploadErrorType[];

export const ASTRICT_IMG_RULE = {
  rule: ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml', 'image/x-icon'],
  error: i18nt('uploadFileTips.astrictImgHint')
};
export const ASTRICT_XLSX_RULE = {
  rule: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  error: i18nt('uploadFileTips.astrictXlsxHint')
};
export const ASTRICT_APK_RULE = {
  rule: 'application/vnd.android.package-archive',
  error: i18nt('uploadFileTips.astrictAPKHint')
};

export const ASTRICT_PDF_RULE = {
  rule: ['application/pdf'],
  error: i18nt('uploadFileTips.astrictPDFHint')
};
export const ASTRICT_VIDEO_RULE = {
  rule: ['video/mp4'],
  error: i18nt('uploadFileTips.astrictVideoHint')
};

export const useUpload = ({
  // 限制文件类型
  astrictFileType,
  // 限制文件大小
  astrictFileSize = 10,
  // 表单数据
  formData,
  // 表单对应model
  model,
  // 成功
  onFinished,
  // 失败
  onErrored,
  // 移除
  onRemoved,
  // 失败时是否清空文件列表
  clearFileList,
  // 默认文件列表
  defaultFileList
}: {
  astrictFileType?: AstrictFileType
  astrictFileSize?: number
  formData?: MaybeRef<any>
  model?: string
  onFinished?: ({ data, file }: { data: any; file: UploadFileInfo }) => Promise<void | undefined> | undefined | void
  onErrored?: () => Promise<void | undefined> | undefined | void
  onRemoved?: () => Promise<void | undefined> | undefined | void
  clearFileList?: boolean
  defaultFileList?: UploadFileInfo[]
}) => {
  const { execute, isLoading: isLoadingUpload, data, response, error } = useAxiosPost<UploadResponseType>();

  // 文件列表
  const fileList = ref<UploadFileInfo[]>(defaultFileList ?? []);

  // 组件状态变化的回调，组件的任何文件状态变化都会触发回调
  const handleUploadChange = (options: { file: UploadFileInfo; fileList: UploadFileInfo[]; event?: Event }) => {
    fileList.value = options.fileList;
  };

  // 上传前请验证文件格式
  const beforeUpload = ({ file }: { file: UploadFileInfo; fileList: UploadFileInfo[] }) => {
    if (!astrictFileType) return true;
    if (!astrictFileType?.rule.includes(file.type ?? '')) {
      $message.warning(astrictFileType?.error ?? i18nt('uploadFileTips.validateFail'));
      return false;
    }
    const fileSize = parseFloat(((file.file?.size ?? 0) / 1024 / 1024).toFixed(1));
    if (fileSize > astrictFileSize) {
      $message.warning(i18nt('uploadFileTips.astrictFileSizeHint', { val: astrictFileSize }));
      return false;
    }
    return true;
  };

  // 上传完成
  const onFinish = ({ file }: { file: UploadFileInfo }) => {
    if (formData && model) {
      // 表单字段赋值
      isRef(formData) ? ((formData.value as any)[model] = data.value) : (toRaw(formData)[model] = data.value);
    }
    onFinished?.({ data: data.value, file });
    if (clearFileList) handleClearFileList();
    return file;
  };

  // 上传失败
  const onError = () => {
    if (clearFileList) handleClearFileList();
    onErrored?.();
  };

  // 删除
  const onRemove = () => {
    isRef(formData) ? ((formData.value as any)[model ?? ''] = null) : (toRaw(formData)[model ?? ''] = null);
    onRemoved?.();
  };

  // 清空列表
  const handleClearFileList = () => nextTick(() => (fileList.value = []));

  // 自定义上传
  const customRequest = async ({
    file,
    action,
    onFinish: finish,
    onError: error,
    onProgress
  }: UploadCustomRequestOptions) => {
    try {
      const params = new FormData();
      params.append('file', file.file ?? '');
      if (file.type === ASTRICT_XLSX_RULE.rule) {
        const appStore = useAppStore();
        params.append('language', `${appStore.local === LOCAL_DEFAULT ? 0 : 1}`);
      }
      await execute(action, {
        data: params,
        onUploadProgress: ({ loaded, total }) => {
          onProgress({ percent: Math.ceil((loaded / (total ?? 0)) * 100) });
        }
      });
      finish();
    } catch (err) {
      console.log('文件上传异常：', err);
      error();
    }
  };

  return {
    handleUploadChange,
    fileList,
    clearFileList,
    customRequest,
    beforeUpload,
    isLoadingUpload,
    handleClearFileList,
    error,
    data,
    response,
    onRemove,
    onFinish,
    onError
  };
};
