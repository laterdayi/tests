<template>
  <n-equation />
</template>
