<script setup lang="ts">
import type { EllipsisProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ EllipsisProps {}
defineProps<PropsType>();
const slots = useSlots();
</script>

<template>
  <n-ellipsis :tooltip="TOOLTIP.tooltip">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-ellipsis>
</template>
