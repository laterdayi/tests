<script setup lang="ts">
import type { TreeSelectProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TreeSelectProps {
  // 表单标签
  label?: string
}
defineProps<PropsType>();
const slots = useSlots();
</script>

<template>
  <n-tree-select
    class="min-component-width!"
    clearable
    filterable
    max-tag-count="responsive"
    :placeholder="`${$t('baseForm.pleaseSelect')}${label ?? ''}`"
  >
    <template v-for="slot in Object.keys(slots)" #[slot]> <slot :name="slot" /> </template>
  </n-tree-select>
</template>
