<script setup lang="tsx">
// @ts-nocheck

import type { EmptyProps } from 'naive-ui';

interface PropsType {
  // 是否展示描述信息
  showDescription?: EmptyProps['showDescription'];
  // 是否展示图标
  showIcon?: EmptyProps['showIcon'];
  // 尺寸
  size?: EmptyProps['size'];
  // 描述
  description?: EmptyProps['description'];
}

const props = withDefaults(defineProps<PropsType>(), {
  size: 'medium',
  showDescription: true,
  showIcon: true,
  description: i18nt('noData')
});

const appStore = useAppStore();
const { themePrimary } = storeToRefs(appStore);

const fontSize = { small: 14, medium: 18, large: 20, huge: 22 };
const imgSize = { small: 200, medium: 200, large: 200, huge: 200 };

const assistColor = computed(() => {
  const { r, g, b } = hexToRgb(themePrimary.value);
  return `rgb(${r + 38}, ${g + 29}, ${b + 15})`;
});

// 线
const linePathStyle = 'stroke: #ffffff; stroke-width: 2; stroke-opacity: 1; stroke-dasharray: 0 0';
// Close
const closePathStyle = 'stroke: #ffffff; stroke-width: 4; stroke-opacity: 1; stroke-dasharray: 0 0';
// 圆
const circlePathStyle = 'stroke: #181818; stroke-width: 1; stroke-opacity: 1; stroke-dasharray: 0 0';

const renderIcon = () => {
  return (
    <>
      <svg
        fill="none"
        viewBox={`0 0 ${imgSize[props.size]} 150`}
        width={imgSize[props.size]}
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
      >
        <defs>
          <path d="M0,60L88,60L88,0L0,0L0,60Z" id="path_0" transform="translate(0 0) rotate(0 44 30)" />
          <filter
            color-interpolation-filters="sRGB"
            filterUnits="userSpaceOnUse"
            height="104"
            id="filter_13"
            width="44"
            x="0"
            y="0"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feGaussianBlur result="effect1_foregroundBlur" stdDeviation="25" />
          </filter>
          <filter
            color-interpolation-filters="sRGB"
            filterUnits="userSpaceOnUse"
            height="44"
            id="filter_15"
            width="180"
            x="0"
            y="0"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feGaussianBlur result="effect1_foregroundBlur" stdDeviation="25" />
          </filter>
          <path
            d="M40,2.31L9.89,19.69C7.41,21.12 5.89,23.76 5.89,26.62L5.89,61.38C5.89,64.24 7.41,66.88 9.89,68.31L40,85.69C42.48,87.12 45.52,87.12 48,85.69L78.11,68.31C80.59,66.88 82.11,64.24 82.11,61.38L82.11,26.62C82.11,23.76 80.59,21.12 78.11,19.69L48,2.31C45.52,0.88 42.48,0.88 40,2.31Z"
            id="path_1"
            transform="translate(0 0) rotate(0 44 44)"
          />
          <filter
            color-interpolation-filters="sRGB"
            filterUnits="userSpaceOnUse"
            height="166"
            id="filter_41"
            width="0"
            x="0"
            y="0"
          >
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
            <feGaussianBlur result="effect1_foregroundBlur" stdDeviation="3" />
          </filter>
        </defs>
        <g opacity="1" transform="translate(0 0)  rotate(0 100 70)">
          <g opacity="1" transform="translate(30 7)  rotate(0 70 60)">
            <g opacity="1" transform="translate(0 60)  rotate(0 44 30)">
              <g opacity="1" transform="translate(0 0)  rotate(0 44 30)">
                <mask fill="white" id="mask-0">
                  <use xlink:href="#path_0" />
                </mask>
                <g mask="url(#mask-0)">
                  <path
                    d="M0,60L88,60L88,0L0,0L0,60Z "
                    fill-rule="evenodd"
                    id="Rectangle 4232"
                    opacity="1"
                    style={{ fill: '#97a3b7' }}
                    transform="translate(0 0)  rotate(0 44 30)"
                  />
                </g>
                <g mask="url(#mask-0)">
                  <g filter="url(#filter_13)" id="Rectangle 4227">
                    <path
                      d="M0,60L80,60L80,0L0,0L0,60Z "
                      fill-rule="evenodd"
                      id="Rectangle 4227"
                      opacity="1"
                      style={{ fill: '#e3e6eb' }}
                      transform="translate(-18 22)  rotate(0 40 30)"
                    />
                  </g>
                </g>
                <g mask="url(#mask-0)">
                  <g filter="url(#filter_15)" id="Rectangle 4228">
                    <path
                      d="M0,60L80,60L80,0L0,0L0,60Z "
                      fill-rule="evenodd"
                      id="Rectangle 4228"
                      opacity="1"
                      style={{ fill: '#e3e6eb' }}
                      transform="translate(50 -8)  rotate(0 40 30)"
                    />
                  </g>
                </g>
              </g>
              <g opacity="1" transform="translate(16 27)  rotate(0 20 8.5)">
                <path d="M0,0L18,0 " id="Vector 67" style={linePathStyle} transform="translate(0 0)  rotate(0 9 0)" />
                <path d="M0,0L40,0 " id="Vector 68" style={linePathStyle} transform="translate(0 10)  rotate(0 20 0)" />
                <path d="M0,0L40,0 " id="Vector 69" style={linePathStyle} transform="translate(0 17)  rotate(0 20 0)" />
              </g>
            </g>
            <g opacity="1" transform="translate(39 0)  rotate(0 46.5 44)">
              <g opacity="1" transform="translate(2 0)  rotate(0 44 44)">
                <g opacity="1" transform="translate(0 0)  rotate(0 44 44)">
                  <g opacity="1" transform="translate(0 0)  rotate(0 44 44)">
                    <mask fill="white" id="mask-1">
                      <use xlink:href="#path_1" />
                    </mask>
                    <g mask="url(#mask-1)">
                      <path
                        d="M40,2.31L9.89,19.69C7.41,21.12 5.89,23.76 5.89,26.62L5.89,61.38C5.89,64.24 7.41,66.88 9.89,68.31L40,85.69C42.48,87.12 45.52,87.12 48,85.69L78.11,68.31C80.59,66.88 82.11,64.24 82.11,61.38L82.11,26.62C82.11,23.76 80.59,21.12 78.11,19.69L48,2.31C45.52,0.88 42.48,0.88 40,2.31Z "
                        fill-rule="evenodd"
                        id="Polygon 6"
                        opacity="1"
                        style={{ fill: themePrimary.value }}
                        transform="translate(0 0)  rotate(0 44 44)"
                      />
                    </g>
                    <g mask="url(#mask-1)">
                      <path
                        d="M40,2.31L9.89,19.69C7.41,21.12 5.89,23.76 5.89,26.62L5.89,61.38C5.89,64.24 7.41,66.88 9.89,68.31L40,85.69C42.48,87.12 45.52,87.12 48,85.69L78.11,68.31C80.59,66.88 82.11,64.24 82.11,61.38L82.11,26.62C82.11,23.76 80.59,21.12 78.11,19.69L48,2.31C45.52,0.88 42.48,0.88 40,2.31Z "
                        fill-rule="evenodd"
                        id="Polygon 5"
                        opacity="1"
                        style={{ fill: themePrimary.value }}
                        transform="translate(0 -44)  rotate(0 44 44)"
                      />
                    </g>
                    <g mask="url(#mask-1)">
                      <path
                        d="M0,0L14.67,10.27 "
                        id="路径 2"
                        style={closePathStyle}
                        transform="translate(36 27.2)  rotate(0 7.33688756096788 5.137343977186761)"
                      />
                    </g>
                    <g mask="url(#mask-1)">
                      <path
                        d="M14.67,0L0,10.27 "
                        id="路径 3"
                        style={closePathStyle}
                        transform="translate(36 27.2)  rotate(0 7.336887560967881 5.1373439771867595)"
                      />
                    </g>
                    <g mask="url(#mask-1)">
                      <g filter="url(#filter_41)" id="Polygon 7">
                        <path
                          d="M40,2.31L9.89,19.69C7.41,21.12 5.89,23.76 5.89,26.62L5.89,61.38C5.89,64.24 7.41,66.88 9.89,68.31L40,85.69C42.48,87.12 45.52,87.12 48,85.69L78.11,68.31C80.59,66.88 82.11,64.24 82.11,61.38L82.11,26.62C82.11,23.76 80.59,21.12 78.11,19.69L48,2.31C45.52,0.88 42.48,0.88 40,2.31Z "
                          fill-rule="evenodd"
                          id="Polygon 7"
                          opacity="0.3"
                          style={{ fill: '#97a3b7' }}
                          transform="translate(-51 39)  rotate(0 44 44)"
                        />
                      </g>
                    </g>
                  </g>
                </g>
              </g>
              <path
                d="M46.74,13.2L37.5,0L0,20.5L10.84,32.59C12.1,34 14.17,34.34 15.81,33.4L46.1,16.09C46.59,15.81 46.94,15.34 47.06,14.79C47.18,14.24 47.07,13.66 46.74,13.2Z "
                fill-rule="evenodd"
                id="路径 1"
                opacity="1"
                style={{ fill: assistColor.value }}
                transform="translate(45 22)  rotate(0 23.999999999999996 17.500000000000004)"
              />
              <path
                d="M45,21.5L10,0L1.29,11.33C0.95,11.76 0.81,12.32 0.9,12.86C0.98,13.4 1.29,13.89 1.74,14.2L29.21,33.08C30.82,34.18 32.99,33.96 34.35,32.56L45,21.5Z "
                fill-rule="evenodd"
                id="路径 1"
                opacity="1"
                style={{ fill: assistColor.value }}
                transform="translate(0 21)  rotate(0 22.5 17.500000000000004)"
              />
              <path
                d="M39.25,0.25L37.5,0.5L34.55,0.92C34.18,0.97 33.83,1.09 33.51,1.27L1.68,19.06C1.48,19.17 1.38,19.4 1.43,19.62C1.49,19.85 1.69,20 1.92,20L5.5,20L41,0L39.25,0.25Z "
                fill-rule="evenodd"
                id="路径 2"
                opacity="1"
                style={{ fill: assistColor.value }}
                transform="translate(5 1)  rotate(0 20.5 10)"
              />
              <path
                d="M36.5,21L39.69,21C39.91,21 40.11,20.85 40.17,20.63C40.23,20.41 40.13,20.18 39.94,20.07L8.52,1.31C8.18,1.1 7.8,0.97 7.4,0.91L4.5,0.5L2.75,0.25L0,0L36.5,21Z "
                fill-rule="evenodd"
                id="路径 2"
                opacity="1"
                style={{ fill: assistColor.value }}
                transform="translate(46 1)  rotate(0 20.750000000000004 10.5)"
              />
            </g>
            <g opacity="1" transform="translate(96 66)  rotate(0 22 22)">
              <path
                d="M22,44C34.15,44 44,34.15 44,22C44,9.85 34.15,0 22,0C9.85,0 0,9.85 0,22C0,34.15 9.85,44 22,44Z "
                fill-rule="evenodd"
                id="Ellipse 1"
                opacity="1"
                style={{ fill: '#fff' }}
                transform="translate(0 0)  rotate(360 22 22)"
              />
              <path
                d="M22,44C34.15,44 44,34.15 44,22C44,9.85 34.15,0 22,0C9.85,0 0,9.85 0,22C0,34.15 9.85,44 22,44Z "
                id="Ellipse 1"
                style={circlePathStyle}
                transform="translate(0 0)  rotate(360 22 22)"
              />
              <rect
                height="2"
                id="Rectangle 5"
                rx="0"
                style={{ stroke: '#181818', strokeWidth: '2', strokeDasharray: '0 0' }}
                transform="translate(22 31) rotate(0 0 0)"
                width="0"
                x="1"
                y="1"
              />
            </g>
          </g>
        </g>
      </svg>
    </>
  );
};
</script>

<template>
  <div class="text-center">
    <renderIcon v-if="props.showIcon" />
    <p v-if="props.showDescription" class="m-0 text-gray" :style="{ fontSize: `${fontSize[props.size]}px` }">
      {{ props.description }}
    </p>
  </div>
</template>
