<script setup lang="ts">
import type { DialogProps, ModalProps } from 'naive-ui';

export interface ModalPropsType extends /** @vue-ignore */ ModalProps {
  // 预设
  preset?: ModalProps['preset']
  // 显示icon
  showIcon?: DialogProps['showIcon']
  // 隐藏操作按钮
  hideActionButton?: boolean
  // 内部滚动
  insideScroll?: boolean
}

withDefaults(defineProps<ModalPropsType>(), {
  preset: 'dialog',
  insideScroll: true,
  hideActionButton: false,
  showIcon: false
});

const emit = defineEmits<{
  close: []
}>();

const slots = useSlots();
</script>

<template>
  <n-modal
    :show-icon="showIcon"
    class="base-modal w-1/2!"
    :auto-focus="false"
    :mask-closable="false"
    :preset="preset"
    :negative-button-props="{ size: 'medium' }"
    :positive-button-props="{ size: 'medium' }"
    :positive-text="hideActionButton ? __ : $t('confirm')"
    :negative-text="hideActionButton ? __ : $t('cancel')"
    @esc="emit('close')"
    @close="emit('close')"
  >
    <template v-for="slot in Object.keys(slots)" #[slot] :key="slot">
      <template v-if="slot === 'default'">
        <div
          class="overflow-auto p-t-2px"
          :class="[{ 'max-h-70vh!': insideScroll }, `pr-${standardVars.dialogPaddingRight}`]"
        >
          <slot name="default" />
        </div>
      </template>
      <slot v-else :name="slot" />
    </template>
  </n-modal>
</template>
