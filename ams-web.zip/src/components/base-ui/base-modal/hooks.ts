export const useModal = () => {
  // 显示
  const showModal = ref(false);

  // 打开
  const openModal = () => {
    showModal.value = true;
  };

  // 关闭
  const closeModal = () => {
    showModal.value = false;
  };

  return {
    showModal,
    closeModal,
    openModal
  };
};
