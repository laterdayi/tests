<script setup lang="ts">
import type { CheckboxGroupProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CheckboxGroupProps {}
defineProps<PropsType>();
</script>

<template>
  <n-checkbox-group>
    <slot />
  </n-checkbox-group>
</template>
