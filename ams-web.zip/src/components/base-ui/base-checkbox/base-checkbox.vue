<script setup lang="ts">
import type { CheckboxProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CheckboxProps {}
defineProps<PropsType>();
</script>

<template>
  <n-checkbox>
    <slot />
  </n-checkbox>
</template>
