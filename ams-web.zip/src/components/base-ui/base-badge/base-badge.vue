<script setup lang="ts">
import type { BadgeProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ BadgeProps {}
defineProps<PropsType>();
</script>

<template>
  <n-badge>
    <slot />
  </n-badge>
</template>
