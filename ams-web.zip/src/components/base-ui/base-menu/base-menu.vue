<script setup lang="ts">
import type { MenuProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ MenuProps {}
defineProps<PropsType>();
</script>

<template>
  <n-menu
    :collapsed-width="standardVars.menuCollapsedWidth"
    :watch-props="['defaultValue', 'defaultExpandedKeys']"
    :indent="standardVars.menuIndent"
    accordion
  />
</template>
