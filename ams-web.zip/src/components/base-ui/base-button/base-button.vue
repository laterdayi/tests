<script setup lang="ts">
import type { ButtonProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ButtonProps {
  // 按钮名称
  buttonName?: string;
  // 是否上报统计
  shouldRecord?: boolean;
}

withDefaults(defineProps<PropsType>(), {
  shouldRecord: false,
  buttonName: undefined
});

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);
const slots = useSlots();
</script>

<template>
  <n-button :size="componentSize">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-button>
</template>
