<script setup lang="ts">
import type { CollapseTransitionProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CollapseTransitionProps {}
defineProps<PropsType>();
</script>

<template>
  <n-collapse-transition>
    <slot />
  </n-collapse-transition>
</template>
