<script setup lang="ts">
import type { ProgressProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ProgressProps {}
defineProps<PropsType>();
</script>

<template>
  <n-progress>
    <slot />
  </n-progress>
</template>
