<script setup lang="ts">
import type { RadioProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ RadioProps {}
defineProps<PropsType>();
</script>

<template>
  <n-radio />
</template>
