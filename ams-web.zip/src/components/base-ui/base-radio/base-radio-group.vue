<script setup lang="ts">
import type { RadioGroupProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ RadioGroupProps {}
defineProps<PropsType>();
</script>

<template>
  <n-radio-group>
    <slot />
  </n-radio-group>
</template>
