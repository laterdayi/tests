import type { DataTableSortState } from 'naive-ui/es/data-table';
import type { InternalRowData, RowData } from 'naive-ui/es/data-table/src/interface';
import type { PaginationProps } from 'naive-ui';
import { pageSizeOption } from '@/layout/aside/layout-setting/constants';

const appStore = useAppStore();

export const useTable = <T = never>(
  api: (string | undefined) & NeverIfNever<T>,
  {
    refactorFormQueryParams,
    queryFormParams,
    tableShallowRef,
    refactorTableData,
    paramsSerializerQuery,
    remote = true
  }: {
    queryFormParams?: Ref<any>;
    refactorFormQueryParams?: (data: any) => any;
    tableShallowRef?: boolean;
    refactorTableData?: (data: T) => T;
    paramsSerializerQuery?: boolean;
    remote?: boolean;
  } = {}
) => {
  const tableRef = ref<TableRefType<T> | null | undefined>(null);

  const sortOrder = ref<SortOrderType>({
    sortName: undefined,
    sort: undefined
  });

  // 监听appStore变化
  watch(
    () => appStore.pageSize,
    val => {
      pagination.value.pageSize = val;
      remote && executeQueryList();
    }
  );

  const mergedQueryFormData = computed(() => ({
    ...queryFormParams?.value,
    ...sortOrder.value,
    page: pagination.value.page,
    size: pagination.value.pageSize
  }));

  // 请求列表
  const sourceTableData = tableShallowRef ? shallowRef<T>() : ref<T>();

  const tableData = tableShallowRef ? shallowRef<T>() : ref<T>();

  const {
    isLoading: isLoadingQuery,
    execute: executeQuery,
    response,
    error
  } = useAxiosGet<any>(api ?? '', __, __, { shallow: tableShallowRef });

  const executeQueryList = async () => {
    try {
      let params = { ...mergedQueryFormData.value };
      if (refactorFormQueryParams) params = refactorFormQueryParams?.(params) ?? params;
      const { data } = await executeQuery(__, {
        params: useOmitNilRequestParams(params),
        paramsSerializer: paramsSerializerQuery ? useParamsSerializer() : __
      });
      sourceTableData.value = data.value;
      let _taleData = data.value;
      if (refactorTableData) _taleData = refactorTableData?.(data.value);
      tableData.value = _taleData;
    } catch (error) {
      console.log('查询列表异常：', error);
    }
  };

  // 总数
  const total = ref<number | undefined>(0);
  watch(
    () => response.value,
    val => {
      total.value = val?.total;
      pagination.value.itemCount = val?.total;
    }
  );

  // 分页
  const pagination = ref<PaginationProps>({
    page: 1,
    pageSize: appStore.pageSize,
    itemCount: 0,
    showSizePicker: true,
    showQuickJumper: true,
    displayOrder: ['size-picker', 'pages', 'quick-jumper'],
    prefix: () => `${i18nt('baseTable.total')} ${total.value || 0} ${i18nt('baseTable.strip')}`,
    pageSizes: pageSizeOption.map((item: { label: string; value: number }) => {
      return {
        label: item.label,
        value: item.value
      };
    }),
    'onUpdate:page': (page: number) => {
      pagination.value.page = page;
      tableRef.value?.clearSelected();
      remote && executeQueryList();
    },
    'onUpdate:pageSize': (pageSize: number) => {
      pagination.value.pageSize = pageSize;
      pagination.value.page = 1;
      tableRef.value?.clearSelected();
      remote && executeQueryList();
    }
  }) as Ref<PaginationProps>;

  // 排序
  const handleSorterChange = (options: DataTableSortState | null) => {
    if (options) {
      pagination.value.page = 1;
      sortOrder.value.sortName = options.order !== false ? options.columnKey : __;
      sortOrder.value.sort = options.order !== false ? options.order : __;
      executeQueryList();
    }
  };

  // 清除排序
  const handleClearSorter = () => {
    [sortOrder.value.sortName, sortOrder.value.sort] = [__, __];
    tableRef?.value?.tableRef?.clearSorter();
  };

  // 重置表格分页 > pageSize
  const handleResetPageSize = () => (pagination.value.page = 1);

  // 重置表格分页
  const handleResetPagination = () => {
    pagination.value.page = 1;
    pagination.value.pageSize = appStore.pageSize;
    total.value = 0;
  };

  // 重置表格分页, 排序, 表格数据
  const handleReset = () => {
    handleResetPagination();
    handleClearSorter();
    tableData.value = undefined;
    sourceTableData.value = undefined;
  };

  return {
    handleResetPagination,
    handleResetPageSize,
    handleClearSorter,
    handleSorterChange,
    handleReset,
    sourceTableData,
    tableData,
    isLoadingQuery,
    total,
    pagination,
    error,
    response,
    mergedQueryFormData,
    sortOrder,
    executeQueryList,
    executeQuery,
    tableRef
  };
};

// 表格选中
export const useTableSelection = (keyField: string) => {
  // 选中数据key列表
  const selectedKeys = ref<MixedArray>([]);

  // 选中数据列表
  const selectedRows = ref<object[]>([]);

  // row-key
  const rowKey = (row: RowData) => row[keyField];

  // checked-row-keys 值改变时触发的回调函数
  const handleCheckedChange = (keys: MixedArray, rows: object[]) => {
    selectedKeys.value = keys;
    selectedRows.value = rows;
  };
  // 清空多选
  const clearSelected = () => {
    selectedKeys.value = [];
    selectedRows.value = [];
  };

  return {
    selectedKeys,
    clearSelected,
    selectedRows,
    rowKey,
    handleCheckedChange
  };
};

// 表格筛选列
export const useFilterColumn = (columns: Ref<DataTableColumns<any>>) => {
  const routeStore = useRouteStore();
  const route = useRoute();

  // 忽略列类型
  const ignoreTypes = ['selection', 'expand'];
  // 筛选列
  const filterColumns = ref<any[]>([]);

  watch(
    () => columns.value,
    val => {
      if (!window.$CONFIG?.projectConfig?.tableFilterColumnCache) {
        filterColumns.value = val.map(item => ({ show: true, ...item }));
      } else {
        const keys = routeStore.filteredColumnKeys[route.name as string];
        filterColumns.value = val.map(item => ({
          show: keys?.length ? !keys.includes((item as any).key) : true,
          ...item
        }));
      }
    },
    {
      immediate: true
    }
  );

  // 最终表格项
  const tableColumns = computed(() => {
    const arr: DataTableColumns<InternalRowData> = [];
    for (let i = 0; i < filterColumns.value.length; i++) {
      const { show, ...otherParams } = filterColumns.value[i];
      if (show) {
        if (filterColumns.value[i].type === 'selection') {
          arr.push({ ...otherParams, width: 45 });
        } else {
          arr.push({
            resizable: true,
            ellipsis: TOOLTIP,
            minWidth: 50,
            ...otherParams
          });
        }
      }
    }
    return arr;
  });

  return {
    tableColumns,
    filterColumns,
    ignoreTypes
  };
};
