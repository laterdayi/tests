import type { DataTableInst, PaginationProps } from 'naive-ui';
import type { ColumnKey } from 'naive-ui/es/data-table/src/interface';

declare global {
  // 表格模板引用
  interface TableRefType<T> {
    selectedKeys: MixedArray
    selectedRows: T
    clearSelected: () => void
    tableRef: DataTableInst | null
  }

  // 分页
  interface SortOrderType {
    sortName?: ColumnKey
    sort?: SortOrder
  }

  // 查询表单参数
  type MergedQueryFormDataType<T = any> = T &
    SortOrderType & { page: PaginationProps['page']; size: PaginationProps['pageSize'] };
}
