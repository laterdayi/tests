<script setup lang="ts">
import type { DataTableColumns, DataTableInst, DataTableProps } from 'naive-ui';

export interface PropsType extends /** @vue-ignore */ DataTableProps {
  // 列
  columns: DataTableColumns<any>;
  // 顶层容器 Class
  containerClass?: string;
  // 是否显示筛选列
  showFilterColumn?: boolean;
}

defineOptions({ inheritAttrs: false });

const props = withDefaults(defineProps<PropsType>(), {
  containerClass: undefined,
  showFilterColumn: true
});

const route = useRoute();
const routeStore = useRouteStore();
const slots = useSlots();
const $CONFIG = window.$CONFIG;

const columnsRef = toRef(props, 'columns');

// 筛选列
const { filterColumns, ignoreTypes, tableColumns } = useFilterColumn(columnsRef);

// 多选
const { selectedKeys, clearSelected, selectedRows, handleCheckedChange, rowKey } = useTableSelection('id');

// 筛选列缓存
const handleFilteredColumnChange = () => {
  const columns = filterColumns.value.filter((item: any) => !item.show && item.type !== 'selection').map(v => v.key);
  if (route.name) routeStore.setFilteredColumnKeys(route.name as string, columns);
};

const tableRef = ref<DataTableInst | null>(null);

defineExpose({ selectedRows, selectedKeys, clearSelected, tableRef });
</script>

<template>
  <div class="base-table w-full" :class="[props.containerClass]">
    <!-- 头部 -->
    <div class="base-table-header flex justify-between">
      <div class="flex-1 header-area mr">
        <slot name="header" />
      </div>
      <!-- 筛选列 -->
      <n-popover v-if="filterColumns.length && props.showFilterColumn" placement="bottom" trigger="click">
        <template #trigger>
          <base-button circle size="small" button-name="baseTable.filterColumn">
            <base-icon icon="i-carbon:data-1" :size="16" />
          </base-button>
        </template>
        <template #header> {{ $t('baseTable.filterColumn') }} </template>
        <div class="flex flex-col">
          <template v-for="item in filterColumns" :key="item.key">
            <n-checkbox
              v-if="!ignoreTypes.includes(item.type)"
              v-model:checked="item.show"
              :value="item.key"
              :label="item.title"
              @update:checked="$CONFIG?.projectConfig?.tableFilterColumnCache ? handleFilteredColumnChange() : __"
            />
          </template>
        </div>
      </n-popover>
    </div>

    <div v-if="slots.center" class="my">
      <slot name="center" />
    </div>
    <!-- 主体 -->
    <n-data-table
      ref="tableRef"
      row-class-name="table-row-class"
      :columns="tableColumns"
      :row-key="rowKey"
      size="small"
      :single-line="false"
      v-bind="$attrs"
      :checked-row-keys="selectedKeys"
      class="base-table"
      @update:checked-row-keys="handleCheckedChange"
    >
      <template #empty> <base-empty /></template>
    </n-data-table>
  </div>
</template>

<style lang="less" scoped>
.base-table {
  &-header {
    margin: var(--margin) 0;
  }
}
</style>
