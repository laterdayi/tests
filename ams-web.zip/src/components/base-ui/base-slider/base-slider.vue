<script setup lang="ts">
import type { SliderProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ SliderProps {}
defineProps<PropsType>();
</script>

<template>
  <n-slider>
    <template #thumb>
      <slot name="thumb" />
    </template>
  </n-slider>
</template>
