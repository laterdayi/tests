<script setup lang="ts">
import type { ResultProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ResultProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-result trigger="hover">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-result>
</template>
