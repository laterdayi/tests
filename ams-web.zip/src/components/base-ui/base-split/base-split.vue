<script setup lang="ts">
import type { SplitProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ SplitProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-split>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-split>
</template>
