<script setup lang="ts">
import type { AvatarProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AvatarProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-avatar>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-avatar>
</template>
