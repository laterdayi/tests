<script setup lang="ts">
import type { AvatarGroupProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AvatarGroupProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-avatar-group expand-on-hover>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-avatar-group>
</template>
