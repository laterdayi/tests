<script setup lang="ts">
import type { AutoCompleteProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AutoCompleteProps {}
defineProps<PropsType>();
const slots = useSlots();
</script>

<template>
  <n-auto-complete>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-auto-complete>
</template>
