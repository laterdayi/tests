<script setup lang="ts">
import type { AffixProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AffixProps {}
defineProps<PropsType>();
</script>

<template>
  <n-affix>
    <slot />
  </n-affix>
</template>
