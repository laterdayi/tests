<script setup lang="ts">
import type { AlertProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ AlertProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-alert>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-alert>
</template>
