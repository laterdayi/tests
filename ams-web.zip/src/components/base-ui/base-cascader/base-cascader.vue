<script setup lang="ts">
import type { CalendarProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CalendarProps {
  // 表单标签
  label?: string
}
defineProps<PropsType>();
</script>

<template>
  <n-cascader :placeholder="`${$t('baseForm.pleaseSelect')}${label ?? ''}`" />
</template>
