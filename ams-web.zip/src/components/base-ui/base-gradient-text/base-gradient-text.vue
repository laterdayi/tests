<script setup lang="ts">
import type { GradientTextProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ GradientTextProps {}
defineProps<PropsType>();
</script>

<template>
  <n-gradient-text>
    <slot />
  </n-gradient-text>
</template>
