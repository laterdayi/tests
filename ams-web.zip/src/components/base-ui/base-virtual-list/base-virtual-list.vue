<script setup lang="ts">
import type { VirtualListProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ VirtualListProps {}

const props = withDefaults(defineProps<PropsType>(), {
  itemSize: 24
});
</script>

<template>
  <n-virtual-list :item-size="props.itemSize" />
</template>
