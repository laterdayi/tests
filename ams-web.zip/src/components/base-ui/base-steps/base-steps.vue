<script setup lang="ts">
import type { StepsProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ StepsProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-steps>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-steps>
</template>
