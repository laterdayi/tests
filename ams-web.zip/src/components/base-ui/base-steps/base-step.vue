<script setup lang="ts">
import type { StepProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ StepProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-step>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-step>
</template>
