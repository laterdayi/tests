<script setup lang="ts">
import type { DatePickerType } from 'naive-ui/es/date-picker/src/config';
import type { DefaultTime } from 'naive-ui/es/date-picker/src/interface';
import type { DatePickerProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ DatePickerProps {
  // 类型
  type?: DatePickerType
}
const props = defineProps<PropsType>();

type PickerDefaultTimeType = {
  [K in DatePickerType]: DefaultTime;
};

type PickerValueFormateType = {
  [K in DatePickerType]: string;
};

type PickerCalendarTimeType = {
  [K in DatePickerType]: number;
};

const slots = useSlots();
// -------------------------------------------------------------------------------------------- > 默认时间
const defaultTimeSets: Partial<PickerDefaultTimeType> = {
  date: 'undefined',
  datetimerange: ['00:00:00', '23:59:59']
};
const defaultTime = computed(() => {
  return defaultTimeSets[props.type ?? 'date'];
});

// -------------------------------------------------------------------------------------------- > valueFormat
const valueFormatMap: Partial<PickerValueFormateType> = {
  date: 'yyyy-MM-dd',
  month: 'yyyy-MM',
  year: 'yyyy',
  datetimerange: 'yyyy-MM-dd HH:mm:ss'
};
const valueFormat = computed(() => {
  return valueFormatMap[props.type ?? 'date'];
});

// -------------------------------------------------------------------------------------------- > 日历面板开始时间
const prevMonthStartTimestamp = +new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
const calendarStartTimeSets: Partial<PickerCalendarTimeType> = {
  daterange: prevMonthStartTimestamp,
  datetimerange: prevMonthStartTimestamp
};

// -------------------------------------------------------------------------------------------- > 日历面板结束时间
const currentMonthStartTimestamp = +new Date(new Date().getFullYear(), new Date().getMonth(), 1);
const calendarEndTimeSets: Partial<PickerCalendarTimeType> = {
  daterange: currentMonthStartTimestamp,
  datetimerange: currentMonthStartTimestamp
};

const calendarStartTime = computed(() => calendarStartTimeSets[props.type ?? 'daterange']);
const calendarEndTime = computed(() => calendarEndTimeSets[props.type ?? 'daterange']);

// -------------------------------------------------------------------------------------------- > 禁用未来时间
const disablePreviousDate = (ts: number) => ts > new Date().setHours(23, 59, 59);
</script>

<template>
  <n-date-picker
    :class="{ 'min-component-width!': !type?.includes('range') }"
    :is-date-disabled="disablePreviousDate"
    :default-time="defaultTime"
    :value-format="valueFormat"
    :default-calendar-start-time="calendarStartTime"
    :default-calendar-end-time="calendarEndTime"
    clearable
    :type="type"
  >
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-date-picker>
</template>
