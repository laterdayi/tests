<script setup lang="ts">
import type { DropdownProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ DropdownProps {}
defineProps<PropsType>();
</script>

<template>
  <n-dropdown trigger="hover" show-arrow>
    <slot />
  </n-dropdown>
</template>
