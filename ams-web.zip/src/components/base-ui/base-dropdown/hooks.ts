export const useDropdown = () => {
  // 显示
  const showDropdown = ref(false);

  // 打开
  const openDropdown = () => {
    showDropdown.value = true;
  };

  // 关闭
  const closeDropdown = () => {
    showDropdown.value = false;
  };

  return {
    showDropdown,
    closeDropdown,
    openDropdown
  };
};
