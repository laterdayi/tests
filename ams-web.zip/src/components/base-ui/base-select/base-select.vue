<script setup lang="ts">
import type { SelectProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ SelectProps {
  // 禁用
  disabled?: SelectProps['disabled']
  // 表单标签
  label?: string
  // 是否可以过滤
  filterable?: SelectProps['filterable']
}

withDefaults(defineProps<PropsType>(), {
  disabled: false,
  label: undefined,
  filterable: true
});

const slots = useSlots();
</script>

<template>
  <n-select
    class="min-component-width!"
    clearable
    :disabled="disabled"
    :filterable="filterable"
    max-tag-count="responsive"
    :placeholder="disabled ? '' : `${$t('baseForm.pleaseSelect')}${label ?? ''}`"
  >
    <n-switch>
      <template v-for="slot in Object.keys(slots)" #[slot]>
        <slot :name="slot" />
      </template>
    </n-switch>
  </n-select>
</template>
