import type { SelectProps } from 'naive-ui';

export type FormSelectProps = Omit<SelectProps, 'options'> & {
  options?: any;
};

declare global {
  interface OptionsType {
    id: string;
    name: string;
  }
}
