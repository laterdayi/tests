<script setup lang="ts">
import type { ScrollbarInst, ScrollbarProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ ScrollbarProps {}
defineProps<PropsType>();

const scrollbarRef = ref<ScrollbarInst | null>(null);
defineExpose({ scrollbarRef });
</script>

<template>
  <n-scrollbar ref="scrollbarRef">
    <slot />
  </n-scrollbar>
</template>
