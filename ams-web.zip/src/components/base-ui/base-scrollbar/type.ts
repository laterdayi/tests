import type { ScrollbarInst } from 'naive-ui';

declare global {
  // 表格模板引用
  interface ScrollbarRefType {
    scrollbarRef: ScrollbarInst | null;
  }
}
