<script setup lang="ts">
import type { CarouselProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CarouselProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-carousel autoplay dot-type="line">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-carousel>
</template>
