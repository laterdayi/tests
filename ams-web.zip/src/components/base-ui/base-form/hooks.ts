import type { FormItemRule, FormValidationError } from 'naive-ui';
import type { UnwrapRef } from 'vue';
import type { FormInst } from 'naive-ui/es/form/src/interface';

export interface BaseFormRefType {
  baseFormRef: FormInst | null
}

/**
 * @params {*} T 原始表单数据
 * @param data
 * @return {*}
 */
export const useForm = <T = never>(data: NoInfer<T>) => {
  // 表单数据
  const formData = ref<T>({ ...(cloneDeep(data) as any) });

  // 表单模板引用
  const formRef = ref<BaseFormRefType | null>(null);

  // 重置表单验证
  const restoreValidation = () => formRef?.value?.baseFormRef?.restoreValidation();

  // 表单验证
  const validate = (
    validateCallback?: (errors?: FormValidationError[]) => void,
    shouldRuleBeApplied?: (rule: FormItemRule) => boolean
  ) => formRef?.value?.baseFormRef?.validate(validateCallback, shouldRuleBeApplied);

  // 更新表单数据
  const updateField = (fields: Partial<T> | null | undefined) => {
    if (!fields) return;
    formData.value = { ...toRaw(formData.value ?? {}), ...fields } as UnwrapRef<T>;
  };

  // 重置表单数据，并移出校验
  const resetField = () => {
    updateField(cloneDeep(data));
    restoreValidation();
  };

  /**
   * ref [] > {}
   * @param selectedList
   * @param formData
   * @description:  过滤列表选择项提供给表单
   * @return {*}
   */
  const useFilterSelectedData = <T = any, Q = any>(selectedList?: T, formData?: Q) => {
    const list = toRaw(selectedList) as unknown as object[];
    return pick(list?.at(0), Object.keys(formData ?? {})) as unknown as Q;
  };

  return {
    updateField,
    resetField,
    formData,
    formRef,
    restoreValidation,
    validate,
    useFilterSelectedData
  };
};
