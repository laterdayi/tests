import type {
  CascaderProps,
  CheckboxProps,
  ColorPickerProps,
  DatePickerProps,
  FormItemProps,
  InputNumberProps,
  InputProps,
  RadioProps,
  SliderProps,
  SwitchProps,
  TimePickerProps,
  TransferProps,
  UploadProps
} from 'naive-ui';
import type { ComputedRef, VNodeChild } from 'vue';
import type { FormSelectProps } from '../base-select/type';
import type { FormTreeSelectProps } from '../base-tree-select/type';

// v-model:***
type ModelValueType = 'formatted-value' | 'value' | 'checked';

declare global {
  // 表单类型
  type FormType = 'query' | 'edit';

  namespace BaseForm {
    namespace Schema {
      // 组件
      interface ComponentPropsType {
        input: InputProps & { replaceSpace?: boolean }
        'input-number': InputNumberProps
        switch: SwitchProps
        select: FormSelectProps
        'date-picker': DatePickerProps
        'tree-select': FormTreeSelectProps
        upload: UploadProps
        transfer: TransferProps
        'time-picker': TimePickerProps
        radio: RadioProps
        cascader: CascaderProps
        'color-picker': ColorPickerProps
        slider: SliderProps
        checkbox: CheckboxProps
      }

      interface FormItemSchemaType<T extends keyof ComponentPropsType> {
        // 组件类型
        type: T
        model?: string
        modelValue?: ModelValueType
        // 作用于 Form Item lass
        formItemClass?: string | string[]
        // Form Item Props
        formItemProps?: FormItemProps
        // Form Item 插槽
        formItemSlots?: RenderSlotType[]
        // 组件属性
        componentProps?: ComponentPropsType[T] | ComputedRef<ComponentPropsType[T]>
        // 组件插槽
        componentSlots?: RenderSlotType[]
        // 作用于组件 Class
        componentClass?: string | string[]
      }

      type CustomFormItemSchema = {
        type: 'custom-form-item'
        model?: string
        render: () => VNodeChild
        // 作用于 Form Item lass
        formItemClass?: string | string[]
        // Form Item Props
        formItemProps?: FormItemProps
        // Form Item 插槽
        formItemSlots?: RenderSlotType[]
      };

      type CustomNodeSchema = {
        type: 'custom-node'
        render: () => VNodeChild
      };

      type InputSchema = FormItemSchemaType<'input'>;
      type SelectSchema = FormItemSchemaType<'select'>;
      type DatePickerSchema = FormItemSchemaType<'date-picker'>;
      type SwitchSchema = FormItemSchemaType<'switch'>;
      type InputNumberSchema = FormItemSchemaType<'input-number'>;
      type TreeSelectSchema = FormItemSchemaType<'tree-select'>;
      type UploadSchema = FormItemSchemaType<'upload'>;
      type TransferSchema = FormItemSchemaType<'transfer'>;
      type TimePickerSchema = FormItemSchemaType<'time-picker'>;
      type RadioSchema = FormItemSchemaType<'radio'>;
      type CascaderSchema = FormItemSchemaType<'cascader'>;
      type ColorPickerSchema = FormItemSchemaType<'color-picker'>;
      type SliderSchema = FormItemSchemaType<'slider'>;
      type CheckboxSchema = FormItemSchemaType<'checkbox'>;

      type Item =
        | CustomNodeSchema
        | CustomFormItemSchema
        | SliderSchema
        | ColorPickerSchema
        | CascaderSchema
        | RadioSchema
        | InputSchema
        | InputNumberSchema
        | SwitchSchema
        | SelectSchema
        | DatePickerSchema
        | TransferSchema
        | TreeSelectSchema
        | TimePickerSchema
        | UploadSchema
        | CheckboxSchema;
    }
  }

  type FormSchemaType = (BaseForm.Schema.Item | undefined)[];
}

// schema > slot
export type RenderSlotType = {
  name?: string
  render: () => VNodeChild
};
