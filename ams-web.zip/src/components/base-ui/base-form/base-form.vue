<script lang="ts">
import type { FormInst, FormProps } from 'naive-ui';
import BaseInput from '../base-input/base-input.vue';
import BaseSelect from '../base-select/base-select.vue';
import BaseDatePicker from '../base-date-picker/base-date-picker.vue';
import BaseSwitch from '../base-switch/base-switch.vue';
import BaseInputNumber from '../base-input-number/base-input-number.vue';
import BaseTreeSelect from '../base-tree-select/base-tree-select.vue';
import BaseUpload from '../base-upload/base-upload.vue';
import BaseTransfer from '../base-transfer/base-transfer.vue';
import BaseTimePicker from '../base-time-picker/base-time-picker.vue';
import BaseRadio from '../base-radio/base-radio.vue';
import BaseCascader from '../base-cascader/base-cascader.vue';
import BaseColorPicker from '../base-color-picker/base-color-picker.vue';
import BaseSlider from '../base-slider/base-slider.vue';
import BaseCheckbox from '../base-checkbox/base-checkbox.vue';

interface PropsType extends /** @vue-ignore */ FormProps {
  // 表单类型
  type?: FormType;
  // v-model
  modelValue: any;
  // Json Schema
  schemas: FormSchemaType;
  // Label 列宽
  labelWidth?: FormProps['labelWidth'];
  // 标签的文本对齐方式
  labelAlign?: FormProps['labelAlign'];
  // 行内表单
  inline?: FormProps['inline'];
  // Label 位置
  labelPlacement?: FormProps['labelPlacement'];
  // 元素超出限制（展开收起）
  rowLimitNumber?: number;
  // 元素超出限制（grid布局）
  rowLayoutLimitNumber?: number;
  // 禁用
  disabled?: FormProps['disabled'];
  // 布局方式
  layout?: 'base' | 'page' | 'dialog';
  // 表单容器 Class
  formWrapperClass?: string;
  // 列数
  gridCols?: number;
  // 是否展示校验反馈
  showFeedback?: FormProps['showFeedback'];
}
</script>

<script setup lang="ts">
defineOptions({
  components: {
    BaseInputNumber,
    BaseInput,
    BaseSelect,
    BaseDatePicker,
    BaseSwitch,
    BaseTreeSelect,
    BaseUpload,
    BaseTransfer,
    BaseTimePicker,
    BaseRadio,
    BaseCascader,
    BaseColorPicker,
    BaseSlider,
    BaseCheckbox
  }
});
const props = withDefaults(defineProps<PropsType>(), {
  type: undefined,
  inline: undefined,
  disabled: undefined,
  formWrapperClass: undefined,
  layout: 'page',
  labelWidth: 120,
  labelAlign: 'right',
  labelPlacement: 'left',
  showFeedback: undefined,
  gridCols: 2,
  rowLimitNumber: 3,
  rowLayoutLimitNumber: 4
});

const appStore = useAppStore();
const { componentSize } = storeToRefs(appStore);

// 是否显示展开项
const formShowExpand = ref<boolean>();
const formInline = ref<boolean>();
// 是否展开
const isExpand = ref(false);

// 表单预设
watch(
  () => props.layout,
  val => {
    formShowExpand.value = val === 'page';
    formInline.value = props.inline || val === 'page';
  },
  { immediate: true }
);

const normalizeSchema = computed(() => compact(props.schemas));

// Json Schema
const formSchemas = computed<FormSchemaType>(() => {
  return formShowExpand.value
    ? isExpand.value
      ? normalizeSchema.value
      : normalizeSchema.value.slice(0, props.rowLimitNumber)
    : normalizeSchema.value;
});

const formModel = computed(() => props.modelValue);

const baseFormRef = ref<FormInst | null>(null);

// 获取自定义 Model Value 参数
const getModelValue = computed(() => {
  return (item: BaseForm.Schema.Item) =>
    item.type !== 'custom-node' && item.type !== 'custom-form-item' ? item.modelValue ?? 'value' : 'value';
});

defineExpose({ baseFormRef });
</script>

<template>
  <n-form
    ref="baseFormRef"
    :inline="formInline"
    :model="formModel"
    require-mark-placement="left"
    :label-align="labelAlign"
    :label-width="labelWidth"
    :label-placement="labelPlacement"
    :show-feedback="showFeedback ?? layout !== 'page'"
    :size="componentSize"
    v-bind="$attrs"
  >
    <!-- 表单区域 -->
    <div
      class="form-wrapper"
      :class="[
        // 页面表单
        { 'flex flex-wrap gap-y-16px mr': layout === 'page' },
        { 'flex-1': layout === 'page' && normalizeSchema?.length > rowLimitNumber },
        // 弹框表单
        {
          [`grid grid-cols-${gridCols} gap-x-8`]: layout === 'dialog' && normalizeSchema?.length > rowLayoutLimitNumber
        },
        { 'w-full': !formShowExpand },
        formWrapperClass
      ]"
    >
      <template v-for="(item, index) in formSchemas" :key="index">
        <template v-if="item">
          <!-- base - *** -->
          <n-form-item
            v-if="item.type !== 'custom-node' && item.type !== 'custom-form-item'"
            :path="item.model ?? item?.formItemProps?.path"
            v-bind="item.formItemProps"
            :class="item.formItemClass"
            :label="item.formItemProps?.label"
          >
            <!-- v-model -->
            <component
              :is="`base-${item.type}`"
              v-if="item.model"
              v-model:[getModelValue(item)]="formModel[item.model]"
              :disabled="disabled"
              :label="item.formItemProps?.label"
              v-bind="unref(item.componentProps as any)"
              :class="[{ 'w-full!': layout === 'dialog' }, item.componentClass]"
              :form-type="type"
            >
              <template v-for="slot in item.componentSlots" #[slot.name!] :key="slot.name">
                <RenderSlot :render-slot="slot" />
              </template>
            </component>

            <!-- 非 v-model -->
            <component
              :is="`base-${item.type}`"
              v-else
              :disabled="disabled"
              :label="item.formItemProps?.label"
              v-bind="unref(item.componentProps as any)"
              :form-type="type"
              :class="[{ 'w-full!': layout === 'dialog' }, item.componentClass]"
            >
              <template v-for="slot in item.componentSlots" #[slot.name!] :key="slot.name">
                <RenderSlot :render-slot="slot" />
              </template>
            </component>
            <!-- Form Item Slot -->
            <template v-for="slot in item.formItemSlots" #[slot.name!] :key="slot.name">
              <RenderSlot :render-slot="slot" />
            </template>
          </n-form-item>
          <!-- 自定义 Form Item  -->
          <n-form-item
            v-else-if="item.type === 'custom-form-item'"
            v-bind="item.formItemProps"
            :class="item.formItemClass"
            :label="item.formItemProps?.label"
            :path="item.model ?? item?.formItemProps?.path"
          >
            <RenderSlot :render-slot="item" />
            <!-- Form Item Slot -->
            <template v-for="slot in item.formItemSlots" #[slot.name!] :key="slot.name">
              <RenderSlot :render-slot="slot" />
            </template>
          </n-form-item>
          <!-- 自定义节点  -->
          <RenderSlot v-else-if="item.type === 'custom-node'" :render-slot="item" />
        </template>
      </template>
    </div>
    <!-- 查询 -->
    <div class="flex">
      <slot name="header-action" :form-ref="baseFormRef" />
      <base-button
        v-if="formShowExpand && normalizeSchema?.length > rowLimitNumber"
        :button-name="isExpand ? 'baseForm.putAway' : 'baseForm.expand'"
        quaternary
        class="ml-12px"
        @click="isExpand = !isExpand"
      >
        {{ $t(isExpand ? 'baseForm.putAway' : 'baseForm.expand') }}
        <base-icon class="ml-5px" icon="i-carbon:chevron-down" :rotate="isExpand ? '180' : '0'" />
      </base-button>
    </div>
  </n-form>
  <slot name="action" />
</template>
