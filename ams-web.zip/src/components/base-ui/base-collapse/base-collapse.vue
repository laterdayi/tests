<script setup lang="ts">
import type { CollapseProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ CollapseProps {}
defineProps<PropsType>();
const slots = useSlots();
</script>

<template>
  <n-collapse>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-collapse>
</template>
