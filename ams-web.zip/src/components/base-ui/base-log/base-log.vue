<script setup lang="ts">
import type { LogProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ LogProps {}
defineProps<PropsType>();
</script>

<template>
  <n-log />
</template>
