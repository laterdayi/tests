<script setup lang="ts">
import type { TagProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TagProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-tag v-bind="$attrs">
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-tag>
</template>
