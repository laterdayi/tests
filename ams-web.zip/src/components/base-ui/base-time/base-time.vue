<script setup lang="ts">
import type { TimeProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TimeProps {}
defineProps<PropsType>();
</script>

<template>
  <n-time />
</template>
