<script setup lang="ts">
import type { TimelineItemProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TimelineItemProps {}
defineProps<PropsType>();

const slots = useSlots();
</script>

<template>
  <n-timeline-item>
    <template v-for="slot in Object.keys(slots)" #[slot]>
      <slot :name="slot" />
    </template>
  </n-timeline-item>
</template>
