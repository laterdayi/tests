<script setup lang="ts">
import type { TimelineProps } from 'naive-ui';

interface PropsType extends /** @vue-ignore */ TimelineProps {}
defineProps<PropsType>();
</script>

<template>
  <n-timeline>
    <slot />
  </n-timeline>
</template>
