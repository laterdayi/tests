<script lang="ts">
import type { DataTableProps, FormProps, ModalProps } from 'naive-ui';
import type { ModalPropsType } from '../base-ui/base-modal/base-modal.vue';
import { EditModalEntry } from '@/constants/enum';

interface PropsType {
  // 新增Api
  createApi?: string;
  // 更新Api
  updateApi?: string;
  // 查询Api
  readApi?: string;
  // 获取编辑详情
  editDetailApi?: string;
  // 删除Api
  deleteApi?: string;
  // 导出数据Api
  exportApi?: string;
  // 下载Api
  downloadApi?: string;
  // 导入Api
  importApi?: string;
  // 是否显示分页
  showPagination?: boolean;
  // 查询表单
  queryFormParams?: any;
  // 查询表单 Schema
  queryFormSchemas?: FormSchemaType;
  // 查询表单 Props
  queryFormProps?: FormProps;
  // 查询表单容器 Class
  queryFormWrapperClass?: string;
  // 查询是否shallowRef数据
  tableShallowRef?: boolean;
  // 操作表单
  formParams?: any;
  // 表单 Schema
  formSchemas?: FormSchemaType;
  // 表单 Props
  formProps?: FormProps;
  // 表单容器 Class
  formWrapperClass?: string;
  // 需要展示的列
  columns?: DataTableColumns<any>;
  // 表格Props
  tableProps?: DataTableProps;
  // 重构查询表单参数函数
  refactorFormQueryParams?: (data: any) => object | undefined;
  // 重构编辑表单参数函数
  refactorFormEditParams?: (data: any) => object | undefined;
  // 重构新增 or 编辑表单提交参数函数
  refactorFormSubmitParams?: (data: any) => object | undefined;
  // 提交前验证
  submitValidate?: () => void;
  // 查询表单元素超出限制（展开收起）
  queryFormRowLimitNumber?: number;
  // 表单元素超出限制（展开收起）
  formRowLimitNumber?: number;
  // 模态框标题
  modalTitle?: string;
  // 模态框 Props
  modalProps?: ModalProps & ModalPropsType;
  // 重构表格数据
  refactorTableData?: (data: any) => any[];
  // 查询请求序列化
  paramsSerializerQuery?: boolean;
  // 忽略查询表单权限按钮显示
  ignoreQueryFormPermissionList?: PermissionType[];
  // 忽略表单权限按钮显示
  ignoreFormPermissionList?: PermissionType[];
  // 忽略权限按钮内置操作
  ignorePermissionActions?: PermissionType[];
  // 查询表单按钮无效条件
  queryFormPermissionDisable?: PermissionDisableType;
  // 表单无效条件
  formPermissionDisable?: PermissionDisableType;
  // 自定义权限按钮loading
  permissionButtonLoadingProps?: PermissionCustomTypeLoading;
  // 是否显示筛选列
  showFilterColumn?: boolean;
}
</script>

<script setup lang="ts">
const props = withDefaults(defineProps<PropsType>(), {
  createApi: undefined,
  updateApi: undefined,
  readApi: undefined,
  deleteApi: undefined,
  importApi: undefined,
  downloadApi: undefined,
  editDetailApi: undefined,
  exportApi: undefined,
  modalTitle: undefined,
  formParams: undefined,
  refactorFormQueryParams: undefined,
  refactorFormSubmitParams: undefined,
  queryFormRowLimitNumber: undefined,
  formRowLimitNumber: undefined,
  refactorFormEditParams: undefined,
  submitValidate: undefined,
  queryFormParams: undefined,
  paramsSerializerQuery: undefined,
  showPagination: true,
  refactorTableData: undefined,
  ignorePermissionActions: () => [],
  ignoreQueryFormPermissionList: () => [],
  ignoreFormPermissionList: () => [],
  queryFormSchemas: () => [],
  formSchemas: () => [],
  columns: () => [],
  tableShallowRef: true,
  permissionButtonLoadingProps: undefined,
  modalProps: undefined,
  queryFormPermissionDisable: undefined,
  formPermissionDisable: undefined,
  queryFormProps: undefined,
  formProps: undefined,
  queryFormWrapperClass: undefined,
  formWrapperClass: undefined,
  tableProps: undefined,
  showFilterColumn: true
});

const emit = defineEmits<{
  handle: [params?: any];
  'before-open-add-modal': [];
  'after-open-add-modal': [];
  'before-open-edit-modal': [];
  'after-open-edit-modal': [];
  'before-add': [];
  'add-success': [];
  'add-error': [];
  'before-edit': [];
  'edit-success': [];
  'edit-error': [];
  'before-delete': [];
  'delete-success': [];
  'delete-error': [];
  'before-import': [];
  'import-success': [];
  'import-error': [];
  'before-export': [];
  'export-success': [];
  'export-error': [];
  'before-download': [];
  'download-success': [];
  'download-error': [];
  'modal-closed': [];
}>();

const slots = useSlots();

// 是否编辑模式
const isEditMode = ref(false);

// 是否有编辑权限
const { hasEditPermission } = useRoutes();

// 往权限按钮注入导入api
provide('importApi', props.importApi);

// -------------------------------------------------------------------------------------------- > Modal
const { showModal, openModal, closeModal } = useModal();

// 查询表单
const { formData: queryFormData, resetField: resetQueryField } = useForm<any>({
  ...props.queryFormParams
});

// 表格
const {
  handleSorterChange,
  pagination,
  isLoadingQuery,
  mergedQueryFormData,
  sortOrder,
  tableData,
  executeQuery,
  executeQueryList,
  handleResetPageSize,
  sourceTableData,
  handleResetPagination,
  tableRef
} = useTable<any>(props.readApi ?? '', {
  queryFormParams: queryFormData,
  refactorFormQueryParams: props.refactorFormQueryParams,
  tableShallowRef: props.tableShallowRef,
  refactorTableData: props.refactorTableData,
  paramsSerializerQuery: props.paramsSerializerQuery
});

onMounted(() => props.readApi && executeQueryList());

// 编辑表单数据
const { formRef, validate, formData, updateField, resetField, useFilterSelectedData } = useForm<any>(props.formParams);

// 更新行数据
const handleUpdateRow = (updater: (tableData: unknown) => void) => updater(tableData.value);

// 新增
const handleAdd = () => {
  emit('before-open-add-modal');
  isEditMode.value = false;
  openModal();
  emit('after-open-add-modal');
};

const useModalTitle = computed(() => {
  return !isEditMode.value
    ? i18nt('add', { val: props.modalTitle && i18nt(props.modalTitle) })
    : i18nt(hasEditPermission.value ? 'edit' : 'viewDetail', {
        val: props.modalTitle && i18nt(props.modalTitle)
      });
});

// 打开编辑框入口
const openEditModalEntry = ref<EditModalEntry>();
// 打开编辑框
const { execute: executeGetCurrentEditData, data: currentEditData } = props.editDetailApi
  ? useAxiosGet(props.editDetailApi)
  : { execute: __, data: __ };
const openEditModal = async (rowData?: unknown, entry?: EditModalEntry) => {
  try {
    openEditModalEntry.value = entry ?? EditModalEntry.button;
    emit('before-open-edit-modal');
    if (!props.editDetailApi || !executeGetCurrentEditData) {
      emit('handle', 'edit-title');
      return;
    }
    const { id } = rowData || toRaw(tableRef.value?.selectedRows.at(0));
    await executeGetCurrentEditData(props.editDetailApi, { params: { id } });
    let tempCurrentEditData = currentEditData.value;
    if (!tempCurrentEditData) throw new Error('未获取到编辑数据');
    // 重构表单编辑参数函数
    if (props.refactorFormEditParams) tempCurrentEditData = props.refactorFormEditParams?.(tempCurrentEditData);
    const result = useFilterSelectedData([tempCurrentEditData], { ...formData.value, id });
    updateField(result);
    isEditMode.value = true;
    openModal();
    emit('after-open-edit-modal');
  } catch (error) {
    console.log('base-curd openEditModal：异常', error);
  }
};

// 提交
const { execute: executeSubmit, isLoading: isLoadingSubmit } = useAxiosPost<ResponseDataType>();
const handleSubmit = async () => {
  try {
    isEditMode.value ? emit('before-edit') : emit('before-add');
    await validate();
    // 提交前验证
    props.submitValidate?.();
    let params = { ...formData.value };
    // 重构表单请求参数函数
    if (props.refactorFormSubmitParams) params = props.refactorFormSubmitParams?.(toRaw(formData.value));
    await executeSubmit(isEditMode.value ? props.updateApi ?? '' : props.createApi ?? '', {
      data: useOmitNilRequestParams(params)
    });
    isEditMode.value ? emit('edit-success') : emit('add-success');
    closeModal();
    executeQueryList();
    tableRef.value?.clearSelected();
  } catch (error) {
    isEditMode.value ? emit('edit-error') : emit('add-error');
    console.log('base-curd handleSubmit异常：', error);
  }
};

// 单一删除操作 - dialog形式
const handleSingleDelete = <T extends { id: string }>(data: T) => {
  const dialog = $dialog.warning({
    content: i18nt('permission-button.confirmTooltip', { val: i18nt('delete') }),
    onPositiveClick: async () => {
      try {
        emit('before-delete');
        dialog.loading = true;
        if (!props.deleteApi) throw new Error('请确认删除APi');
        await useAxiosPost(props.deleteApi ?? '', { id: data.id }, __, { immediate: true });
        emit('delete-success');
        pagination.value.page = 1;
        executeQueryList();
      } catch (error) {
        console.log('base-curd handleDialogDelete：异常', error);
        emit('delete-error');
        return false;
      } finally {
        dialog.loading = false;
      }
    }
  });
};

// 多选删除操作 - 权限按钮
const handleDelete = async (resolve?: AsyncEmitResolveType) => {
  try {
    emit('before-delete');
    const { execute } = useAxiosPost(props.deleteApi ?? '', {
      ids: tableRef.value?.selectedKeys
    });
    await execute();
    emit('delete-success');
    pagination.value.page = 1;
    executeQueryList();
    tableRef.value?.clearSelected();
    resolve?.(true);
  } catch (error) {
    console.log('多选删除异常：', error);
    emit('delete-error');
    resolve?.(false);
  }
};

// 导出数据
const { isLoading: isLoadingExportData, execute: executeExportData } = props.exportApi
  ? useDownloadFile(props.exportApi ?? '')
  : { execute: __, isLoading: __ };
const handleExport = props.exportApi
  ? async () => {
      try {
        emit('before-export');
        let params = { ...mergedQueryFormData.value };
        if (props.refactorFormQueryParams) params = props.refactorFormQueryParams?.(params);
        await executeExportData?.(useOmitNilRequestParams(params), {
          paramsSerializer: props.paramsSerializerQuery ? useParamsSerializer() : __
        });
        emit('export-success');
      } catch (error) {
        console.log('导出数据异常：', error);
        emit('export-error');
      }
    }
  : __;

// 下载
const { execute: executeDownload, isLoading: isLoadingDownload } = props.downloadApi
  ? useDownloadFile(props.downloadApi ?? '')
  : { execute: __, isLoading: __ };
const handleDownload = props.downloadApi
  ? async () => {
      try {
        emit('before-download');
        await executeDownload?.();
        emit('download-success');
      } catch (error) {
        emit('download-error');
        console.log('下载异常:', error);
      }
    }
  : __;

// 查询
const handleSearch = () => {
  handleResetPageSize();
  executeQueryList();
  tableRef?.value?.selectedKeys?.length && tableRef.value?.clearSelected();
};

// 重置表单
const handleReset = () => (handleResetPageSize(), resetQueryField(), executeQueryList());

// 操作权限
const handlePermission = (permission: PermissionType, resolve?: AsyncEmitResolveType) => {
  emit('handle', permission);
  const permissionAction: PermissionActionType = {
    add: props.createApi && !props.ignorePermissionActions.includes('add') && handleAdd,
    delete: props.deleteApi && !props.ignorePermissionActions.includes('delete') ? () => handleDelete(resolve) : __,
    edit: !props.ignorePermissionActions.includes('edit') ? () => openEditModal(__, EditModalEntry.button) : __,
    search: props.readApi && !props.ignorePermissionActions.includes('search') && handleSearch,
    reset: handleReset,
    export: handleExport,
    download: handleDownload
  };
  if (permissionAction[permission]) permissionAction[permission]();
};

// Modal 关闭后的回调
const modalAfterLeave = () => {
  resetField();
  emit('modal-closed');
  currentEditData?.value && (currentEditData.value = null);
};

defineExpose({
  sortOrder,
  formRef,
  resetField,
  validate,
  pagination,
  handleResetPagination,
  handleDelete,
  handleReset,
  handleSearch,
  queryFormData,
  mergedQueryFormData,
  sourceTableData,
  formData,
  isLoadingQuery,
  isEditMode,
  tableData,
  currentEditData,
  tableRef,
  handleAdd,
  openEditModal,
  handleSingleDelete,
  handleUpdateRow,
  executeQueryList,
  openEditModalEntry,
  executeQuery,
  handleResetPageSize,
  updateField
});
</script>

<template>
  <base-card>
    <!-- 查询表单 -->
    <base-form
      v-if="queryFormSchemas.length"
      v-model="queryFormData"
      :schemas="queryFormSchemas"
      :row-limit-number="queryFormRowLimitNumber"
      type="query"
      :form-wrapper-class="queryFormWrapperClass"
      v-bind="formProps"
    >
      <template #header-action>
        <permission-button
          form
          :ignore-permission-actions="ignorePermissionActions"
          :loading-props="{
            searchLoading: isLoadingQuery
          }"
          :ignore-permission-list="ignoreQueryFormPermissionList"
          :disable-condition="queryFormPermissionDisable"
          @handle="handlePermission"
        />
      </template>
    </base-form>
    <div class="flex main-area">
      <div v-if="slots['table-prefix']" class="mr w-1/3">
        <slot name="table-prefix" />
      </div>
      <!-- 表格 -->
      <base-table
        ref="tableRef"
        class="flex-1"
        :show-filter-column="showFilterColumn"
        :loading="isLoadingQuery || isLoadingExportData"
        :data="tableData ?? []"
        remote
        :columns="columns"
        :pagination="showPagination && pagination"
        v-bind="tableProps"
        @update:sorter="handleSorterChange"
      >
        <template #header>
          <permission-button
            :loading-props="{
              exportLoading: isLoadingExportData,
              downloadLoading: isLoadingDownload,
              ...permissionButtonLoadingProps
            }"
            :disable-condition="formPermissionDisable"
            :select-length="tableRef?.selectedKeys?.length"
            :ignore-permission-actions="ignorePermissionActions"
            :ignore-permission-list="ignoreFormPermissionList"
            @handle="handlePermission"
            @before-import="emit('before-import')"
            @import-success="emit('import-success'), handleSearch()"
            @import-error="emit('import-error')"
          />
        </template>
        <template v-if="slots['table-top']" #center> <slot name="table-top" /> </template>
      </base-table>
      <div v-if="slots['table-suffix']" class="ml w-1/3">
        <slot name="table-suffix" />
      </div>
    </div>
    <!-- 模态框 -->
    <base-modal
      :show="showModal"
      :loading="isLoadingSubmit"
      :positive-text="isEditMode && !hasEditPermission ? __ : $t('confirm')"
      :title="useModalTitle"
      v-bind="modalProps"
      @after-leave="modalAfterLeave"
      @close="closeModal()"
      @negative-click="closeModal()"
      @positive-click="handleSubmit"
    >
      <slot name="modal-header" />
      <div class="flex">
        <slot name="modal-prefix" />
        <!-- 编辑表单 -->
        <base-form
          ref="formRef"
          v-model="formData"
          :row-limit-number="formRowLimitNumber"
          class="flex-1"
          :disabled="!hasEditPermission && isEditMode"
          :schemas="formSchemas"
          layout="dialog"
          :form-wrapper-class="formWrapperClass"
          v-bind="formProps"
        />
        <slot name="modal-suffix" />
      </div>
      <slot name="modal-footer" />
    </base-modal>
  </base-card>
</template>
