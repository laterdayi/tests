# base-curd

统一表单+表格，满足大部分业务场景

## base-curd Props

| Name                          | Type                                 | Default     | Description                                                    |
| ----------------------------- | ------------------------------------ | ----------- | -------------------------------------------------------------- |
| createApi                     | `string`                             | `undefined` | 新增 Api，不传触发 emit('handle', '\*') 进行自定义             |
| updateApi                     | `string`                             | `undefined` | 更新 Api，不传触发 emit('handle', '\*') 进行自定义             |
| readApi                       | `string`                             | `undefined` | 查询 Api，不传触发 emit('handle', '\*') 进行自定义             |
| editDetailApi                 | `string`                             | `undefined` | 获取编辑数据详情 Api，不传触发 emit('handle', '\*') 进行自定义 |
| deleteApi                     | `string`                             | `undefined` | 删除 Api，不传触发 emit('handle', '\*') 进行自定义             |
| exportApi                     | `string`                             | `undefined` | 导出数据 Api，不传触发 emit('handle', '\*') 进行自定义         |
| downloadApi                   | `string`                             | `undefined` | 下载接口 Api，不传触发 emit('handle', '\*') 进行自定义         |
| importApi                     | `string`                             | `undefined` | 导入接口 Api，不传触发 emit('handle', '\*') 进行自定义         |
| showPagination                | `boolean`                            | `true`      | 是否显示分页                                                   |
| showFilterColumn              | `boolean`                            | `true`      | 是否显示筛选列                                                 |
| queryFormParams               | `any`                                | `undefined` | 查询表单参数                                                   |
| queryFormSchemas              | `FormSchemaType`                     | `[]`        | 查询表单 Scheme                                                |
| queryFormProps                | `FormProps`                          | `undefined` | 查询表单 Props                                                 |
| queryFormWrapperClass         | `FormProps`                          | `undefined` | 查询表单容器 Class                                             |
| tableShallowRef               | `boolean`                            | `true`      | 查询结果是否为 shallowRef 类型数据                             |
| formParams                    | `any`                                | `undefined` | 操作表单参数                                                   |
| formSchemas                   | `FormSchemaType`                     | `[]`        | 操作表单 Scheme                                                |
| formProps                     | `FormProps`                          | `undefined` | 表单 Props                                                     |
| formWrapperClass              | `FormProps`                          | `undefined` | 表单容器 Class                                                 |
| columns                       | `DataTableColumns<any>`              | `[]`        | 需要展示的列                                                   |
| tableProps                    | `DataTableProps`                     | `undefined` | Table Props                                                    |
| refactorFormQueryParams       | `(data: any) => object \| undefined` | `undefined` | 重构查询表单参数函数                                           |
| refactorFormEditParams        | `(data: any) => object \| undefined` | `undefined` | 重构编辑表单参数函数                                           |
| refactorFormSubmitParams      | `(data: any) => object \| undefined` | `undefined` | 重构新增 or 编辑表单提交参数函数                               |
| submitValidate                | `() => void`                         | `undefined` | 提交前验证                                                     |
| queryFormRowLimitNumber       | `number`                             | `undefined` | 查询表单元素超出限制（展开收起）                               |
| formRowLimitNumber            | `number`                             | `undefined` | 表单元素超出限制（展开收起）                                   |
| modalTitle                    | `string`                             | `undefined` | 模态框标题                                                     |
| modalProps                    | `ModalProps`                         | `undefined` | 模态框 Props                                                   |
| refactorTableData             | `(data: any) => any[]`               | `undefined` | 重构表格数据                                                   |
| paramsSerializerQuery         | `boolean`                            | `undefined` | Axios 查询列表参数序列化                                       |
| ignoreQueryFormPermissionList | `PermissionType[]`                   | `[]`        | 忽略查询表单权限按钮显示                                       |
| ignoreFormPermissionList      | `PermissionType[]`                   | `[]`        | 忽略表单权限按钮显示                                           |
| ignorePermissionActions       | `PermissionType[]`                   | `true`      | 忽略权限按钮内置操作，触发`handle`事件自定义处理               |
| queryFormPermissionDisable    | `PermissionDisableType`              | `undefined` | 查询表单按钮无效条件                                           |
| formPermissionDisable         | `PermissionDisableType`              | `undefined` | 表单按钮无效条件                                               |
| permissionButtonLoadingProps  | `PermissionCustomTypeLoading`        | `undefined` | 自定义权限按钮 loading                                         |

## base-curd emit

| Name                   | Type                         | Description           |
| ---------------------- | ---------------------------- | --------------------- |
| handle                 | `emit('handle', permission)` | 权限按钮操作          |
| before-open-add-modal  | `void`                       | 打开新增 Modal 前回调 |
| after-open-add-modal   | `void`                       | 打开新增 Modal 后回调 |
| before-open-edit-modal | `void`                       | 打开编辑 Modal 前回调 |
| after-open-edit-modal  | `void`                       | 打开编辑 Modal 后回调 |
| before-add             | `void`                       | 新增请求前回调        |
| add-success            | `void`                       | 新增成功回调          |
| add-error              | `void`                       | 新增失败回调          |
| before-edit            | `void`                       | 编辑请求前回调        |
| edit-success           | `void`                       | 编辑成功后回调        |
| edit-error             | `void`                       | 编辑失败后回调        |
| before-delete          | `void`                       | 删除请求前回调        |
| delete-success         | `void`                       | 删除成功后回调        |
| delete-error           | `void`                       | 删除失败后回调        |
| before-import          | `void`                       | 导入请求前回调        |
| import-success         | `void`                       | 导入成功后回调        |
| import-error           | `void`                       | 导入失败后回调        |
| before-export          | `void`                       | 导出请求前回调        |
| export-success         | `void`                       | 导出成功后回调        |
| export-error           | `void`                       | 导出失败后回调        |
| before-download        | `void`                       | 下载请求前回调        |
| download-success       | `void`                       | 下载成功后回调        |
| download-error         | `void`                       | 下载失败后回调        |
| modal-closed           | `void`                       | Modal 关闭后回调      |

## base-curd defineExpose

| Name                  | Type                                                                                                  | Description                                                           |
| --------------------- | ----------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| queryFormData         | `Ref<any>`                                                                                            | 查询表单数据                                                          |
| mergedQueryFormData   | `ComputedRef<any>`                                                                                    | 查询表单参数 + 分页数据, 不可修改, v-model 使用 queryFormData         |
| formData              | `Ref<any>`                                                                                            | 编辑表单数据                                                          |
| isLoadingQuery        | `Ref<boolean>`                                                                                        | 列表 loading                                                          |
| isEditMode            | `Ref<boolean>`                                                                                        | 是否编辑模式                                                          |
| sourceTableData       | `tableData: Ref<L \| undefined> \|\| shallowRef<L \| undefined>`                                      | 原始表格数据                                                          |
| tableData             | `tableData: Ref<L \| undefined> \|\| shallowRef<L \| undefined>`                                      | 表格数据 \| 重构后表格数据                                            |
| currentEditData       | `Ref<unknown> \| undefined`                                                                           | 当前编辑数据                                                          |
| tableRef              | `Ref<{selectedKeys: any; selectedRows: any[]; queryParams: any; clearSelected: () => void;} \| null>` | Table 模板引用 <已选择 key 列表，已选择 row 列表，请求参数，清空选择> |
| handleAdd             | `() => void`                                                                                          | 新增按钮操作，场景：<安装包上传>                                      |
| handleDelete          | `() => void`                                                                                          | 重置表单                                                              |
| handleReset           | `() => void`                                                                                          | 重置表单                                                              |
| handleResetPageSize   | `() => void`                                                                                          | 重置表格分页 > pageSize                                               |
| handleResetPagination | `() => void`                                                                                          | 重置表格分页 > pageSIze、total                                        |
| handleSearch          | `() => void`                                                                                          | 查询执行函数（跳转首页，清空选择项）                                  |
| handleSingleDelete    | `<T extends { id: string}>(data: T) => void`                                                          | 单一删除                                                              |
| handleUpdateRow       | `(updater: (tableData: unknown) => void) => void`                                                     | 更新行数据                                                            |
| executeQueryList      | `() => Promise<void>`                                                                                 | 查询执行函数                                                          |
| executeQuery          | `ExecuteFunctionType`                                                                                 | 原始查询执行函数                                                      |
| openEditModal         | `(rowData?: unknown) => Promise<void>`                                                                | 打开编辑弹框，场景：<标题编辑>                                        |
| formRef               | `Ref<BaseFormRefType \| null>`                                                                        | 编辑表单引用                                                          |
| openEditModalEntry    | `EditModalEntry`                                                                                      | 编辑表单入口                                                          |
| validate              | `(validateCallback?, shouldRuleBeApplied?) => Promise<void> \| undefined`                             | 编辑表单验证                                                          |
| resetField            | `() => void`                                                                                          | 清空编辑表单字段                                                      |
| updateField           | `() => void`                                                                                          | 更新编辑表单字段                                                      |

## base-curd slots

| Name         | Description  |
| ------------ | ------------ |
| table-prefix | `表格前缀`   |
| table-top    | `表格上方`   |
| table-suffix | `表格后缀`   |
| modal-header | `模态框头部` |
| modal-prefix | `模态框前缀` |
| modal-suffix | `模态框后缀` |
| modal-footer | `模态框底部` |
