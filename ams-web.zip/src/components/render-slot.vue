<script setup lang="ts">
import type { FunctionalComponent } from 'vue';
import type { RenderSlotType } from './base-ui/base-form/type';

interface PropsType {
  // Render
  renderSlot?: RenderSlotType
}
const props = defineProps<PropsType>();

const render: FunctionalComponent = () => props.renderSlot?.render();
</script>

<template>
  <render />
</template>
