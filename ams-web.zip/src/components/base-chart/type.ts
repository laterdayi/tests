import type { ECharts } from 'echarts/core';
import type { CustomSeriesRenderItemParams } from 'echarts/types/dist/shared.js';
import type { ECOption } from '@/plugins/core/echarts';

declare global {
  // chart 图表类型
  interface ChartRefType {
    elRef?: HTMLElement;
    setOption: (
      options: ECOption,
      notMerge?: boolean | undefined,
      lazyUpdate?: boolean | undefined
    ) => void | undefined;
    option?: ECOption;
    setEmptyOption: () => void;
    getInstance: () => ECharts | null;
    resize: () => void | undefined;
  }

  interface CustomSeriesRenderItemParamsType extends CustomSeriesRenderItemParams {
    coordSys: {
      type: string;
      [key: string]: any;
    };
  }
}
