<script lang="ts">
import type { Arrayable } from '@vueuse/core';
import type { CustomSeriesOption, XAXisOption } from 'echarts/types/dist/shared.js';
import { type EChartRefType, useChart } from './use-chart/use-chart';
import type { ECOption } from '@/plugins/core/echarts';

interface PropsType {
  // 图表类型
  type?: EChartRefType;
  // 初始化配置
  initOptions?: ECOption;
  // 加载状态
  loading?: boolean;
  // 标题
  title?: string;
  // 标题位置
  titleAlign?: 'left' | 'right' | 'center';
  // x轴数据
  xAxisData?: MixedArray;
  // 数据集
  seriesOptions?: any;
  // 数据源
  seriesData?: any;
  // dataZoom
  dataZoom?: boolean;
}
</script>

<script setup lang="ts">
defineOptions({ inheritAttrs: false });

const props = withDefaults(defineProps<PropsType>(), {
  type: undefined,
  initOptions: undefined,
  loading: false,
  title: undefined,
  titleAlign: 'center',
  xAxisData: undefined,
  seriesOptions: undefined,
  seriesData: undefined,
  dataZoom: false
});

const { elRef, setOption, option, setEmptyOption, getInstance, resize } = useChart({
  type: props.type,
  initOptions: props.initOptions
});

// 空数据
const isEmptyData = () => {
  let isOk = false;
  if (!props.seriesData?.length && !props.xAxisData?.length) {
    setEmptyOption();
    isOk = true;
  }
  return isOk;
};

// 数据缩放
const handleDataZoom = (option: ECOption) => {
  if (props.dataZoom) option.dataZoom = useChartDataZoomOption(props.xAxisData?.length ?? 0);
  return option;
};

tryOnMounted(() => {
  if (isEmptyData()) return;
  let _options: ECOption = { ...option };
  _options = handleDataZoom(_options);
  if (option) setOption(_options, true);
});

watch(
  () => [...(props.seriesData ?? [])],
  newVal => {
    if (isEmptyData()) return;
    if (option?.series) {
      (option.series as CustomSeriesOption[])[0] = {
        ...(option.series as CustomSeriesOption[])[0],
        ...props.seriesOptions,
        data: newVal
      };
    }
    if (option?.xAxis) {
      option.xAxis = { ...option.xAxis, data: props.xAxisData } as Arrayable<XAXisOption>;
    }
    let _options: ECOption = { ...option };
    _options = handleDataZoom(_options);
    if (option) setOption(_options, true);
  },
  {
    immediate: true
  }
);

defineExpose({
  resize,
  getInstance,
  elRef,
  setOption,
  option,
  setEmptyOption
});
</script>

<template>
  <base-spin :show="loading" class="w-full">
    <div v-if="title" :class="[`text-${titleAlign}`]" class="text-18px text-gray-500">{{ $t(title) }}</div>
    <div ref="elRef" class="h-300px w-full" v-bind="$attrs" />
    <div class="text-16px text-center text-gray-500">
      <slot name="footer" />
    </div>
  </base-spin>
</template>
