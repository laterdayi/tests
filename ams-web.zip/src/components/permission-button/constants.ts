// 默认权限按钮
export type PermissionPresetType = 'search' | 'add' | 'edit' | 'delete' | 'download' | 'import' | 'export';
export const PERMISSION_BUTTON_CUSTOM_SETS = {
  // -------------------------------------------------------------------------------------------- > Config
  // 账号管理
  'config/user-manage/account-manage': ['resetPassword', 'openIDQuery', 'enableDisable'],
  // 角色权限
  'config/user-manage/role-permission': ['save', 'copy'],
  // 设备信息管理
  'config/equipment-manage/equipment-info-manage': ['generateQRcode'],
  // 安装包管理
  'config/system-manage/apk-upload': ['scanCodeDownload'],
  // 系统设置
  'config/system-setting': ['mailSettings', 'basicSettings', 'passwordPolicy'],
  // 项目管理
  'config/admin-manage/project-manage': ['permissionAssign'],
  // Kafka设置
  'config/admin-manage/kafka-settings': ['updatePartition'],
  // 表单管理
  'config/electron-form/form-manage': ['preview'],
  // -------------------------------------------------------------------------------------------- > SystemMonitor
  // 任务计划
  'system-monitor/task-plan/task-setting': ['executeNow'],
  // -------------------------------------------------------------------------------------------- > Ams
  // 关闭报警
  'ams/manual-operate/close-alarm': ['closeAlarm'],
  // 状态切换
  'ams/manual-operate/status-switch': ['statusSwitch'],
  // 报警录入
  'ams/manual-operate/alarm-logging': ['send', 'clear'],
  // 报警转单记录
  'ams/manual-operate/alarm-transfer-record': ['statusSwitch', 'turnOrder', 'operate'],
  // 报警解锁
  'ams/manual-operate/alarm-unlock': ['unlock'],
  // 系统设置
  'ams/system-setting': [
    'alarmActionSetting',
    'mailTemplateSetting',
    'alarmDashboardSetting',
    'generalSettings',
    'smsTemplateSetting',
    'weChatTemplateSetting',
    'dingTalkTemplateSettings',
    'feishuTemplateSettings',
    'repairSettings'
  ],
  // 维修履历
  'ams/maintenance-manage/repair-history': [
    'takeOver',
    'changedHand',
    'maintenanceConfirmation',
    'qcConfirm',
    'equipmentReceive'
  ],
  // 报警历史记录
  'ams/query-statistics/alarm-history-record': ['operate', 'turnOrder'],
  // 发起呼叫
  'ams/equipment-call/call-equipment-overview': ['initiateCall'],
  // 设备解锁
  'ams/equipment-maintain/equipment-unlock': ['equipmentUnlock'],
  // 呼叫管理-维修履历
  'ams/equipment-maintain/repair-history': ['takeAnOrder', 'turnOrder', 'engineerRepair', 'staging', 'clearStaging'],
  // 稽查设置
  'ams/equipment-maintain/audit-settings': ['hide', 'display'],
  // -------------------------------------------------------------------------------------------- > Assembly
  // 状态标准定义
  'assembly/basic-config/state-standard-definition': ['associateSetting'],
  // 改机单
  'assembly/production-manage/change-machine-order': [
    'review',
    'takeOver',
    'changedHand',
    'changeMachineConfirm',
    'qcConfirm',
    'equipmentReceive',
    'abolitionAndRestructuring'
  ],
  // 报修管理
  'assembly/production-manage/repair-manage': [
    'takeOver',
    'changedHand',
    'maintenanceConfirmation',
    'qcConfirm',
    'equipmentReceive'
  ],
  // 材料信息管理
  'assembly/material-manage/material-info-manage': ['startTimer'],
  // 备件基础信息
  'assembly/spares-manage/spares-basic-information': [
    'collect',
    'grant',
    'restitution',
    'receive',
    'boarding',
    'disembark',
    'maintain',
    'externalRepairRestitution'
  ],
  // 备件报废管理
  'assembly/spares-manage/spares-scrap-manage': ['confirmScrap', 'applyForScrapping'],
  // 备件统计查询
  'assembly/spares-manage/spares-statistical-query': ['collectAndReturn', 'preserve', 'repair', 'stock'],
  // 备件领用单
  'assembly/spares-manage/spares-collecting-doc': ['collectingApplication', 'grant'],
  // 报警作业
  'ams/manual-operate/alarm-handling': ['send', 'clear'],
  // -------------------------------------------------------------------------------------------- > Testing
  // 设备布局管理
  'testing/basic-config/equipment-layout-manage': ['copy'],
  'testing/rule-manage/rule-config': ['stopUse'],
  // 清除报警
  'testing/production-manage/clear-alarm': ['clearAlarm'],
  // -------------------------------------------------------------------------------------------- > PMS
  // 保养管理 -> 保养计划安排
  'pms/maintain-manage/maintain-plan-arrange': ['start', 'abort', 'changeExecutor'],
  // 维修管理 -> 报修管理
  'pms/maintenance-manage/repair-manage': [
    'takeOver',
    'changedHand',
    'maintenanceConfirmation',
    'qcConfirm',
    'equipmentReceive'
  ],
  // 材料管理 -> 材料信息管理
  'pms/material-manage/material-info-manage': ['startTimer'],
  // 备件管理 -> 备件基础信息
  'pms/spares-manage/spares-basic-information': [
    'collect',
    'grant',
    'restitution',
    'receive',
    'boarding',
    'disembark',
    'maintain',
    'externalRepairRestitution'
  ],
  // 备件管理 ->备件报废管理
  'pms/spares-manage/spares-scrap-manage': ['confirmScrap', 'applyForScrapping'],
  // 备件管理 -> 备件统计查询
  'pms/spares-manage/spares-statistical-query': ['collectAndReturn', 'preserve', 'repair', 'stock'],
  // 备件管理 ->备件领用单
  'pms/spares-manage/spares-collecting-doc': ['collectingApplication', 'grant'],
  // 信息通知->系统设置
  'pms/information-notification/system-setting': [
    'alarmActionSetting',
    'mailTemplateSetting',
    'alarmDashboardSetting',
    'alarmConfiguration'
  ],
  // 系统监控---->
  // redis资源阈值设置
  'system-monitor/system-setting': [
    'redisResourceThresholdSettings',
    'monitoringDashboardSetting'
  ]
} as const;

export type PermissionType = PermissionPresetType | PermissionCustomType | 'reset';

declare global {
  type PermissionCustomType =
    (typeof PERMISSION_BUTTON_CUSTOM_SETS)[keyof typeof PERMISSION_BUTTON_CUSTOM_SETS][number];

  type PermissionType = PermissionPresetType | PermissionCustomType | 'reset';

  type PermissionTypeLoading = {
    [K in PermissionType as `${K}Loading`]?: boolean;
  };

  type PermissionCustomTypeLoading = {
    [K in PermissionCustomType as `${K}Loading`]?: boolean;
  };

  type PermissionDisableType = {
    [K in PermissionType]?: boolean;
  };

  type ButtonIconType = {
    [K in PermissionType]: string;
  };

  type PermissionActionType = {
    [K in PermissionType]?: any;
  };
}
