<script lang="ts">
import type { UploadFileInfo } from 'naive-ui';
import type { Type } from 'naive-ui/es/button/src/interface';
import type { PermissionType } from './constants';

// 默认权限按钮位置
export const PRESET_PERMISSION_BUTTON = ['search', 'add', 'edit', 'delete', 'import', 'export', 'download'];
</script>

<script setup lang="ts">
interface PropsType {
  // 是否为查询表单
  form?: boolean;
  // 当前选中列表项个数
  selectLength?: number;
  // 忽略权限按钮显示
  ignorePermissionList?: PermissionType[];
  // 忽略权限按钮内置操作
  ignorePermissionActions?: PermissionType[];
  // 按钮无效条件
  disableCondition?: PermissionDisableType;
  // 删除 Api
  deleteApi?: string;
  // Loading Prop
  loadingProps?: PermissionTypeLoading;
}
const props = defineProps<PropsType>();
const emit = defineEmits<EmitType>();
const router = useRouter();
type EmitType = {
  handle: [permission: PermissionType, resolve?: AsyncEmitResolveType];
  'before-import': [];
  'import-success': [];
  'import-error': [];
};

const importApi = inject('importApi', '');

// 权限列表
const permissions = router.currentRoute.value.meta.powers as string[];

// 图标
const buttonIcons: { [K in PermissionType]?: string } = {
  search: 'i-carbon:search',
  add: 'i-carbon:add',
  edit: 'i-carbon:edit',
  delete: 'i-carbon:trash-can',
  download: 'i-carbon:download',
  import: 'i-carbon:document-import',
  export: 'i-carbon:document-export',
  reset: 'i-carbon:reset',
  permissionAssign: 'i-carbon:reset',
  resetPassword: 'i-carbon:reset',
  scanCodeDownload: 'i-carbon:qr-code',
  generateQRcode: 'i-carbon:qr-code',
  executeNow: 'i-carbon:update-now',
  startTimer: 'i-carbon:alarm',
  collect: 'i-carbon:document-tasks',
  grant: 'i-carbon:arrow-up-right',
  boarding: 'i-carbon:arrow-up',
  disembark: 'i-carbon:arrow-down',
  maintain: 'i-carbon:tools',
  restitution: 'i-carbon:arrow-down-right',
  receive: 'i-carbon:down-to-bottom',
  externalRepairRestitution: 'i-carbon:arrows-horizontal',
  copy: 'i-carbon:copy',
  associateSetting: 'i-carbon:movement'
};

// 查询表单预设权限
const formActionPermissions: string[] = ['search'];
const buttons = computed(() => {
  const queryPermissions = [...intersection(permissions, formActionPermissions)];
  permissions.includes('search') && queryPermissions.push('reset');
  const result = props?.form ? queryPermissions : without(permissions, ...formActionPermissions);
  return without(result, ...(props.ignorePermissionList ?? []));
});

// 按钮主题配置
const buttonsPrimary: { [K in PermissionType]?: Type } = {
  delete: 'error'
};

// emit
const handleEmit = (permission: PermissionType) => {
  const permissionAction: PermissionActionType = {
    delete: props.ignorePermissionActions?.includes('delete')
      ? __
      : () => {
          const dialog = $dialog.warning({
            title: i18nt('tips'),
            content: i18nt('permission-button.confirmTooltip', { val: i18nt('delete') }),
            onPositiveClick: async () => {
              try {
                dialog.loading = true;
                const result = await asyncEmit<EmitType>(emit, 'handle', permission);
                return !!result;
              } catch (error) {
                console.log('handleDeleteEmit - asyncEmit：异常', error);
                return false;
              } finally {
                dialog.loading = false;
              }
            }
          });
        }
  };
  permissionAction[permission as PermissionType]
    ? permissionAction[permission as PermissionType]?.()
    : emit('handle', permission as PermissionType);
};

// 上传
const { beforeUpload, customRequest, fileList, onError, onFinish, isLoadingUpload } = useUpload({
  astrictFileType: ASTRICT_XLSX_RULE,
  clearFileList: true,
  onFinished: () => emit('import-success'),
  onErrored: () => emit('import-error')
});

const handleBeforeUpload = (options: { file: UploadFileInfo; fileList: UploadFileInfo[] }) => {
  if (!importApi) return false;
  emit('before-import');
  return beforeUpload(options);
};

// 无效条件
const isDisableCondition = (item: PermissionType) => {
  const state: PermissionDisableType = {
    edit: props?.selectLength !== 1,
    delete: props?.selectLength === 0,
    search: false,
    add: false,
    ...props.disableCondition
  };
  return state[item];
};

// Loading
const isLoading = (item: PermissionType) => {
  return props.loadingProps?.[`${item}Loading`];
};

// Disabled
const isDisabled = (item: PermissionType) => {
  return isLoading(item as PermissionType) || isDisableCondition(item as PermissionType);
};
</script>

<template>
  <div class="flex min-h-30px">
    <template v-for="item in buttons" :key="item">
      <!-- 导入 -->
      <base-upload
        v-if="item === 'import'"
        v-model:file-list="fileList"
        class="mr-8px w-auto"
        :button-name="item"
        :loading="isLoadingUpload"
        :action="importApi"
        :custom-request="customRequest"
        :max="1"
        :show-file-list="false"
        @finish="onFinish"
        @error="onError"
        @before-upload="handleBeforeUpload"
      >
        {{ i18nt(item) }}
      </base-upload>
      <!-- 其余权限 -->
      <base-button
        v-else
        class="mr-8px"
        :button-name="item"
        :type="
          isDisableCondition(item as PermissionType) ? 'default' : buttonsPrimary[item as PermissionType] ?? 'primary'
        "
        :disabled="isDisabled(item as PermissionType)"
        :loading="isLoading(item as PermissionType)"
        @click="handleEmit(item as PermissionType)"
      >
        {{ i18nt(item) }}
        <template #icon>
          <base-icon :icon="`${buttonIcons[item as PermissionType] ?? 'i-carbon:cube'}`" />
        </template>
      </base-button>
    </template>
  </div>
</template>
