import type { Editor } from 'tinymce';

export type EditorType = Editor;
export type NestedMenuItemContents = string | NestedMenuItemSpec;

export type NestedMenuItemSpec = {
  type?: 'menuitem';
  icon?: string;
  onSetup?: (api: unknown) => (api: unknown) => void;
  onAction?: (api: unknown) => void;
};
export type ToolbarType = {
  value: string;
  text: string;
};
