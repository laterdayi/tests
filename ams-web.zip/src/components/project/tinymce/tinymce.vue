<script lang="ts" setup>
import type { Editor } from 'tinymce/tinymce';
import tinymce from 'tinymce/tinymce';
import 'tinymce/models/dom/model';
import 'tinymce/themes/silver';
import 'tinymce/icons/default';
import 'tinymce/plugins/advlist';
import 'tinymce/plugins/lists';
import 'tinymce/plugins/table';

import 'tinymce/skins/ui/oxide/skin.min.css';
import skinContentUrl from './skins/oxide/content.min.css?url';
import defaultContentUrl from './skins/default/content.min.css?url';
// import skinUrl from './skins/oxide/skin.min.css?url';
import './langs/zh-cn.js';

const props = withDefaults(
  defineProps<{
    // 宽度
    width?: string | number;
    // 高度
    height?: number;
    // 顶部菜单
    toolbar?: string;
    // 插件
    plugins?: string[];
    // 自定义菜单事件
    editorSetup: (editor: Editor) => void;
  }>(),
  {
    width: '100%',
    height: 500,
    toolbar: `undo redo | casechange blocks | bold italic forecolor backcolor | \
           alignleft aligncenter alignright alignjustify | \
           bullist numlst lists checklist outdent indent table `,
    plugins: () => ['lists', 'advlist']
  }
);

const appStore = useAppStore();
const { local } = storeToRefs(appStore);

const editorRef = ref<Editor | null>(null);
const initWrapper = async () => {
  const res = await tinymce.init({
    selector: '#editor',
    language: local.value === 'zh-CN' ? 'zh_CN' : 'en',
    width: props.width,
    height: props.height,
    branding: false,
    menubar: false,
    // 'skin_url': ',
    'content_css': [skinContentUrl, defaultContentUrl],
    plugins: props.plugins,
    toolbar: props.toolbar,
    'table_border_styles': [
      { title: 'Solid', value: 'solid' },
      { title: 'Dashed', value: 'dashed' },
      { title: 'Hidden', value: 'hidden' }
    ],
    setup(editor) {
      return props.editorSetup(editor);
    }
  });
  editorRef.value = res[0];
};
// 写入数据
const setContent = (item?: string) => {
  // console.log(item);
  editorRef?.value?.setContent(item || '');
};
// 获取数据
const getContent = (item?: { format: string }) => {
  return item ? editorRef?.value?.getContent({ format: 'text' }) : editorRef?.value?.getContent();
};
tryOnUnmounted(() => {
  // console.log('卸载');
  tinymce.activeEditor?.destroy();
  tinymce.remove();
});
defineExpose({
  initWrapper,
  setContent,
  getContent
});
</script>

<template>
  <textarea id="editor" />
</template>
