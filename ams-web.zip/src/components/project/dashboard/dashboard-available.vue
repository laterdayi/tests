<template>
  <div class="available">
    <img alt="" class="available-img" src="@/assets/images/ams/screen-dashboard/screen-dashboard-6.png" />
    <div class="available-text">{{ i18nt('noData') }}</div>
  </div>
</template>

<style lang="less" scoped>
.available {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;

  .available-img {
    z-index: 9;
    width: 218px;
    height: 146px;
  }
  .available-text {
    margin-top: 20px;
    font-size: 14px;
    height: 19px;
    width: 100%;
    text-align: center;
    color: #9bd0ff;
  }
}
</style>
