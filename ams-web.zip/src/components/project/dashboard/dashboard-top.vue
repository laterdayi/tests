<script setup lang="tsx">
import type { DashboardTopType } from './dashboard-type'

const props = defineProps<DashboardTopType>();
const emit = defineEmits<{
  'refresh': [];
  'toggleScreen': [];
}>();
const nowTime = useDateFormat(useNow(), 'YYYY-MM-DD HH:mm:ss');
</script>

<template>
  <!-- 顶部 -->
  <div class="dashboard-top">
    <!-- 顶部下拉框 -->
    <div class="top-area">
      <div class="area-top">{{ props.selectName }}</div>
      <div class="area-bottom" />
    </div>
    <!-- 顶部标题 -->
    <div class="top-title">
      <div class="title-top">{{ props.dashboardName }}</div>
      <div class="title-bottm">{{ props.dashboardTitle }}</div>
    </div>
    <!-- 顶部设置 -->
    <div class="top-time">
      <div class="time-top">
        <div class="time-tm">{{ nowTime }}</div>
        <div v-if="!props.refreshIsShow" class="time-city">
          <base-icon
            icon="i-carbon:restart"
            class="cursor-pointer"
            color="#31c8eb"
            :size="24"
            @click="emit('refresh')"
          />
        </div>
        <div class="time-fullScreen" @click="emit('toggleScreen')" />
      </div>
      <div class="time-bottom" />
    </div>
  </div>
</template>

<style lang="less" scoped>
@import './dashboard.less';
.dashboard-content {
  @dashboard-top();
}
</style>
