export type DashboardTopType = {
  // 下拉名称
  selectName: string;
  // 看板名称
  dashboardName: string;
  // 看半标题
  dashboardTitle: string;
  // 是否显示刷新按钮
  refreshIsShow?: boolean
};
