<script setup lang="ts">
import { VueDraggable } from 'vue-draggable-plus';
import type { SortableEvent } from 'sortablejs';
import type { ColsType, CreateDesignerType, RowsType, WidgetListType, WidgetType } from '../../utils/designer-type';
import formWrapper from '../form-item.vue';

defineOptions({
  components: {
    formWrapper
  }
});

const props = withDefaults(
  defineProps<{
    // 实例
    designer: CreateDesignerType;
    // 实例
    widget: ColsType;
    //
    parentWidget: WidgetListType;
    //
    rowIndex: number;
    //
    rowLength: number;
    //
    rowArray: RowsType[];
    //
    colIndex: number;
    //
    colLength: number;
    //
    colArray: ColsType[];
  }>(),
  {}
);
const { designer, widget, parentWidget, rowIndex, rowArray, rowLength, colIndex, colArray, colLength } = toRefs(props);

const selected = computed(() => widget.value.id === designer.value.selectedId);

const selectWidget = (widget: WidgetListType) => {
  designer.value.setSelected(widget);
};

const onTableDragAdd = (evt: SortableEvent, subList: WidgetType[] | undefined) => {
  // 重复代码，可合并
  const newIndex = evt.newIndex!;
  if (subList && subList[newIndex]) {
    designer.value.setSelected(subList[newIndex]);
  }

  designer.value.emitEvent('field-selected', widget.value);
};

// 右下角置灰
const mergeLeftColDisabled = computed(() => {
  return colIndex.value <= 0 || colArray.value[colIndex.value - 1].options.rowspan !== widget.value.options.rowspan;
});
const mergeRightColDisabled = computed(() => {
  const rightColIndex = colIndex.value + widget.value.options.colspan;
  return (
    colIndex.value >= colLength.value - 1 ||
    rightColIndex > colLength.value - 1 ||
    colArray.value[rightColIndex].options.rowspan !== widget.value.options.rowspan
  );
});
const mergeWholeRowDisabled = computed(() => colLength.value <= 1 || colLength.value === widget.value.options.colspan);
const mergeAboveRowDisabled = computed(() => {
  return (
    rowIndex.value <= 0 ||
    rowArray.value[rowIndex.value - 1].cols[colIndex.value].options.colspan !== widget.value.options.colspan
  );
});
const mergeBelowRowDisabled = computed(() => {
  const belowRowIndex = rowIndex.value + widget.value.options.rowspan;
  return (
    rowIndex.value >= rowLength.value - 1 ||
    belowRowIndex > rowLength.value - 1 ||
    rowArray.value[belowRowIndex].cols[colIndex.value].options.colspan !== widget.value.options.colspan
  );
});
const mergeWholeColDisabled = computed(() => rowLength.value <= 1 || rowLength.value === widget.value.options.rowspan);
const undoMergeRowDisabled = computed(() => widget.value.merged || widget.value.options.rowspan <= 1);
const undoMergeColDisabled = computed(() => widget.value.merged || widget.value.options.colspan <= 1);
const deleteWholeColDisabled = computed(
  () => colLength.value === 1 || widget.value.options.colspan === colLength.value
);
const deleteWholeRowDisabled = computed(
  () => rowLength.value === 1 || widget.value.options.rowspan === rowLength.value
);

// 右下角单元格操作
const tableCellList = ref([
  {
    label: i18nt('cellTips'),
    key: 'insertLeftCol'
  },
  {
    label: i18nt('cellTips1'),
    key: 'insertRightCol'
  },
  {
    label: i18nt('cellTips2'),
    key: 'insertAboveRow'
  },
  {
    label: i18nt('cellTips3'),
    key: 'insertBelowRow'
  },
  {
    label: i18nt('cellTips4'),
    key: 'mergeLeftCol',
    disabled: mergeLeftColDisabled
  },
  {
    label: i18nt('cellTips5'),
    key: 'mergeRightCol',
    disabled: mergeRightColDisabled
  },
  {
    label: i18nt('cellTips6'),
    key: 'mergeWholeRow',
    disabled: mergeWholeRowDisabled
  },
  {
    label: i18nt('cellTips7'),
    key: 'mergeAboveRow',
    disabled: mergeAboveRowDisabled
  },
  {
    label: i18nt('cellTips8'),
    key: 'mergeBelowRow',
    disabled: mergeBelowRowDisabled
  },
  {
    label: i18nt('cellTips9'),
    key: 'mergeWholeCol',
    disabled: mergeWholeColDisabled
  },
  {
    label: i18nt('cellTips10'),
    key: 'undoMergeRow',
    disabled: undoMergeRowDisabled
  },
  {
    label: i18nt('cellTips11'),
    key: 'undoMergeCol',
    disabled: undoMergeColDisabled
  },
  {
    label: i18nt('cellTips12'),
    key: 'deleteWholeCol',
    disabled: deleteWholeColDisabled
  },
  {
    label: i18nt('cellTips13'),
    key: 'deleteWholeRow',
    disabled: deleteWholeRowDisabled
  }
]);
const tableCellListObj: {
  [key: string]: () => void;
} = {
  // 插入左侧列
  insertLeftCol: () => designer.value.insertTableCol(parentWidget.value, colIndex.value, rowIndex.value, true),
  // 插入右侧列
  insertRightCol: () => designer.value.insertTableCol(parentWidget.value, colIndex.value, rowIndex.value, false),
  // 插入上方行
  insertAboveRow: () =>
    designer.value.insertTableRow(parentWidget.value, rowIndex.value, rowIndex.value, colIndex.value, true),
  // 插入下方行
  insertBelowRow: () =>
    designer.value.insertTableRow(parentWidget.value, rowIndex.value, rowIndex.value, colIndex.value, false),
  // 合并左侧单元格
  mergeLeftCol: () =>
    designer.value.mergeTableCol(rowArray.value, colArray.value, rowIndex.value, colIndex.value, true, widget.value),
  // 合并右侧单元格
  mergeRightCol: () =>
    designer.value.mergeTableCol(rowArray.value, colArray.value, rowIndex.value, colIndex.value, false, widget.value),
  // 合并整行
  mergeWholeRow: () =>
    designer.value.mergeTableWholeRow(rowArray.value, colArray.value, rowIndex.value, colIndex.value),
  // 合并上方单元格
  mergeAboveRow: () => designer.value.mergeTableRow(rowArray.value, rowIndex.value, colIndex.value, true, widget.value),
  // 合并下方单元格
  mergeBelowRow: () =>
    designer.value.mergeTableRow(rowArray.value, rowIndex.value, colIndex.value, false, widget.value),
  // 合并整列
  mergeWholeCol: () =>
    designer.value.mergeTableWholeCol(rowArray.value, colArray.value, rowIndex.value, colIndex.value),
  // 撤销列合并
  undoMergeRow: () =>
    designer.value.undoMergeTableRow(
      rowArray.value,
      rowIndex.value,
      colIndex.value,
      widget.value.options.colspan,
      widget.value.options.rowspan
    ),
  // 撤销行合并
  undoMergeCol: () =>
    designer.value.undoMergeTableCol(
      rowArray.value,
      rowIndex.value,
      colIndex.value,
      widget.value.options.colspan,
      widget.value.options.rowspan
    ),
  // 删除整列
  deleteWholeCol: () => designer.value.deleteTableWholeCol(rowArray.value, colIndex.value),
  // 删除整行
  deleteWholeRow: () => designer.value.deleteTableWholeRow(rowArray.value, rowIndex.value)
};
// 单元格操作处理
const handleTableCellCommand = (command: string) => {
  tableCellListObj[command]();
};
</script>

<template>
  <td
    id="table-cell-widget"
    :class="[selected ? 'selected' : '']"
    :colspan="widget.options.colspan || 1"
    :rowspan="widget.options.rowspan || 1"
    @click.stop="selectWidget(widget)"
  >
    <vue-draggable
      v-model="widget.widgetList"
      item-key="table-cell-widget"
      class="draggable-div"
      v-bind="{ group: 'dragGroup', ghostClass: 'ghost', animation: 200 }"
      handle=".drag-handler"
      @add="evt => onTableDragAdd(evt, widget.widgetList)"
    >
      <template v-for="(element, index) in widget.widgetList" :key="element.id">
        <transition-group v-if="widget.widgetList.length !== 0" name="fade" tag="div" class="draggable-item">
          <component
            :is="`${'formWrapper'}`"
            :key="element.id + element.type + index"
            :field="element"
            :designer="designer"
            :parent-list="widget.widgetList"
            :index-of-parent-list="index"
            :parent-widget="widget"
            design-state
            :preview="false"
          />
        </transition-group>
      </template>
    </vue-draggable>
    <!-- 左上角 -->
    <div v-if="designer.selectedId === widget.id && widget.type === 'table-cell-widget'" class="table-upper-left">
      <i>{{ i18nt('cell') }}</i>
    </div>
    <!-- 右下角 -->
    <div v-if="designer.selectedId === widget.id && widget.type === 'table-cell-widget'" class="table-lower-right">
      <base-dropdown trigger="click" class="cursor-pointer" :options="tableCellList" @select="handleTableCellCommand">
        <div class="i-carbon:switcher icon" :title="i18nt('cellOperations')" />
      </base-dropdown>
    </div>
  </td>
</template>

<style lang="less" scoped>
#table-cell-widget {
  border: 1px dashed #336699;
  display: table-cell;
  position: relative;
  line-height: 40px;
  border: 1px dashed #336699;
  padding: 5px 5px 0px;
  display: table-cell;
  .draggable-div {
    position: relative;
    min-height: 40px;
    .draggable-item {
      border: 1px solid #336699;
      padding: 10px 5% 0px;
      margin-bottom: 5px;
      min-height: 36px;
    }
  }
  .table-lower-right {
    position: absolute;
    bottom: -1px;
    right: -1px;
    height: 20px;
    width: 20px;
    background: #409eff;
    z-index: 999;
    display: flex;
    align-items: center;
    justify-content: center;

    .icon {
      width: 15px;
      height: 15px;
      color: #fff;
      cursor: pointer;
    }
  }
  .table-upper-left {
    position: absolute;
    top: -2px;
    left: -2px;
    height: 22px;
    line-height: 22px;
    background: #409eff;
    z-index: 9;

    i {
      font-size: 14px;
      font-style: normal;
      color: #fff;
      margin: 4px;
      cursor: default;
    }
  }
}
#table-cell-widget.selected {
  border: 1px solid #409eff !important;
  z-index: 9;
}
</style>
