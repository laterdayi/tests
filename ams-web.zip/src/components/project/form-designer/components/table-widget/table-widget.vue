<script setup lang="ts">
import type { ColsType, CreateDesignerType, WidgetListType } from '../../utils/designer-type';
import ContainerWrapper from './container-wrapper.vue';
import TableCellWidget from './table-cell-widget.vue';

const props = withDefaults(
  defineProps<{
    // 实例
    widget: WidgetListType
    // 样式
    designer: CreateDesignerType
    //
    parentWidget: WidgetListType | null
    //
    parentList: ColsType[]
    //
    indexOfParentList: number
  }>(),
  {}
);
const { widget, designer, parentWidget, parentList, indexOfParentList } = toRefs(props);
const selectWidget = (widget: WidgetListType) => {
  designer.value.setSelected(widget);
};
const selected = computed(() => {
  return widget.value.id === designer.value.selectedId;
});
</script>

<template>
  <container-wrapper
    :designer="designer"
    :widget="widget"
    :parent-widget="parentWidget || null"
    :parent-list="parentList"
    :index-of-parent-list="indexOfParentList"
  >
    <div id="table-widget" :key="widget.id" :class="[selected ? 'selected' : '']" @click.stop="selectWidget(widget)">
      <table class="table-content">
        <tbody>
          <tr v-for="(row, rowIdx) in widget.rows" :key="row.id">
            <template v-for="(colWidget, colIdx) in row.cols">
              <table-cell-widget
                v-if="!colWidget.merged"
                :key="colWidget.id"
                :widget="colWidget"
                :parent-widget="widget"
                :row-index="rowIdx"
                :row-length="widget.rows?.length || 0"
                :row-array="widget.rows"
                :col-index="colIdx"
                :col-length="row.cols.length"
                :col-array="row.cols"
                :designer="designer"
              />
            </template>
          </tr>
        </tbody>
      </table>
    </div>
  </container-wrapper>
</template>

<style lang="less" scoped>
// 表格
#table-widget {
  padding: 10px;
  border: 1px solid #336699;
  box-sizing: border-box;
  cursor: pointer;

  .table-content {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    table-layout: fixed;
  }
}
#table-widget.selected {
  outline: 2px solid #336699 !important;
}
</style>
