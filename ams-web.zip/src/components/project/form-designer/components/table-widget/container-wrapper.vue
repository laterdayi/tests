<script setup lang="ts">
import type { ColsType, CreateDesignerType, WidgetListType } from '../../utils/designer-type';

const props = withDefaults(
  defineProps<{
    // 样式
    designer: CreateDesignerType
    // 实例
    widget: WidgetListType
    //
    parentWidget: WidgetListType | null
    //
    parentList: ColsType[]
    //
    indexOfParentList: number
  }>(),
  {}
);

const { widget, designer, parentWidget, parentList, indexOfParentList } = toRefs(props);
// 插入新行
const appendTableRow = (widget: WidgetListType) => {
  designer.value.appendTableRow(widget);
};

// 插入新列
const appendTableCol = (widget: WidgetListType) => {
  designer.value.appendTableCol(widget);
};

const removeWidget = () => {
  if (parentList.value) {
    let nextSelected: WidgetListType | null = null;
    if (parentList.value.length === 1) {
      if (parentWidget.value) {
        nextSelected = parentWidget.value;
      }
    } else if (parentList.value.length === 1 + indexOfParentList.value) {
      nextSelected = parentList.value[indexOfParentList.value - 1];
    } else {
      nextSelected = parentList.value[indexOfParentList.value + 1];
    }

    nextTick(() => {
      parentList.value.splice(indexOfParentList.value, 1);
      if (nextSelected) {
        designer.value.setSelected(nextSelected);
      }
    });
  }
};
</script>

<template>
  <div id="container-wrapper">
    <slot />
    <!-- 左上 -->
    <div v-if="designer.selectedId === widget.id && !widget.outside" class="container-upper-left">
      <!-- <i class="i-carbon:move" title="拖拽手柄" /> -->
      <i>{{ widget.name }}</i>
      <i v-if="widget.options.hidden === true" class="icon-hide iconfont" />
    </div>
    <div v-if="designer.selectedId === widget.id && !widget.outside" class="container-lower-right">
      <i
        v-if="widget.type === 'table'"
        class="i-carbon:decision-tree iconfont"
        :title="i18nt('insertNewRow')"
        @click.stop="appendTableRow(widget)"
      />
      <i
        v-if="widget.type === 'table'"
        class="i-carbon:container-services iconfont"
        :title="i18nt('insertNewColumn')"
        @click.stop="appendTableCol(widget)"
      />
      <i class="i-carbon:trash-can" :title="i18nt('removeTable')" @click.stop="removeWidget" />
    </div>
  </div>
</template>

<style lang="less" scoped>
#container-wrapper {
  position: relative;
  margin-bottom: 10px;
  .container-upper-left {
    position: absolute;
    top: 1px;
    left: 1px;
    height: 22px;
    line-height: 22px;
    background: #409eff;
    z-index: 9;

    i {
      font-size: 14px;
      font-style: normal;
      color: #fff;
      margin: 4px;
      cursor: default;
    }
  }

  .container-lower-right {
    position: absolute;
    bottom: 1px;
    right: 1px;
    height: 28px;
    line-height: 28px;
    background: #409eff;
    z-index: 999;

    i {
      font-size: 15px;
      color: #fff;
      margin: 0 5px;
      cursor: pointer;
    }
  }
}
</style>
