<script setup lang="ts">
import type { ColsType, CreateDesignerType } from '../../../utils/designer-type';
import formWrapper from '../../form-item.vue';

defineOptions({
  components: {
    formWrapper
  }
});

const props = withDefaults(
  defineProps<{
    // 实例
    widget: ColsType,
      //
      designer: CreateDesignerType
  }>(),
  {}
);
const { widget, designer } = toRefs(props);
</script>

<template>
  <td id="table-cell-widget" :colspan="widget.options.colspan || 1" :rowspan="widget.options.rowspan || 1">
    <component
      :is="`${'formWrapper'}`"
      v-for="(subWidget, swIdx) in widget.widgetList"
      :key="swIdx"
      :field="subWidget"
      :designer="designer"
      :parent-list="widget.widgetList"
      :index-of-parent-list="swIdx"
      :parent-widget="widget"
      preview
    >
      <template v-for="slot in Object.keys($slots)" #[slot]="scope">
        <slot :name="slot" v-bind="scope" />
      </template>
    </component>
  </td>
</template>

<style lang="less" scoped>
#table-cell-widget {
  height: 36px;
  border: 1px solid #e5e5e5;
  padding: 10px 10px 0px;
}
</style>
