<script setup lang="ts">
import type { CreateDesignerType, WidgetListType } from '../../../utils/designer-type';
import tableCellItem from './table-cell-item.vue';

const props = withDefaults(
  defineProps<{
    // 实例
    widget: WidgetListType
    //
    designer: CreateDesignerType
  }>(),
  {}
);
const { widget, designer } = toRefs(props);
</script>

<template>
  <div v-show="!widget.options.hidden" id="table-item" :key="widget.id">
    <table :ref="widget.id" class="table-content">
      <tbody>
        <tr v-for="(row, rowIdx) in widget.rows" :key="row.id">
          <template v-for="(colWidget, colIdx) in row.cols">
            <table-cell-item
              v-if="!colWidget.merged"
              :key="colIdx"
              :widget="colWidget"
              :designer="designer"
              :parent-list="widget.cols"
              :row-index="rowIdx"
              :col-index="colIdx"
              :parent-widget="widget"
            >
              <!-- 递归传递插槽！！！ -->
              <template v-for="slot in Object.keys($slots)" #[slot]="scope">
                <slot :name="slot" v-bind="scope" />
              </template>
            </table-cell-item>
          </template>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style lang="less" scoped>
#table-item {
  .table-content {
    width: 100%;
    table-layout: fixed;
    border-collapse: collapse;
  }
}
</style>
