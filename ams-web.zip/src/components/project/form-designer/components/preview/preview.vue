<script setup lang="tsx">
import type { CreateDesignerType } from '../../utils/designer-type';
import tableItem from './components/table-item.vue';

// 预览
defineOptions({
  components: {
    tableItem
  }
});
const props = withDefaults(
  defineProps<{
    // 实例
    designer: CreateDesignerType;
    //  1 正常生成,2仅预览且预览不为弹窗
    previewType: number;
  }>(),
  {}
);
const { designer, previewType } = toRefs(props);
const widgetList = computed(() => designer.value.widgetList || []);
// 弹窗开启
const { showModal, openModal, closeModal } = useModal();
//  打开弹窗
const handleOpenModal = () => {
  openModal();
};

// 关闭弹窗 清除弹窗操作
const closeModalNew = () => {
  designer?.value?.previewModal();
  closeModal();
};
defineExpose({
  handleOpenModal
});
</script>

<template>
  <base-modal
    v-if="previewType === 1"
    :show="showModal"
    class="w-85%!"
    :title="$t('preview')"
    :positive-text="__"
    :negative-text="__"
    @close="closeModalNew"
    @negative-click="closeModalNew"
  >
    <component
      :is="`${'table-item'}`"
      v-for="(widget, index) in widgetList"
      :key="widget.id"
      :widget="widget"
      :designer="designer"
      :parent-list="widgetList"
      :index-of-parent-list="index"
      :parent-widget="null"
    >
      <!-- 递归传递插槽！！！ -->
      <template v-for="slot in Object.keys($slots)" #[slot]="scope">
        <slot :name="slot" v-bind="scope" />
      </template>
    </component>
  </base-modal>
  <base-card v-else>
    <component
      :is="`${'table-item'}`"
      v-for="(widget, index) in widgetList"
      :key="widget.id"
      :widget="widget"
      :designer="designer"
      :parent-list="widgetList"
      :index-of-parent-list="index"
      :parent-widget="null"
    >
      <!-- 递归传递插槽！！！ -->
      <template v-for="slot in Object.keys($slots)" #[slot]="scope">
        <slot :name="slot" v-bind="scope" />
      </template>
    </component>
  </base-card>
</template>
