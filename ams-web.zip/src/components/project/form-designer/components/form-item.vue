<script setup lang="ts">
import type { CreateDesignerType, WidgetListType, WidgetType } from '../utils/designer-type';
import { formItemComponentObj } from '../utils/form-item-method';

const props = withDefaults(
  defineProps<{
    // 实例
    field: WidgetType;
    //
    designer: CreateDesignerType;
    //
    parentWidget: WidgetListType | null;
    //
    parentList: WidgetType[];
    //
    indexOfParentList: number;
    // 是否预览
    preview: boolean;
  }>(),
  {}
);
const { field, designer, parentWidget, parentList, indexOfParentList, preview } = toRefs(props);

const widgetPanelIsShow = computed(() => field.value.options.formId === '0');
const isHideTitle = computed(() => field.value.options.isHideTitle);
const selected = computed(() => field.value.id === designer.value.selectedId);

// 选中
const selectField = (field: WidgetListType) => {
  if (!preview.value) {
    designer.value.setSelected(field);
  }
};
// 移除组件
const removeFieldWidget = () => {
  if (parentList.value) {
    let nextSelected: WidgetListType | null = null;
    if (parentList.value.length === 1) {
      if (parentWidget.value) {
        nextSelected = parentWidget.value;
      }
    } else if (parentList.value.length === 1 + indexOfParentList.value) {
      nextSelected = parentList.value[indexOfParentList.value - 1];
    } else {
      nextSelected = parentList.value[indexOfParentList.value + 1];
    }

    nextTick(() => {
      parentList.value.splice(indexOfParentList.value, 1);
      if (nextSelected) {
        if (!designer.value) return;
        designer.value.setSelected(nextSelected);
      }
    });
  }
};

const formItemComponent = (props: { field: WidgetType; type: number }) => {
  const { field, type } = props;
  const validateIsShow = type === 1 ? widgetPanelIsShow.value : false;
  return formItemComponentObj[field.options.dataType](
    field.options,
    designer.value.tableItemComponentIsShow,
    validateIsShow
  );
};
</script>

<template>
  <div
    class="form-item"
    :class="[
      selected ? 'selected' : '',
      preview ? '' : isHideTitle === 1 ? 'preview-form-item1' : 'preview-form-item',
      designer?.previewType === 1 ? '' : 'form-item-preview'
    ]"
    @click.stop="selectField(field)"
  >
    <!-- 标题控件 -->
    <div v-if="widgetPanelIsShow">
      <div :class="preview ? 'form-item-preview widget-panel' : 'form-item '">
        <div v-if="preview" class="mr">{{ field.options.itemValue }}</div>
        <formItemComponent v-else class="formItemComponen w-100%!" :field="field" :type="1" />
      </div>
    </div>
    <div v-else>
      <!-- 控件 -->
      <div v-if="isHideTitle === 1" :class="preview ? 'form-item-preview widget-panel' : 'form-item'">
        <div v-if="!preview">{{ field.options.name }}</div>
        <formItemComponent v-else class="formItemComponen" :field="field" :type="2" />
      </div>
      <!-- 业务 -->
      <div v-else :class="preview ? 'form-item-preview' : 'form-item'">
        <div class="mr title">{{ field.options.name }}</div>
        <formItemComponent v-if="preview" class="formItemComponen" :field="field" :type="2" />
      </div>
    </div>

    <!-- 拖拽 -->
    <div v-if="!preview">
      <div v-if="designer.selectedId === field.id" class="field-action">
        <i class="i-carbon:trash-can" :title="i18nt('removeComponent')" @click.stop="removeFieldWidget" />
      </div>
      <div v-if="designer.selectedId === field.id" class="drag-handler">
        <i class="i-carbon:move" :title="i18nt('dragHandle')" />
        <div>{{ field.type }}</div>
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped>
.form-item {
  position: relative;
  line-height: 36px;
  cursor: pointer;

  .field-action {
    position: absolute;
    bottom: 0;
    right: -2px;
    height: 22px;
    line-height: 22px;
    background: #409eff;
    z-index: 9;

    i {
      font-size: 14px;
      color: #fff;
      margin: 0 5px;
    }
  }

  .drag-handler {
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    top: -1px;
    left: -1px;
    z-index: 9;
    padding: 0px 5px;
    color: #ffffff;
    font-size: 12px;
    cursor: move;
    background: #409eff;
    i {
      font-style: normal;
    }
    div {
      line-height: 20px;
      margin-left: 5px;
    }
  }
  .form-item {
    display: flex;
    justify-content: center;
  }

  .form-item-preview {
    display: flex;
    justify-content: start;
    margin-bottom: 10px;
    .formItemComponen {
      width: 75% !important;
      :deep(.min-component-width\!) {
        width: 100% !important;
      }
    }
    .title {
      min-width: 15% !important;
    }
  }
  .widget-panel {
    justify-content: center;
  }
}
.form-item-preview {
  cursor: default;
}

.preview-form-item {
  margin-bottom: 10px;
  padding: 5px 10px;
  border: 1px dashed #336699;
}
.preview-form-item1 {
  margin-bottom: 10px;
  padding: 5px 10px;
  border: 1px dashed #f56c6c;
}
.selected {
  border: 2px solid #409eff;
}
</style>
