<script setup lang="ts">
import { VueDraggable } from 'vue-draggable-plus';
import type { SortableEvent } from 'sortablejs';
import type { CreateDesignerType } from '../utils/designer-type';
import tableWidget from './table-widget/table-widget.vue';

// 右侧拖拽
defineOptions({
  components: {
    tableWidget
  }
});

const props = withDefaults(
  defineProps<{
    // 实例
    designer: CreateDesignerType;
  }>(),
  {}
);
const { designer } = toRefs(props);
const formDesignerHeight = computed<string>(() => `${designer.value.formHeight + 67}px`);

// 右侧新增
const onDragAdd = (evt: SortableEvent) => {
  const newIndex = evt.newIndex!;
  if (designer.value.widgetList[newIndex]) {
    designer.value.setSelected(designer.value.widgetList[newIndex]);
  }
  designer.value.emitEvent('field-selected', null);

  // 限制表格内组件移除表格
  if (designer.value.widgetList.length > 1) {
    $message.error(i18nt('formDesignerTips9'));
    designer.value.widgetList = designer.value.widgetList.filter(ele => ele.type === 'table');
  }
};
// 使用的组件
const getWidgetName = (type: string) => {
  return `${type}-widget`;
};
</script>

<template>
  <div id="content-panel">
    <div v-if="designer.widgetList.length === 0" class="content-tip">
      {{ i18nt('formDesignerTips10') }}
    </div>
    <vue-draggable
      v-model="designer.widgetList"
      v-bind="{ group: 'dragGroup', ghostClass: 'ghost', animation: 300 }"
      handle=".drag-handler"
      item-key="form-widget"
      class="content-item"
      @add="onDragAdd"
    >
      <template v-for="(element, index) in designer.widgetList" :key="element.id">
        <transition-group name="fade" tag="div">
          <component
            :is="getWidgetName(element.type)"
            :key="element.id"
            :widget="element"
            :designer="designer"
            :parent-list="designer.widgetList"
            :index-of-parent-list="index"
            :parent-widget="null"
          />
        </transition-group>
      </template>
    </vue-draggable>
  </div>
</template>

<style lang="less" scoped>
#content-panel {
  .content-tip {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-size: 18px;
    color: #999999;
  }
  .content-item {
    height: calc(100vh - v-bind(formDesignerHeight));
    padding: 3px;
    overflow-y: scroll;
    background-color: #ffffff;
  }
}
</style>
