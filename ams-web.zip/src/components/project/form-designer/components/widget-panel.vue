<script setup lang="ts">
import { VueDraggable } from 'vue-draggable-plus';
import { containers } from '../utils/designer-config';
import type { BasicFieldsType, ContainersType, CreateDesignerType, WidgetType } from '../utils/designer-type';

// 左侧拖拽
const props = withDefaults(
  defineProps<{
    // 实例
    designer: CreateDesignerType;
  }>(),
  {}
);
const { designer } = toRefs(props);
const containersNew = ref<ContainersType[]>([]);

tryOnMounted(() => {
  containersNew.value = containers.filter(ele => {
    return !ele.outside;
  });
  controlListSearch.value = designer.value.basicFieldsContro;
  controlListSearchIsShow.value = controlListSearch.value.length !== 0;
  sharedListSearch.value = designer.value.basicFieldsShared;
  sharedListSearchIsShow.value = sharedListSearch.value.length !== 0;
  projectListSearch.value = designer.value.basicFieldsProject;
  projectListSearchIsShow.value = projectListSearch.value.length !== 0;
});
// 左侧
// 控件表单项
const controlSearch = ref<string>('');
const controlIsShow = ref<boolean>(true);
const controlListSearch = ref<BasicFieldsType[]>([]);
const controlListSearchIsShow = ref<boolean>(true);
const controlInputSearch = () => {
  controlListSearch.value = designer.value.basicFieldsContro.filter(ele =>
    ele.options.name.includes(controlSearch.value)
  );
};

// 共用表单项
const sharedSearch = ref<string>('');
const sharedIsShow = ref<boolean>(false);
const sharedListSearch = ref<BasicFieldsType[]>([]);
const sharedListSearchIsShow = ref<boolean>(true);
const sharedInputSearch = () => {
  sharedListSearch.value = designer.value.basicFieldsShared.filter(ele =>
    ele.options.name.includes(sharedSearch.value)
  );
};
// 项目表单项
const projectSearch = ref<string>('');
const projectIsShow = ref<boolean>(false);
const projectListSearch = ref<BasicFieldsType[]>([]);
const projectListSearchIsShow = ref<boolean>(true);
const projectInputSearch = () => {
  projectListSearch.value = designer.value.basicFieldsProject.filter(ele =>
    ele.options.name.includes(projectSearch.value)
  );
};
// 展开
const iconClick = (type: number) => {
  controlSearch.value = '';
  controlListSearch.value = designer.value.basicFieldsContro;
  controlListSearchIsShow.value = controlListSearch.value.length !== 0;

  sharedSearch.value = '';
  sharedListSearch.value = designer.value.basicFieldsShared;
  sharedListSearchIsShow.value = sharedListSearch.value.length !== 0;

  projectSearch.value = '';
  projectListSearch.value = designer.value.basicFieldsProject;
  projectListSearchIsShow.value = projectListSearch.value.length !== 0;

  if (type === 0) {
    sharedIsShow.value = false;
    projectIsShow.value = false;
    controlIsShow.value = !controlIsShow.value;
  } else if (type === 1) {
    controlIsShow.value = false;
    projectIsShow.value = false;
    sharedIsShow.value = !sharedIsShow.value;
  } else if (type === 2) {
    controlIsShow.value = false;
    sharedIsShow.value = false;
    projectIsShow.value = !projectIsShow.value;
  }
};
// 拖拽克隆(表格)
const handleContainerWidgetClone = (origin: WidgetType) => {
  return designer.value.copyNewContainerWidget(origin);
};
// 添加左侧点击事件(表格)
const addContainerByDbClick = (container: WidgetType) => {
  if (tableWidgetClass.value !== '.table ') return;
  designer.value.addContainerByDbClick(container);
};
// 拖拽克隆(插件)
const handleFieldWidgetClone = (origin: WidgetType) => {
  return designer.value.copyNewFieldWidget(origin);
};
// 拖拽触碰(左到右 插件)
const checkFieldMove = (evt: any) => {
  return designer.value.checkFieldMove(evt);
};
// 添加左侧点击事件(插件)
const addFieldByDbClick = (widget: WidgetType) => {
  if (tableWidgetClass.value !== '.table ') return;
  designer.value.addFieldByDbClick(widget);
};
// 表单拖拽结束
const onContainerDragFormEnd = () => {
  if (designer.value.widgetList.length === 1) {
    if (designer.value.widgetList[0].type !== 'table') {
      designer.value.widgetList = [];
      $message.error(i18nt('formDesignerTips8'));
    }
  } else {
    if (designer.value.widgetList.length !== 0) {
      $message.error(i18nt('formDesignerTips9'));
      designer.value.widgetList = designer.value.widgetList.filter(ele => ele.type === 'table');
    }
  }
};
// 表格组件是否可以拖拽
const tableWidgetClass = computed<string>(() => {
  return designer.value.widgetList.length === 1 ? '.table' : '';
});
</script>

<template>
  <div id="widget-panel">
    <div class="widget-table">
      <div class="widget-title">
        <div class="title">{{ i18nt('table') }}</div>
      </div>
      <!-- 表格 -->
      <vue-draggable
        v-model="containersNew"
        tag="ul"
        class="table widget-item"
        :group="{ name: 'dragGroup', pull: 'clone', put: false }"
        :clone="handleContainerWidgetClone"
        ghost-class="ghost"
        :sort="false"
        item-key="containers"
        :filter="tableWidgetClass"
      >
        <li
          v-for="element in containersNew"
          :key="element.name"
          class="widget-li"
          :class="tableWidgetClass ? 'table-widget-li' : ''"
          @dblclick="addContainerByDbClick(element as unknown as WidgetType)"
        >
          <span> {{ element.name }} </span>
        </li>
      </vue-draggable>
    </div>
    <!-- 表单项  -->
    <div class="form-content">
      <!-- 控件表单项 -->
      <div v-if="controlListSearchIsShow" class="widget-title">
        <div class="title" :class="controlIsShow ? 'w-45%!' : 'w-95%!'">
          {{ i18nt('control') }}{{ i18nt('formItem') }}
        </div>
        <base-input
          v-if="controlIsShow"
          v-model:value="controlSearch"
          :placeholder="i18nt('baseForm.pleaseInput') + i18nt('search')"
          class="input"
          @input="controlInputSearch"
        />
        <base-icon
          :icon="controlIsShow ? 'i-carbon:chevron-up' : 'i-carbon:chevron-down'"
          class="cursor-pointer m-l"
          :size="25"
          color="gray"
          @click="iconClick(0)"
        />
      </div>
      <div v-if="controlSearch && controlListSearch.length === 0" class="available">
        {{ i18nt('noData') }}
      </div>
      <vue-draggable
        v-if="controlIsShow"
        v-model="controlListSearch"
        tag="ul"
        class="form widget-form widget-item"
        :group="{ name: 'dragGroup', pull: 'clone', put: false }"
        :move="checkFieldMove"
        :clone="handleFieldWidgetClone"
        ghost-class="ghost"
        :sort="false"
        item-key="uiList"
        @end="onContainerDragFormEnd"
      >
        <template v-for="element in controlListSearch" :key="element.options.id">
          <li c class="widget-li" @dblclick="addFieldByDbClick(element as WidgetType)">
            <span> {{ element.options.name }} </span>
          </li>
        </template>
      </vue-draggable>
      <!-- 共用表单项 -->
      <div v-if="sharedListSearchIsShow" class="mt widget-title">
        <div class="title" :class="sharedIsShow ? 'w-45%!' : 'w-95%!'">
          {{ i18nt('shared') }}{{ i18nt('formItem') }}
        </div>
        <base-input
          v-if="sharedIsShow"
          v-model:value="sharedSearch"
          :placeholder="i18nt('baseForm.pleaseInput') + i18nt('search')"
          class="input"
          @input="sharedInputSearch"
        />
        <base-icon
          :icon="sharedIsShow ? 'i-carbon:chevron-up' : 'i-carbon:chevron-down'"
          class="cursor-pointer m-l"
          :size="25"
          color="gray"
          @click="iconClick(1)"
        />
      </div>
      <div v-if="sharedSearch && sharedListSearch.length === 0" class="available">
        {{ i18nt('noData') }}
      </div>
      <vue-draggable
        v-if="sharedIsShow"
        v-model="sharedListSearch"
        tag="ul"
        class="form widget-form widget-item"
        :group="{ name: 'dragGroup', pull: 'clone', put: false }"
        :move="checkFieldMove"
        :clone="handleFieldWidgetClone"
        ghost-class="ghost"
        :sort="false"
        item-key="basicFieldsshared"
        @end="onContainerDragFormEnd"
      >
        <template v-for="element in sharedListSearch" :key="element.options.id">
          <li c class="widget-li" @dblclick="addFieldByDbClick(element as WidgetType)">
            <span> {{ element.options.name }} </span>
          </li>
        </template>
      </vue-draggable>
      <!-- 项目表单项 -->
      <div v-if="projectListSearchIsShow" class="mt widget-title">
        <div class="title" :class="projectIsShow ? 'w-45%!' : 'w-95%!'">
          {{ designer.projectName }}{{ i18nt('formItem') }}
        </div>
        <base-input
          v-if="projectIsShow"
          v-model:value="projectSearch"
          :placeholder="i18nt('baseForm.pleaseInput') + i18nt('search')"
          class="input"
          @input="projectInputSearch"
        />
        <base-icon
          :icon="projectIsShow ? 'i-carbon:chevron-up' : 'i-carbon:chevron-down'"
          class="cursor-pointer m-l"
          :size="25"
          color="gray"
          @click="iconClick(2)"
        />
      </div>
      <vue-draggable
        v-if="projectIsShow"
        v-model="projectListSearch"
        tag="ul"
        class="form widget-form widget-item"
        :group="{ name: 'dragGroup', pull: 'clone', put: false }"
        :move="checkFieldMove"
        :clone="handleFieldWidgetClone"
        ghost-class="ghost"
        :sort="false"
        item-key="basicFieldsProject"
        @end="onContainerDragFormEnd"
      >
        <template v-for="element in projectListSearch" :key="element.options.id">
          <li c class="widget-li" @dblclick="addFieldByDbClick(element as WidgetType)">
            <span> {{ element.options.name }} </span>
          </li>
        </template>
      </vue-draggable>
      <div v-if="projectIsShow && projectListSearch.length === 0" class="available">
        {{ i18nt('noData') }}
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped>
// 左侧数据
#widget-panel {
  height: 100%;
  // 标题样式
  .widgetTitleType() {
    .widget-title {
      line-height: 30px;
      border-bottom: 1px solid #ebeef5;
      display: flex;
      justify-content: space-between;
      .title {
        font-size: 13px;
        width: 45%;
        font-weight: bold;
        color: #303133;
      }
      .input {
        width: 60% !important;
        height: 30px;
        margin-bottom: 12px;
      }
    }

    .available {
      margin-top: 10px;
      font-size: 15px;
      width: 100%;
      text-align: center;
      color: #999999;
    }
  }
  // li样式
  .widgetItemType() {
    .widget-item {
      padding-inline-start: 10px;
      width: calc(100% - 10px);
      margin-top: 12px;
      .widget-li {
        list-style-type: none;
        line-height: 30px;
        margin-bottom: 10px;
        padding: 0px 12px;
        cursor: move;
        background: #fff;
        border: 1px solid #e8e9eb;
        border-radius: 4px;
      }
      .table-widget-li {
        cursor: default;
        color: #c2c2c2;
      }
    }
  }
  // 表格
  .widget-table {
    .widgetTitleType();
    .widgetItemType();
    height: 98px;
  }
  // 表单
  .form-content {
    height: calc(100% - 110px);
    padding-bottom: 12px;
    overflow: hidden;
    // 公共
    .widgetTitleType();
    .widgetItemType();
    .widget-form {
      max-height: calc(100% - 124px);
      overflow: scroll;
    }
  }
}
</style>
