<script setup lang="ts">
import { type ComponentInternalInstance, getCurrentInstance } from 'vue';
import { widgetControlList } from './utils/designer-config';
import preview from './components/preview/preview.vue';
import widgetPanel from './components/widget-panel.vue';
import contentPanel from './components/content-panel.vue';
import { createDesigner } from './utils/designer';
import type { BasicFieldsType, CreateDesignerType, WidgetListType } from './utils/designer-type';

const props = withDefaults(
  defineProps<{
    // 左侧控件表单项数据
    basicFieldsContro: BasicFieldsType[];
    //  左侧共用表单项数据
    basicFieldsShared: BasicFieldsType[];
    // 左侧项目表单项数据
    basicFieldsProject: BasicFieldsType[];
    // 左侧项目名称
    projectName: string | null;
    // 组件高度
    formHeight: number;
    // 预览展示与否
    previewIsShow: boolean;
    // 组件状态 1 正常生成,2仅预览且预览不为弹窗
    previewType: number;
    // previewType=2 ,右侧回填数据
    widgetList: WidgetListType[];
    // 组件是否不可编辑(表格内部)
    tableItemComponentIsShow: boolean;
  }>(),
  {}
);
const {
  basicFieldsContro,
  basicFieldsShared,
  basicFieldsProject,
  projectName,
  previewType,
  widgetList,
  formHeight,
  previewIsShow,
  tableItemComponentIsShow
} = toRefs(props);
const currentInstance: ComponentInternalInstance | null = getCurrentInstance();
const designer = ref<CreateDesignerType>();
const formDesignerHeight = ref<string>('');
tryOnMounted(() => {
  designer.value = createDesigner(currentInstance);
  designer.value.formHeight = formHeight.value;

  designer.value.basicFieldsContro = widgetControlList.concat(basicFieldsContro.value);
  designer.value.basicFieldsShared = basicFieldsShared.value;
  designer.value.basicFieldsProject = basicFieldsProject.value;

  designer.value.projectName = projectName.value;

  formDesignerHeight.value = `${designer.value.formHeight}px`;

  designer.value.widgetList = widgetList.value;
  designer.value.previewType = previewType.value;
  designer.value.tableItemComponentIsShow = tableItemComponentIsShow.value;
});
watch([previewType, widgetList], newValue => {
  if (!designer.value) return;
  designer.value.widgetList = newValue[1];
  designer.value.previewType = newValue[0];
});
// 预览
const previewRef = ref();
const previewClick = () => {
  previewRef.value.handleOpenModal(designer.value);
};

// 返回数据
const designerHandle = () => {
  return designer.value;
};

defineExpose({
  designerHandle
});
</script>

<template>
  <div id="form-designer">
    <div v-if="previewType === 1" class="form-designer-content">
      <base-card class="mr w-350px">
        <widgetPanel v-if="designer" :designer="designer" />
      </base-card>
      <base-card>
        <base-button
          v-if="previewIsShow"
          :disabled="designer?.widgetList.length === 0 ? true : false"
          class="mb-12px"
          type="primary"
          @click="previewClick"
        >
          {{ i18nt('preview') }}
        </base-button>
        <contentPanel v-if="designer" :designer="designer" />
      </base-card>
    </div>
    <!-- 预览 -->
    <preview
      v-if="designer"
      ref="previewRef"
      :designer="designer"
      :preview-type="previewType"
      :table-item-component-is-show="tableItemComponentIsShow"
    />
  </div>
</template>

<style lang="less" scoped>
#form-designer {
  // background-color: #f3f3f3;
  .form-designer-content {
    display: flex;
    height: calc(100vh - v-bind(formDesignerHeight));
    :deep(.n-card__content) {
      height: 100%;
    }
  }
}
</style>
