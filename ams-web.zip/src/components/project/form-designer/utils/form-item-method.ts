import { NCheckbox, NCheckboxGroup, NRadio, NRadioGroup } from 'naive-ui';
import type { UploadFileInfo } from 'naive-ui';
import BaseInput from '@c/base-ui/base-input/base-input.vue';
import BaseSelect from '@c/base-ui/base-select/base-select.vue';
import BaseSwitch from '@c/base-ui/base-switch/base-switch.vue';
import BaseInputNumber from '@c/base-ui/base-input-number/base-input-number.vue';
import BaseUpload from '@c/base-ui/base-upload/base-upload.vue';
import BaseIcon from '@c/base-icon.vue';
import type { ValidateFormItemResultType } from './form-item-type';
import { ItemListDataType, ValidateFormItemResult, validateFeedbackObj } from './form-item-type';
import type { BasicFieldsOptionsType, OptionsType, WidgetType } from './designer-type';

import { API_PREFIX_CONFIG, CommonApis } from '@/service/apis/common/common';

export const FormItemMethodApis = {
  // 获取表单项列表
  getFormItemListApi: `${API_PREFIX_CONFIG}/GenerateForm/GetFormItems`,
  // 检查表单项
  validateFormItemApi: `${API_PREFIX_CONFIG}/GenerateForm/JudgeFormItemResult`
};

// 生成表单项
export const formItemComponentObj: {
  [key: number]: (rowData: OptionsType, disabled: boolean, validateIsShow?: boolean) => void;
} = {
  [ItemListDataType.number]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(BaseInputNumber, {
        value: rowData.itemValue === '' ? null : Number(rowData.itemValue),
        min: rowData.judgeType === 3 ? 0 : undefined,
        max: 10 ** 12 - 1,
        precision: rowData.judgeType === 3 ? undefined : 0,
        status: valiedateComponentState(rowData),
        disabled,
        onBlur: () => {
          handleGetValidateFormItemResult(rowData);
        },
        onUpdateValue: (v: number | null) => {
          handleUpdateFormItemValue(rowData, v ? String(v) : '');
        }
      }),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.string]: (rowData: OptionsType, disabled: boolean, validateIsShow?: boolean) => {
    return h('div', null, [
      h(BaseInput, {
        value: String(rowData.itemValue),
        disabled,
        onBlur: () => {
          handleGetValidateFormItemResult(rowData, validateIsShow);
        },
        onUpdateValue: (v: string) => {
          handleUpdateFormItemValue(rowData, String(v));
        }
      }),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.boolean]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(BaseSwitch, {
        value: rowData.itemValue,
        disabled,
        checkedValue: rowData.dataSourceList && rowData.dataSourceList.length !== 0 ? rowData.dataSourceList[1] : '1',
        uncheckedValue: rowData.dataSourceList && rowData.dataSourceList.length !== 0 ? rowData.dataSourceList[0] : '0',
        onUpdateValue: (v: string) => {
          rowData.operateIsShow = true;
          handleUpdateFormItemValue(rowData, String(v));
          handleGetValidateFormItemResult(rowData);
        }
      }),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.select]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(BaseSelect, {
        value: rowData.itemValue || null,
        disabled,
        options: rowData.dataSourceList.map(item => ({ label: item, value: item })),
        onUpdateValue: (v: string) => {
          handleUpdateFormItemValue(rowData, v && String(v));
          handleGetValidateFormItemResult(rowData);
        }
      }),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.multiSelct]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(BaseSelect, {
        value: rowData.itemValue === '' ? null : rowData.itemValue.split(','),
        multiple: true,
        disabled,
        options: rowData.dataSourceList.map(item => ({ label: item, value: item })),
        onUpdateValue: (v: string[]) => {
          handleUpdateFormItemValue(rowData, v.join(','));
          handleGetValidateFormItemResult(rowData);
        }
      }),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.radio]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(
        NRadioGroup,
        {
          value: rowData.itemValue,
          disabled,
          onUpdateValue: v => {
            handleUpdateFormItemValue(rowData, v);
            handleGetValidateFormItemResult(rowData);
          }
        },
        {
          default: () =>
            rowData.dataSourceList.map(item => h(NRadio, { key: item, value: item }, { default: () => item }))
        }
      ),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.checkbox]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(
        NCheckboxGroup,
        {
          value: rowData.itemValue === '' ? null : rowData.itemValue.split(','),
          disabled,
          onUpdateValue: v => {
            handleUpdateFormItemValue(rowData, v.join(','));
            handleGetValidateFormItemResult(rowData);
          }
        },
        {
          default: () => rowData.dataSourceList.map(item => h(NCheckbox, { value: item, label: item }))
        }
      ),
      renderValidateFeedback(rowData)
    ]);
  },
  [ItemListDataType.upload]: (rowData: OptionsType, disabled: boolean) => {
    return h('div', null, [
      h(BaseUpload, {
        loading: isLoading.value,
        disabled: isLoading.value || disabled,
        value: String(rowData.itemValue),
        defaultUpload: false,
        showFileList: false,
        max: 999,
        onChange: async (options: { file: UploadFileInfo; fileList: UploadFileInfo[] }) => {
          if (!options.file.file) return;
          const params = new FormData();
          params.append('file', options.file.file ?? '');
          const { data } = await imgChange({
            data: params
          });
          handleUpdateFormItemValueName(rowData, String(options.file.name));
          handleUpdateFormItemValue(rowData, String(data.value));
          options.fileList = [];
        }
      }),
      rowData.attachmentName
        ? h(
            'div',
            {
              style: {
                cursor: 'pointer'
              }
            },
            [
              h(
                'span',
                {
                  style: {
                    marginRight: '10px',
                    color: 'var(--n-color-target)'
                  },
                  onClick: () => {
                    window.open(`${window.$CONFIG?.projectConfig?.ossUrl}${rowData.itemValue}`, '_blank');
                  }
                },
                rowData.attachmentName
              ),
              disabled
                ? ''
                : h(BaseIcon, {
                    icon: 'i-carbon:trash-can',
                    size: 15,
                    color: 'var(--error-color)',
                    onClick: () => {
                      handleUpdateFormItemValueName(rowData, String(''));
                      handleUpdateFormItemValue(rowData, String(''));
                    }
                  })
            ]
          )
        : '',
      renderValidateFeedback(rowData)
    ]);
  }
};
// 数值组件验证状态
const valiedateComponentState = (rowData: OptionsType) =>
  rowData?.result === ValidateFormItemResult.fail && rowData.currentValue ? 'error' : 'success';

// 附件上传
const { execute: imgChange, isLoading } = useAxiosPost<number>(CommonApis.uploadFileApi);
// 更新表单列表 - ItemValue(附件)
const handleUpdateFormItemValueName = (rowData: OptionsType, val: string) => {
  if (rowData) {
    rowData.attachmentName = val;
  }
};

// 更新表单列表
const handleUpdateFormItemValue = (rowData: OptionsType, val: string) => {
  rowData.itemValue = val;
  if (rowData.dataType === 3) {
    if (!val) {
      rowData.result = 0;
      rowData.currentValue = '';
      rowData.maxItemValueIsShow = false;
    }
  }
};

// 获取校验表单项结果
const handleGetValidateFormItemResult = async (rowData: OptionsType, validateIsShow?: boolean) => {
  if (!rowData.itemValue) {
    handleUpdateFormItemValidateResult(rowData, 0, undefined, false);
    return;
  }
  try {
    if (rowData.isCheck === 0) {
      const isShow = rowData.maxItemValue && rowData.itemValue.length > rowData.maxItemValue;
      handleUpdateFormItemValidateResult(rowData, isShow ? 0 : 1, `${rowData.maxItemValue}`, !!isShow);
    } else {
      if (rowData.maxItemValue && rowData.itemValue.length > rowData.maxItemValue) {
        handleUpdateFormItemValidateResult(rowData, 0, `${rowData.maxItemValue}`, true);
        return;
      }
      // 自有ui下不走别的验证
      if (validateIsShow) return;
      if (rowData.itemValue === '' || rowData.itemValue === null) return;
      const { data } = await useAxiosGet<ValidateFormItemResultType>(
        FormItemMethodApis.validateFormItemApi,
        {
          itemId: rowData.formId,
          itemValue: rowData.itemValue
        },
        __,
        { immediate: true }
      );
      if (data.value !== __) {
        rowData.result = data.value.result;
        rowData.currentValue = data.value.currentValue;
        rowData.maxItemValueIsShow = false;

        rowData.type = data.value.type;
        rowData.standard = data.value.standard;

        handleUpdateFormItemValidateResult(
          rowData,
          data.value?.result,
          data.value?.currentValue,
          false,
          data.value.type,
          data.value.standard,
          data.value.isContainMax,
          data.value.isContainMin
        );
      }
    }
  } catch (error) {
    console.log('获取校验表单项结果异常：', error);
  }
};

// 更新表单列表
const handleUpdateFormItemValidateResult = (
  rowData: OptionsType,
  result: ValidateFormItemResult,
  currentValue?: string,
  maxItemValueIsShow?: boolean,
  type?: number,
  standard?: string,
  isContainMax?: number,
  isContainMin?: number
) => {
  if (rowData) {
    rowData.result = result;
    rowData.currentValue = currentValue;
    rowData.maxItemValueIsShow = maxItemValueIsShow;
    rowData.type = type || 1;
    rowData.standard = standard || '';
    rowData.isContainMax = isContainMax;
    rowData.isContainMin = isContainMin;
  }
};

// 验证样式组件
const renderValidateFeedback = (rowData: OptionsType) => {
  return (
    rowData?.result === 0 &&
    rowData.currentValue &&
    (rowData.maxItemValueIsShow
      ? h(
          'div',
          {
            style: {
              color: 'var(--error-color)',
              marginTop: '-5px'
            }
          },
          rowData.name + i18nt('validateFailMaxItemValue') + rowData.maxItemValue
        )
      : h(
          'div',
          {
            style: {
              color: 'var(--error-color)',
              marginTop: '5px',
              lineHeight: '20px'
            }
          },
          validateFeedbackHandle(rowData)
        ))
  );
};
// 验证报错返回值处理
const validateFeedbackHandle = (rowData: OptionsType) => {
  const { currentValue, standard, type, isContainMax, isContainMin } = rowData;
  const item = validateFeedbackObj[type || 1];
  let strList: string[] = [];
  if (type === 4) {
    strList = standard ? standard.replace(/\[|\]/g, '').split(',') : [];
  }
  switch (type) {
    case 1:
      return `${i18nt('validateFail')},${item.standard} ${standard},${item.currentValue}${currentValue},${item.type}`;
    case 2:
      return `${i18nt('validateFail')},${item.standard} ${standard},${item.currentValue}${currentValue},${item.type}`;
    case 3:
      return `${item.type}`;
    case 4:
      return `${i18nt('validateFail')},${item.standard} ${standard},
      ${isContainMin === 1 ? i18nt('inclusive') : i18nt('exclusive')}
      ${strList[0]}
       ${isContainMax === 1 ? i18nt('inclusive') : i18nt('exclusive')} ${strList[1]},
       ${item.currentValue}${currentValue},${item.type}`;
    case 5:
      return `${i18nt('validateFail')},${item.standard} ${standard}${i18nt('bit')},${item.currentValue}${currentValue},${item.type}`;
    default:
      return '';
  }
};
// 将table结构转化为list(布尔值暂时不作处理)
export const handleTableTransformList = (formItemList: WidgetType) => {
  return formItemList.rows.flatMap(row => row.cols.flatMap(col => col.widgetList.map(widget => widget.options)));
};

// 循环校验表单是否为空
export const handleValidateChangeMachineForm = (formItemList: BasicFieldsOptionsType[]) => {
  let isOk = true;
  let content = ``;
  formItemList.forEach(item => {
    if (item.itemValue === '' || item.itemValue === null) {
      isOk = false;
      content += `${i18nt('notEmpty', { val: item.name })}\n`;
    }
  });
  if (!isOk) $notification.warning({ title: i18nt('tips'), content });
  return isOk;
};

// 循环校验表单是否有长度报错
export const handleValidateFormIsMaxItemValue = (formItemList: BasicFieldsOptionsType[]) => {
  const isShow = formItemList.some(ele => ele.maxItemValueIsShow === true);
  if (isShow) $notification.warning({ title: i18nt('tips'), content: i18nt('validateFormIsMaxItemValueTips') });
  return isShow;
};
// 循环校验表单是否通过
export const handleValidateFormIsPass = (formItemList: BasicFieldsOptionsType[]) => {
  const isShow = formItemList.every(ele => ele.result === ValidateFormItemResult.pass);
  if (!isShow) $notification.warning({ title: i18nt('tips'), content: i18nt('validateFormIsPassTips') });
  return isShow;
};
// 表格中是否有空(暂存使用)
export const tableLenght = (formItemList: BasicFieldsOptionsType[]) => {
  const isShow = formItemList
    ?.filter(ele => ele.formId !== '0' && ele.dataType !== ItemListDataType.boolean)
    .some(item => {
      return item.itemValue === '' || item.itemValue === null;
    });
  return isShow;
};
// 循环校验表单是否通过(暂存使用)
export const handleValidateStagingFormIsPass = (formItemList: BasicFieldsOptionsType[]) => {
  const list = formItemList?.filter(
    ele =>
      ele.formId !== '0' &&
      ele.dataType !== ItemListDataType.boolean &&
      ele.itemValue !== '' &&
      ele.itemValue !== null &&
      ele.itemValue
  );
  const res = every(list, { result: ValidateFormItemResult.pass });
  if (!res) $notification.warning({ title: i18nt('tips'), content: i18nt('validateFormIsPassTips') });
  return res;
};
