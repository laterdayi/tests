import type { ComponentInternalInstance } from 'vue';
import type { BasicFieldsType, ContainersType, RowsType, WidgetType } from './designer-type';

// 右侧表格所需
export const containers: ContainersType[] = [
  {
    type: 'table',
    name: i18nt('table'),
    rows: [],
    options: {
      id: '',

    }
  },
  {
    type: 'table-cell-widget',
    name: i18nt('cell'),
    outside: true,
    widgetList: [],
    merged: false,
    options: {
      id: '',

    }
  }
];

export const widgetControlList: BasicFieldsType[] = [
  {
    type: 'string',
    options: {
      formId: '0',
      name: '标题生成-控件',
      category: 1,
      dataType: 2,
      dataSourceList: [],
      isCheck: 0,
      judgeType: 2,
      finalResult: 0,
      maxItemValue: 100,
      id: '',
      attachment: 1,
      belongTo: 1,
      apply: 1,
      itemValue: '',
      result: 1,
      isHideTitle: 1
    }
  }
];
// 随机ID
export const generateId = function () {
  return Math.floor(
    Math.random() * 100000 + Math.random() * 20000 + Math.random() * 5000
  );
};

export const deepClone = function (
  origin:
  WidgetType |
  WidgetType[] |
  RowsType |
  ComponentInternalInstance |
  string |
  number |
  null |
  void
) {
  if (origin === undefined) {
    return undefined;
  }

  return JSON.parse(JSON.stringify(origin));
};
