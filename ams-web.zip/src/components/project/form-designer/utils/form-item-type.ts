import type { WidgetType } from './designer-type';

// 表单类型
export enum ItemListDataType {
  // 数字
  number = 1,
  // 字符串
  string,
  // 布尔
  boolean,
  // 单选 selct
  select,
  // 多选 select
  multiSelct,
  // 单选
  radio,
  // 多选
  checkbox,
  // 上传
  upload
}
export const itemTypeObj: {
  [key: number]: string;
} = {
  1: 'number',
  2: 'string',
  3: 'boolean',
  4: 'select',
  5: 'multiSelct',
  6: 'radio',
  7: 'checkbox',
  8: 'systemImport',
  9: 'upload',
  10: 'numberInput'
};
export const validateFeedbackObj: {
  [key: number]: {
    standard: string;
    type: string;
    currentValue: string;
  };
} = {
  1: {
    type: i18nt('errorExist'),
    standard: i18nt('errorOptionIs'),
    currentValue: i18nt('yourCurrentOptionIs')
  },
  2: {
    type: i18nt('incorrectInputValue'),
    standard: i18nt('errorValueIs'),
    currentValue: i18nt('inputValueIs')
  },
  3: {
    type: i18nt('validateFail'),
    standard: '',
    currentValue: ''
  },
  4: {
    type: i18nt('outOfRange'),
    standard: i18nt('rangeIs'),
    currentValue: i18nt('currentValueIs')
  },
  5: {
    type: i18nt('decimalPrecisionMismatch'),
    standard: i18nt('standardDecimalPrecisionIs'),
    currentValue: i18nt('currentValueIs')
  }
};
// 获取表单项
export type FormItemListType = {
  fromResult: number;
  formName?: string;
  table: WidgetType;
};
// 校验表单项
export type ValidateFormItemResultType = {
  currentValue: string;
  itemValue: string;
  standard: string;
  type: number;
  result: ValidateFormItemResult;
  isContainMax: number
  isContainMin: number
};
// 校验结果
export enum ValidateFormItemResult {
  // 不通过
  fail,
  // 通过
  pass
}
