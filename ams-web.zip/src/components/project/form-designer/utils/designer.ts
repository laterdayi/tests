import type { ComponentInternalInstance } from 'vue';
import { containers, deepClone, generateId } from './designer-config';
import type { ColsType, CreateDesignerType, EvtType, RowsType, WidgetListType, WidgetType } from './designer-type';

// Designer整体类
export const createDesigner = (vueInstance: ComponentInternalInstance | null): CreateDesignerType => {
  return {
    // 左侧控件数据
    basicFieldsContro: [],
    // 左侧共用数据
    basicFieldsShared: [],
    // 左侧项目数据
    basicFieldsProject: [],
    // 左侧项目名称
    projectName: null,
    // 组件类型 1生成+弹窗预览,2页面预览
    previewType: 1,
    // 组件高度
    formHeight: 116,
    // 组件是否不可编辑(表格内部)
    tableItemComponentIsShow: false,
    // 整体配置
    widgetList: [],
    formConfig: null,
    selectedId: null,
    selectedWidget: null,
    // 选中组件名称（唯一）
    selectedWidgetName: null,
    vueInstance,
    // 左侧拖拽克隆处理(表格)
    copyNewContainerWidget(origin: WidgetType) {
      const newCon = deepClone(origin);
      newCon.id = newCon.type.replace(/-/g, '') + generateId();
      newCon.options.id = newCon.id;

      if (newCon.type === 'table') {
        // 处理行
        for (let i = 0; i < 2; i++) {
          const newRow: RowsType = {
            cols: this.newCellHandle()
          };
          newRow.id = `table-row-${generateId()}`;
          newRow.merged = false;
          newCon.rows.push(newRow);
        }
      }
      delete newCon.displayName;
      return newCon;
    },
    // 处理列(表格)
    newCellHandle() {
      const newCellList = [];
      for (let i = 0; i < 2; i++) {
        const newCell = deepClone(this.getContainerByType('table-cell-widget'));
        newCell.id = `table-cell-widget-${generateId()}`;
        newCell.options.id = newCell.id;
        newCell.merged = false;
        newCell.options.colspan = 1;
        newCell.options.rowspan = 1;
        newCellList.push(newCell);
      }
      return newCellList;
    },
    // 按类型获取容器
    getContainerByType(typeName: string) {
      const allWidgets = [
        ...containers,
        ...this.basicFieldsContro,
        ...this.basicFieldsShared,
        ...this.basicFieldsProject
      ];
      let foundCon = null;
      allWidgets.forEach(con => {
        if (!!con.type && con.type === typeName) {
          foundCon = con;
        }
      });
      return foundCon;
    },
    // 添加左侧表格点击事件
    addContainerByDbClick(container: WidgetType) {
      const newCon = this.copyNewContainerWidget(container);
      this.widgetList.push(newCon);
      this.setSelected(newCon);
    },
    // 左侧拖拽克隆处理(组件)
    copyNewFieldWidget(origin: WidgetType) {
      const newWidget = deepClone(origin);
      const tempId = generateId();
      newWidget.id = newWidget.type.replace(/-/g, '') + tempId;
      newWidget.options.id = newWidget.id;
      newWidget.options.name = newWidget.options.name || newWidget.type.toLowerCase();
      delete newWidget.displayName;
      return newWidget;
    },
    // 拖拽触碰右侧(组件)
    checkFieldMove(evt: EvtType) {
      if (!!evt.draggedContext && !!evt.draggedContext.element) {
        const wgType = `${evt.draggedContext.element.type}`;
        if (evt.to) {
          if (evt.to.className === 'sub-form-table' && wgType === 'slot') {
            return false;
          }
        }
      }
      return true;
    },
    addFieldByDbClick(widget: WidgetType) {
      const newWidget = this.copyNewFieldWidget(widget);
      if (!!this.selectedWidget && !!this.selectedWidget.widgetList) {
        this.selectedWidget.widgetList.push(newWidget);
      } else {
        this.widgetList.push(newWidget);
      }

      this.setSelected(newWidget);
    },
    // 表格 单元格列处理
    insertTableCol(widget: WidgetListType, insertPos: number, curRow: number, leftFlag: boolean) {
      // 初步确定插入列位置
      if (!widget.rows) return;
      let newColIdx = leftFlag ? insertPos : insertPos + 1;
      if (!leftFlag) {
        // 继续向右寻找同行第一个未被合并的单元格
        let tmpColIdx = newColIdx;
        let colFoundFlag = false;
        while (tmpColIdx < widget.rows[curRow].cols.length) {
          if (!widget.rows[curRow].cols[tmpColIdx].merged) {
            newColIdx = tmpColIdx;
            colFoundFlag = true;
            break;
          } else {
            tmpColIdx++;
          }

          if (!colFoundFlag) {
            newColIdx = widget.rows[curRow].cols.length;
          }
        }
      }

      widget.rows.forEach(row => {
        const newCol = deepClone(this.getContainerByType('table-cell-widget'));
        newCol.id = `table-cell-widget-${generateId()}`;
        newCol.options.id = newCol.id;
        newCol.merged = false;
        newCol.options.colspan = 1;
        newCol.options.rowspan = 1;
        newCol.widgetList.length = 0;
        row.cols.splice(newColIdx, 0, newCol);
      });

      let rowNo = 0;
      while (newColIdx < widget.rows[0].cols.length - 1 && rowNo < widget.rows.length) {
        // 越界判断
        const cellOfNextCol = widget.rows[rowNo].cols[newColIdx + 1];
        // 确定插入位置右侧列的单元格是否为合并单元格
        const colMerged = cellOfNextCol.merged;
        if (colMerged) {
          const colArray = widget.rows[rowNo].cols;
          let unMergedCell = {
            options: {
              colspan: 0,
              rowspan: 0
            }
          };
          let startColIndex = null;
          for (let i = newColIdx; i >= 0; i--) {
            // 查找该行已合并的主单元格
            if (!colArray[i].merged && colArray[i].options.colspan > 1) {
              startColIndex = i;
              unMergedCell = colArray[i];
              break;
            }
          }

          if (unMergedCell.options) {
            // 如果有符合条件的unMergedCell
            const newColspan = unMergedCell.options.colspan + 1;
            this.setPropsOfMergedCols(widget.rows, rowNo, startColIndex, newColspan, unMergedCell.options.rowspan);
            rowNo += unMergedCell.options.rowspan;
          } else {
            rowNo += 1;
          }
        } else {
          // rowNo += 1
          rowNo += cellOfNextCol.options.rowspan || 1;
        }
      }
    },
    setPropsOfMergedCols(rowArray, startRowIndex, startColIndex, newColspan, rowspan) {
      for (let i = startRowIndex; i < startRowIndex + rowspan; i++) {
        startColIndex = startColIndex || 0;
        for (let j = startColIndex; j < startColIndex + newColspan; j++) {
          if (i === startRowIndex && j === startColIndex) {
            // 合并后的主单元格
            rowArray[i].cols[j].options.colspan = newColspan;
            continue;
          }

          rowArray[i].cols[j].merged = true;
          rowArray[i].cols[j].options.colspan = newColspan;
          rowArray[i].cols[j].widgetList = [];
        }
      }
    },
    // 表格 单元格行处理
    insertTableRow(widget, insertPos, cloneRowIdx, curCol, aboveFlag) {
      // 初步确定插入行位置
      if (!widget.rows) return;
      let newRowIdx = aboveFlag ? insertPos : insertPos + 1;
      if (!aboveFlag) {
        // 继续向下寻找同列第一个未被合并的单元格
        let tmpRowIdx = newRowIdx;
        let rowFoundFlag = false;
        while (tmpRowIdx < widget.rows.length) {
          if (!widget.rows[tmpRowIdx].cols[curCol].merged) {
            newRowIdx = tmpRowIdx;
            rowFoundFlag = true;
            break;
          } else {
            tmpRowIdx++;
          }
        }

        if (!rowFoundFlag) {
          newRowIdx = widget.rows.length;
        }
      }

      const newRow: RowsType = deepClone(widget.rows[cloneRowIdx]);
      newRow.id = `table-row-${generateId()}`;
      newRow.merged = false;
      newRow.cols.forEach((col: ColsType) => {
        col.id = `table-cell-widget-${generateId()}`;
        col.options.id = col.id;
        col.merged = false;
        col.options.colspan = 1;
        col.options.rowspan = 1;
        col.widgetList.length = 0;
      });
      widget.rows.splice(newRowIdx, 0, newRow);

      let colNo = 0;
      while (newRowIdx < widget.rows.length - 1 && colNo < widget.rows[0].cols.length) {
        // 越界判断
        const cellOfNextRow = widget.rows[newRowIdx + 1].cols[colNo];
        // 确定插入位置下一行的单元格是否为合并单元格
        const rowMerged = cellOfNextRow.merged;
        if (rowMerged) {
          const rowArray = widget.rows;
          let unMergedCell = {
            options: {
              colspan: 0,
              rowspan: 0
            }
          };
          let startRowIndex = null;
          for (let i = newRowIdx; i >= 0; i--) {
            // 查找该行已合并的主单元格
            if (!rowArray[i].cols[colNo].merged && rowArray[i].cols[colNo].options.rowspan > 1) {
              startRowIndex = i;
              unMergedCell = rowArray[i].cols[colNo];
              break;
            }
          }

          if (unMergedCell.options) {
            // 如果有符合条件的unMergedCell
            const newRowspan = unMergedCell.options.rowspan + 1;
            this.setPropsOfMergedRows(widget.rows, startRowIndex, colNo, unMergedCell.options.colspan, newRowspan);
            colNo += unMergedCell.options.colspan;
          } else {
            colNo += 1;
          }
        } else {
          // colNo += 1
          colNo += cellOfNextRow.options.colspan || 1;
        }
      }
    },
    setPropsOfMergedRows(rowArray, startRowIndex, startColIndex, colspan, newRowspan) {
      startRowIndex = startRowIndex || 0;
      for (let i = startRowIndex; i < startRowIndex + newRowspan; i++) {
        startColIndex = startColIndex || 0;
        for (let j = startColIndex; j < startColIndex + colspan; j++) {
          if (i === startRowIndex && j === startColIndex) {
            rowArray[i].cols[j].options.rowspan = newRowspan;
            continue;
          }
          rowArray[i].cols[j].merged = true;
          rowArray[i].cols[j].options.rowspan = newRowspan;
          rowArray[i].cols[j].widgetList = [];
        }
      }
    },
    // 合并行处理
    mergeTableCol(rowArray, colArray, curRow, curCol, leftFlag, cellWidget) {
      const mergedColIdx = leftFlag ? curCol : curCol + colArray[curCol].options.colspan;

      let remainedColIdx = leftFlag ? curCol - 1 : curCol;
      if (leftFlag) {
        // 继续向左寻找同行未被合并的第一个单元格
        let tmpColIdx = remainedColIdx;
        while (tmpColIdx >= 0) {
          if (!rowArray[curRow].cols[tmpColIdx].merged) {
            remainedColIdx = tmpColIdx;
            break;
          } else {
            tmpColIdx--;
          }
        }
      }

      if (!!colArray[mergedColIdx].widgetList && colArray[mergedColIdx].widgetList.length > 0) {
        // 保留widgetList
        if (!colArray[remainedColIdx].widgetList || colArray[remainedColIdx].widgetList.length === 0) {
          colArray[remainedColIdx].widgetList = deepClone(colArray[mergedColIdx].widgetList);
        }
      }

      const newColspan = colArray[mergedColIdx].options.colspan * 1 + colArray[remainedColIdx].options.colspan * 1;
      this.setPropsOfMergedCols(rowArray, curRow, remainedColIdx, newColspan, cellWidget.options.rowspan);
    },
    // 合并整行
    mergeTableWholeRow(rowArray, colArray, rowIndex, colIndex) {
      // 整行所有单元格行高不一致不可合并
      const startRowspan = rowArray[rowIndex].cols[0].options.rowspan;
      let unmatchedFlag = false;
      for (let i = 1; i < rowArray[rowIndex].cols.length; i++) {
        if (rowArray[rowIndex].cols[i].options.rowspan !== startRowspan) {
          unmatchedFlag = true;
          break;
        }
      }
      if (unmatchedFlag) {
        $message.error(i18nt('formDesignerTips'));
        return;
      }

      const widgetListCols = colArray.filter(colItem => {
        return !colItem.merged && !!colItem.widgetList && colItem.widgetList.length > 0;
      });
      if (!!widgetListCols && widgetListCols.length > 0) {
        // 保留widgetList
        if (
          widgetListCols[0].id !== colArray[0].id &&
          (!colArray[0].widgetList || colArray[0].widgetList.length <= 0)
        ) {
          colArray[0].widgetList = deepClone(widgetListCols[0].widgetList);
        }
      }

      this.setPropsOfMergedCols(rowArray, rowIndex, 0, colArray.length, colArray[colIndex].options.rowspan);
    },
    // 合并上方单元格
    mergeTableRow(rowArray, curRow, curCol, aboveFlag, cellWidget) {
      const mergedRowIdx = aboveFlag ? curRow : curRow + cellWidget.options.rowspan;
      let remainedRowIdx = aboveFlag ? curRow - 1 : curRow;
      if (aboveFlag) {
        // 继续向上寻找同列未被合并的第一个单元格
        let tmpRowIdx = remainedRowIdx;
        while (tmpRowIdx >= 0) {
          if (!rowArray[tmpRowIdx].cols[curCol].merged) {
            remainedRowIdx = tmpRowIdx;
            break;
          } else {
            tmpRowIdx--;
          }
        }
      }

      if (
        !!rowArray[mergedRowIdx].cols[curCol].widgetList &&
        rowArray[mergedRowIdx].cols[curCol].widgetList.length > 0
      ) {
        // 保留widgetList
        if (
          !rowArray[remainedRowIdx].cols[curCol].widgetList ||
          rowArray[remainedRowIdx].cols[curCol].widgetList.length === 0
        ) {
          rowArray[remainedRowIdx].cols[curCol].widgetList = deepClone(rowArray[mergedRowIdx].cols[curCol].widgetList);
        }
      }
      const newRowspan =
        rowArray[mergedRowIdx].cols[curCol].options.rowspan * 1 +
        rowArray[remainedRowIdx].cols[curCol].options.rowspan * 1;
      this.setPropsOfMergedRows(rowArray, remainedRowIdx, curCol, cellWidget.options.colspan, newRowspan);
    },
    // 合并整列
    mergeTableWholeCol(rowArray, colArray, rowIndex, colIndex) {
      // 整列所有单元格列宽不一致不可合并
      const startColspan = rowArray[0].cols[colIndex].options.colspan;
      let unmatchedFlag = false;
      for (let i = 1; i < rowArray.length; i++) {
        if (rowArray[i].cols[colIndex].options.colspan !== startColspan) {
          unmatchedFlag = true;
          break;
        }
      }
      if (unmatchedFlag) {
        $message.error(i18nt('formDesignerTips1'));
        return;
      }

      const widgetListCols: ColsType[] = [];
      rowArray.forEach(rowItem => {
        const tempCell = rowItem.cols[colIndex];
        if (!tempCell.merged && !!tempCell.widgetList && tempCell.widgetList.length > 0) {
          widgetListCols.push(tempCell);
        }
      });

      const firstCellOfCol = rowArray[0].cols[colIndex];
      if (!!widgetListCols && widgetListCols.length > 0) {
        // 保留widgetList
        if (
          widgetListCols[0].id !== firstCellOfCol.id &&
          (!firstCellOfCol.widgetList || firstCellOfCol.widgetList.length <= 0)
        ) {
          firstCellOfCol.widgetList = deepClone(widgetListCols[0].widgetList);
        }
      }

      this.setPropsOfMergedRows(rowArray, 0, colIndex, firstCellOfCol.options.colspan, rowArray.length);
    },
    // 撤销合并列
    undoMergeTableRow(rowArray, rowIndex, colIndex, colspan, rowspan) {
      this.setPropsOfSplitRow(rowArray, rowIndex, colIndex, colspan, rowspan);
    },
    setPropsOfSplitRow(rowArray, startRowIndex, startColIndex, colspan, rowspan) {
      for (let i = startRowIndex; i < startRowIndex + rowspan; i++) {
        for (let j = startColIndex; j < startColIndex + colspan; j++) {
          rowArray[i].cols[j].merged = false;
          rowArray[i].cols[j].options.rowspan = 1;
          rowArray[i].cols[j].options.colspan = 1;
        }
      }
    },
    // 撤销合并行
    undoMergeTableCol(rowArray, rowIndex, colIndex, colspan, rowspan) {
      this.setPropsOfSplitCol(rowArray, rowIndex, colIndex, colspan, rowspan);
    },
    setPropsOfSplitCol(rowArray, startRowIndex, startColIndex, colspan, rowspan) {
      for (let i = startRowIndex; i < startRowIndex + rowspan; i++) {
        for (let j = startColIndex; j < startColIndex + colspan; j++) {
          rowArray[i].cols[j].merged = false;
          rowArray[i].cols[j].options.rowspan = 1;
          rowArray[i].cols[j].options.colspan = 1;
        }
      }
    },
    // 删除整列
    deleteTableWholeCol(rowArray, colIndex) {
      // 需考虑删除的是合并列！！
      let onlyOneColFlag = true;
      rowArray.forEach(ri => {
        if (ri.cols[0].options.colspan !== rowArray[0].cols.length) {
          onlyOneColFlag = false;
        }
      });
      // 仅剩一列则不可删除！！
      if (onlyOneColFlag) {
        $message.error(i18nt('formDesignerTips2'));
        return;
      }

      // 整列所有单元格列宽不一致不可删除！！
      const startColspan = rowArray[0].cols[colIndex].options.colspan;
      let unmatchedFlag = false;
      for (let i = 1; i < rowArray.length; i++) {
        if (rowArray[i].cols[colIndex].options.colspan !== startColspan) {
          unmatchedFlag = true;
          break;
        }
      }
      if (unmatchedFlag) {
        $message.error(i18nt('formDesignerTips3'));
        return;
      }

      rowArray.forEach(rItem => {
        rItem.cols.splice(colIndex, startColspan);
      });
    },
    // 删除整行
    deleteTableWholeRow(rowArray, rowIndex) {
      // 需考虑删除的是合并行！！
      let onlyOneRowFlag = true;
      rowArray[0].cols.forEach(ci => {
        if (ci.options.rowspan !== rowArray.length) {
          onlyOneRowFlag = false;
        }
      });
      // 仅剩一行则不可删除！！
      if (onlyOneRowFlag) {
        $message.error(i18nt('formDesignerTips4'));
        return;
      }

      // 整行所有单元格行高不一致不可删除！！
      const startRowspan = rowArray[rowIndex].cols[0].options.rowspan;
      let unmatchedFlag = false;
      for (let i = 1; i < rowArray[rowIndex].cols.length; i++) {
        if (rowArray[rowIndex].cols[i].options.rowspan !== startRowspan) {
          unmatchedFlag = true;
          break;
        }
      }
      if (unmatchedFlag) {
        $message.error(i18nt('formDesignerTips5'));
        return;
      }

      rowArray.splice(rowIndex, startRowspan);
    },
    // 上移组件
    moveUpWidget(parentList, indexOfParentList) {
      if (parentList) {
        if (indexOfParentList === 0) {
          $message.error(i18nt('formDesignerTips6'));
          return;
        }

        const tempWidget = parentList[indexOfParentList];
        parentList.splice(indexOfParentList, 1);
        parentList.splice(indexOfParentList - 1, 0, tempWidget);
      }
    },
    // 下移组件
    moveDownWidget(parentList, indexOfParentList) {
      if (parentList) {
        if (indexOfParentList === parentList.length - 1) {
          $message.error(i18nt('formDesignerTips7'));
          return;
        }

        const tempWidget = parentList[indexOfParentList];
        parentList.splice(indexOfParentList, 1);
        parentList.splice(indexOfParentList + 1, 0, tempWidget);
      }
    },
    // 插入新行/追加表格新行
    appendTableRow(widget) {
      // 确定插入行位置
      const rowIdx = widget.rows.length;
      const newRow = deepClone(widget.rows[widget.rows.length - 1]);
      newRow.id = `table-row-${generateId()}`;
      newRow.merged = false;
      newRow.cols.forEach((col: ColsType) => {
        col.id = `table-cell-widget-${generateId()}`;
        col.options.id = col.id;
        col.merged = false;
        col.options.colspan = 1;
        col.options.rowspan = 1;
        col.widgetList.length = 0;
      });
      widget.rows.splice(rowIdx, 0, newRow);
    },
    // 插入新列/追加表格新列
    appendTableCol(widget) {
      // 确定插入列位置
      const colIdx = widget.rows[0].cols.length;
      widget.rows.forEach(row => {
        const newCol = deepClone(this.getContainerByType('table-cell-widget'));
        newCol.id = `table-cell-widget-${generateId()}`;
        newCol.options.id = newCol.id;
        newCol.merged = false;
        newCol.options.colspan = 1;
        newCol.options.rowspan = 1;
        newCol.widgetList.length = 0;
        row.cols.splice(colIdx, 0, newCol);
      });
    },
    // 复制组件
    cloneContainer(containWidget) {
      if (containWidget.type === 'table') {
        const newTable = deepClone(this.getContainerByType('table'));
        newTable.id = newTable.type + generateId();
        newTable.options.id = newTable.id;
        containWidget.rows.forEach(tRow => {
          const newRow = deepClone(tRow);
          newRow.id = `table-row-${generateId()}`;
          newRow.cols.forEach((col: ColsType) => {
            col.id = `table-cell-widget-${generateId()}`;
            col.options.id = col.id;
            // 清空组件列表
            col.widgetList = [];
          });
          newTable.rows.push(newRow);
        });

        return newTable;
      }
      // 其他容器组件不支持clone操作
      return null;
    },
    emitEvent(evtName, evtData) {
      // 用于兄弟组件发射事件
      if (this.vueInstance) {
        this.vueInstance.emit(evtName, evtData);
      }
    },
    // 新增选中事件
    setSelected(selected: WidgetListType) {
      if (!selected) {
        this.clearSelected();
        return;
      }
      this.selectedWidget = selected;
      if (selected.id) {
        this.selectedId = selected.id;
        this.selectedWidgetName = selected.options.id;
      }
    },
    // 清除选中事件(在右侧页面没有内容时)
    clearSelected() {
      this.selectedId = null;
      this.selectedWidgetName = null;
      this.selectedWidget = null;
    },
    // 预览弹窗操作
    previewModal() {
      const { rows } = this.widgetList[0];
      this.previewModalHandle(rows);
    },
    // 清除数据
    previewModalHandle(item: RowsType[] | ColsType[] | WidgetType[]) {
      item.forEach((ele: RowsType | ColsType | WidgetType) => {
        if (Array.isArray((ele as RowsType).cols)) {
          this.previewModalHandle((ele as RowsType).cols);
        }
        if (Array.isArray((ele as ColsType).widgetList)) {
          this.previewModalHandle((ele as ColsType).widgetList);
        }
        if ((ele as ColsType).options && (ele as ColsType).options.formId) {
          (ele as ColsType).options.result = 0;
          (ele as ColsType).options.currentValue = '';
          (ele as ColsType).options.maxItemValueIsShow = false;
          (ele as ColsType).options.itemValue = '';
          (ele as ColsType).options.attachmentName = '';
        }
      });
    }
  };
};
