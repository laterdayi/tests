import type { ComponentInternalInstance } from 'vue';

// 右侧表格类型
export type ContainersType = {
  type: string
  name: string
  id?: string
  rows?: string[]
  outside?: boolean
  merged?: boolean
  widgetList?: string[]
  displayName?: string
  options: {
    id: string
    hidden?: boolean
    colspan?: number
    rowspan?: number
  }
};
// 左侧拖拽列表类型
export type BasicFieldsType = {
  type: string
  options: BasicFieldsOptionsType
};
export type BasicFieldsOptionsType = {
  id: string
  formId: string
  name: string
  category: number
  dataType: number
  dataSource?: string
  dataSourceList: string[]
  attachment: number
  isCheck: number
  judgeType: number

  belongTo: number
  apply: number
  finalResult: number

  // 验证
  itemValue: string
  result: number
  standard?: string
  type?: number
  maxItemValue?: number
  maxItemValueIsShow?: boolean
  currentValue?: string
  isContainMax?: number
  isContainMin?: number

  failValue?: string
  operateIsShow?: boolean
  attachmentName?: string

  isHideTitle: number
};

// Designer整体类---------------------

// 拖拽克隆类型
export type WidgetType = {
  type: string
  id: string
  options: OptionsType
  widgetList?: WidgetType[]
  rows: RowsType[]
};

// WidgetList 最外层相关
export type WidgetListType = {
  // 组件类别
  id: string
  name?: string
  type: string
  // 是否是内部嵌套
  outside?: boolean
  // 表格内部行列存储
  rows: RowsType[]
  cols?: ColsType[]
  // 表格嵌套表格使用
  widgetList?: WidgetType[]
  // 存储当前数据在第几行列 内部嵌套表格使用
  options: OptionsType
};
export type RowsType = {
  id?: string
  // 是否合并的单元格
  merged?: boolean
  cols: ColsType[]
};
export type ColsType = {
  id: string
  type: string
  outside?: boolean
  merged?: boolean
  // 存储当前数据在第几行列
  options: OptionsType
  widgetList: WidgetType[]
  rows: RowsType[]
};
export type OptionsType = BasicFieldsOptionsType & {
  hidden?: boolean
  colspan: number
  rowspan: number
  wordBreak?: string
};

export type EvtType = {
  draggedContext: {
    element: {
      type: string
    }
  }
  to: { className: string }
};
export type FormConfigType = {
  cssCode: string
};

// Designer整体类
export type CreateDesignerType = {
  basicFieldsContro: BasicFieldsType[]
  basicFieldsShared: BasicFieldsType[]
  basicFieldsProject: BasicFieldsType[]

  projectName: string | null
  previewType: number
  formHeight: number
  tableItemComponentIsShow: boolean
  widgetList: WidgetListType[]
  formConfig: ComponentInternalInstance | null
  selectedId: string | null
  selectedWidget: WidgetListType | null
  selectedWidgetName: string | null
  vueInstance: ComponentInternalInstance | null
  copyNewContainerWidget: (origin: WidgetType) => WidgetListType
  newCellHandle: () => ColsType[]
  getContainerByType: (typeName: string) => void
  addContainerByDbClick: (container: WidgetType) => void
  copyNewFieldWidget: (origin: WidgetType) => WidgetType
  checkFieldMove: (evt: EvtType) => boolean
  addFieldByDbClick: (widget: WidgetType) => void
  insertTableCol: (widget: WidgetListType, insertPos: number, curRow: number, leftFlag: boolean) => void
  setPropsOfMergedCols: (
    rowArray: RowsType[],
    startRowIndex: number,
    startColIndex: number | null,
    newColspan: number,
    rowspan: number
  ) => void
  insertTableRow: (
    widget: WidgetListType,
    insertPos: number,
    cloneRowIdx: number,
    curCol: number,
    aboveFlag: boolean
  ) => void
  setPropsOfMergedRows: (
    rowArray: RowsType[],
    startRowIndex: number | null,
    startColIndex: number | null,
    newColspan: number,
    rowspan: number
  ) => void
  mergeTableCol: (
    rowArray: RowsType[],
    colArray: ColsType[],
    curRow: number,
    curCol: number,
    leftFlag: boolean,
    cellWidget: ColsType
  ) => void
  mergeTableWholeRow: (rowArray: RowsType[], colArray: ColsType[], rowIndex: number, colIndex: number) => void
  mergeTableRow: (
    rowArray: RowsType[],
    curRow: number,
    curCol: number,
    aboveFlag: boolean,
    cellWidget: ColsType
  ) => void
  mergeTableWholeCol: (rowArray: RowsType[], colArray: ColsType[], rowIndex: number, colIndex: number) => void
  undoMergeTableRow: (
    rowArray: RowsType[],
    rowIndex: number,
    colIndex: number,
    colspan: number,
    rowspan: number
  ) => void
  setPropsOfSplitRow: (
    rowArray: RowsType[],
    rowIndex: number,
    colIndex: number,
    colspan: number,
    rowspan: number
  ) => void
  undoMergeTableCol: (
    rowArray: RowsType[],
    rowIndex: number,
    colIndex: number,
    colspan: number,
    rowspan: number
  ) => void
  setPropsOfSplitCol: (
    rowArray: RowsType[],
    rowIndex: number,
    colIndex: number,
    colspan: number,
    rowspan: number
  ) => void

  moveUpWidget: (parentList: ColsType[], indexOfParentList: number) => void
  moveDownWidget: (parentList: ColsType[], indexOfParentList: number) => void
  appendTableRow: (widget: WidgetListType) => void
  appendTableCol: (widget: WidgetListType) => void
  cloneContainer: (containWidget: WidgetListType) => WidgetListType

  deleteTableWholeCol: (rowArray: RowsType[], colIndex: number) => void
  deleteTableWholeRow: (rowArray: RowsType[], rowIndex: number) => void

  emitEvent: (evtName: any, evtData: any) => void
  setSelected: (selected: WidgetListType) => void
  clearSelected: () => void
  previewModal: () => void
  previewModalHandle: (item: RowsType[] | ColsType[] | WidgetType[]) => void
};
