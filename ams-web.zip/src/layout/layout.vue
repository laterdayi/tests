<script setup lang="ts">
import LayoutMenu from './aside/layout-menu.vue';
import LayoutHeader from './aside/layout-header.vue';
import LayoutTabsView from './aside/layout-tabs-view.vue';
import { LayoutKey } from './type';
import { BASE_LAYOUT } from '@/constants/app';

provide(LayoutKey, BASE_LAYOUT);
const appStore = useAppStore();
const routeStore = useRouteStore();
const userStore = useUserStore();
const { userInfo } = storeToRefs(userStore);
const { workbenchList } = storeToRefs(routeStore);
const { themePrimary } = storeToRefs(appStore);
const route = useRoute();
const router = useRouter();

// Layout 头部高度
const layoutHeaderHeight = `${LAYOUT_HEADER_HEIGHT}px`;

// Layout 高度
const layoutHeight = `${LAYOUT_HEADER_HEIGHT + LAYOUT_TABS_VIEW_HEIGHT}px`;

// 缓存路由缓存
const keepAliveRoutes = computed(() => {
  return router
    .getRoutes()
    .filter(route => route.meta?.noCache === false)
    .map(route => kebabCase((route.name as string)?.split('-').at(-1) as string)) as string[];
});

// Sider Collapsed
const collapsed = ref(false);

const layoutLogoPaddingLeft = computed(() => (collapsed.value ? 0 : `${LAYOUT_PADDING}px`));

// 是否空白布局
const isBlankLayout = computed(() => route.meta.layoutType === LayoutType.blank);
</script>

<template>
  <n-layout id="base-layout" has-sider>
    <n-layout-sider
      v-show="!isBlankLayout"
      v-model:collapsed="collapsed"
      collapse-mode="width"
      :collapsed-width="standardVars.menuCollapsedWidth"
      :width="standardVars.menuWidth"
      content-class="h-full flex flex-col"
      class="h-full relative"
    >
      <!-- logo -->
      <div
        class="box-border flex items-center logo-area pb-5px pt-5px relative"
        :style="{ backgroundColor: themePrimary }"
        :class="[{ 'text-center': collapsed }]"
      >
        <transition name="logo" mode="out-in">
          <img v-if="collapsed" key="minilogo" class="h-full w-full" :src="`${userInfo?.user?.miniLogo}`" />
          <img v-else key="logo" class="h-full" :src="`${userInfo?.user?.logo}`" />
        </transition>
      </div>
      <base-scrollbar class="flex-1">
        <layout-menu :collapsed="collapsed" />
      </base-scrollbar>
      <div
        class="cursor-pointer flex items-center justify-center w-full"
        :class="[`h-${standardVars.layoutSiderTriggerHeight}px`]"
        @click="collapsed = !collapsed"
      >
        <base-icon icon="i-carbon:list" />
      </div>
    </n-layout-sider>
    <n-layout>
      <layout-header v-show="!isBlankLayout" />
      <layout-tabs-view v-show="workbenchList.length && !isBlankLayout" class="bg-placeholderColor" />
      <n-layout-content
        :native-scrollbar="false"
        :content-style="{ padding: `${LAYOUT_PADDING}px` }"
        class="bg-placeholderColor main-container"
      >
        <router-view
          v-slot="{ Component, route: slotRoute }"
          class="router-view"
          :class="{ 'blank-router-view': isBlankLayout }"
        >
          <transition name="fade-slide" mode="out-in" appear>
            <keep-alive :include="keepAliveRoutes" :max="10">
              <component :is="Component" :key="slotRoute.fullPath" />
            </keep-alive>
          </transition>
        </router-view>
      </n-layout-content>
    </n-layout>
  </n-layout>
</template>

<style lang="less" scoped>
#base-layout {
  .main-container {
    height: calc(100% - v-bind('isBlankLayout ? 0 :  !workbenchList.length ? layoutHeaderHeight : layoutHeight'));
  }
  .logo-area {
    transition: all var(--duration);
    height: v-bind(layoutHeaderHeight) !important;
    padding-left: v-bind(layoutLogoPaddingLeft);
  }
  .blank-router-view {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 999;
  }

  .logo-enter-active,
  .logo-leave-active {
    transition: all var(--duration) cubic-bezier(0, 0, 0.2, 1);
  }
  .logo-enter-from {
    opacity: 0;
    transform: scale(0.9);
  }
  .logo-leave-to {
    opacity: 0;
    transform: translateX(-30px);
  }
}
</style>
