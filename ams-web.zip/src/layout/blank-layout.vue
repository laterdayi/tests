<script setup lang="ts">
import LayoutHeader from './aside/layout-header.vue';
import { LayoutKey } from './type';
import { BLANK_LAYOUT } from '@/constants/app';

provide(LayoutKey, BLANK_LAYOUT);
const layoutHeaderHeight = `${LAYOUT_HEADER_HEIGHT}px`;
</script>

<template>
  <n-layout un-cloak position="absolute">
    <layout-header />
    <n-layout-content :native-scrollbar="false" content-style="padding: 16px;" class="background main-container">
      <router-view v-slot="{ Component, route }" class="router-view">
        <transition name="fade-slide" mode="out-in" appear>
          <component :is="Component" :key="route.path" />
        </transition>
      </router-view>
    </n-layout-content>
  </n-layout>
</template>

<style scoped lang="less">
.main-container {
  height: calc(100% - v-bind(layoutHeaderHeight));
}
</style>
