import type { InjectionKey } from 'vue';

export const LayoutKey = Symbol() as InjectionKey<string>;
