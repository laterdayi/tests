<script setup lang="ts">
import { componentSizeOption, pageSizeOption, themePrimaryOption } from './constants';
import type { ComponentSizeType, LocalType } from '@/stores/app';

const appStore = useAppStore();
const { local, themePrimary, componentSize, pageSize } = storeToRefs(appStore);

// 显示设置
const isShowSetting = ref(false);
// 打开侧边栏
const open = () => (isShowSetting.value = true);

// 语言设置
const { availableLocales, locale } = useI18n();

// 更改语言
const toggleLocales = () => {
  const locales = availableLocales;
  const value = locales[(locales.indexOf(locale.value) + 1) % locales.length];
  $dialog.warning({
    content: i18nt('toggleLanguageTips', { val: value === 'en' ? i18nt(value) : i18nt('zhCN') }),
    onPositiveClick: () => {
      try {
        appStore.setLocal(value as LocalType);
        window.location.reload();
      } catch (error) {
        console.log('切换语言异常：', error);
      }
    }
  });
};

const setComponentSize = (value: ComponentSizeType) => appStore.setComponentSize(value);
const setPageSize = (value: number) => appStore.setPageSize(value);

// 重置
const handleReset = () => {
  appStore.resetStore();
  if (locale.value !== LOCAL_DEFAULT) locale.value = LOCAL_DEFAULT;
};

const itemTitleCls = `mr text-${light.common.fontSizeHuge}`;
const wrapperCls = 'mb-32px';

defineExpose({
  open
});
</script>

<template>
  <!-- 配置 -->
  <base-drawer v-model:show="isShowSetting" :width="360" :title="$t('themeConfig')">
    <base-scrollbar>
      <div class="flex flex-col">
        <!-- 语言设置 -->
        <div class="px" :class="wrapperCls">
          <span :class="itemTitleCls">{{ $t('languageSetting') }}</span>
          <base-switch :value="local" checked-value="en" unchecked-value="zh-CN" @update:value="toggleLocales">
            <template #checked> <base-icon icon="i-carbon:language" /> </template>
            <template #unchecked><base-icon icon="i-carbon:database-enterprise-db2" /> </template>
          </base-switch>
        </div>

        <!-- 系统主题 -->
        <div class="flex px" :class="wrapperCls">
          <span :class="itemTitleCls">{{ $t('systemTheme') }}</span>
          <div class="grid grid-flow-col grid-rows-2">
            <div
              v-for="item in themePrimaryOption"
              :key="item"
              class="cursor-pointer h-20px mb-5px mr-5px w-20px"
              :style="{ backgroundColor: item, borderRadius: standardVars.borderRadiusSmall }"
              @click="appStore.setThemePrimary(item)"
            >
              <base-icon
                v-if="item === themePrimary"
                class="bottom-2px relative"
                icon="i-carbon:checkmark"
                color="#FFFFFF"
              />
            </div>
          </div>
        </div>

        <!-- 按钮设置 -->
        <div class="flex items-center px" :class="wrapperCls">
          <span :class="itemTitleCls">{{ $t('componentSize') }}</span>
          <base-select
            class="flex-1"
            :value="componentSize"
            :options="componentSizeOption"
            :on-update:value="setComponentSize"
          />
        </div>

        <!-- 表格设置 -->
        <div class="flex items-center px" :class="wrapperCls">
          <span :class="itemTitleCls">{{ $t('tableSetting') }}</span>
          <base-select class="flex-1" :value="pageSize" :options="pageSizeOption" :on-update:value="setPageSize" />
        </div>
      </div>
    </base-scrollbar>
    <template #footer>
      <base-button button-name="reset" type="primary" ghost @click="handleReset">{{ $t('reset') }}</base-button>
    </template>
  </base-drawer>
</template>
