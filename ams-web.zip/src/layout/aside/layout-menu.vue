<script setup lang="ts">
import { NEllipsis } from 'naive-ui';
import type { MenuOption, TooltipInst } from 'naive-ui';
import { RouterLink } from 'vue-router';
import { Routes } from '@/router/routes';
import { useRouteStore } from '@/stores/route';
import BaseIcon from '@/components/base-icon.vue';
import type { RouteType } from '@/service/apis/common/type';

const props = withDefaults(
  defineProps<{
    // 是否折叠
    collapsed?: boolean
  }>(),
  {
    collapsed: false
  }
);

const route = useRoute();
const { routes, currentModule } = storeToRefs(useRouteStore());

// 图标
const renderIcon = (icon: string) => () => h(BaseIcon, { icon });

// 悬浮文字
const ellipsisRef = ref<{ tooltipRef: TooltipInst } | null>(null);

// 选中菜单回调
const handleUpdateMenuValue = () => {
  if (route?.meta?.layoutType === LayoutType.blank) {
    ellipsisRef?.value?.tooltipRef?.setShow(false);
  }
};

// 路由 & 文本
const renderLabel = (path: string, label: string, link?: number) => () => {
  const item = link
    ? h('a', { href: path, target: '_blank' }, i18nt(label))
    : h(RouterLink, { to: { path } }, { default: () => i18nt(label) });
  return props.collapsed
    ? item
    : h(
      NEllipsis,
      { ref: ellipsisRef },
      {
        default: () => item
      }
    );
};

// 菜单项
const menuOptions = computed<MenuOption[]>(() => {
  const menus: MenuOption[] = [
    {
      label: renderLabel(Routes.WORKBENCH, 'workbench', 0),
      key: Routes.WORKBENCH,
      icon: renderIcon('i-carbon:home')
    }
  ];
  const module = routes.value.filter((item: RouteType) => toLower(item.name) === toLower(currentModule.value));
  return module?.length && module[0]?.children?.length
    ? menus.concat([...convertToMenu(`/${toLower(module[0].path)}`, '', module[0].children)])
    : menus;
});

// 路由表 > 菜单
const convertToMenu = (module: string, parentPath: string, routes: RouteType[]) => {
  const menus: MenuOption[] = [];
  routes.forEach(route => {
    const { meta } = toRaw(route);
    const menu: MenuOption = {
      label: renderLabel(
        meta?.link ? route.path : route.children?.length ? '' : `${module}/${parentPath}${route.path}`,
        route.name,
        meta?.link
      ),
      key: `${module}/${parentPath}${route.path}`,
      icon: renderIcon(route.meta.icon ?? 'i-carbon:settings-adjust')
    };
    if (route.children?.length) menu.children = convertToMenu(module, `${route.path}/`, route.children);
    if (!meta.hidden) menus.push(menu);
  });
  return menus;
};
</script>

<template>
  <base-menu :indent="28" :options="menuOptions" :value="route.path" @update:value="handleUpdateMenuValue" />
</template>
