<script setup lang="ts">
import type { RouteLocationNormalizedLoaded } from 'vue-router';
import BaseIcon from '@c/base-icon.vue';
import { Routes } from '@/router/routes';
import { useRouteStore } from '@/stores/route';

const route = useRoute();
const router = useRouter();
const routeStore = useRouteStore();
const appStore = useAppStore();
const { tabsViewList, isLastTab, isFirstTab } = storeToRefs(routeStore);
const { themePrimary } = storeToRefs(appStore);
type ActionType = 'closeCurrentTab' | 'closeOtherTabs' | 'closeLeftTabs' | 'closeRightTabs';

// layout 高度
const layoutTabsViesHeight = `${LAYOUT_TABS_VIEW_HEIGHT}px`;
const layoutTabsViesItemHeight = `${LAYOUT_TABS_VIEW_HEIGHT - 6}px`;

// 切换标签
const handleClick = (item: Partial<RouteLocationNormalizedLoaded>) => {
  if (route.path !== item.path) {
    router.push(item?.path ?? Routes.WORKBENCH);
  }
};

// -------------------------------------------------------------------------------------------- > 同步滚动条位置
const scrollbarRef = ref<ScrollbarRefType>();
const syncScrollbarPosition = () => {
  nextTick(() => {
    if (!tabsViewList.value.length) return;
    const containerDom = document.querySelector('.scrollbar-area .n-scrollbar-container');
    const containerWidth = (containerDom as HTMLElement)?.offsetWidth;
    const activeDom = document.querySelector('.tabs-view-item-active');
    const left = Math.max(0, (activeDom as HTMLElement)?.offsetLeft - containerWidth + containerWidth / 2);
    scrollbarRef?.value?.scrollbarRef?.scrollTo({ left });
  });
};
onMounted(syncScrollbarPosition);
router.afterEach(syncScrollbarPosition);

const renderIcon = (icon: string) => () => h(BaseIcon, { icon, size: 16 });

// select 选项
const options = computed(() => [
  {
    label: i18nt('tabs.closeCurrentTab'),
    key: 'closeCurrentTab',
    icon: renderIcon('i-carbon:close'),
    disabled: !tabsViewList.value.length
  },
  {
    label: i18nt('tabs.closeOtherTabs'),
    key: 'closeOtherTabs',
    icon: renderIcon('i-carbon:close'),
    disabled: tabsViewList.value.length === 1 || !tabsViewList.value.length
  },
  { key: 'd2', type: 'divider' },
  {
    label: i18nt('tabs.closeLeftTabs'),
    key: 'closeLeftTabs',
    icon: renderIcon('i-carbon:page-first'),
    disabled: isFirstTab.value || !tabsViewList.value.length
  },
  {
    label: i18nt('tabs.closeRightTabs'),
    key: 'closeRightTabs',
    icon: renderIcon('i-carbon:page-last'),
    disabled: isLastTab.value || !tabsViewList.value.length
  }
]);

// 选择操作
const handleSelect = (key: ActionType) => {
  const actions: { [key in ActionType]: () => void } = {
    // 关闭当前标签
    closeCurrentTab() {
      const index = findIndex(tabsViewList.value, item => item.path === route.path);
      routeStore.deleteTabsView(route, index, true);
    },
    // 关闭其余标签
    closeOtherTabs() {
      routeStore.setTabsView(
        filter(
          tabsViewList.value,
          (item: RouteLocationNormalizedLoaded) => item.path === route.path
        ) as RouteLocationNormalizedLoaded[]
      );
    },
    // 关闭左侧标签
    closeLeftTabs() {
      const index = findIndex(tabsViewList.value, item => item.path === route.path);
      routeStore.setTabsView(drop(tabsViewList.value, index));
    },
    // 关闭右侧标签
    closeRightTabs() {
      const index = findIndex(tabsViewList.value, item => item.path === route.path);
      routeStore.setTabsView(dropRight(tabsViewList.value, tabsViewList.value.length - (index + 1)));
    }
  };
  actions[key]();
};

// 鼠标事件
const onMouseUp = (
  e: MouseEvent,
  item: Partial<RouteLocationNormalizedLoaded>,
  index: number,
  isCurrentTab: boolean
) => {
  if (e.button === 1) {
    routeStore.deleteTabsView(item, index, isCurrentTab);
  }
};
</script>

<template>
  <div class="tabs-view-area">
    <base-scrollbar ref="scrollbarRef" x-scrollable class="scrollbar-area">
      <div class="flex whitespace-nowrap">
        <div
          v-for="(item, index) in tabsViewList"
          :key="item.path"
          class="tabs-view-item"
          :class="[{ 'tabs-view-item-active': item.path === route.path }]"
          @click="handleClick(item)"
          @mouseup="onMouseUp($event, item, index, item.path === route.path)"
        >
          <base-ellipsis
            :class="[`min-w-${standardVars.tabsViewItemMinWidth}!`, `max-w-${standardVars.tabsViewItemMaxWidth}!`]"
          >
            {{ $t(last((item.name as string).split('-')) as string) }}
          </base-ellipsis>
          <base-icon
            class="tabs-view-item-icon"
            icon="i-carbon:close"
            @click.stop="routeStore.deleteTabsView(item, index, item.path === route.path)"
          />
        </div>
      </div>
    </base-scrollbar>
    <base-tooltip>
      <template #trigger>
        <base-icon
          icon="i-carbon:rotate-360"
          class="cursor-pointer w-36px"
          @click="router.replace({ path: `/redirect${route.path}` })"
        />
      </template>
      {{ $t('refresh') }}
    </base-tooltip>
    <base-dropdown :options="options" @select="handleSelect">
      <base-icon icon="i-carbon:menu" class="cursor-pointer w-36px" />
    </base-dropdown>
  </div>
</template>

<style lang="less" scoped>
@keyframes fade {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

.tabs-view-area {
  padding: 0 var(--padding);
  display: flex;
  justify-content: center;
  align-items: center;
  .tabs-view-item {
    padding: 0 4px;
    margin-right: 10px;
    height: v-bind(layoutTabsViesItemHeight);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    transition: border var(--duration) ease;
    animation: fade var(--duration) ease;
    &-icon {
      margin-left: 6px;
    }
    &:hover {
      border-bottom: 2px solid v-bind(themePrimary);
      color: v-bind(themePrimary);
    }
  }
  .tabs-view-item-active {
    color: v-bind(themePrimary);
    border-bottom: 2px solid v-bind(themePrimary);
  }
  :deep(.scrollbar-area) {
    height: v-bind(layoutTabsViesHeight);
    line-height: v-bind(layoutTabsViesHeight);
  }
}
</style>
