import antfu from '@antfu/eslint-config';
import { FlatCompat } from '@eslint/eslintrc';
import prettier from '@standard-semi/config/lib/prettier.mjs';

const compat = new FlatCompat();

// Javascript Eslint https://eslint.org/docs/rules/
const js = {
  // 禁止使用不安全的正则表达式
  'regexp/no-unused-capturing-group': 'off',
  // 不规则空白
  'no-irregular-whitespace': 'off',
  // 对所有控制语句强制执行一致的大括号样式
  'curly': 'off',
  // 禁止使用RegExp构造函数而支持正则表达式文字
  'prefer-regex-literals': 'off',
  // 强制使用骆驼拼写法命名约定
  'camelcase': 'error',
  // 符号描述
  'symbol-description': 'off',
  // 禁止使用逗号运算符
  'no-sequences': 'off',
  // 要求所有 switch 语句都有 default
  'default-case': 'error',
  // 强制可嵌套的块的最大深度
  'max-depth': 'error',
  // 强制回调函数最大嵌套深度
  'max-nested-callbacks': 'error',
  // 强制对多行注释使用特定风格
  'multiline-comment-style': ['error', 'separate-lines'],
  // 禁用 alert、confirm 和 prompt
  'no-alert': 'error',
  // 禁止 consoloe
  'no-console': 'off',
  // 在 if 语句中，禁止在 return 语句后使用 else 块
  'no-else-return': 'error',
  // 禁止空函数
  'no-empty-function': 'error',
  // 禁止空静态块
  'no-empty-static-block': 'error',
  // 禁止在代码后使用内联注释
  'no-inline-comments': 'error',
  // 禁用 Script URL
  'no-script-url': 'error',
  // 禁止不必要的文字或模板文字串联
  'no-useless-concat': 'error',
  // 禁止修改const声明的变量
  'no-const-assign': 'error',
  // 禁止使用不带 await 表达式的 async 函数
  'require-await': 'error',
  // 强制行注释的位置
  'line-comment-position': 'error',
  // 要求简化赋值操作
  'operator-assignment': 'error',
  // 运算符换行符
  'operator-linebreak': 'off',
  // 三元表达式的操作数之间强制换行
  'multiline-ternary': 'off'
};

// Typescript Eslint https://typescript-eslint.io/rules/
const ts = {
  // 在定义变量之前禁止使用变量
  'ts/no-use-before-define': 'off',
  // 尾随分号
  'ts/semi': 'off',
  // 禁止指定的全局变量
  'no-restricted-globals': 'off',
  // 始终对数组使用T[]
  'ts/array-type': 'error',
  // 不允许重复的枚举成员值
  'ts/no-duplicate-enum-values': 'error',
  // 不允许声明空接口
  'ts/no-empty-interface': 'error',
  // 不允许对初始化为数字、字符串或布尔值的变量或参数进行显式类型声明
  'ts/no-inferrable-types': 'error',
  // 禁止定义未使用的变量
  'ts/no-unused-vars': 'error',
  // 禁止使用 any 类型
  'ts/no-explicit-any': 'error',
  // // 强制使用简洁的可选链式表达式，而不是链式逻辑与、否定逻辑或或空对象
  // 'ts/prefer-optional-chain': 'error',
  // // 命名约定
  // 'ts/naming-convention': [
  //   'error',
  //   // 强制 接口 类型别名 枚举 为大驼峰
  //   { selector: ['interface', 'typeAlias', 'enum'], format: ['PascalCase'] },
  //   // 强制 函数 参数 为小驼峰
  //   { selector: ['function', 'parameter'], format: ['camelCase'] },
  //   {
  //     selector: 'memberLike',
  //     modifiers: ['private'],
  //     format: ['camelCase'],
  //     leadingUnderscore: 'require'
  //   }
  // ],
  // 适当处理类似 Promise 的语句
  'ts/no-floating-promises': 'off',
  // 禁止等待不是 Thenable 的值
  'ts/await-thenable': 'off',
  // 尾随逗号
  'ts/comma-dangle': 'off',
  // 禁止使用 type 的值调用函数 any
  'ts/no-unsafe-argument': 'off',
  // 强制执行一致的大括号样式
  'ts/brace-style': ['error', '1tbs'],
  // 成员分隔符
  'ts/member-delimiter-style': 'off',
  // 禁用类型
  'ts/ban-types': 'off',
  // 强制类型定义一致
  'ts/consistent-type-definitions': 'off',
  // 缩进
  'ts/indent': 'off'
};

// Vue Eslint https://eslint.vuejs.org/rules/
const vue = {
  // 禁止注册模板中未使用的组件
  'vue/no-unused-components': 'error',
  // 禁止未使用的发出声明
  'vue/no-unused-emit-declarations': 'off',
  // 尾随逗号
  'vue/comma-dangle': 'off',
  // 需要在单行元素的内容之前和之后换行
  'vue/singleline-html-element-content-newline': 'off',
  // 要求运算符周围有间距
  'vue/space-infix-ops': 'error',
  // 强制模板文字
  'vue/prefer-template': 'error',
  // 要求对象文字的方法和属性速记语法
  'vue/object-shorthand': ['error', 'properties'],
  // 禁止不必要的文字或模板文字串联
  'vue/no-useless-concat': 'error',
  // 不允许<template> <script> <style>块为空
  'vue/no-empty-component-block': 'error',
  // 为模板中的组件命名样式强制使用特定大小写
  'vue/component-name-in-template-casing': ['error', 'kebab-case'],
  // 强制属性顺序
  'vue/attributes-order': 'error',
  // 在括号内强制使用一致的间距
  'vue/space-in-parens': 'error',
  // 在大括号内强制执行一致的间距
  'vue/object-curly-spacing': ['error', 'always'],
  // 关键字前后强制使用一致的间距
  'vue/keyword-spacing': 'error',
  // 强制执行键和值之间的一致间距
  'vue/key-spacing': 'error',
  // 强制执行驼峰命名约定 <template>
  'vue/camelcase': 'error',
  // 强制执行一致的大括号样式 <template>
  'vue/brace-style': ['error', '1tbs'],
  // 箭头函数中的箭头前后强制执行一致的间距 <template>
  'vue/arrow-spacing': 'error',
  // 数组括号内强制执行一致的间距 <template>
  'vue/array-bracket-spacing': 'error',
  // 需要使用===和!== <template>
  'vue/eqeqeq': 'error',
  // 强制 v-for 指令的分隔符样式
  'vue/v-for-delimiter-style': 'error',
  // 强制执行静态类名顺序
  'vue/static-class-names-order': 'error',
  // 强制每个 Prop 都有注释
  'vue/require-prop-comment': ['error', { type: 'line' }],
  // 要求组件直接导出
  'vue/require-direct-export': 'error',
  // 需要简写形式属性 true
  'vue/prefer-true-attribute-shorthand': 'error',
  // 要求模板中的静态类名位于单独的 class 属性中
  'vue/prefer-separate-static-class': 'error',
  // 组件定义中要求块之间的间距
  'vue/padding-lines-in-component-definition': 'error',
  // 要求块之间的间距
  'vue/padding-line-between-blocks': 'error',
  // 禁止使用 v-text
  'vue/no-v-text': 'error',
  // 禁止不必要的 v-bind 指令
  'vue/no-useless-v-bind': 'error',
  // 禁止不必要的插值
  'vue/no-useless-mustaches': 'error',
  // 禁止未使用的引用
  'vue/no-unused-refs': 'error',
  // 禁止静态内联 style 属性
  'vue/no-static-inline-styles': 'error',
  // 在 HTML 注释中强制执行一致的缩进
  'vue/html-comment-indent': 'error',
  // 在 HTML 注释中强制统一间距
  'vue/html-comment-content-spacing': 'error',
  // 在 HTML 注释中强制执行统一的换行符
  'vue/html-comment-content-newline': 'error',
  // 执行声明样式 defineEmits
  'vue/define-emits-declaration': 'error',
  // 为 emit 事件名称强制使用特定大小写
  'vue/custom-event-name-casing': ['error', 'kebab-case'],
  // components 在选项中强制组件名称的大小写
  'vue/component-options-name-casing': ['error', 'PascalCase'],
  // 强制执行组件 API 样式
  'vue/component-api-style': 'error',
  // 在打开和关闭块级标签之前强制换行
  'vue/block-tag-newline': 'error',
  // 禁止在模板中使用 this
  'vue/this-in-template': 'error',
  // 强制执行组件中的属性顺序
  'vue/order-in-components': 'error',
  // 禁止不必要的 <template>
  'vue/no-lone-template': 'error',
  // 强制执行组件顶级元素的顺序
  'vue/block-order': [
    'error',
    {
      order: ['script:not([setup])', 'script[setup]', 'template', 'style']
    }
  ],
  // 强制 v-slot 指令风格
  'vue/v-slot-style': 'error',
  // 强制 v-on 指令风格
  'vue/v-on-style': 'error',
  // 强制执行 v-on 事件命名样式
  'vue/v-on-event-hyphenation': 'error',
  // 强制 v-bind 指令风格
  'vue/v-bind-style': 'error',
  // 需要在 props 中定义类型
  'vue/require-prop-types': 'error',
  // 需要 emits 名称触发的选项
  'vue/require-explicit-emits': 'error',
  // 需要 Prop 默认值
  'vue/require-default-prop': 'error',
  // Prop 名称强制使用特定大小写
  'vue/prop-name-casing': 'error',
  // 强制每个组件都应该在它自己的文件中
  'vue/one-component-per-file': 'error',
  // 消除 v-for 指令或范围属性的阴影变量声明
  'vue/no-template-shadow': 'error',
  // 属性中等号周围不允许有空格
  'vue/no-spaces-around-equal-signs-in-attribute': 'error',
  // 不允许多个空格
  'vue/no-multi-spaces': 'error',
  // 在插值中强制统一间距
  'vue/mustache-interpolation-spacing': 'error',
  // 在多行元素的内容之前和之后强制换行。
  'vue/multiline-html-element-content-newline': 'error',
  // 强制执行一致的缩进
  'vue/html-indent': 'off',
  // 强制标签自闭和
  'vue/html-self-closing': [
    'error',
    {
      html: {
        void: 'always',
        normal: 'always',
        component: 'always'
      },
      svg: 'always',
      math: 'always'
    }
  ],
  // 运算符换行符
  'vue/operator-linebreak': 'off',
  // 不允许在标签的右括号前有一个空格
  'vue/html-closing-bracket-spacing': 'error',
  // 不允许在标记的右括号前换行
  'vue/html-closing-bracket-newline': 'error',
  // 强制在 Vue 模板中的自定义组件上使用带连字符的属性名称
  'vue/attribute-hyphenation': 'error',
  // 组件名称始终为多词
  'vue/multi-word-component-names': 'off',
  // 禁止使用 v-html 来防止 XSS 攻击
  'vue/no-v-html': 'off',
  // 禁止在同一元素上使用v-else-if/v-elsev-for
  'vue/no-use-v-else-with-v-for': 'error',
  // 使用时强制inheritAttrs设置为false v-bind="$attrs"
  'vue/no-duplicate-attr-inheritance': 'off',
  // 禁止使用console in <template>
  'vue/no-console': 'error',
  // 禁止未定义的属性
  'vue/no-undef-properties': 'error',
  // 需要特定的宏变量名称
  'vue/require-macro-variable-name': 'error',
  // 强制使用defineOptions而不是默认导出
  'vue/prefer-define-options': 'error',
  // 强制defineEmits编译defineProps器宏的顺序
  'vue/define-macros-order': 'error',
  // 强制执行有效的defineOptions编译器宏
  'vue/valid-define-options': 'error',
  // 禁止特定的 HTML 元素
  'vue/no-restricted-html-elements': [
    'error',
    { element: 'marquee', message: '不能使用废弃的 HTML 标签' },
    { element: 'n-alert', message: '请使用 <base-alert /> 组件' },
    { element: 'n-avatar-group', message: '请使用 <base-avatar-group /> 组件' },
    { element: 'n-button', message: '请使用 <base-button /> 组件' },
    { element: 'n-card', message: '请使用 <base-card /> 组件' },
    { element: 'n-carousel', message: '请使用 <base-carousel /> 组件' },
    { element: 'n-collapse', message: '请使用 <base-collapse /> 组件' },
    {
      element: 'n-collapse-item',
      message: '请使用 <base-collapse-item /> 组件'
    },
    { element: 'n-divider', message: '请使用 <base-divider /> 组件' },
    { element: 'n-dropdown', message: '请使用 <base-dropdown /> 组件' },
    { element: 'n-ellipsis', message: '请使用 <base-ellipsis /> 组件' },
    {
      element: 'n-gradient-text',
      message: '请使用 <base-gradient-text /> 组件'
    },
    {
      element: 'n-icon',
      message: '请使用 <base-icon /> 组件, 设置 Carbon Icon 名称'
    },
    { element: 'n-tag', message: '请使用 <base-tag /> 组件' },
    { element: 'n-watermark', message: '请使用 <base-watermark /> 组件' },
    {
      element: 'n-auto-complete',
      message: '请使用 <base-auto-complete /> 组件'
    },
    { element: 'n-cascader', message: '请使用 <base-cascader /> 组件' },
    { element: 'n-color-picker', message: '请使用 <base-color-picker /> 组件' },
    { element: 'n-checkbox', message: '请使用 <base-checkbox /> 组件' },
    {
      element: 'n-checkbox-group',
      message: '请使用 <base-checkbox-group /> 组件'
    },
    { element: 'n-date-picker', message: '请使用 <base-date-picker /> 组件' },
    {
      element: 'n-dynamic-input',
      message: '请使用 <base-dynamic-input /> 组件'
    },
    { element: 'n-dynamic-tags', message: '请使用 <base-dynamic-tags /> 组件' },
    { element: 'n-form', message: '请使用 <base-form /> 组件' },
    { element: 'n-input', message: '请使用 <base-input /> 组件' },
    { element: 'n-input-number', message: '请使用 <base-input-number /> 组件' },
    { element: 'n-mention', message: '请使用 <base-mention /> 组件' },
    { element: 'n-radio', message: '请使用 <base-radio /> 组件' },
    { element: 'n-radio-group', message: '请使用 <base-radio-group /> 组件' },
    { element: 'n-rate', message: '请使用 <base-rate /> 组件' },
    { element: 'n-select', message: '请使用 <base-select /> 组件' },
    { element: 'n-slider', message: '请使用 <base-slider /> 组件' },
    { element: 'n-time-picker', message: '请使用 <base-time-picker /> 组件' },
    { element: 'n-transfer', message: '请使用 <base-transfer /> 组件' },
    { element: 'n-tree-select', message: '请使用 <base-tree-select /> 组件' },
    { element: 'n-upload', message: '请使用 <base-upload /> 组件' },
    { element: 'n-calendar', message: '请使用 <base-calendar /> 组件' },
    { element: 'n-countdown', message: '请使用 <base-countdown /> 组件' },
    { element: 'n-code', message: '请使用 <base-code /> 组件' },
    { element: 'n-data-table', message: '请使用 <base-table /> 组件' },
    { element: 'n-descriptions', message: '请使用 <base-descriptions /> 组件' },
    { element: 'n-empty', message: '请使用 <base-empty /> 组件' },
    { element: 'n-equation', message: '请使用 <base-equation /> 组件' },
    { element: 'n-image', message: '请使用 <base-image /> 组件' },
    { element: 'n-image-group', message: '请使用 <base-image-group /> 组件' },
    { element: 'n-list', message: '请使用 <base-list /> 组件' },
    { element: 'n-log', message: '请使用 <base-log /> 组件' },
    {
      element: 'n-number-animation',
      message: '请使用 <base-number-animation /> 组件'
    },
    { element: 'n-statistic', message: '请使用 <base-statistic /> 组件' },
    { element: 'n-table', message: '请使用 <base-table /> 组件' },
    { element: 'n-thing', message: '请使用 <base-thing /> 组件' },
    { element: 'n-time', message: '请使用 <base-time /> 组件' },
    { element: 'n-timeline', message: '请使用 <base-timeline /> 组件' },
    {
      element: 'n-timeline-item',
      message: '请使用 <base-timeline-item /> 组件'
    },
    { element: 'n-tree', message: '请使用 <base-tree /> 组件' },
    { element: 'n-affix', message: '请使用 <base-affix /> 组件' },
    { element: 'n-anchor', message: '请使用 <base-anchor /> 组件' },
    { element: 'n-anchor-link', message: '请使用 <base-anchor-link /> 组件' },
    { element: 'n-back-top', message: '请使用 <base-back-top /> 组件' },
    { element: 'n-menu', message: '请使用 <base-menu /> 组件' },
    { element: 'n-pagination', message: '表格中已内置分页' },
    { element: 'n-steps', message: '请使用 <base-steps /> 组件' },
    { element: 'n-step', message: '请使用 <base-step /> 组件' },
    { element: 'n-badge', message: '请使用 <base-badge /> 组件' },
    { element: 'n-drawer', message: '请使用 <base-drawer /> 组件' },
    { element: 'n-modal', message: '请使用 <base-modal /> 组件' },
    { element: 'n-popconfirm', message: '请使用 <base-popconfirm /> 组件' },
    { element: 'n-popover', message: '请使用 <base-popover /> 组件' },
    { element: 'n-popselect', message: '请使用 <base-popselect /> 组件' },
    { element: 'n-result', message: '请使用 <base-result /> 组件' },
    { element: 'n-skeleton', message: '请使用 <base-skeleton /> 组件' },
    { element: 'n-spin', message: '请使用 <base-spin /> 组件' },
    { element: 'n-tooltip', message: '请使用 <base-tooltip /> 组件' },
    { element: 'n-space', message: '请使用 <base-space /> 组件' },
    {
      element: 'n-collapse-transition',
      message: '请使用 <base-collapse-transition /> 组件'
    },
    { element: 'n-scrollbar', message: '请使用 <base-scrollbar /> 组件' }
  ]
};

// Stylistic https://eslint.style/packages/default
const stylistic = {
  // jsx-禁止多行 JSX 周围缺少括号
  'style/jsx-wrap-multilines': 'error',
  // jsx-等于间距
  'style/jsx-sort-props': 'error',
  // jsx-等于间距
  'style/jsx-equals-spacing': ['error', 'never'],
  // jsx-右括号位置
  'style/jsx-closing-bracket-location': 'error',
  // jsx-结束标签位置
  'style/jsx-closing-tag-location': 'error',
  // 键间距
  'style/key-spacing': 'error',
  // 类成员之间的换行
  'style/lines-between-class-members': 'error',
  // 没有额外的括号
  'style/no-extra-parens': 'error',
  // 无多重空格
  'style/no-multi-spaces': 'error',
  // 块前的空格
  'style/padded-blocks': ['error', 'never'],
  // 块前的空格
  'style/space-before-blocks': 'error',
  // 函数括号前的空格
  'style/space-before-function-paren': 'error',
  // 括号内无空格
  'style/space-in-parens': 'error',
  // 切换冒号间距
  'style/switch-colon-spacing': 'error',
  // 间隔评论
  'style/spaced-comment': ['error', 'always', { exceptions: ['#'] }],
  // 隐式箭头换行符
  'style/implicit-arrow-linebreak': 'off',
  // 块间​​距
  'style/block-spacing': 'error',
  // 数组括号间距
  'style/array-bracket-spacing': 'error',
  // 箭头函数只有一个参数时，可以省略括号
  'style/arrow-parens': ['error', 'as-needed'],
  // 对象文字属性名称周围加上引号
  'style/quote-props': 'off',
  // 尾随分号
  'style/semi': 'off',
  // 尾随逗号
  'style/comma-dangle': 'off',
  // 为块强制执行一致的大括号样式
  'style/brace-style': ['error', '1tbs'],
  // 成员分隔符
  'style/member-delimiter-style': 'off',
  // 每行需要一个 JSX 元素
  'style/jsx-one-expression-per-line': 'off',
  // 运算符换行符
  'style/operator-linebreak': 'off',
  // 缩进
  'style/indent': 'off',
  // 多行三元换行符
  'style/multiline-ternary': 'off',
  // 在 JSX 属性和表达式中的大括号中强制执行一致的换行符
  'style/jsx-curly-newline': 'off',
  // 二元运算符的缩进
  'style/indent-binary-ops': 'off'
};

// Extra
const extra = {
  'node/prefer-global/process': 'off',
  'unused-imports/no-unused-vars': 'off',
  'antfu/if-newline': 'off',
  'antfu/top-level-function': 'off',
  'unicorn/prefer-number-properties': 'off',
  'n/prefer-global/process': 'off',
  'unicorn/escape-case': 'off',
  'jsdoc/valid-types': 'off',
  'antfu/consistent-list-newline': 'off'
};

// 重写
const overrides = [
  {
    files: ['src/**/*', 'public/**/*'],
    rules: {
      'standard-recommended/folder-name-convention': 'error',
      'standard-recommended/file-name-convention': 'error'
    }
  },
  {
    files: ['src/views/**/*'],
    rules: {
      'standard-recommended/no-index': 'error'
    }
  },
  {
    files: ['src/plugins/core/vue-i18n.ts', 'src/App.vue', 'src/AppProvider.vue', 'src/**/*.md', 'public/**/*.md'],
    rules: {
      'standard-recommended/file-name-convention': 'off'
    }
  },
  {
    files: ['src/service/apis/**/*'],
    rules: {
      'prefer-template': 'off',
      'standard-recommended/api-name-convention': 'error'
    }
  },
  {
    files: ['src/components/base-ui/**/*'],
    rules: {
      'vue/no-restricted-html-elements': 'off',
      'ts/no-empty-interface': 'off'
    }
  },
  {
    files: ['src/components/**/*'],
    rules: {
      'no-inline-comments': 'off'
    }
  },
  {
    files: [
      'src/service/type.ts',
      'src/components/**/*',
      'src/types/**/*',
      'src/utils/*',
      'src/hooks/**/*',
      'src/socket/**/*'
    ],
    rules: {
      'ts/no-explicit-any': 'off',
      'ts/ban-ts-comment': 'off',
      'ts/no-namespace': 'off'
    }
  },
  {
    files: ['env.d.ts', 'components.d.ts', 'auto-imports.d.ts', 'index.html'],
    rules: {
      'multiline-comment-style': 'off',
      'ts/ban-ts-comment': 'off',
      'spaced-comment': 'off',
      'style/spaced-comment': 'off',
      'format/prettier': 'off'
    }
  }
];

export default antfu(
  {
    rules: {
      ...js,
      ...ts,
      ...vue,
      ...stylistic,
      ...extra
    },
    formatters: {
      css: true,
      html: true,
      markdown: 'prettier',
      prettierOptions: prettier
    }
  },
  ...overrides,
  ...compat.config({
    extends: ['./.eslintrc-auto-import.json'],
    plugins: ['standard-recommended']
  })
);
